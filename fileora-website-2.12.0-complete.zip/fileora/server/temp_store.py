"""
Temporary processing storage and the automatic cleanup of the Fileora service.

Each task gets its own folder, named with a random 32-character task id, inside
one dedicated directory (FILEORA_WORKDIR, by default /var/lib/fileora/jobs):

    <FILEORA_WORKDIR>/.fileora-temp-root   marks the directory as Fileora's temp root
    <FILEORA_WORKDIR>/<task id>/status.json  task record: status, tool, created, size…
    <FILEORA_WORKDIR>/<task id>/in, out      uploads and work files (removed when the task ends)
    <FILEORA_WORKDIR>/<task id>/result       the result, until it's downloaded or expires

Settings, run state and history live next to it in FILEORA_STATEDIR (default:
the parent of FILEORA_WORKDIR, i.e. /var/lib/fileora), so they survive restarts.

Safety rules. Nothing outside these rules is ever deleted:

1. One directory only: the configured temp root, and only after it's verified
   (absolute, a real directory and not a symlink, no symlink in its path, not a
   system, home or web directory, no application files in it, owned by the
   service user, and carrying the .fileora-temp-root marker). If it can't be
   verified, cleanup stops and deletes nothing.
2. Allowlist: only entries whose name is a task id (32 lowercase hex) or a
   leftover ".trash-<task id>" are eligible. Everything else is left alone.
3. Never active work: a task is skipped while its status is queued/running or
   while this process is using it (upload, processing, download).
4. Age-based expiry: a task is expired when now - created >= expiry, where
   created comes from status.json (or the folder's time when that's missing).
5. No path tricks: an eligible entry must be a real directory directly inside
   the verified root, on the same filesystem; symlinks are never followed.
6. Race-safe removal: the folder is first renamed to .trash-<id> under the same
   lock that marks tasks active, so a task can't be picked up while it's being
   deleted. The renamed folder is then removed with Python's symlink-attack-
   resistant recursive delete, limited to that one folder. Failures are kept
   and retried on the next run.

Manual deletion from the dashboard goes through the same checks.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import stat
import sys
import threading
import time
import uuid
from collections import deque
from pathlib import Path

MARKER = ".fileora-temp-root"
MARKER_TEXT = "Fileora temporary processing directory. Cleanup removes expired task folders only.\n"
TASK_ID = re.compile(r"\A[0-9a-f]{32}\Z")   # \Z, not $: "$" would also accept a trailing newline
TRASH = re.compile(r"\A\.trash-([0-9a-f]{32})(?:-[0-9a-f]{8})?\Z")
ACTIVE_STATES = ("queued", "running")

# Never a temp root, whatever the configuration says.
FORBIDDEN_ROOTS = {
    "/", "/bin", "/boot", "/dev", "/etc", "/home", "/lib", "/lib32", "/lib64", "/media", "/mnt", "/opt",
    "/proc", "/root", "/run", "/sbin", "/snap", "/srv", "/sys", "/tmp", "/usr", "/var", "/var/backups",
    "/var/cache", "/var/lib", "/var/lib/mysql", "/var/lib/postgresql", "/var/log", "/var/mail", "/var/opt",
    "/var/spool", "/var/tmp", "/var/www", "/var/www/html", "/opt/fileora", "/opt/fileora/app", "/etc/fileora",
    "/var/lib/fileora",
}
# A directory holding any of these is an application or site directory, not a temp root.
APP_MARKERS = ("wp-config.php", "wp-content", "wp-includes", "wp-admin", "index.php", ".git", "app.py",
               "fileora.env", "cleanup-settings.json", "uploads", "public_html")

LIMITS = {"ttl_min": (15, 1440), "interval_min": (1, 60)}
HISTORY_KEEP = 300
FAILURE_KEEP = 200


def _now() -> float:
    return time.time()


def _audit(event: str, **data):
    """One JSON line per administrative action, in the service log (journalctl -u fileora)."""
    print("fileora-audit " + json.dumps({"event": event, "at": int(_now()), **data}, sort_keys=True), file=sys.stderr, flush=True)


def _atomic_write(path: Path, data: dict):
    tmp = path.with_name(f".{path.name}.{uuid.uuid4().hex[:8]}.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o640)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, sort_keys=True)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _read_json(path: Path, default):
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    except OSError:
        return default
    try:
        with os.fdopen(fd, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return default
    return data if isinstance(data, type(default)) else default


def _error_text(exc: BaseException) -> str:
    """A short error without any filesystem path."""
    if isinstance(exc, OSError) and exc.strerror:
        return exc.strerror
    return exc.__class__.__name__


def tree_size(path: str) -> tuple[int, int]:
    """Bytes and file count under path. Symlinks are counted as links, never followed."""
    total, count = 0, 0
    for dirpath, dirnames, filenames in os.walk(path, followlinks=False):
        for name in filenames + [d for d in dirnames if os.path.islink(os.path.join(dirpath, d))]:
            try:
                st = os.lstat(os.path.join(dirpath, name))
            except OSError:
                continue
            count += 1
            if stat.S_ISREG(st.st_mode):
                total += st.st_size
    return total, count


def remove_tree(path: str) -> list[str]:
    """Removes one already-validated folder. Returns the errors (empty = removed)."""
    if not getattr(shutil.rmtree, "avoids_symlink_attacks", False):
        return ["This system has no symlink-safe recursive delete; nothing was removed."]
    errors: list[str] = []

    def onexc(_func, failed, exc):
        rel = os.path.relpath(failed, path) if failed != path else "."
        errors.append(f"{rel}: {_error_text(exc)}")

    if sys.version_info >= (3, 12):
        shutil.rmtree(path, onexc=onexc)
    else:  # pragma: no cover - Python 3.11 and older
        shutil.rmtree(path, onerror=lambda func, failed, info: onexc(func, failed, info[1]))
    if os.path.lexists(path) and not errors:
        errors.append("The folder is still there.")
    return errors[:5]


class Settings:
    """Cleanup settings, validated and stored as JSON so they survive restarts."""

    def __init__(self, path: Path, default_ttl_min: int):
        self.path = path
        lo, hi = LIMITS["ttl_min"]
        self.defaults = {"enabled": True, "ttl_min": max(lo, min(hi, int(default_ttl_min))), "interval_min": 5}
        self._lock = threading.Lock()

    def get(self) -> dict:
        stored = _read_json(self.path, {})
        out = dict(self.defaults)
        for key, value in stored.items():
            if key in ("updated", "updated_by"):
                out[key] = value
            elif key in self.defaults and not self.validate({key: value}):
                out[key] = value
        return out

    @staticmethod
    def validate(changes: dict) -> list[str]:
        errors = []
        if not isinstance(changes, dict):
            return ["Send a JSON object."]
        for key, value in changes.items():
            if key == "enabled":
                if not isinstance(value, bool):
                    errors.append("enabled must be true or false.")
            elif key in LIMITS:
                lo, hi = LIMITS[key]
                if isinstance(value, bool) or not isinstance(value, int) or not lo <= value <= hi:
                    errors.append(f"{key} must be a whole number from {lo} to {hi}.")
            else:
                errors.append(f"Unknown setting: {key}.")
        return errors

    def update(self, changes: dict, actor: str) -> tuple[dict, list[str]]:
        errors = self.validate(changes)
        if errors:
            return self.get(), errors
        with self._lock:
            current = self.get()
            new = {k: current[k] for k in self.defaults}
            new.update(changes)
            new["updated"] = int(_now())
            new["updated_by"] = actor[:120]
            _atomic_write(self.path, new)
        return self.get(), []


class TempStore:
    """The temp root, its task folders and the cleanup job."""

    def __init__(self, root, state_dir=None, default_ttl_min=60, clock=_now):
        self.root = Path(root)
        self.state_dir = Path(state_dir) if state_dir else self.root.parent
        self.settings = Settings(self.state_dir / "cleanup-settings.json", default_ttl_min)
        self.state_path = self.state_dir / "cleanup-state.json"
        self.history_path = self.state_dir / "cleanup-history.jsonl"
        self.clock = clock
        self._active: dict[str, int] = {}
        self._active_lock = threading.Lock()   # guards _active and every rename to .trash-
        self._run_lock = threading.Lock()      # one cleanup run (or manual delete) at a time
        self._state_lock = threading.Lock()
        self._root_id = None
        self._wake = threading.Event()
        self._stop = threading.Event()
        self.next_run = None
        self.running_since = None
        self.thread = None

    # ------------------------------------------------------------ the root
    def _rule_problem(self) -> str:
        """Checks every rule except the marker. Returns '' when the root is acceptable."""
        p = self.root
        if not p.is_absolute():
            return "FILEORA_WORKDIR must be an absolute path."
        try:
            st = os.lstat(p)
        except FileNotFoundError:
            return "The temporary directory doesn't exist."
        except OSError as exc:
            return f"The temporary directory can't be read ({_error_text(exc)})."
        if stat.S_ISLNK(st.st_mode):
            return "The temporary directory is a symbolic link."
        if not stat.S_ISDIR(st.st_mode):
            return "The temporary directory isn't a directory."
        norm = os.path.normpath(str(p))
        if os.path.realpath(norm) != norm:
            return "The path of the temporary directory goes through a symbolic link."
        if norm in FORBIDDEN_ROOTS or len(Path(norm).parts) < 3:
            return "The temporary directory is a system directory."
        home = os.path.realpath(os.path.expanduser("~"))
        if norm == home or home.startswith(norm + os.sep):
            return "The temporary directory is a home directory or contains one."
        if self.state_dir.resolve() == Path(norm):
            return "The temporary directory and the state directory must be different."
        if hasattr(os, "geteuid") and st.st_uid != os.geteuid():
            return "The temporary directory is owned by another user."
        for name in APP_MARKERS:
            if os.path.lexists(os.path.join(norm, name)):
                return "The temporary directory contains application files."
        return ""

    def verify(self) -> tuple[bool, str]:
        problem = self._rule_problem()
        if problem:
            self._root_id = None
            return False, problem
        marker = _read_marker(self.root / MARKER)
        if marker != MARKER_TEXT:
            self._root_id = None
            return False, f"The marker file {MARKER} is missing, so the folder can't be confirmed as Fileora's temp directory."
        st = os.lstat(self.root)
        self._root_id = (st.st_dev, st.st_ino)
        return True, ""

    def prepare(self) -> tuple[bool, str]:
        """At start-up: creates the temp root if needed and marks it, then verifies it.

        An existing folder without the marker is adopted only when it holds
        nothing but task folders (upgrade from 2.3). Otherwise it stays
        unverified and cleanup deletes nothing until an admin checks it.
        """
        created = False
        try:
            self.state_dir.mkdir(parents=True, exist_ok=True, mode=0o750)
            if not os.path.lexists(self.root):
                os.makedirs(self.root, mode=0o750)
                created = True
        except OSError as exc:
            return False, f"The temporary directory can't be created ({_error_text(exc)})."
        if not os.path.lexists(self.root / MARKER) and not self._rule_problem():
            try:
                entries = list(os.scandir(self.root))
            except OSError:
                entries = None
            only_tasks = entries is not None and all(
                (TASK_ID.match(e.name) or TRASH.match(e.name)) and e.is_dir(follow_symlinks=False) for e in entries)
            if created or only_tasks:
                try:
                    fd = os.open(self.root / MARKER, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o640)
                    with os.fdopen(fd, "w", encoding="utf-8") as fh:
                        fh.write(MARKER_TEXT)
                except OSError:
                    pass
        ok, reason = self.verify()
        if not ok:
            print(f"fileora: automatic cleanup is paused: {reason}", file=sys.stderr, flush=True)
        return ok, reason

    # ------------------------------------------------------------ active tasks
    def activate(self, task_id: str) -> bool:
        """Marks a task as in use by this process (upload, processing, download)."""
        if not TASK_ID.match(task_id or ""):
            return False
        with self._active_lock:
            self._active[task_id] = self._active.get(task_id, 0) + 1
        return True

    def open_result(self, task_id: str, name: str):
        """Opens a task's result for download. An open file keeps working even if cleanup removes
        the folder a moment later, so downloads never need to block cleanup."""
        if not TASK_ID.match(task_id or "") or not name or "/" in name or name in (".", ".."):
            return None
        folder = self.root / task_id
        try:
            if stat.S_ISLNK(os.lstat(folder).st_mode) or stat.S_ISLNK(os.lstat(folder / "result").st_mode):
                return None
            fd = os.open(folder / "result" / name, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        except OSError:
            return None
        fh = os.fdopen(fd, "rb")
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            fh.close()
            return None
        return fh

    def release(self, task_id: str):
        with self._active_lock:
            n = self._active.get(task_id, 0) - 1
            if n > 0:
                self._active[task_id] = n
            else:
                self._active.pop(task_id, None)

    def is_active(self, task_id: str) -> bool:
        with self._active_lock:
            return task_id in self._active

    # ------------------------------------------------------------ reading tasks
    def _status(self, folder: Path) -> dict:
        return _read_json(folder / "status.json", {})

    def _created(self, status: dict, st) -> float:
        created = status.get("created")
        now = self.clock()
        if isinstance(created, (int, float)) and not isinstance(created, bool) and 0 < created <= now + 300:
            return float(created)
        return float(st.st_mtime)

    def task_dirs(self):
        """Valid task folders (name, path, lstat) directly inside the verified root."""
        try:
            entries = list(os.scandir(self.root))
        except OSError:
            return
        for entry in entries:
            if TASK_ID.match(entry.name) and entry.is_dir(follow_symlinks=False):
                yield entry.name, Path(entry.path), entry.stat(follow_symlinks=False)

    def describe(self, task_id: str, folder: Path, st, settings: dict, failures: dict, now: float) -> dict:
        status = self._status(folder)
        created = self._created(status, st)
        ttl = settings["ttl_min"] * 60
        size, files = tree_size(str(folder))
        state = status.get("status") or "unknown"
        active = state in ACTIVE_STATES or self.is_active(task_id)
        expires = created + ttl
        if active:
            cleanup = "active"
        elif task_id in failures:
            cleanup = "failed"
        elif now < expires:
            cleanup = "scheduled"
        elif settings["enabled"]:
            cleanup = "due"
        else:
            cleanup = "kept"
        name = status.get("name") or ""
        failure = failures.get(task_id) or {}
        return {
            "id": task_id,
            "tool": status.get("tool") or "",
            "status": state,
            "result": (Path(name).suffix.lstrip(".").lower()[:8] if name else ""),
            "kind": status.get("kind") or "",
            "created": round(created, 3),
            "started": status.get("started"),
            "finished": status.get("finished"),
            "expires": round(expires, 3),
            "remaining": max(0, int(expires - now)),
            "age": max(0, int(now - created)),
            "size": size,
            "files": files,
            "inputs": status.get("files"),
            "error": (status.get("error") or "")[:300],
            "cleanup": cleanup,
            "in_use": self.is_active(task_id),
            "cleanup_error": failure.get("error", ""),
            "cleanup_attempts": failure.get("attempts", 0),
        }

    def scan(self) -> dict:
        """Every task folder with its cleanup status, and storage totals."""
        settings = self.settings.get()
        ok, reason = self.verify()
        state = self.read_state()
        failures = state.get("failures", {})
        now = self.clock()
        tasks, ignored, trash = [], 0, 0
        try:
            entries = list(os.scandir(self.root)) if ok else []
        except OSError:
            entries = []
        for entry in entries:
            if entry.name == MARKER:
                continue
            if TRASH.match(entry.name) and entry.is_dir(follow_symlinks=False):
                trash += 1
                continue
            if TASK_ID.match(entry.name) and entry.is_dir(follow_symlinks=False):
                tasks.append(self.describe(entry.name, Path(entry.path), entry.stat(follow_symlinks=False), settings, failures, now))
            else:
                ignored += 1
        tasks.sort(key=lambda t: t["created"], reverse=True)
        expired = [t for t in tasks if t["cleanup"] in ("due", "kept", "failed")]
        summary = {
            "verified": ok,
            "reason": reason,
            "tasks": len(tasks),
            "bytes": sum(t["size"] for t in tasks),
            "active": sum(1 for t in tasks if t["cleanup"] == "active"),
            "expired": len(expired),
            "expired_bytes": sum(t["size"] for t in expired),
            "failed": sum(1 for t in tasks if t["cleanup"] == "failed"),
            "trash": trash,
            "ignored": ignored,
        }
        try:
            du = shutil.disk_usage(self.root)
            summary["disk_free"], summary["disk_total"] = du.free, du.total
        except OSError:
            summary["disk_free"] = summary["disk_total"] = None
        return {"tasks": tasks, "summary": summary, "settings": settings}

    def task(self, task_id: str):
        if not TASK_ID.match(task_id or ""):
            return None
        ok, _ = self.verify()
        if not ok:
            return None
        folder = self.root / task_id
        try:
            st = os.lstat(folder)
        except OSError:
            return None
        if not stat.S_ISDIR(st.st_mode):
            return None
        return self.describe(task_id, folder, st, self.settings.get(), self.read_state().get("failures", {}), self.clock())

    # ------------------------------------------------------------ state + history
    def read_state(self) -> dict:
        return _read_json(self.state_path, {})

    def _update_state(self, fn):
        with self._state_lock:
            state = self.read_state()
            fn(state)
            fails = state.get("failures", {})
            if len(fails) > FAILURE_KEEP:
                state["failures"] = dict(sorted(fails.items(), key=lambda kv: kv[1].get("last", 0))[-FAILURE_KEEP:])
            _atomic_write(self.state_path, state)
            return state

    def _add_history(self, entry: dict):
        with self._state_lock:
            lines = []
            try:
                with open(self.history_path, "r", encoding="utf-8") as fh:
                    lines = [l for l in fh.read().splitlines() if l.strip()]
            except OSError:
                pass
            lines.append(json.dumps(entry, sort_keys=True))
            lines = lines[-HISTORY_KEEP:]
            tmp = self.history_path.with_name(f".{self.history_path.name}.{uuid.uuid4().hex[:8]}.tmp")
            with open(tmp, "w", encoding="utf-8") as fh:
                fh.write("\n".join(lines) + "\n")
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, self.history_path)

    def history(self, limit=100) -> list:
        try:
            with open(self.history_path, "r", encoding="utf-8") as fh:
                lines = fh.read().splitlines()
        except OSError:
            return []
        out = []
        for line in reversed(lines):
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
            if len(out) >= limit:
                break
        return out

    def removed(self, limit=HISTORY_KEEP) -> dict:
        """Task id -> {at, by} for task folders removed by cleanup or an admin (newest history first)."""
        out = {}
        for entry in self.history(limit):
            for task_id in entry.get("removed_ids", []):
                out.setdefault(task_id, {"at": entry.get("finished") or entry.get("started"), "by": entry.get("trigger")})
        return out

    # ------------------------------------------------------------ deleting
    def _detach(self, task_id: str, *, require_expired: bool, settings: dict):
        """Validates one task folder and renames it to .trash-<id>. Returns (trash path, error code, message)."""
        folder = self.root / task_id
        with self._active_lock:
            if task_id in self._active:
                return None, "active", "The task is in use right now."
            try:
                st = os.lstat(folder)
            except FileNotFoundError:
                return None, "not_found", "The task folder is already gone."
            except OSError as exc:
                return None, "error", _error_text(exc)
            if stat.S_ISLNK(st.st_mode) or not stat.S_ISDIR(st.st_mode):
                return None, "not_a_folder", "Not a task folder; left alone."
            root_st = os.lstat(self.root)
            if self._root_id != (root_st.st_dev, root_st.st_ino) or st.st_dev != root_st.st_dev:
                return None, "unverified", "The temporary directory changed; nothing was deleted."
            if os.path.realpath(folder) != os.path.join(os.path.realpath(self.root), task_id):
                return None, "outside", "The path leaves the temporary directory; nothing was deleted."
            status = self._status(folder)
            if status.get("status") in ACTIVE_STATES:
                return None, "active", "The task is still waiting or running."
            if require_expired and self.clock() - self._created(status, st) < settings["ttl_min"] * 60:
                return None, "not_expired", "The task hasn't expired yet."
            trash = self.root / f".trash-{task_id}"
            if os.path.lexists(trash):
                trash = self.root / f".trash-{task_id}-{uuid.uuid4().hex[:8]}"
            try:
                os.rename(folder, trash)
            except FileNotFoundError:
                return None, "not_found", "The task folder is already gone."
            except OSError as exc:
                return None, "error", _error_text(exc)
        return trash, "", ""

    def _purge_trash(self, trash: Path) -> tuple[int, list[str]]:
        try:
            st = os.lstat(trash)
        except FileNotFoundError:
            return 0, []
        if stat.S_ISLNK(st.st_mode) or not stat.S_ISDIR(st.st_mode) or trash.parent != self.root:
            return 0, ["Not a task folder; left alone."]
        size, _ = tree_size(str(trash))
        errors = remove_tree(str(trash))
        return (0 if errors else size), errors

    def _note_failure(self, state: dict, task_id: str, error: str):
        fails = state.setdefault("failures", {})
        item = fails.get(task_id, {"attempts": 0, "first": int(self.clock())})
        item.update({"attempts": item["attempts"] + 1, "last": int(self.clock()), "error": error[:300]})
        fails[task_id] = item

    def delete(self, task_id: str, *, trigger: str, actor: str = "", require_expired: bool = False) -> dict:
        """Deletes one task folder (manual delete, retry, or WordPress after a download)."""
        if not TASK_ID.match(task_id or ""):
            return {"ok": False, "code": "invalid_id", "error": "Not a task id."}
        if not self._run_lock.acquire(timeout=30):
            return {"ok": False, "code": "busy", "error": "A cleanup run is in progress. Try again in a minute."}
        try:
            ok, reason = self.verify()
            if not ok:
                return {"ok": False, "code": "unverified", "error": reason}
            settings = self.settings.get()
            trash, code, message = self._detach(task_id, require_expired=require_expired, settings=settings)
            leftovers = []
            if trash is None and code == "not_found":
                leftovers = self._trash_for(task_id)
                if not leftovers:
                    self._update_state(lambda s: s.get("failures", {}).pop(task_id, None))
                    return {"ok": True, "deleted": False, "code": code, "error": message, "freed": 0}
            elif trash is None:
                return {"ok": False, "code": code, "error": message}
            freed, errors = 0, []
            for path in ([trash] if trash else leftovers):
                f, e = self._purge_trash(path)
                freed += f
                errors += e
            ok_now = not errors

            def apply(state):
                if ok_now:
                    state.get("failures", {}).pop(task_id, None)
                    key = "download_deleted" if trigger == "download" else "manual_deleted"
                    state[key] = state.get(key, 0) + 1
                    state["freed_total"] = state.get("freed_total", 0) + freed
                else:
                    self._note_failure(state, task_id, "; ".join(errors))
                    state["failed_total"] = state.get("failed_total", 0) + 1

            self._update_state(apply)
            if trigger != "download":
                now = self.clock()
                self._add_history({
                    "started": now, "finished": now, "trigger": trigger, "actor": actor[:120], "mode": "delete",
                    "deleted": 1 if ok_now else 0, "failed": 0 if ok_now else 1, "freed": freed,
                    "removed_ids": [task_id] if ok_now else [],
                    "errors": [] if ok_now else [{"task": task_id, "error": "; ".join(errors)[:300]}],
                })
                _audit("temp.delete", trigger=trigger, actor=actor[:120], task=task_id, ok=ok_now, freed=freed)
            if ok_now:
                return {"ok": True, "deleted": True, "freed": freed}
            return {"ok": False, "code": "delete_failed", "error": "; ".join(errors), "retry": True}
        finally:
            self._run_lock.release()

    def discard(self, task_id: str):
        """Removes the folder of a task that failed while it was being created (owned by this request)."""
        if not TASK_ID.match(task_id or ""):
            return
        folder = self.root / task_id
        try:
            st = os.lstat(folder)
        except OSError:
            return
        if stat.S_ISDIR(st.st_mode) and not stat.S_ISLNK(st.st_mode) and folder.parent == self.root:
            remove_tree(str(folder))

    def _trash_for(self, task_id: str) -> list[Path]:
        try:
            return [Path(e.path) for e in os.scandir(self.root)
                    if (m := TRASH.match(e.name)) and m.group(1) == task_id and e.is_dir(follow_symlinks=False)]
        except OSError:
            return []

    def run(self, trigger: str = "schedule", actor: str = "") -> dict:
        """One cleanup pass: deletes expired, inactive task folders. Never blocks on a running pass."""
        if not self._run_lock.acquire(blocking=False):
            return {"ok": False, "code": "busy", "error": "A cleanup run is already in progress."}
        self.running_since = self.clock()
        started = self.clock()
        result = {"started": started, "trigger": trigger, "actor": actor[:120], "mode": "delete", "deleted": 0,
                  "failed": 0, "freed": 0, "skipped_active": 0, "waiting": 0, "ignored": 0, "removed_ids": [], "errors": []}
        try:
            settings = self.settings.get()
            ok, reason = self.verify()
            if not ok:
                result.update({"mode": "blocked", "reason": reason})
                return result
            ttl = settings["ttl_min"] * 60
            now = self.clock()
            entries = list(os.scandir(self.root))
            for entry in entries:
                name = entry.name
                if name == MARKER:
                    continue
                trash_match = TRASH.match(name)
                if trash_match and entry.is_dir(follow_symlinks=False):
                    freed, errors = self._purge_trash(Path(entry.path))
                    self._count(result, trash_match.group(1), freed, errors)
                    continue
                if not (TASK_ID.match(name) and entry.is_dir(follow_symlinks=False)):
                    result["ignored"] += 1
                    continue
                st = entry.stat(follow_symlinks=False)
                status = self._status(Path(entry.path))
                if status.get("status") in ACTIVE_STATES or self.is_active(name):
                    result["skipped_active"] += 1
                    continue
                if now - self._created(status, st) < ttl:
                    result["waiting"] += 1
                    continue
                trash, code, message = self._detach(name, require_expired=True, settings=settings)
                if trash is None:
                    if code == "active":
                        result["skipped_active"] += 1
                    elif code == "not_expired":
                        result["waiting"] += 1
                    elif code != "not_found":
                        self._count(result, name, 0, [message])
                    continue
                freed, errors = self._purge_trash(trash)
                self._count(result, name, freed, errors)
            return result
        except OSError as exc:
            result.update({"mode": "error", "reason": _error_text(exc)})
            return result
        finally:
            result["finished"] = self.clock()
            result["duration_ms"] = int((result["finished"] - started) * 1000)
            result["removed_ids"] = result["removed_ids"][:500]
            result["errors"] = result["errors"][:20]
            self._finish_run(result)
            self.running_since = None
            self._run_lock.release()

    def _count(self, result, task_id, freed, errors):
        if errors:
            result["failed"] += 1
            result["errors"].append({"task": task_id, "error": "; ".join(errors)[:300]})
        else:
            result["deleted"] += 1
            result["freed"] += freed
            result["removed_ids"].append(task_id)

    def _finish_run(self, result):
        repeat = {"value": False}

        def apply(state):
            summary = {k: result.get(k) for k in ("started", "finished", "trigger", "mode", "deleted", "failed",
                                                   "freed", "skipped_active", "waiting", "ignored", "duration_ms", "reason")}
            prev = state.get("last_run") or {}
            repeat["value"] = prev.get("mode") == summary["mode"] and prev.get("reason") == summary["reason"]
            state["last_run"] = summary
            state["runs"] = state.get("runs", 0) + 1
            if result["mode"] == "delete" and not result["failed"]:
                state["last_success"] = result["finished"]
                state["success_runs"] = state.get("success_runs", 0) + 1
            else:
                state["failed_runs"] = state.get("failed_runs", 0) + 1
            state["deleted_total"] = state.get("deleted_total", 0) + result["deleted"]
            state["failed_total"] = state.get("failed_total", 0) + result["failed"]
            state["freed_total"] = state.get("freed_total", 0) + result["freed"]
            fails = state.setdefault("failures", {})
            for task_id in result["removed_ids"]:
                fails.pop(task_id, None)
            for err in result["errors"]:
                self._note_failure(state, err["task"], err["error"])

        try:
            self._update_state(apply)
            # Scheduled runs that found nothing, or hit the same block again, are counted, not added to the history.
            scheduled = result["trigger"] == "schedule"
            quiet = result["mode"] == "delete" and not result["deleted"] and not result["failed"]
            if not scheduled or not (quiet or (result["mode"] != "delete" and repeat["value"])):
                self._add_history(result)
        except OSError as exc:
            print(f"fileora: can't save the cleanup state: {_error_text(exc)}", file=sys.stderr, flush=True)
        if result["failed"] or result["mode"] != "delete":
            print("fileora: cleanup " + json.dumps({k: result.get(k) for k in ("trigger", "mode", "deleted", "failed", "reason", "errors")}),
                  file=sys.stderr, flush=True)

    # ------------------------------------------------------------ settings + schedule
    def update_settings(self, changes: dict, actor: str) -> tuple[dict, list[str]]:
        before = self.settings.get()
        after, errors = self.settings.update(changes, actor)
        if not errors:
            diff = {k: [before.get(k), after.get(k)] for k in ("enabled", "ttl_min", "interval_min") if before.get(k) != after.get(k)}
            if diff:
                now = self.clock()
                self._add_history({"started": now, "finished": now, "trigger": "settings", "actor": actor[:120],
                                   "mode": "settings", "changes": diff, "deleted": 0, "failed": 0, "freed": 0, "removed_ids": []})
            if diff:
                _audit("cleanup.settings", actor=actor[:120], changes=diff)
            if "interval_min" in diff or "enabled" in diff:
                self.next_run = (self.clock() + after["interval_min"] * 60) if after["enabled"] else None
                self._wake.set()
        return after, errors

    def status(self) -> dict:
        settings = self.settings.get()
        ok, reason = self.verify()
        state = self.read_state()
        return {
            "settings": settings,
            "verified": ok,
            "reason": reason,
            "scheduler": ("running" if self.running_since else "stopped" if not settings["enabled"]
                          else "scheduled" if self.thread and self.thread.is_alive() else "not started"),
            "running_since": self.running_since,
            "next_run": self.next_run if settings["enabled"] else None,
            "last_run": state.get("last_run"),
            "last_success": state.get("last_success"),
            "counts": {k: state.get(k, 0) for k in ("runs", "success_runs", "failed_runs", "deleted_total", "failed_total",
                                                       "freed_total", "manual_deleted", "download_deleted")},
            "failures": [{"task": k, **v} for k, v in sorted(state.get("failures", {}).items(), key=lambda kv: -kv[1].get("last", 0))][:50],
        }

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        settings = self.settings.get()
        self.next_run = self.clock() + 60 if settings["enabled"] else None
        self.thread = threading.Thread(target=self._loop, name="fileora-cleanup", daemon=True)
        self.thread.start()

    def stop(self):
        self._stop.set()
        self._wake.set()

    def _loop(self):
        while not self._stop.is_set():
            settings = self.settings.get()
            if not settings["enabled"]:
                self.next_run = None
            elif self.next_run is None:
                self.next_run = self.clock() + settings["interval_min"] * 60
            elif self.clock() >= self.next_run:
                try:
                    self.run("schedule")
                except Exception as exc:  # never let the scheduler die
                    print(f"fileora: cleanup run failed: {exc!r}", file=sys.stderr, flush=True)
                self.next_run = self.clock() + settings["interval_min"] * 60
            self._wake.wait(timeout=5)
            self._wake.clear()


def _read_marker(path: Path) -> str:
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    except OSError:
        return ""
    try:
        with os.fdopen(fd, "r", encoding="utf-8") as fh:
            return fh.read(512)
    except (OSError, UnicodeDecodeError):
        return ""


class Metrics:
    """CPU, memory, disk, network and uptime of this server, read from /proc.

    A background sampler reads CPU and network counters every 10 seconds, so
    a request gets the recent average without waiting. Any value this system
    doesn't provide is None (shown as "Not Available" in WordPress).
    """

    def __init__(self, disk_path: Path):
        self.disk_path = disk_path
        self.samples = deque(maxlen=32)  # (time, cpu_total, cpu_idle, rx, tx)
        self.started = time.time()
        self.thread = None

    @staticmethod
    def _cpu():
        try:
            with open("/proc/stat", encoding="ascii") as fh:
                parts = fh.readline().split()
            values = [int(v) for v in parts[1:]]
            idle = values[3] + (values[4] if len(values) > 4 else 0)
            return sum(values[:8]), idle
        except (OSError, ValueError, IndexError):
            return None, None

    @staticmethod
    def _net():
        try:
            rx = tx = 0
            with open("/proc/net/dev", encoding="ascii") as fh:
                for line in fh.readlines()[2:]:
                    name, data = line.split(":", 1)
                    if name.strip() == "lo":
                        continue
                    fields = data.split()
                    rx += int(fields[0])
                    tx += int(fields[8])
            return rx, tx
        except (OSError, ValueError, IndexError):
            return None, None

    def sample(self):
        total, idle = self._cpu()
        rx, tx = self._net()
        self.samples.append((time.time(), total, idle, rx, tx))

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.sample()
        self.thread = threading.Thread(target=self._loop, name="fileora-metrics", daemon=True)
        self.thread.start()

    def _loop(self):
        while True:
            time.sleep(10)
            self.sample()

    def _rates(self, back: int):
        if len(self.samples) < 2:
            return None, None, None
        new = self.samples[-1]
        old = self.samples[max(0, len(self.samples) - 1 - back)]
        dt = new[0] - old[0]
        cpu = rx = tx = None
        if new[1] is not None and old[1] is not None and new[1] > old[1]:
            cpu = round(100.0 * (1 - (new[2] - old[2]) / (new[1] - old[1])), 1)
        if dt > 0 and new[3] is not None and old[3] is not None and new[3] >= old[3] and new[4] >= old[4]:
            rx, tx = int((new[3] - old[3]) / dt), int((new[4] - old[4]) / dt)
        return cpu, rx, tx

    @staticmethod
    def _meminfo():
        out = {}
        try:
            with open("/proc/meminfo", encoding="ascii") as fh:
                for line in fh:
                    key, value = line.split(":", 1)
                    out[key] = int(value.split()[0]) * 1024
        except (OSError, ValueError, IndexError):
            pass
        return out

    def read(self) -> dict:
        cpu_now, _, _ = self._rates(1)
        cpu_5m, rx_5m, tx_5m = self._rates(30)
        mem = self._meminfo()
        total, avail = mem.get("MemTotal"), mem.get("MemAvailable")
        try:
            du = shutil.disk_usage(self.disk_path)
            # Same percentage as "df -h": used / (used + space available to the service)
            disk = {"total": du.total, "used": du.used, "free": du.free,
                    "pct": round(100.0 * du.used / (du.used + du.free), 1) if du.used + du.free else None}
        except OSError:
            disk = {"total": None, "used": None, "free": None, "pct": None}
        try:
            with open("/proc/uptime", encoding="ascii") as fh:
                uptime = int(float(fh.read().split()[0]))
        except (OSError, ValueError, IndexError):
            uptime = None
        try:
            load = [round(v, 2) for v in os.getloadavg()]
        except (OSError, AttributeError):
            load = None
        last = self.samples[-1] if self.samples else (None, None, None, None, None)
        return {
            "time": time.time(),
            "cpu": {"pct": cpu_now, "pct_5m": cpu_5m, "cores": os.cpu_count(), "load": load},
            "memory": {"total": total, "available": avail, "used": (total - avail) if total and avail is not None else None,
                       "pct": round(100.0 * (total - avail) / total, 1) if total and avail is not None else None,
                       "swap_total": mem.get("SwapTotal"), "swap_free": mem.get("SwapFree")},
            "disk": disk,
            "network": {"rx_bytes": last[3], "tx_bytes": last[4], "rx_bps": rx_5m, "tx_bps": tx_5m},
            "uptime": uptime,
            "service_uptime": int(time.time() - self.started),
        }
