"""
HTTP tests for the monitoring and cleanup endpoints of app.py.

Needs FastAPI's test client (pip install httpx); skipped without it.

    cd server && python3 -m unittest discover -s tests -v
"""

import importlib.util
import json
import logging
import os
import shutil
import sys
import tempfile
import time
import unittest
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
TMP = Path(os.path.realpath(tempfile.mkdtemp(prefix="fileora-api-")))
os.environ.update({"FILEORA_KEY": "k" * 48, "FILEORA_WORKDIR": str(TMP / "state" / "jobs"), "FILEORA_TTL_MIN": "60"})
os.environ.pop("FILEORA_STATEDIR", None)
sys.path.insert(0, str(HERE))
logging.getLogger("httpx").setLevel(logging.WARNING)

try:
    from fastapi.testclient import TestClient
    import app as service
except ImportError as exc:  # pragma: no cover
    TestClient = None
    SKIP = f"needs fastapi and httpx ({exc})"
else:
    SKIP = ""

KEY = {"X-Fileora-Key": "k" * 48, "X-Fileora-Actor": "wp-user:1:admin"}
ROOT = TMP / "state" / "jobs"


def old_task(status="done", hours=3):
    task_id = uuid.uuid4().hex
    (ROOT / task_id / "result").mkdir(parents=True)
    (ROOT / task_id / "result" / "out.pdf").write_bytes(b"%PDF-1.4 test")
    (ROOT / task_id / "status.json").write_text(json.dumps({"status": status, "tool": "compress", "name": "out.pdf",
                                                           "kind": "file", "created": time.time() - hours * 3600}))
    return task_id


@unittest.skipIf(SKIP, SKIP)
class Api(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(service.app)
        cls.client.__enter__()   # runs the lifespan: recovery, cleanup scheduler, metrics sampler

    @classmethod
    def tearDownClass(cls):
        cls.client.__exit__(None, None, None)
        service.STORE.stop()
        shutil.rmtree(TMP, ignore_errors=True)

    def setUp(self):
        service.STORE.update_settings({"enabled": True, "ttl_min": 60, "interval_min": 5}, "test")

    def test_admin_endpoints_need_the_key(self):
        calls = [("get", "/metrics"), ("get", "/admin/cleanup"), ("put", "/admin/cleanup/settings"),
                 ("post", "/admin/cleanup/run"), ("get", "/admin/cleanup/history"), ("get", "/admin/temp"),
                 ("get", "/admin/temp/" + "0" * 32), ("delete", "/admin/temp/" + "0" * 32),
                 ("post", "/admin/temp/" + "0" * 32 + "/retry")]
        task = old_task()
        for method, path in calls:
            for headers in ({}, {"X-Fileora-Key": "wrong"}):
                r = getattr(self.client, method)(path, headers=headers)
                self.assertEqual(r.status_code, 401, (method, path, headers))
        self.assertTrue((ROOT / task).exists())

    def test_health_stays_public_and_compatible(self):
        body = self.client.get("/health").json()
        for key in ("ok", "key_set", "tools", "workers", "queue"):
            self.assertIn(key, body)
        self.assertNotIn("temp", body)
        self.assertNotIn("cpu", body)

    def test_metrics_shape_and_no_paths(self):
        body = self.client.get("/metrics", headers=KEY).json()
        for key in ("cpu", "memory", "disk", "network", "uptime", "temp", "version"):
            self.assertIn(key, body)
        self.assertNotIn(str(TMP), json.dumps(body))

    def test_list_run_and_history(self):
        due = old_task(hours=3)
        fresh = old_task(hours=0)
        listing = self.client.get("/admin/temp", headers=KEY).json()
        states = {t["id"]: t["cleanup"] for t in listing["tasks"]}
        self.assertEqual(states[due], "due")
        self.assertEqual(states[fresh], "scheduled")
        self.assertNotIn(str(TMP), json.dumps(listing))
        run = self.client.post("/admin/cleanup/run", headers=KEY).json()
        self.assertIn(due, run["removed_ids"])
        self.assertFalse((ROOT / due).exists())
        self.assertTrue((ROOT / fresh).exists())
        history = self.client.get("/admin/cleanup/history", headers=KEY).json()["history"]
        self.assertTrue(any(h["trigger"] == "manual" and due in h["removed_ids"] and h["actor"].startswith("wp-user:1:admin")
                            for h in history))
        self.assertIn(due, self.client.get("/admin/temp", headers=KEY).json()["removed"])

    def test_settings_are_validated_and_persisted(self):
        r = self.client.put("/admin/cleanup/settings", headers=KEY, json={"ttl_min": 1})
        self.assertEqual(r.status_code, 422)
        r = self.client.put("/admin/cleanup/settings", headers=KEY, content=b"not json")
        self.assertEqual(r.status_code, 422)
        r = self.client.put("/admin/cleanup/settings", headers=KEY, json={"enabled": False, "ttl_min": 120})
        self.assertEqual(r.status_code, 200)
        saved = json.loads((TMP / "state" / "cleanup-settings.json").read_text())
        self.assertEqual((saved["enabled"], saved["ttl_min"]), (False, 120))
        task = old_task(hours=5)
        listing = self.client.get("/admin/temp", headers=KEY).json()
        self.assertEqual({t["id"]: t["cleanup"] for t in listing["tasks"]}[task], "kept")
        self.assertGreater(listing["summary"]["expired_bytes"], 0)
        self.assertIsNone(self.client.get("/admin/cleanup", headers=KEY).json()["next_run"])

    def test_running_task_cannot_be_deleted(self):
        task = old_task(status="running", hours=10)
        r = self.client.delete(f"/admin/temp/{task}", headers=KEY)
        self.assertEqual(r.status_code, 409)
        r = self.client.delete(f"/jobs/{task}", headers=KEY)
        self.assertEqual(r.json()["deleted"], False)
        self.assertTrue((ROOT / task / "result" / "out.pdf").exists())
        (ROOT / task / "status.json").write_text(json.dumps({"status": "failed", "created": time.time() - 36000}))
        self.assertEqual(self.client.delete(f"/admin/temp/{task}", headers=KEY).status_code, 200)

    def test_bad_ids_are_refused(self):
        for bad in ["..%2F..%2Fetc", "0" * 31, "Z" * 32]:
            r = self.client.delete(f"/admin/temp/{bad}", headers=KEY)
            self.assertIn(r.status_code, (404, 405), bad)

    def test_download_then_delete(self):
        task = old_task(hours=0)
        r = self.client.get(f"/jobs/{task}/file", headers=KEY)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.content, b"%PDF-1.4 test")
        self.assertIn('filename="out.pdf"', r.headers["content-disposition"])
        self.assertEqual(self.client.delete(f"/jobs/{task}", headers=KEY).json()["deleted"], True)
        self.assertFalse((ROOT / task).exists())

    @unittest.skipUnless(shutil.which("qpdf") and importlib.util.find_spec("pikepdf"), "needs qpdf and pikepdf (the Repair tool)")
    def test_real_job_end_to_end(self):
        pdf = (b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj 2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj "
               b"3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 200 200]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n")
        r = self.client.post("/jobs/repair", headers=KEY, files={"files[0]": ("test.pdf", pdf, "application/pdf")})
        self.assertEqual(r.status_code, 202, r.text)
        job = r.json()["job"]
        for _ in range(600):   # up to 60 s on a busy machine
            st = self.client.get(f"/jobs/{job}", headers=KEY).json()
            if st["status"] in ("done", "failed"):
                break
            time.sleep(0.1)
        self.assertEqual(st["status"], "done", st)
        self.assertFalse(service.STORE.is_active(job))
        listed = {t["id"]: t for t in self.client.get("/admin/temp", headers=KEY).json()["tasks"]}
        self.assertEqual(listed[job]["cleanup"], "scheduled")
        self.assertEqual(listed[job]["result"], "pdf")
        self.assertTrue(self.client.get(f"/jobs/{job}/file", headers=KEY).content.startswith(b"%PDF"))
        self.client.delete(f"/jobs/{job}", headers=KEY)
        self.assertFalse((ROOT / job).exists())


if __name__ == "__main__":
    unittest.main()
