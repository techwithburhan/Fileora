"""
Tests for the temporary storage and cleanup (temp_store.py). Standard library only.

    cd server && python3 -m unittest discover -s tests -v

Every test builds a throw-away "server" in a temporary folder:

    <tmp>/srv/var-lib-fileora/jobs        the temp root (FILEORA_WORKDIR)
    <tmp>/srv/var-lib-fileora             the state directory
    <tmp>/srv/site/...                    permanent data: blog posts, uploads, a database file
"""

import hashlib
import json
import os
import sys
import tempfile
import threading
import time
import unittest
import uuid
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import temp_store  # noqa: E402
from temp_store import MARKER, MARKER_TEXT, TempStore  # noqa: E402

HOUR = 3600


def tid():
    return uuid.uuid4().hex


def digest(folder: Path) -> dict:
    """Path -> sha256 of every file under folder (to prove nothing changed)."""
    out = {}
    for dirpath, _dirs, files in os.walk(folder):
        for name in files:
            p = Path(dirpath) / name
            out[str(p.relative_to(folder))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return out


class Clock:
    def __init__(self):
        self.t = time.time()

    def __call__(self):
        return self.t


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(os.path.realpath(tempfile.mkdtemp(prefix="fileora-test-")))
        self.state = self.tmp / "srv" / "var-lib-fileora"
        self.root = self.state / "jobs"
        self.site = self.tmp / "srv" / "site"
        self.clock = Clock()
        # Permanent data next to the temp root, like on a real server.
        (self.site / "wp-content" / "uploads" / "2026" / "10").mkdir(parents=True)
        (self.site / "wp-content" / "uploads" / "2026" / "10" / "cover.jpg").write_bytes(os.urandom(2048))
        (self.site / "posts").mkdir()
        for i in range(3):
            (self.site / "posts" / f"post-{i}.html").write_text(f"<h1>Published post {i}</h1>", encoding="utf-8")
        (self.site / "mysql").mkdir()
        (self.site / "mysql" / "wp_posts.ibd").write_bytes(os.urandom(4096))
        self.before = digest(self.site)
        self.store = self.new_store()
        ok, reason = self.store.prepare()
        self.assertTrue(ok, reason)

    def tearDown(self):
        self.assertEqual(digest(self.site), self.before, "permanent data changed")
        for dirpath, dirs, files in os.walk(self.tmp, topdown=False):
            for n in files + dirs:
                p = os.path.join(dirpath, n)
                (os.unlink if os.path.islink(p) or not os.path.isdir(p) else os.rmdir)(p)
        os.rmdir(self.tmp)

    def new_store(self, ttl=60):
        return TempStore(self.root, self.state, ttl, clock=self.clock)

    def make_task(self, status="done", age=2 * HOUR, files=2, task_id=None, with_status=True):
        task_id = task_id or tid()
        folder = self.root / task_id
        (folder / "result").mkdir(parents=True)
        for i in range(files):
            (folder / "result" / f"out-{i}.pdf").write_bytes(os.urandom(1000))
        if with_status:
            (folder / "status.json").write_text(json.dumps({"status": status, "tool": "ocr", "created": self.clock() - age,
                                                            "name": "out-0.pdf", "kind": "file"}), encoding="utf-8")
        else:
            t = self.clock() - age
            os.utime(folder, (t, t))
        return task_id


class Expiry(Base):
    def test_expired_finished_task_is_deleted(self):
        old = self.make_task(age=61 * 60)
        result = self.store.run("schedule")
        self.assertEqual(result["deleted"], 1, result)
        self.assertFalse((self.root / old).exists())
        self.assertIn(old, result["removed_ids"])

    def test_task_younger_than_expiry_is_kept(self):
        young = self.make_task(age=59 * 60)
        result = self.store.run("schedule")
        self.assertEqual(result["deleted"], 0)
        self.assertEqual(result["waiting"], 1)
        self.assertTrue((self.root / young / "result" / "out-0.pdf").exists())

    def test_expiry_is_counted_from_creation_time_not_folder_time(self):
        # The folder was touched just now, but the task was created 2 hours ago.
        old = self.make_task(age=2 * HOUR)
        os.utime(self.root / old, None)
        self.assertEqual(self.store.run("schedule")["deleted"], 1)

    def test_missing_status_falls_back_to_folder_age(self):
        old = self.make_task(age=2 * HOUR, with_status=False)
        young = self.make_task(age=60, with_status=False)
        self.store.run("schedule")
        self.assertFalse((self.root / old).exists())
        self.assertTrue((self.root / young).exists())

    def test_creation_time_in_the_future_is_not_trusted(self):
        task = self.make_task(age=-10 * HOUR)  # created "in 10 hours": falls back to the folder time (now)
        self.assertEqual(self.store.run("schedule")["deleted"], 0)
        self.assertTrue((self.root / task).exists())

    def test_configured_expiry_is_used(self):
        task = self.make_task(age=20 * 60)
        self.store.update_settings({"ttl_min": 15}, "test")
        self.assertEqual(self.store.run("schedule")["deleted"], 1)
        self.assertFalse((self.root / task).exists())


class ActiveTasks(Base):
    def test_queued_and_running_tasks_are_never_deleted(self):
        queued = self.make_task(status="queued", age=30 * HOUR)
        running = self.make_task(status="running", age=30 * HOUR)
        result = self.store.run("schedule")
        self.assertEqual(result["skipped_active"], 2)
        self.assertTrue((self.root / queued).exists())
        self.assertTrue((self.root / running).exists())

    def test_task_in_use_by_the_process_is_protected(self):
        task = self.make_task(status="done", age=30 * HOUR)
        self.store.activate(task)
        self.assertEqual(self.store.run("schedule")["skipped_active"], 1)
        self.assertEqual(self.store.delete(task, trigger="admin-delete")["code"], "active")
        self.assertTrue((self.root / task).exists())
        self.store.release(task)
        self.assertEqual(self.store.run("schedule")["deleted"], 1)

    def test_upload_in_progress_without_status_is_protected(self):
        task = tid()
        self.store.activate(task)          # app.py does this before creating the folder
        (self.root / task / "in" / "0").mkdir(parents=True)
        t = self.clock() - 5 * HOUR
        os.utime(self.root / task, (t, t))
        self.store.run("schedule")
        self.assertTrue((self.root / task / "in" / "0").exists())

    def test_task_that_becomes_active_during_a_run_is_skipped(self):
        task = self.make_task(age=3 * HOUR)
        real_detach = self.store._detach

        def detach(task_id, **kw):
            self.store.activate(task_id)   # a download/upload started between the scan and the delete
            return real_detach(task_id, **kw)

        with mock.patch.object(self.store, "_detach", side_effect=detach):
            result = self.store.run("schedule")
        self.assertEqual(result["deleted"], 0)
        self.assertTrue((self.root / task).exists())

    def test_open_download_survives_cleanup(self):
        task = self.make_task(age=3 * HOUR)
        fh = self.store.open_result(task, "out-0.pdf")
        self.assertIsNotNone(fh)
        self.assertEqual(self.store.run("schedule")["deleted"], 1)
        self.assertEqual(len(fh.read()), 1000)   # the open file still reads completely
        fh.close()

    def test_concurrent_runs_do_not_overlap(self):
        for _ in range(5):
            self.make_task(age=3 * HOUR)
        results = []
        threads = [threading.Thread(target=lambda: results.append(self.store.run("manual"))) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(sum(r.get("deleted", 0) for r in results), 5)
        self.assertEqual(sum(r.get("failed", 0) for r in results), 0)


class PathSafety(Base):
    def test_only_task_ids_are_eligible(self):
        names = ["notes.txt", "ABCDEF0123456789ABCDEF0123456789", "0123456789abcdef0123456789abcde",
                 "0123456789abcdef0123456789abcdef0", "backup", ".hidden"]
        for n in names:
            p = self.root / n
            p.mkdir()
            (p / "keep.txt").write_text("keep")
            t = self.clock() - 30 * HOUR
            os.utime(p, (t, t))
        (self.root / "loose-file.pdf").write_bytes(b"x")
        result = self.store.run("schedule")
        self.assertEqual(result["deleted"], 0)
        self.assertEqual(result["ignored"], len(names) + 1)
        for n in names:
            self.assertTrue((self.root / n / "keep.txt").exists(), n)

    def test_symlink_named_like_a_task_is_not_followed(self):
        link = self.root / tid()
        os.symlink(self.site / "posts", link)
        result = self.store.run("schedule")
        self.assertEqual(result["deleted"], 0)
        self.assertTrue(os.path.islink(link))
        self.assertEqual(self.store.delete(link.name, trigger="admin-delete")["code"], "not_a_folder")

    def test_symlinks_inside_a_task_are_removed_as_links_only(self):
        task = self.make_task(age=3 * HOUR)
        os.symlink(self.site / "wp-content" / "uploads", self.root / task / "result" / "uploads-link")
        os.symlink(self.site / "posts" / "post-0.html", self.root / task / "post-link.html")
        os.symlink(self.site, self.root / task / "in")
        self.assertEqual(self.store.run("schedule")["deleted"], 1)
        self.assertFalse(os.path.lexists(self.root / task))
        # tearDown checks that every permanent file is still there, unchanged

    def test_invalid_ids_are_rejected(self):
        for bad in ["..", "../site", "/etc", "", "0" * 31, "0" * 32 + "/..", "G" * 32, "0" * 32 + "\n"]:
            r = self.store.delete(bad, trigger="admin-delete")
            self.assertFalse(r.get("deleted"), bad)
            self.assertEqual(r["code"], "invalid_id", bad)
        self.assertIsNone(self.store.task("../site"))
        self.assertIsNone(self.store.open_result(tid(), "../../site/posts/post-0.html"))

    def test_result_path_cannot_escape(self):
        task = self.make_task(age=60)
        os.symlink(self.site / "posts" / "post-0.html", self.root / task / "result" / "evil.pdf")
        self.assertIsNone(self.store.open_result(task, "evil.pdf"))
        self.assertIsNone(self.store.open_result(task, "../status.json"))

    def test_swapped_root_is_detected(self):
        task = self.make_task(age=3 * HOUR)
        self.store.verify()
        # Someone replaces the temp root with a symlink to the site between verification and deletion.
        os.rename(self.root, self.state / "jobs-real")
        os.symlink(self.site, self.root)
        r = self.store.delete(task, trigger="admin-delete")
        self.assertFalse(r.get("deleted"))
        self.assertEqual(r["code"], "unverified")
        os.unlink(self.root)
        os.rename(self.state / "jobs-real", self.root)


class RootVerification(Base):
    def check_refused(self, store):
        ok, reason = store.verify()
        self.assertFalse(ok)
        result = store.run("schedule")
        self.assertEqual(result["mode"], "blocked")
        self.assertEqual(result["deleted"], 0)
        return reason

    def test_missing_marker_blocks_everything(self):
        task = self.make_task(age=30 * HOUR)
        os.unlink(self.root / MARKER)
        self.assertIn("marker", self.check_refused(self.store))
        self.assertEqual(self.store.delete(task, trigger="admin-delete")["code"], "unverified")
        self.assertTrue((self.root / task).exists())

    def test_wrong_marker_content_blocks(self):
        (self.root / MARKER).write_text("something else")
        self.check_refused(self.store)

    def test_directory_with_foreign_files_is_not_adopted(self):
        other = self.tmp / "srv" / "other"
        (other / "photos").mkdir(parents=True)
        (other / "photos" / "a.jpg").write_bytes(b"jpg")
        store = TempStore(other, self.state, 60, clock=self.clock)
        ok, _ = store.prepare()
        self.assertFalse(ok)
        self.assertFalse((other / MARKER).exists())
        self.assertTrue((other / "photos" / "a.jpg").exists())

    def test_site_and_system_directories_are_refused(self):
        (self.site / "wp-config.php").write_text("<?php // config")
        self.before = digest(self.site)
        (self.site / MARKER).write_text(MARKER_TEXT)          # even with a marker
        self.check_refused(TempStore(self.site, self.state, 60, clock=self.clock))
        os.unlink(self.site / MARKER)
        for path in ["/", "/var", "/var/www", "/tmp", "/home", "/var/lib", "relative/jobs"]:
            ok, _ = TempStore(path, self.state, 60).verify()
            self.assertFalse(ok, path)

    def test_root_that_is_a_symlink_is_refused(self):
        link = self.tmp / "srv" / "jobs-link"
        os.symlink(self.root, link)
        self.assertIn("symbolic link", self.check_refused(TempStore(link, self.state, 60, clock=self.clock)))

    def test_root_reached_through_a_symlinked_parent_is_refused(self):
        link = self.tmp / "srv" / "lib-link"
        os.symlink(self.state, link)
        self.check_refused(TempStore(link / "jobs", self.tmp / "srv" / "state2", 60, clock=self.clock))

    def test_root_owned_by_another_user_is_refused(self):
        real = os.lstat(self.root)
        fake = os.stat_result((real.st_mode, real.st_ino, real.st_dev, real.st_nlink, real.st_uid + 1, real.st_gid,
                               real.st_size, int(real.st_atime), int(real.st_mtime), int(real.st_ctime)))
        orig = os.lstat
        with mock.patch("temp_store.os.lstat", side_effect=lambda p, *a, **k: fake if Path(p) == self.root else orig(p, *a, **k)):
            ok, reason = self.store.verify()
        self.assertFalse(ok)
        self.assertIn("another user", reason)

    def test_existing_task_folder_is_adopted_on_upgrade(self):
        other = self.tmp / "srv" / "old-jobs"
        (other / tid() / "result").mkdir(parents=True)
        ok, reason = TempStore(other, self.tmp / "srv" / "state3", 60).prepare()
        self.assertTrue(ok, reason)
        self.assertEqual((other / MARKER).read_text(), MARKER_TEXT)


class SettingsAndSchedule(Base):
    def test_disabled_cleanup_deletes_nothing_on_schedule(self):
        task = self.make_task(age=30 * HOUR)
        self.store.update_settings({"enabled": False}, "admin #1")
        self.store.next_run = self.clock() - 1
        self.store.start()
        time.sleep(0.3)
        self.store.stop()
        self.assertTrue((self.root / task).exists())
        listing = self.store.scan()
        self.assertEqual(listing["tasks"][0]["cleanup"], "kept")
        self.assertEqual(listing["summary"]["expired_bytes"], listing["tasks"][0]["size"])
        self.assertIsNone(self.store.status()["next_run"])
        self.assertEqual(self.store.status()["scheduler"], "stopped")

    def test_disabling_does_not_delete_or_touch_active_tasks(self):
        running = self.make_task(status="running", age=5 * HOUR)
        snap = digest(self.root / running)
        self.store.update_settings({"enabled": False}, "admin #1")
        self.store.update_settings({"enabled": True}, "admin #1")
        self.assertEqual(digest(self.root / running), snap)

    def test_settings_survive_a_restart(self):
        self.store.update_settings({"enabled": False, "ttl_min": 120, "interval_min": 10}, "admin #1")
        again = self.new_store(ttl=60)
        s = again.settings.get()
        self.assertEqual((s["enabled"], s["ttl_min"], s["interval_min"]), (False, 120, 10))
        self.assertEqual(s["updated_by"], "admin #1")

    def test_default_expiry_is_one_hour(self):
        fresh = TempStore(self.tmp / "srv" / "x" / "jobs", self.tmp / "srv" / "x")
        self.assertEqual(fresh.settings.get()["ttl_min"], 60)

    def test_invalid_settings_are_refused(self):
        for bad in [{"ttl_min": 5}, {"ttl_min": 99999}, {"ttl_min": "60"}, {"interval_min": 0}, {"enabled": "yes"},
                    {"ttl_min": True}, {"path": "/"}, {"ttl_min": 1.5}]:
            _, errors = self.store.update_settings(bad, "t")
            self.assertTrue(errors, bad)
        self.assertEqual(self.store.settings.get()["ttl_min"], 60)

    def test_corrupt_settings_file_falls_back_to_defaults(self):
        (self.state / "cleanup-settings.json").write_text("{not json")
        self.assertEqual(self.new_store().settings.get()["ttl_min"], 60)

    def test_history_and_counts(self):
        self.make_task(age=3 * HOUR)
        self.store.run("manual", "admin #1")
        status = self.store.status()
        self.assertEqual(status["counts"]["deleted_total"], 1)
        self.assertEqual(status["counts"]["success_runs"], 1)
        self.assertIsNotNone(status["last_success"])
        hist = self.store.history()
        self.assertEqual(hist[0]["trigger"], "manual")
        self.assertEqual(hist[0]["deleted"], 1)

    def test_blocked_runs_are_not_repeated_in_history(self):
        os.unlink(self.root / MARKER)
        for _ in range(5):
            self.store.run("schedule")
        blocked = [h for h in self.store.history() if h["mode"] == "blocked"]
        self.assertEqual(len(blocked), 1)
        self.assertEqual(self.store.status()["counts"]["runs"], 5)


class Failures(Base):
    def test_failed_deletion_is_reported_and_retried(self):
        task = self.make_task(age=3 * HOUR)

        def broken(path):
            return ["result/out-0.pdf: Permission denied"]

        with mock.patch("temp_store.remove_tree", side_effect=broken):
            result = self.store.run("schedule")
        self.assertEqual(result["failed"], 1)
        status = self.store.status()
        self.assertEqual(status["failures"][0]["task"], task)
        self.assertEqual(status["failures"][0]["attempts"], 1)
        self.assertNotIn(str(self.root), json.dumps(status))       # no paths in what the dashboard sees
        # Retry from the dashboard: the leftover .trash- folder is removed.
        r = self.store.delete(task, trigger="retry", actor="admin #1")
        self.assertTrue(r["ok"], r)
        self.assertEqual(self.store.status()["failures"], [])
        self.assertEqual([e for e in os.listdir(self.root) if e != MARKER], [])

    def test_leftover_trash_is_finished_on_the_next_run(self):
        task = tid()
        (self.root / f".trash-{task}" / "result").mkdir(parents=True)
        self.assertEqual(self.store.run("schedule")["deleted"], 1)
        self.assertEqual(os.listdir(self.root), [MARKER])


class ManualDelete(Base):
    def test_manual_delete_of_finished_task(self):
        task = self.make_task(age=60, status="failed")
        r = self.store.delete(task, trigger="admin-delete", actor="admin #1")
        self.assertTrue(r["deleted"])
        self.assertGreater(r["freed"], 0)
        self.assertIn(task, self.store.removed())

    def test_manual_delete_refuses_running_task(self):
        task = self.make_task(age=60, status="running")
        self.assertEqual(self.store.delete(task, trigger="admin-delete")["code"], "active")
        self.assertTrue((self.root / task).exists())

    def test_download_delete_is_not_in_history(self):
        task = self.make_task(age=60)
        self.store.delete(task, trigger="download", actor="wordpress")
        self.assertEqual(self.store.history(), [])
        self.assertEqual(self.store.status()["counts"]["download_deleted"], 1)


class PermanentData(Base):
    """The whole point: nothing but expired temp task folders ever disappears."""

    def test_full_cycle_leaves_permanent_data_untouched(self):
        for _ in range(4):
            self.make_task(age=3 * HOUR)
        keep = self.make_task(age=10)
        running = self.make_task(status="running", age=9 * HOUR)
        for ttl in (15, 60, 1440):
            self.store.update_settings({"ttl_min": ttl}, "t")
            self.store.run("manual")
        for task in os.listdir(self.root):
            if task not in (MARKER, keep, running):
                self.store.delete(task, trigger="admin-delete")
        self.assertTrue((self.root / keep).exists())
        self.assertTrue((self.root / running).exists())
        self.assertEqual(sorted(os.listdir(self.root)), sorted([MARKER, keep, running]))
        # tearDown: blog posts, uploads and the database file are byte-for-byte unchanged

    def test_state_files_are_outside_the_temp_root(self):
        self.make_task(age=3 * HOUR)
        self.store.run("manual")
        self.assertTrue((self.state / "cleanup-state.json").exists())
        self.assertTrue((self.state / "cleanup-history.jsonl").exists())
        self.assertEqual(os.listdir(self.root), [MARKER])


class MetricsTest(unittest.TestCase):
    def test_metrics_never_invent_values(self):
        m = temp_store.Metrics(Path("/"))
        data = m.read()               # no samples yet: rates are unknown, not zero
        self.assertIsNone(data["cpu"]["pct"])
        self.assertIsNone(data["network"]["rx_bps"])
        m.sample()
        time.sleep(0.5)
        m.sample()
        data = m.read()
        if os.path.exists("/proc/stat"):
            self.assertIsNotNone(data["cpu"]["pct"])
            self.assertGreaterEqual(data["cpu"]["pct"], 0)
            self.assertLessEqual(data["memory"]["pct"], 100)
        self.assertNotIn("/", json.dumps({k: v for k, v in data.items() if k != "time"}).replace("\\/", ""))


if __name__ == "__main__":
    unittest.main()
