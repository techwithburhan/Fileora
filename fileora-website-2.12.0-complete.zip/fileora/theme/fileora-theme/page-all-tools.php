<?php
/**
 * Template Name: All tools
 *
 * Every tool, grouped by category, with tabs and a filter. Text written in
 * the page editor appears under the catalogue.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="main">
	<?php while ( have_posts() ) : the_post(); ?>
		<div class="wrap" style="padding-top:32px"><?php fileora_theme_crumbs( array( get_the_title() => '' ) ); ?></div>
		<?php
		if ( fileora_theme_core() ) {
			$fileora_c = fileora_theme_counts();
			get_template_part(
				'template-parts/catalog',
				null,
				array(
					'heading' => get_the_title(),
					'level'   => 'h1',
					/* translators: 1: number of tools, 2: number running in the browser */
					'text'    => has_excerpt() ? get_the_excerpt() : sprintf( __( '%1$s free tools for PDFs and images. %2$s of them run in your browser, so your files stay on your device.', 'fileora' ), number_format_i18n( $fileora_c['all'] ), number_format_i18n( $fileora_c['browser'] ) ),
				)
			);
		} else {
			echo '<div class="page-head wrap"><h1>' . esc_html( get_the_title() ) . '</h1></div>';
		}
		if ( '' !== trim( get_the_content() ) ) {
			echo '<div class="article article-wide prose" style="padding-top:48px">';
			the_content();
			echo '</div>';
		}
		?>
	<?php endwhile; ?>
	<div style="height:72px"></div>
</main>
<?php
get_footer();
