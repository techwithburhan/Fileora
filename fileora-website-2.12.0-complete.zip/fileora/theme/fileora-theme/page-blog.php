<?php
/**
 * Template Name: Blog
 *
 * The blog listing on a normal page (used when Settings → Reading has no
 * posts page). Text written in the page editor appears under the title.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
$fileora_paged = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
$fileora_q     = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'paged' => $fileora_paged, 'ignore_sticky_posts' => false ) );
the_post();
$fileora_intro = trim( wp_strip_all_tags( get_the_excerpt() ) );
?>
<main id="main">
	<header class="page-head wrap">
		<?php fileora_theme_crumbs( array( get_the_title() => '' ) ); ?>
		<h1><?php the_title(); ?></h1>
		<p><?php echo esc_html( has_excerpt() ? get_the_excerpt() : sprintf( /* translators: %s: site name */ __( 'Guides and tips from %s: PDFs, photos, government forms and documents, explained step by step.', 'fileora' ), get_bloginfo( 'name' ) ) ); ?></p>
		<?php fileora_theme_category_chips(); ?>
	</header>
	<div class="wrap blog-list">
		<?php if ( '' !== trim( get_the_content() ) ) : ?><div class="prose" style="max-width:760px;margin-bottom:32px"><?php the_content(); ?></div><?php endif; ?>
		<?php if ( $fileora_q->have_posts() ) : ?>
			<?php
			if ( 1 === $fileora_paged ) {
				$fileora_q->the_post();
				get_template_part( 'template-parts/post-card', null, array( 'featured' => true ) );
			}
			?>
			<div class="posts">
				<?php
				while ( $fileora_q->have_posts() ) {
					$fileora_q->the_post();
					get_template_part( 'template-parts/post-card' );
				}
				?>
			</div>
			<?php
			$fileora_links = paginate_links(
				array(
					'total'     => $fileora_q->max_num_pages,
					'current'   => $fileora_paged,
					'type'      => 'array',
					'mid_size'  => 1,
					'prev_text' => fileora_theme_icon( 'arrow-left', 'ic ic-sm' ) . '<span class="sr">' . __( 'Previous', 'fileora' ) . '</span>',
					'next_text' => '<span class="sr">' . __( 'Next', 'fileora' ) . '</span>' . fileora_theme_icon( 'arrow-right', 'ic ic-sm' ),
				)
			);
			if ( $fileora_links ) {
				echo '<nav class="pagination" aria-label="' . esc_attr__( 'Pages', 'fileora' ) . '">' . implode( '', $fileora_links ) . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			wp_reset_postdata();
			?>
		<?php else : ?>
			<div class="empty"><span class="tile lg"><?php fileora_theme_e_icon( 'file' ); ?></span><h3><?php esc_html_e( 'Nothing here yet', 'fileora' ); ?></h3><p><?php esc_html_e( 'New articles will appear here.', 'fileora' ); ?></p></div>
		<?php endif; ?>
	</div>
</main>
<?php
get_footer();
