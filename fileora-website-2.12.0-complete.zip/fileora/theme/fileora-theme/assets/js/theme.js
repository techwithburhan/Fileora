/* Fileora theme: dark mode, header menus, search palette, tool catalogue,
   homepage drop ("which tool?") and the homepage animation.
   Tool workspaces are run by the Fileora Core plugin, not by this file. */
(function () {
  'use strict';
  var C = window.FileoraTheme || { tools: [], i18n: {} };
  var T = C.tools || [];
  var I = C.i18n || {};
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches || document.documentElement.classList.contains('fo-a11y-motion');
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('fileora.' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('fileora.' + k, JSON.stringify(v)); } catch (e) { /* storage off */ } }
  };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function icon(n, cls) { return '<svg class="' + (cls || 'ic') + '" aria-hidden="true" focusable="false"><use href="#i-' + n + '"/></svg>'; }
  function fmt(s, v) { return String(s || '').replace('%s', v).replace('%d', v); }
  var byId = {}; T.forEach(function (t) { byId[t.id] = t; });

  /* ---------- dark mode ---------- */
  var root = document.documentElement;
  $$('[data-theme-toggle]').forEach(function (b) {
    b.addEventListener('click', function () {
      var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', next); store.set('theme', next);
    });
  });

  /* ---------- header ---------- */
  var hdr = $('#hdr');
  function onScroll() { if (hdr) hdr.classList.toggle('scrolled', scrollY > 4); }
  addEventListener('scroll', onScroll, { passive: true }); onScroll();

  var megaBtn = $('[data-mega]'), mega = $('#mega');
  function setMega(open) {
    if (!megaBtn || !mega) return;
    megaBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    mega.hidden = !open;
  }
  if (megaBtn && mega) {
    megaBtn.addEventListener('click', function (e) { e.stopPropagation(); setMega(mega.hidden); });
    document.addEventListener('click', function (e) { if (!mega.hidden && !mega.contains(e.target)) setMega(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !mega.hidden) { setMega(false); megaBtn.focus(); } });
  }

  /* overlays: drawer, palette, suggest */
  var lastFocus = null;
  function openOv(el, focusEl) {
    if (!el) return;
    lastFocus = document.activeElement;
    el.hidden = false; document.body.classList.add('locked');
    setTimeout(function () { (focusEl || $('button, input, a', el) || el).focus(); }, 20);
  }
  function closeOv(el) {
    if (!el || el.hidden) return;
    el.hidden = true;
    if (!$$('.ov:not([hidden]), .drawer:not([hidden])').length) document.body.classList.remove('locked');
    var b = $('[data-drawer]'); if (el.id === 'drawer' && b) b.setAttribute('aria-expanded', 'false');
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  $$('.ov, .drawer').forEach(function (el) {
    el.addEventListener('click', function (e) { if (e.target.closest('[data-close]')) closeOv(el); });
    el.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.stopPropagation(); closeOv(el); return; }
      if (e.key !== 'Tab') return;
      var f = $$('a[href], button:not([disabled]), input, summary, [tabindex]:not([tabindex="-1"])', el).filter(function (x) { return x.offsetParent !== null; });
      if (!f.length) return;
      if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
    });
  });
  var drawer = $('#drawer');
  $$('[data-drawer]').forEach(function (b) { b.addEventListener('click', function () { b.setAttribute('aria-expanded', 'true'); openOv(drawer); }); });
  addEventListener('resize', function () { if (drawer && !drawer.hidden && innerWidth > 1020) closeOv(drawer); });

  /* ---------- recently used tools ---------- */
  var recent = store.get('recent', []);
  if (!Array.isArray(recent)) recent = [];
  recent = recent.filter(function (id) { return byId[id]; });
  if (C.tool && byId[C.tool]) {
    recent = [C.tool].concat(recent.filter(function (x) { return x !== C.tool; })).slice(0, 6);
    store.set('recent', recent);
  }

  /* ---------- search palette ---------- */
  var pal = $('#palette'), q = $('#pl-q'), list = $('#pl-list'), sel = 0, rows = [];
  var POPULAR = ['merge', 'compress', 'pdf2word', 'jpg2pdf', 'sign', 'split', 'imgcompress', 'unlock'];
  function norm(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9ऀ-ॿ]+/g, ' ').trim(); }
  function score(t, words) {
    var name = norm(t.name), hay = name + ' ' + norm(t.desc) + ' ' + norm(t.keys) + ' ' + norm(t.cat), s = 0;
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      if (hay.indexOf(w) === -1) {
        // "jpg2pdf"-style and "to" queries: try without spaces
        if (hay.replace(/ /g, '').indexOf(w) === -1) return 0;
        s += 1; continue;
      }
      s += name.indexOf(w) === 0 ? 6 : (name.indexOf(' ' + w) !== -1 || name.indexOf(w) !== -1 ? 4 : 1);
    }
    if (name === words.join(' ')) s += 10;
    if (name.replace(/ /g, '').indexOf(words.join('to').replace(/ /g, '')) !== -1) s += 8;
    return s + (t.ready ? 0.5 : 0);
  }
  function rowHtml(t, i) {
    return '<div class="pl-item" role="option" id="pl-' + i + '" data-i="' + i + '" data-cat="' + esc(t.color) + '" aria-selected="false">' +
      '<span class="tile">' + icon(t.icon) + '</span><div><b>' + esc(t.name) + '</b><small>' + esc(t.desc) + '</small></div>' +
      '<span class="pl-cat">' + esc(t.runs === 'browser' ? I.browser : I.server) + '</span></div>';
  }
  function renderPal() {
    var v = norm(q.value), html = '';
    rows = [];
    if (!v) {
      var groups = [];
      if (recent.length) groups.push([I.recent, recent.map(function (id) { return byId[id]; })]);
      groups.push([I.popular, POPULAR.map(function (id) { return byId[id]; }).filter(function (t) { return t && recent.indexOf(t.id) === -1; })]);
      groups.forEach(function (g) {
        var ts = g[1].filter(Boolean); if (!ts.length) return;
        html += '<div class="pl-group">' + esc(g[0]) + '</div>';
        ts.forEach(function (t) { rows.push({ url: t.url }); html += rowHtml(t, rows.length - 1); });
      });
    } else {
      var words = v.split(' ').filter(function (w) { return w && w !== 'to'; });
      if (!words.length) words = v.split(' ');
      var hits = T.map(function (t) { return [score(t, words), t]; }).filter(function (x) { return x[0] > 0; })
        .sort(function (a, b) { return b[0] - a[0]; }).slice(0, 12);
      if (hits.length) {
        html += '<div class="pl-group">' + esc(I.tools) + '</div>';
        hits.forEach(function (h) { rows.push({ url: h[1].url }); html += rowHtml(h[1], rows.length - 1); });
      } else if (T.length) {
        html += '<div class="pl-empty">' + esc(fmt(I.noTools, q.value.trim())) + '</div>';
      }
      rows.push({ url: C.search + (C.search.indexOf('?') === -1 ? '?' : '&') + 's=' + encodeURIComponent(q.value.trim()) });
      html += '<div class="pl-item" role="option" id="pl-' + (rows.length - 1) + '" data-i="' + (rows.length - 1) + '" aria-selected="false"><span class="tile">' + icon('search') + '</span><div><b>' + esc(fmt(I.searchBlog, q.value.trim())) + '</b></div></div>';
    }
    list.innerHTML = html;
    sel = 0; mark();
  }
  function mark() {
    $$('.pl-item', list).forEach(function (el) { el.setAttribute('aria-selected', +el.dataset.i === sel ? 'true' : 'false'); });
    var cur = $('#pl-' + sel);
    if (cur) { cur.scrollIntoView({ block: 'nearest' }); q.setAttribute('aria-activedescendant', cur.id); }
  }
  function openPal() { if (!pal) return; q.value = ''; renderPal(); openOv(pal, q); }
  if (pal) {
    $$('[data-palette]').forEach(function (b) { b.addEventListener('click', function () { if (drawer && !drawer.hidden) closeOv(drawer); openPal(); }); });
    q.addEventListener('input', renderPal);
    q.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(rows.length - 1, sel + 1); mark(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); mark(); }
      else if (e.key === 'Enter') { e.preventDefault(); if (rows[sel]) location.href = rows[sel].url; }
    });
    list.addEventListener('click', function (e) { var it = e.target.closest('.pl-item'); if (it && rows[+it.dataset.i]) location.href = rows[+it.dataset.i].url; });
    list.addEventListener('mousemove', function (e) { var it = e.target.closest('.pl-item'); if (it && +it.dataset.i !== sel) { sel = +it.dataset.i; mark(); } });
    document.addEventListener('keydown', function (e) {
      var tag = (e.target.tagName || '').toLowerCase(), typing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable;
      if ((e.key === '/' && !typing) || ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K'))) {
        if (!pal.hidden) return; e.preventDefault(); openPal();
      }
    });
  }

  /* ---------- tool catalogue ---------- */
  var cat = $('#catalog');
  if (cat) {
    var tabs = $$('.tab'), filter = $('#tool-filter'), local = $('#local-only'), empty = $('#catalog-empty'), active = 'all';
    var tabsBox = $('.tabs');
    function moreMask() { if (tabsBox) tabsBox.classList.toggle('more', tabsBox.scrollWidth - tabsBox.clientWidth - tabsBox.scrollLeft > 4); }
    if (tabsBox) { tabsBox.addEventListener('scroll', moreMask, { passive: true }); addEventListener('resize', moreMask); moreMask(); }
    function apply() {
      var v = norm(filter.value), lo = local.getAttribute('aria-pressed') === 'true', any = false;
      $$('.cat-block', cat).forEach(function (b) {
        var showCat = active === 'all' || b.id === active, n = 0;
        $$('.tool', b).forEach(function (t) {
          var ok = showCat && (!lo || t.dataset.runs === 'browser') && (!v || v.split(' ').every(function (w) { return t.dataset.keys.indexOf(w) !== -1; }));
          t.hidden = !ok; if (ok) n++;
        });
        b.hidden = !n; if (n) any = true;
      });
      empty.hidden = any;
    }
    function setTab(id, scroll) {
      active = id;
      tabs.forEach(function (t) { t.setAttribute('aria-selected', t.dataset.tab === id ? 'true' : 'false'); });
      apply();
      var tb = $('.tab[data-tab="' + id + '"]'); if (tb && tb.scrollIntoView) tb.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      if (scroll) { var top = $('#tools').getBoundingClientRect().top + scrollY - 8; if (scrollY > top) scrollTo({ top: top, behavior: REDUCED ? 'auto' : 'smooth' }); }
    }
    tabs.forEach(function (t) {
      t.addEventListener('click', function () {
        setTab(t.dataset.tab, true);
        try { history.replaceState(null, '', t.dataset.tab === 'all' ? location.pathname + location.search : '#' + t.dataset.tab); } catch (e) { /* ignore */ }
      });
    });
    filter.addEventListener('input', apply);
    local.addEventListener('click', function () { local.setAttribute('aria-pressed', local.getAttribute('aria-pressed') === 'true' ? 'false' : 'true'); apply(); });
    $('#filter-clear').addEventListener('click', function () { filter.value = ''; local.setAttribute('aria-pressed', 'false'); setTab('all'); });
    function fromHash() {
      var h = location.hash.slice(1);
      if (h && $('.tab[data-tab="' + h + '"]')) { setTab(h); var s = $('#tools'); if (s) setTimeout(function () { s.scrollIntoView({ block: 'start' }); }, 30); }
    }
    addEventListener('hashchange', fromHash); fromHash();
    var bar = $('#toolbar');
    if (bar && 'IntersectionObserver' in window) {
      var sent = document.createElement('div'); bar.parentNode.insertBefore(sent, bar);
      new IntersectionObserver(function (e) { bar.classList.toggle('stuck', !e[0].isIntersecting); }, { rootMargin: '-' + ((hdr ? hdr.offsetHeight : 68) + 1) + 'px 0px 0px 0px' }).observe(sent);
    }
    var rc = $('#recent');
    if (rc && recent.length) {
      rc.innerHTML = '<span>' + esc(I.recent) + ':</span>' + recent.map(function (id) { var t = byId[id]; return '<a class="chip" data-cat="' + esc(t.color) + '" href="' + esc(t.url) + '">' + icon(t.icon) + esc(t.name) + '</a>'; }).join('');
      rc.hidden = false;
    }
  }

  /* ---------- homepage: drop files, pick a tool ---------- */
  var stage = $('#stage'), sg = $('#suggest');
  var KINDS = { pdf: ['pdf'], image: ['image'], pdfimage: ['pdf', 'image'], heic: ['heic', 'image'], svg: ['svg'], word: ['word'], ppt: ['ppt'], excel: ['excel'], url: [] };
  var BEST = {
    pdf: ['merge', 'compress', 'pdf2word', 'split', 'sign', 'pdf2jpg', 'organize', 'unlock', 'protect'],
    image: ['jpg2pdf', 'imgcompress', 'imgresize', 'imgconvert', 'imgkb', 'passport'],
    heic: ['heic2jpg'], svg: ['svg2png'], word: ['word2pdf'], ppt: ['ppt2pdf'], excel: ['excel2pdf']
  };
  function kindOf(f) {
    var m = /\.([^.]+)$/.exec(f.name || ''), e = m ? m[1].toLowerCase() : '';
    if (e === 'pdf' || f.type === 'application/pdf') return 'pdf';
    if (e === 'svg' || f.type === 'image/svg+xml') return 'svg';
    if (e === 'heic' || e === 'heif' || /^image\/hei[cf]/.test(f.type)) return 'heic';
    if (['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'avif'].indexOf(e) !== -1 || /^image\//.test(f.type)) return 'image';
    if (['doc', 'docx', 'odt', 'rtf', 'txt'].indexOf(e) !== -1) return 'word';
    if (['ppt', 'pptx', 'pps', 'ppsx', 'odp'].indexOf(e) !== -1) return 'ppt';
    if (['xls', 'xlsx', 'ods', 'csv'].indexOf(e) !== -1) return 'excel';
    return 'other';
  }
  function handoff(files) {
    return new Promise(function (res, rej) {
      if (!window.indexedDB) return rej(new Error('no idb'));
      var r = indexedDB.open('fileora', 1);
      r.onupgradeneeded = function () { r.result.createObjectStore('handoff'); };
      r.onerror = function () { rej(r.error); };
      r.onsuccess = function () {
        var db = r.result, tx = db.transaction('handoff', 'readwrite');
        tx.objectStore('handoff').put({ files: files, ts: Date.now() }, 'next');
        tx.oncomplete = function () { db.close(); res(); };
        tx.onerror = function () { db.close(); rej(tx.error); };
      };
    });
  }
  function go(t, files) {
    handoff(files).then(function () { location.href = t.url + (t.url.indexOf('?') === -1 ? '?' : '&') + 'fo_handoff=1'; })
      .catch(function () { location.href = t.url; });
  }
  function suggest(fileList) {
    var files = Array.prototype.slice.call(fileList || []);
    if (!files.length || !sg) return;
    var kinds = []; files.forEach(function (f) { var k = kindOf(f); if (kinds.indexOf(k) === -1) kinds.push(k); });
    var fits = T.filter(function (t) {
      var ks = KINDS[t.accept] || [];
      return t.ready && kinds.every(function (k) { return ks.indexOf(k) !== -1; });
    });
    var bestIds = []; kinds.forEach(function (k) { (BEST[k] || []).forEach(function (id) { if (bestIds.indexOf(id) === -1) bestIds.push(id); }); });
    if (kinds.length > 1 && kinds.every(function (k) { return k === 'pdf' || k === 'image'; })) bestIds.unshift('merge');
    var best = bestIds.map(function (id) { return fits.filter(function (t) { return t.id === id; })[0]; }).filter(Boolean).slice(0, 6);
    var rest = fits.filter(function (t) { return best.indexOf(t) === -1; });
    $('#sg-files').innerHTML = files.slice(0, 6).map(function (f) { return '<span class="tag">' + icon('file') + esc(f.name.length > 34 ? f.name.slice(0, 31) + '…' : f.name) + '</span>'; }).join('') +
      (files.length > 6 ? '<span class="tag">+' + (files.length - 6) + '</span>' : '');
    function items(ts) {
      return '<div class="sg-grid">' + ts.map(function (t) {
        return '<button class="sg-item" type="button" data-id="' + esc(t.id) + '" data-cat="' + esc(t.color) + '"><span class="tile">' + icon(t.icon) + '</span><span><b>' + esc(t.name) + '</b><small>' + esc(t.runs === 'browser' ? I.browser : I.server) + '</small></span></button>';
      }).join('') + '</div>';
    }
    var html = '';
    if (!fits.length) html = '<div class="pl-empty">' + esc(I.noMatch) + '</div>';
    else {
      if (best.length) html += '<div class="sg-sub" style="margin-top:0">' + esc(I.best) + '</div>' + items(best);
      if (rest.length) html += '<div class="sg-sub">' + esc(best.length ? I.more : I.tools) + '</div>' + items(rest);
    }
    var box = $('#sg-list'); box.innerHTML = html;
    box.onclick = function (e) { var b = e.target.closest('.sg-item'); if (b && byId[b.dataset.id]) { b.disabled = true; go(byId[b.dataset.id], files); } };
    openOv(sg, $('.sg-item', sg));
  }
  var input = $('#home-files');
  if (input) input.addEventListener('change', function () { suggest(input.files); input.value = ''; });
  var pd = $('#page-drop');
  if (stage && sg) {
    var depth = 0;
    var hasFiles = function (e) { return e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') !== -1; };
    addEventListener('dragenter', function (e) { if (!hasFiles(e)) return; depth++; if (pd) pd.hidden = false; stage.classList.add('over'); });
    addEventListener('dragleave', function () { depth = Math.max(0, depth - 1); if (!depth) { if (pd) pd.hidden = true; stage.classList.remove('over'); } });
    addEventListener('dragover', function (e) { if (hasFiles(e)) e.preventDefault(); });
    addEventListener('drop', function (e) {
      if (!hasFiles(e)) return; e.preventDefault(); depth = 0;
      if (pd) pd.hidden = true; stage.classList.remove('over');
      suggest(e.dataTransfer.files);
    });
  }

  /* ---------- homepage animation: merge, compress, sign ---------- */
  if (stage && !REDUCED && Element.prototype.animate) {
    var sheets = $$('.sheet', stage), badge = $('#st-badge'), size = $('#st-size'), cap = $('#stage-cap'), sig = $('.sh-sig', stage);
    var scenes = [
      { cap: 'Merging, right in your browser', run: function () {
        var fan = [-58, 0, 58];
        sheets.forEach(function (s, i) {
          s.animate([{ transform: 'translate(' + fan[i] + '%, 4%) rotate(' + (i - 1) * 8 + 'deg)' }, { transform: 'translate(' + fan[i] + '%, 4%) rotate(' + (i - 1) * 8 + 'deg)', offset: .35 }, { transform: 'translate(' + (i - 1) * 3 + '%, ' + (i - 1) * -3 + '%) rotate(0deg)' }], { duration: 1600, easing: 'cubic-bezier(.6,0,.2,1)', fill: 'forwards' });
        });
        badge.textContent = '3 files → 1 PDF';
        badge.animate([{ opacity: 0, transform: 'translate(-50%, 8px)' }, { opacity: 1, transform: 'translate(-50%, 0)' }], { duration: 400, delay: 1500, fill: 'forwards' });
      } },
      { cap: 'Compressing, without uploading', run: function () {
        sheets.forEach(function (s, i) { s.animate([{ transform: 'translate(' + (i - 1) * 3 + '%, ' + (i - 1) * -3 + '%) scale(1)', opacity: 1 }, { transform: 'translate(0, 6%) scale(.72)', opacity: i === 1 ? 1 : 0 }], { duration: 1300, delay: 300, easing: 'cubic-bezier(.6,0,.2,1)', fill: 'forwards' }); });
        size.textContent = '4.2 MB → 1.1 MB';
        size.animate([{ opacity: 0, transform: 'translate(-50%, 8px)' }, { opacity: 1, transform: 'translate(-50%, 0)' }], { duration: 400, delay: 1400, fill: 'forwards' });
      } },
      { cap: 'Signing, in seconds', run: function () {
        sheets.forEach(function (s, i) { s.animate([{ transform: 'translate(0, 6%) scale(.72)', opacity: i === 1 ? 1 : 0 }, { transform: 'translate(0, 2%) scale(1.06)', opacity: i === 1 ? 1 : 0 }], { duration: 900, easing: 'cubic-bezier(.6,0,.2,1)', fill: 'forwards' }); });
        if (sig) {
          var p = $('path', sig), L = p.getTotalLength ? p.getTotalLength() : 300;
          p.style.strokeDasharray = L;
          sig.animate([{ opacity: 1 }, { opacity: 1 }], { duration: 2400, delay: 700, fill: 'forwards' });
          p.animate([{ strokeDashoffset: L }, { strokeDashoffset: 0 }], { duration: 1400, delay: 800, easing: 'ease-in-out', fill: 'forwards' });
        }
        badge.textContent = 'Signed ✓';
        badge.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 400, delay: 2100, fill: 'forwards' });
      } }
    ];
    var n = 0, timer = null;
    var reset = function () {
      stage.getAnimations({ subtree: true }).forEach(function (a) { a.cancel(); });
      [badge, size].forEach(function (b) { b.style.opacity = 0; });
    };
    var play = function () {
      reset();
      var sc = scenes[n % scenes.length];
      // carry the end state of the previous scene into this one
      if (n % scenes.length === 0) sheets.forEach(function (s, i) { s.style.transform = ''; s.style.opacity = ''; });
      cap.textContent = sc.cap; sc.run(); n++;
      timer = setTimeout(play, 3600);
    };
    var vis = function () { clearTimeout(timer); if (!document.hidden) play(); };
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (e) { clearTimeout(timer); if (e[0].isIntersecting) play(); else reset(); }).observe(stage);
    } else play();
    document.addEventListener('visibilitychange', vis);
  }
})();

/* ---------- blog post: reading progress, active TOC entry, copy link ---------- */
(function () {
  'use strict';
  var bar = document.getElementById('read-progress');
  var body = document.querySelector('.post-main .prose');
  if (bar && body) {
    var upd = function () {
      var r = body.getBoundingClientRect(), total = r.height - innerHeight * 0.6;
      bar.style.width = Math.max(0, Math.min(100, (-r.top + innerHeight * 0.2) / Math.max(1, total) * 100)) + '%';
    };
    addEventListener('scroll', upd, { passive: true }); addEventListener('resize', upd); upd();
  }
  var links = Array.prototype.slice.call(document.querySelectorAll('.post-side .toc a'));
  if (links.length && 'IntersectionObserver' in window) {
    var map = {};
    links.forEach(function (a) { map[decodeURIComponent(a.hash.slice(1))] = a; });
    var heads = Object.keys(map).map(function (id) { return document.getElementById(id); }).filter(Boolean);
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (e.isIntersecting) { links.forEach(function (a) { a.classList.remove('on'); }); var a = map[e.target.id]; if (a) a.classList.add('on'); }
      });
    }, { rootMargin: '-15% 0px -70% 0px' });
    heads.forEach(function (h) { io.observe(h); });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-copy-link]'); if (!b) return;
    var url = b.getAttribute('data-copy-link'), old = b.textContent;
    var done = function () { b.textContent = b.getAttribute('data-done') || 'Copied'; setTimeout(function () { b.textContent = old; }, 1800); };
    if (navigator.clipboard) navigator.clipboard.writeText(url).then(done, function () { prompt('', url); });
    else { prompt('', url); }
  });
  var mob = document.querySelector('.toc-mobile');
  if (mob) mob.addEventListener('click', function (e) { if (e.target.closest('a')) mob.open = false; });
})();

/* Tables in page and post text: each cell gets its column name, so on small screens a row can be shown as a card. */
(function () {
  document.querySelectorAll('.prose table').forEach(function (t) {
    var heads = [].map.call(t.querySelectorAll('thead th'), function (th) { return th.textContent.trim(); });
    if (heads.length < 2) return;
    t.classList.add('fo-stack');
    t.querySelectorAll('tbody tr').forEach(function (tr) {
      [].forEach.call(tr.children, function (td, i) { if (heads[i]) td.setAttribute('data-label', heads[i]); });
    });
  });
})();

/* Code blocks in posts and pages: a "Copy code" button, and keyboard scrolling for long lines. */
(function () {
  var pres = document.querySelectorAll('.prose pre');
  if (!pres.length) return;
  var status = document.createElement('span');
  status.className = 'screen-reader-text'; status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
  document.body.appendChild(status);
  [].forEach.call(pres, function (pre) {
    if (pre.parentNode.classList.contains('code-wrap')) return;
    var wrap = document.createElement('div');
    wrap.className = 'code-wrap';
    pre.parentNode.insertBefore(wrap, pre);
    wrap.appendChild(pre);
    if (!pre.hasAttribute('tabindex')) { pre.setAttribute('tabindex', '0'); pre.setAttribute('aria-label', 'Code example'); }
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'code-copy'; b.textContent = 'Copy code';
    b.addEventListener('click', function () {
      var text = (pre.querySelector('code') || pre).textContent;
      var done = function (ok) {
        b.textContent = ok ? 'Copied' : 'Select and copy';
        status.textContent = ok ? 'Code copied to the clipboard' : 'Copy isn’t allowed here. Select the code and copy it.';
        setTimeout(function () { b.textContent = 'Copy code'; status.textContent = ''; }, 1800);
      };
      if (navigator.clipboard) navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(false); });
      else done(false);
    });
    wrap.appendChild(b);
  });
})();
