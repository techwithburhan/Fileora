/* Fileora theme: the accessibility button and panel.
   Choices live in this browser only (localStorage "fileora.a11y") and are put on <html> as classes;
   inc/setup.php applies them before the page is drawn, this file keeps them in sync. */
(function () {
  'use strict';
  var d = document.documentElement;
  var root = document.querySelector('[data-a11y]');
  if (!root) return;
  var fab = root.querySelector('[data-a11y-open]');
  var panel = root.querySelector('#a11y-panel');
  var status = root.querySelector('.a11y-status');
  var KEYS = ['contrast', 'links', 'readable', 'spacing', 'motion', 'cursor'];
  var st = {};
  try { st = JSON.parse(localStorage.getItem('fileora.a11y') || '{}') || {}; } catch (e) { st = {}; }

  function save() { try { localStorage.setItem('fileora.a11y', JSON.stringify(st)); } catch (e) { /* storage off: choices last for this page */ } }
  function apply() {
    var size = +st.text || 0;
    [1, 2, 3].forEach(function (n) { d.classList.toggle('fo-a11y-text-' + n, size === n); });
    KEYS.forEach(function (k) { d.classList.toggle('fo-a11y-' + k, !!st[k]); });
    root.querySelectorAll('[data-a11y-text]').forEach(function (b) { b.setAttribute('aria-pressed', String(size === +b.getAttribute('data-a11y-text'))); });
    root.querySelectorAll('[data-a11y-toggle]').forEach(function (b) { b.setAttribute('aria-pressed', String(!!st[b.getAttribute('data-a11y-toggle')])); });
    fab.classList.toggle('on', size > 0 || KEYS.some(function (k) { return st[k]; }));
    try { document.dispatchEvent(new CustomEvent('fileora:a11y', { detail: st })); } catch (e) { /* old browser */ }
  }
  function say(msg) { status.textContent = ''; setTimeout(function () { status.textContent = msg; }, 40); }
  function open() {
    panel.hidden = false;
    fab.setAttribute('aria-expanded', 'true');
    var first = panel.querySelector('.a11y-seg [aria-pressed="true"]') || panel.querySelector('button');
    if (first) first.focus();
  }
  function close(returnFocus) {
    if (panel.hidden) return;
    panel.hidden = true;
    fab.setAttribute('aria-expanded', 'false');
    if (returnFocus !== false) fab.focus();
  }

  fab.addEventListener('click', function () { if (panel.hidden) open(); else close(); });
  root.addEventListener('click', function (e) {
    var b = e.target.closest('button');
    if (!b || b === fab) return;
    if (b.hasAttribute('data-a11y-close')) { close(); return; }
    if (b.hasAttribute('data-a11y-text')) {
      st.text = +b.getAttribute('data-a11y-text'); apply(); save();
      say((b.getAttribute('aria-label') || b.textContent) + ' selected');
      return;
    }
    if (b.hasAttribute('data-a11y-toggle')) {
      var k = b.getAttribute('data-a11y-toggle');
      st[k] = !st[k]; apply(); save();
      say(b.querySelector('b').textContent + (st[k] ? ' on' : ' off'));
      return;
    }
    if (b.hasAttribute('data-a11y-reset')) { st = {}; apply(); save(); say('All accessibility options reset'); }
  });
  panel.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { e.stopPropagation(); close(); }
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !panel.hidden) close(); });
  document.addEventListener('click', function (e) { if (!panel.hidden && !root.contains(e.target)) close(false); });
  apply();
})();
