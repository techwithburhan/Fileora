/* Fileora theme: header and footer motion with GSAP 3 + ScrollTrigger.
   Runs only when <html> has "fo-motion": the Customizer setting is on, the visitor's
   system doesn't ask for reduced motion, and "Stop animations" isn't chosen. */
(function () {
  'use strict';
  var d = document.documentElement;
  var done = function () { d.classList.add('fo-motion-done'); };
  if (!window.gsap || !d.classList.contains('fo-motion')) { done(); return; }
  var gsap = window.gsap;
  if (window.ScrollTrigger) gsap.registerPlugin(window.ScrollTrigger);
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var stopped = function () { return d.classList.contains('fo-a11y-motion'); };

  /* ---------- header: entrance ---------- */
  var logo = $('.hdr-in > .logo');
  var navItems = $$('.hdr .nav-btn, .hdr .nav > ul > li, .hdr .nav .menu > li');
  var actions = $$('.hdr-actions > *');
  if (logo) gsap.from(logo, { y: -12, autoAlpha: 0, duration: 0.55, ease: 'power3.out', clearProps: 'transform,opacity,visibility' });
  if (navItems.length) gsap.from(navItems, { y: -10, autoAlpha: 0, duration: 0.45, stagger: 0.05, delay: 0.08, ease: 'power2.out', clearProps: 'transform,opacity,visibility' });
  if (actions.length) gsap.from(actions, { scale: 0.85, autoAlpha: 0, duration: 0.4, stagger: 0.06, delay: 0.16, ease: 'back.out(2)', clearProps: 'transform,opacity,visibility' });
  done();

  /* ---------- header: scroll progress (blog posts have their own bar) ---------- */
  var bar = $('.hdr-progress');
  if (bar && window.ScrollTrigger && !document.getElementById('read-progress')) {
    gsap.to(bar, { scaleX: 1, ease: 'none', scrollTrigger: { start: 0, end: 'max', scrub: 0.3 } });
  } else if (bar) {
    bar.remove();
  }

  /* ---------- header: gentle "magnetic" pull on the contact link and buttons (mouse only) ---------- */
  if (matchMedia('(pointer: fine)').matches) {
    $$('.nav .menu-contact > a, .hdr-actions .icon-btn, .hdr-actions .search-trigger').forEach(function (el) {
      var xTo = gsap.quickTo(el, 'x', { duration: 0.4, ease: 'power3' });
      var yTo = gsap.quickTo(el, 'y', { duration: 0.4, ease: 'power3' });
      el.addEventListener('pointermove', function (e) {
        if (stopped()) return;
        var r = el.getBoundingClientRect();
        xTo((e.clientX - r.left - r.width / 2) * 0.18);
        yTo((e.clientY - r.top - r.height / 2) * 0.25);
      });
      el.addEventListener('pointerleave', function () { xTo(0); yTo(0); });
    });
  }

  /* ---------- tools menu and mobile drawer: animate when opened ---------- */
  var watch = function (el, run) {
    if (!el || !window.MutationObserver) return;
    new MutationObserver(function () { if (!el.hidden && !stopped()) run(); }).observe(el, { attributes: true, attributeFilter: ['hidden'] });
  };
  var mega = document.getElementById('mega');
  watch(mega, function () {
    gsap.fromTo($$('.mega-col', mega), { y: 14, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: 0.35, stagger: 0.04, ease: 'power2.out', overwrite: true, clearProps: 'transform' });
  });
  var drawer = document.getElementById('drawer');
  watch(drawer, function () {
    gsap.fromTo($('.drawer-panel', drawer), { xPercent: 8, autoAlpha: 0 }, { xPercent: 0, autoAlpha: 1, duration: 0.35, ease: 'power3.out', clearProps: 'transform' });
    gsap.fromTo($$('.drawer-body > *', drawer), { y: 10, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: 0.3, stagger: 0.03, delay: 0.08, ease: 'power2.out', clearProps: 'transform' });
  });

  /* ---------- footer: columns rise in, glow drifts slowly while visible ---------- */
  if (window.ScrollTrigger) {
    var cols = $$('.ftr-top > *');
    if (cols.length) gsap.from(cols, { y: 28, autoAlpha: 0, duration: 0.7, stagger: 0.08, ease: 'power3.out', clearProps: 'transform,opacity,visibility', scrollTrigger: { trigger: '.ftr', start: 'top 90%', once: true } });
    var bottom = $$('.ftr-bottom > *');
    if (bottom.length) gsap.from(bottom, { y: 12, autoAlpha: 0, duration: 0.5, stagger: 0.06, ease: 'power2.out', clearProps: 'transform,opacity,visibility', scrollTrigger: { trigger: '.ftr-bottom', start: 'top 99%', once: true } });
    var glow = gsap.timeline({ repeat: -1, yoyo: true, paused: true });
    $$('.ftr-glow span').forEach(function (s, i) {
      glow.to(s, { x: [60, -50, 40][i] || 30, y: [30, -40, -20][i] || 20, scale: [1.15, 0.9, 1.1][i] || 1, duration: 7 + i * 1.5, ease: 'sine.inOut' }, 0);
    });
    window.ScrollTrigger.create({ trigger: '.ftr', start: 'top bottom', end: 'bottom top', onToggle: function (self) { if (self.isActive && !stopped()) glow.play(); else glow.pause(); } });
  }

  /* ---------- back to top: smooth, and focus goes to the top of the page ---------- */
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-to-top]');
    if (!a) return;
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: stopped() ? 'auto' : 'smooth' });
    var first = $('.skip') || $('#hdr a');
    if (first) first.focus({ preventScroll: true });
  });

  /* ---------- "Stop animations" chosen in the accessibility panel: stop everything now ---------- */
  document.addEventListener('fileora:a11y', function (e) {
    if (e.detail && e.detail.motion) {
      gsap.globalTimeline.pause();
      gsap.set($$('.hdr-in *, .ftr-top > *, .ftr-bottom > *, .mega-col, .drawer-panel, .drawer-body > *'), { clearProps: 'transform,opacity,visibility' });
    } else {
      gsap.globalTimeline.resume();
    }
  });
})();
