<?php
/**
 * Site header.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<span id="top"></span>
<a class="skip" href="#main"><?php esc_html_e( 'Skip to content', 'fileora' ); ?></a>

<header class="hdr" id="hdr">
	<span class="hdr-progress" aria-hidden="true"></span>
	<div class="wrap hdr-in">
		<?php fileora_theme_logo(); ?>
		<nav class="nav" aria-label="<?php esc_attr_e( 'Main', 'fileora' ); ?>">
			<?php if ( fileora_theme_groups() ) : ?>
				<button class="nav-btn" type="button" aria-expanded="false" aria-controls="mega" data-mega><?php esc_html_e( 'Tools', 'fileora' ); ?><?php fileora_theme_e_icon( 'chev-down' ); ?></button>
			<?php endif; ?>
			<?php fileora_theme_primary_menu(); ?>
		</nav>
		<div class="hdr-actions">
			<button class="search-trigger" type="button" data-palette aria-label="<?php esc_attr_e( 'Search', 'fileora' ); ?>">
				<?php fileora_theme_e_icon( 'search' ); ?>
				<span><?php echo esc_html( fileora_theme_core() ? __( 'Search tools…', 'fileora' ) : __( 'Search…', 'fileora' ) ); ?></span>
				<kbd>/</kbd>
			</button>
			<button class="icon-btn theme-toggle" type="button" data-theme-toggle aria-label="<?php esc_attr_e( 'Switch light or dark mode', 'fileora' ); ?>">
				<?php fileora_theme_e_icon( 'sun', 'ic sun' ); ?><?php fileora_theme_e_icon( 'moon', 'ic moon' ); ?>
			</button>
			<?php if ( fileora_theme_mod( 'header_login' ) ) : ?>
				<?php if ( is_user_logged_in() ) : ?>
					<a class="btn-link" href="<?php echo esc_url( admin_url() ); ?>"><?php esc_html_e( 'Account', 'fileora' ); ?></a>
				<?php else : ?>
					<a class="btn-link" href="<?php echo esc_url( wp_login_url() ); ?>"><?php echo esc_html( fileora_theme_mod( 'login_label' ) ); ?></a>
					<?php if ( get_option( 'users_can_register' ) ) : ?>
						<a class="btn btn-ink btn-sm" href="<?php echo esc_url( wp_registration_url() ); ?>"><?php echo esc_html( fileora_theme_mod( 'signup_label' ) ); ?></a>
					<?php endif; ?>
				<?php endif; ?>
			<?php endif; ?>
			<button class="icon-btn menu-btn" type="button" data-drawer aria-controls="drawer" aria-expanded="false" aria-label="<?php esc_attr_e( 'Open menu', 'fileora' ); ?>"><?php fileora_theme_e_icon( 'menu' ); ?></button>
		</div>
	</div>
	<?php fileora_theme_mega_menu(); ?>
</header>
<?php fileora_theme_drawer(); ?>
