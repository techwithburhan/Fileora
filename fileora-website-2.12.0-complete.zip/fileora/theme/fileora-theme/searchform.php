<?php
/**
 * Search form.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;
$fileora_id = wp_unique_id( 'search-' );
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="sr" for="<?php echo esc_attr( $fileora_id ); ?>"><?php esc_html_e( 'Search for', 'fileora' ); ?></label>
	<input type="search" id="<?php echo esc_attr( $fileora_id ); ?>" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search tools and articles', 'fileora' ); ?>">
	<button type="submit"><?php esc_html_e( 'Search', 'fileora' ); ?></button>
</form>
