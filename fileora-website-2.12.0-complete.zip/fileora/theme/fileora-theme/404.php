<?php
/**
 * Page not found.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="main">
	<div class="wrap empty" style="padding:96px 0 120px">
		<span class="tile lg"><?php fileora_theme_e_icon( 'file' ); ?></span>
		<h1 class="h2" style="margin:18px 0 10px"><?php esc_html_e( 'This page doesn’t exist', 'fileora' ); ?></h1>
		<p><?php esc_html_e( 'The link may be old, or the address has a typo. Search for what you need:', 'fileora' ); ?></p>
		<div style="display:flex;justify-content:center;margin-top:20px"><?php get_search_form(); ?></div>
		<p style="margin-top:20px"><a class="btn btn-ink" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Go to the homepage', 'fileora' ); ?></a></p>
	</div>
</main>
<?php
get_footer();
