<?php
/**
 * A tool page (/merge-pdf/): title, the workspace from Fileora Core, the
 * page text written in the editor, related tools and the FAQ.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
	the_post();
	$fileora_tool = fileora_theme_core() ? fileora_get_tool( get_post() ) : null;
	$fileora_cat  = $fileora_tool && $fileora_tool['category'] ? $fileora_tool['category'] : null;
	$fileora_col  = $fileora_cat ? $fileora_cat['color'] : 'organize';
	$fileora_desc = has_excerpt() ? get_the_excerpt() : ( $fileora_tool ? $fileora_tool['desc'] : '' );
	?>
	<main id="main" data-cat="<?php echo esc_attr( $fileora_col ); ?>">
		<section class="tool-hero">
			<div class="wrap">
				<?php
				$fileora_trail = array();
				if ( $fileora_cat ) {
					$fileora_trail[ $fileora_cat['name'] ] = fileora_theme_all_tools_url( 'cat-' . sanitize_title( $fileora_cat['slug'] ) );
				}
				$fileora_trail[ get_the_title() ] = '';
				fileora_theme_crumbs( $fileora_trail );
				?>
				<div class="tool-hero-in">
					<?php if ( $fileora_tool ) : ?><span class="tile lg"><?php fileora_theme_e_icon( $fileora_tool['icon'] ); ?></span><?php endif; ?>
					<div>
						<h1><?php the_title(); ?></h1>
						<?php if ( $fileora_desc ) : ?><p class="lede"><?php echo esc_html( $fileora_desc ); ?></p><?php endif; ?>
						<?php if ( $fileora_tool ) : ?><div class="tool-badges"><?php echo fileora_theme_tool_tags( $fileora_tool ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
					</div>
				</div>
			</div>
		</section>

		<section class="tool-body">
			<div class="wrap">
				<?php
				if ( $fileora_tool ) {
					echo fileora_render_workspace( $fileora_tool ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built by Fileora Core with escaping
				} elseif ( current_user_can( 'activate_plugins' ) ) {
					echo '<div class="notice-box">' . fileora_theme_icon( 'info' ) . '<p>' . esc_html__( 'Activate the Fileora Core plugin to show this tool.', 'fileora' ) . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				?>
			</div>
		</section>

		<?php
		$fileora_related = array();
		if ( $fileora_cat ) {
			foreach ( fileora_theme_groups() as $g ) {
				if ( (int) $g['id'] === (int) $fileora_cat['id'] ) {
					foreach ( $g['tools'] as $t ) {
						if ( $t['id'] !== $fileora_tool['id'] && 'ready' === $t['status'] ) {
							$fileora_related[] = $t;
						}
					}
				}
			}
		}
		$fileora_has_text = '' !== trim( wp_strip_all_tags( get_the_content() ) );
		if ( $fileora_has_text || $fileora_related ) :
			?>
			<section class="wrap tool-info">
				<div class="prose"><?php the_content(); ?></div>
				<?php if ( $fileora_related ) : ?>
					<aside class="tool-aside" aria-labelledby="rel-h">
						<?php /* translators: %s: category name */ ?>
						<h2 id="rel-h"><?php echo esc_html( sprintf( __( 'More %s', 'fileora' ), $fileora_cat['name'] ) ); ?></h2>
						<ul>
							<?php foreach ( array_slice( $fileora_related, 0, 8 ) as $t ) : ?>
								<li><a href="<?php echo esc_url( $t['url'] ); ?>"><span class="tile sm"><?php fileora_theme_e_icon( $t['icon'] ); ?></span><?php echo esc_html( $t['name'] ); ?></a></li>
							<?php endforeach; ?>
						</ul>
					</aside>
				<?php endif; ?>
			</section>
		<?php endif; ?>

		<?php
		$fileora_faq = fileora_theme_core() ? fileora_tool_faq() : array();
		if ( $fileora_faq ) :
			?>
			<section class="wrap tool-faq">
				<?php get_template_part( 'template-parts/faq', null, array( 'items' => $fileora_faq ) ); ?>
			</section>
		<?php endif; ?>
	</main>
	<?php
endwhile;

get_footer();
