<?php
/**
 * The tool catalogue: category tabs, a filter, "In browser only", and a grid
 * per category. Used on the homepage and the "All tools" page.
 *
 * $args: 'heading' (string, optional), 'text' (string, optional), 'level' ('h1'|'h2').
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

$groups = fileora_theme_groups();
if ( ! $groups ) {
	return;
}
$total   = 0;
foreach ( $groups as $g ) {
	$total += count( $g['tools'] );
}
$level   = isset( $args['level'] ) && 'h1' === $args['level'] ? 'h1' : 'h2';
$heading = isset( $args['heading'] ) ? $args['heading'] : '';
$cat_h   = 'h1' === $level ? 'h2' : 'h3'; // category names one level below the heading, tool names one below that
$text    = isset( $args['text'] ) ? $args['text'] : '';
?>
<section class="tools" id="tools" aria-labelledby="tools-h">
	<div class="wrap">
		<div class="sec-head tools-head">
			<div>
				<<?php echo $level; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> class="h2" id="tools-h"><?php echo esc_html( $heading ); ?></<?php echo $level; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
				<?php if ( $text ) : ?><p><?php echo esc_html( fileora_theme_tokens( $text ) ); ?></p><?php endif; ?>
			</div>
		</div>
		<div class="recent" id="recent" hidden></div>
	</div>
	<div class="toolbar" id="toolbar">
		<div class="wrap toolbar-in">
			<div class="tabs" role="tablist" aria-label="<?php esc_attr_e( 'Tool categories', 'fileora' ); ?>">
				<button class="tab" type="button" role="tab" aria-selected="true" data-tab="all"><?php esc_html_e( 'All', 'fileora' ); ?> <span class="n"><?php echo esc_html( number_format_i18n( $total ) ); ?></span></button>
				<?php foreach ( $groups as $g ) : ?>
					<button class="tab" type="button" role="tab" aria-selected="false" data-tab="<?php echo esc_attr( fileora_theme_cat_anchor( $g ) ); ?>"><?php echo esc_html( $g['name'] ); ?> <span class="n"><?php echo esc_html( number_format_i18n( count( $g['tools'] ) ) ); ?></span></button>
				<?php endforeach; ?>
			</div>
			<div class="tb-right">
				<label class="filter"><?php fileora_theme_e_icon( 'search', 'ic ic-sm' ); ?><span class="sr"><?php esc_html_e( 'Filter tools', 'fileora' ); ?></span><input type="search" id="tool-filter" placeholder="<?php esc_attr_e( 'Filter tools', 'fileora' ); ?>" autocomplete="off"></label>
				<button class="toggle-chip" type="button" aria-pressed="false" id="local-only" title="<?php esc_attr_e( 'Only tools that never upload your file', 'fileora' ); ?>"><?php fileora_theme_e_icon( 'device' ); ?><span><?php esc_html_e( 'In browser only', 'fileora' ); ?></span></button>
			</div>
		</div>
	</div>
	<div class="wrap catalog" id="catalog">
		<?php foreach ( $groups as $g ) : ?>
			<div class="cat-block" id="<?php echo esc_attr( fileora_theme_cat_anchor( $g ) ); ?>" data-cat="<?php echo esc_attr( $g['color'] ); ?>">
				<div class="cat-head">
					<<?php echo $cat_h; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> class="cat-name"><span class="dot"></span><?php echo esc_html( $g['name'] ); ?></<?php echo $cat_h; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
					<?php /* translators: %d: number of tools */ ?>
					<span class="cnt"><?php echo esc_html( sprintf( _n( '%d tool', '%d tools', count( $g['tools'] ), 'fileora' ), count( $g['tools'] ) ) ); ?></span>
					<?php if ( $g['desc'] ) : ?><p><?php echo esc_html( $g['desc'] ); ?></p><?php endif; ?>
				</div>
				<div class="grid">
					<?php
					foreach ( $g['tools'] as $t ) {
						get_template_part( 'template-parts/tool-card', null, array( 'tool' => $t, 'level' => 'h1' === $level ? 3 : 4 ) );
					}
					?>
				</div>
			</div>
		<?php endforeach; ?>
		<div class="empty" id="catalog-empty" hidden>
			<span class="tile lg"><?php fileora_theme_e_icon( 'search' ); ?></span>
			<p class="empty-title"><?php esc_html_e( 'No tool matches', 'fileora' ); ?></p>
			<p><?php esc_html_e( 'Try another word, or clear the filter.', 'fileora' ); ?></p>
			<button class="btn btn-line" type="button" id="filter-clear"><?php esc_html_e( 'Show all tools', 'fileora' ); ?></button>
		</div>
	</div>
</section>
