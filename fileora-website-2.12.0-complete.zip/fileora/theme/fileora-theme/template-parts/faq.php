<?php
/**
 * A FAQ list. $args['items'] = [ ['q' => ..., 'a' => ...], ... ], $args['heading'], $args['intro'].
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

$items = isset( $args['items'] ) ? $args['items'] : array();
if ( ! $items ) {
	return;
}
?>
<div class="faq-in">
	<div>
		<h2 class="h2"><?php echo esc_html( isset( $args['heading'] ) ? $args['heading'] : __( 'Questions, answered', 'fileora' ) ); ?></h2>
		<?php if ( ! empty( $args['intro'] ) ) : ?><p><?php echo wp_kses_post( $args['intro'] ); ?></p><?php endif; ?>
	</div>
	<div class="qa">
		<?php foreach ( $items as $i => $qa ) : ?>
			<details<?php echo 0 === $i ? ' open' : ''; ?>>
				<summary><?php echo esc_html( $qa['q'] ); ?><?php fileora_theme_e_icon( 'plus' ); ?></summary>
				<p><?php echo esc_html( $qa['a'] ); ?></p>
			</details>
		<?php endforeach; ?>
	</div>
</div>
