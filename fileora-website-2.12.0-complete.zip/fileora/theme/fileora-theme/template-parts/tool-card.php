<?php
/**
 * One tool card. Expects $args['tool'] (a Fileora Core tool array).
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

$t = $args['tool'];
$h = isset( $args['level'] ) && in_array( (int) $args['level'], array( 2, 3, 4 ), true ) ? 'h' . (int) $args['level'] : 'h4'; // heading level of the tool name
$c = $t['category'] ? $t['category']['color'] : 'organize';
?>
<article class="tool" data-cat="<?php echo esc_attr( $c ); ?>" data-id="<?php echo esc_attr( $t['id'] ); ?>" data-runs="<?php echo esc_attr( fileora_runs_on( $t ) ); ?>" data-keys="<?php echo esc_attr( strtolower( $t['name'] . ' ' . $t['desc'] . ' ' . $t['keys'] ) ); ?>">
	<span class="tile"><?php fileora_theme_e_icon( $t['icon'] ); ?></span>
	<div class="tx">
		<<?php echo $h; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> class="tool-name"><a class="tool-link" href="<?php echo esc_url( $t['url'] ); ?>"><?php echo esc_html( $t['name'] ); ?></a></<?php echo $h; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
		<p><?php echo esc_html( $t['desc'] ); ?></p>
		<div class="tool-meta"><?php echo fileora_theme_tool_tags( $t ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
	</div>
</article>
