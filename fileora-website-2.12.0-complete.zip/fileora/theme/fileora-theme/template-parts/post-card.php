<?php
/**
 * A blog post card (inside the loop). $args['featured'] = true for the large card.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

$fileora_featured = ! empty( $args['featured'] );
$fileora_cats     = get_the_category();
$fileora_cat      = $fileora_cats && 'uncategorized' !== $fileora_cats[0]->slug ? $fileora_cats[0] : null;
?>
<article <?php post_class( $fileora_featured ? 'post-card featured-card' : 'post-card' ); ?>>
	<div class="thumb"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( $fileora_featured ? 'post-thumbnail' : 'fileora-card', array( 'loading' => $fileora_featured ? 'eager' : 'lazy', 'alt' => '' ) ); } ?></div>
	<div class="body">
		<?php if ( $fileora_cat ) : ?><span class="kicker"><?php echo esc_html( $fileora_cat->name ); ?></span><?php endif; ?>
		<?php if ( $fileora_featured ) : ?>
			<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<?php else : ?>
			<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<?php endif; ?>
		<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), $fileora_featured ? 36 : 22 ) ); ?></p>
		<div class="meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time><span>·</span><span><?php $fileora_m = max( 1, (int) round( str_word_count( wp_strip_all_tags( get_the_content() ) ) / 220 ) ); /* translators: %d: minutes */ echo esc_html( sprintf( _n( '%d min read', '%d min read', $fileora_m, 'fileora' ), $fileora_m ) ); ?></span></div>
	</div>
</article>
