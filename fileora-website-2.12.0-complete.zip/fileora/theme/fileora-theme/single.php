<?php
/**
 * A blog post: title, meta, featured image, table of contents, content,
 * tools used in the guide, share links, author, related posts, comments.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
$fileora_blog = fileora_theme_blog_url();
while ( have_posts() ) :
	the_post();
	list( $fileora_html, $fileora_items ) = fileora_theme_post_body();
	$fileora_toc   = fileora_theme_toc( $fileora_items );
	$fileora_tools = fileora_theme_post_tools();
	$fileora_cats  = get_the_category();
	?>
	<div class="read-progress" aria-hidden="true"><span id="read-progress"></span></div>
	<main id="main">
		<article <?php post_class( 'post-single' ); ?>>
			<header class="post-head wrap">
				<?php
				$fileora_trail = array();
				if ( $fileora_blog ) {
					$fileora_trail[ __( 'Blog', 'fileora' ) ] = $fileora_blog;
				}
				if ( $fileora_cats && 'uncategorized' !== $fileora_cats[0]->slug ) {
					$fileora_trail[ $fileora_cats[0]->name ] = get_category_link( $fileora_cats[0] );
				}
				$fileora_trail[ get_the_title() ] = '';
				fileora_theme_crumbs( $fileora_trail );
				?>
				<h1><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?><p class="post-lede"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
				<div class="post-byline">
					<?php echo get_avatar( get_the_author_meta( 'ID' ), 36, '', '' ); ?>
					<div><b><?php the_author(); ?></b><?php fileora_theme_post_meta(); ?></div>
				</div>
			</header>
			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="post-cover wrap"><?php the_post_thumbnail( 'post-thumbnail', array( 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?></figure>
			<?php endif; ?>

			<div class="wrap post-layout<?php echo $fileora_toc ? '' : ' no-toc'; ?>">
				<?php if ( $fileora_toc ) : ?>
					<div class="post-side"><?php echo $fileora_toc; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped when built ?></div>
				<?php endif; ?>
				<div class="post-main">
					<?php if ( $fileora_toc ) : ?>
						<details class="toc-mobile"><summary><?php esc_html_e( 'On this page', 'fileora' ); ?><?php fileora_theme_e_icon( 'chev-down' ); ?></summary><?php echo $fileora_toc; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></details>
					<?php endif; ?>
					<div class="prose"><?php echo $fileora_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the_content output ?></div>
					<?php wp_link_pages( array( 'before' => '<nav class="pagination">', 'after' => '</nav>' ) ); ?>

					<?php if ( $fileora_tools ) : ?>
						<section class="post-tools" aria-labelledby="pt-h">
							<h2 id="pt-h"><?php esc_html_e( 'Tools used in this guide', 'fileora' ); ?></h2>
							<p><?php esc_html_e( 'Free, no sign-up. Browser tools never upload your file.', 'fileora' ); ?></p>
							<div class="grid">
								<?php
								foreach ( $fileora_tools as $t ) {
									get_template_part( 'template-parts/tool-card', null, array( 'tool' => $t, 'level' => 3 ) );
								}
								?>
							</div>
						</section>
					<?php endif; ?>

					<?php
					$fileora_tags = get_the_tags();
					if ( $fileora_tags ) {
						echo '<div class="post-tags">';
						foreach ( $fileora_tags as $tag ) {
							echo '<a class="tag" href="' . esc_url( get_tag_link( $tag ) ) . '">#' . esc_html( $tag->name ) . '</a>';
						}
						echo '</div>';
					}
					fileora_theme_share();
					fileora_theme_author_box();
					?>

					<?php
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
					?>
				</div>
			</div>
		</article>

		<?php
		$fileora_rel = fileora_theme_related_posts( 3 );
		if ( $fileora_rel->post_count ) :
			?>
			<section class="sec related-posts" aria-labelledby="rp-h">
				<div class="wrap">
					<div class="sec-head"><h2 class="h2" id="rp-h"><?php esc_html_e( 'Keep reading', 'fileora' ); ?></h2>
						<?php if ( $fileora_blog ) : ?><a class="more-link" href="<?php echo esc_url( $fileora_blog ); ?>"><?php esc_html_e( 'All posts', 'fileora' ); ?><?php fileora_theme_e_icon( 'arrow-right', 'ic ic-sm' ); ?></a><?php endif; ?>
					</div>
					<div class="posts">
						<?php
						global $post;
						foreach ( $fileora_rel->posts as $post ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
							setup_postdata( $post );
							get_template_part( 'template-parts/post-card' );
						}
						wp_reset_postdata();
						?>
					</div>
				</div>
			</section>
		<?php endif; ?>
	</main>
	<?php
endwhile;
get_footer();
