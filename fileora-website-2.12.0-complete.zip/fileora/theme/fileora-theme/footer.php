<?php
/**
 * Site footer, plus the search palette and the "which tool?" dialog.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

$fileora_titles = array_pad( array_map( 'trim', explode( '|', (string) fileora_theme_mod( 'footer_titles' ) ) ), 4, '' );
?>
<footer class="ftr">
	<div class="ftr-glow" aria-hidden="true"><span></span><span></span><span></span></div>
	<div class="wrap">
		<div class="ftr-top">
			<div class="ftr-brand">
				<?php fileora_theme_logo(); ?>
				<p><?php echo esc_html( fileora_theme_mod( 'footer_about' ) ); ?></p>
				<?php fileora_theme_social(); ?>
			</div>
			<?php
			for ( $fileora_i = 1; $fileora_i <= 4; $fileora_i++ ) {
				echo '<div>';
				fileora_theme_footer_column( $fileora_i, $fileora_titles[ $fileora_i - 1 ] );
				echo '</div>';
			}
			?>
		</div>
		<div class="ftr-bottom">
			<span><?php echo esc_html( fileora_theme_tokens( fileora_theme_mod( 'footer_copy' ) ) ); ?></span>
			<?php fileora_theme_credit(); ?>
			<?php
			// Only a menu you assign to "Footer bottom links" shows here; the Privacy Policy is already in the Information column.
			if ( has_nav_menu( 'legal' ) ) {
				wp_nav_menu( array( 'theme_location' => 'legal', 'container' => 'nav', 'container_class' => 'social', 'depth' => 1, 'items_wrap' => '%3$s', 'fallback_cb' => false ) );
			}
			?>
			<a class="to-top" href="#top" data-to-top><?php esc_html_e( 'Back to top', 'fileora' ); ?><svg class="ic ic-sm" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 19V5m-6 6 6-6 6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
		</div>
	</div>
</footer>

<div class="ov" id="palette" hidden>
	<div class="ov-bg" data-close></div>
	<div class="pl-box" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Search', 'fileora' ); ?>">
		<div class="pl-in">
			<?php fileora_theme_e_icon( 'search' ); ?>
			<input type="search" id="pl-q" autocomplete="off" spellcheck="false" placeholder="<?php echo esc_attr( fileora_theme_core() ? __( 'Search tools, e.g. “merge” or “jpg to pdf”', 'fileora' ) : __( 'Search the site', 'fileora' ) ); ?>" role="combobox" aria-expanded="true" aria-controls="pl-list" aria-autocomplete="list">
			<button class="icon-btn sm" type="button" data-close aria-label="<?php esc_attr_e( 'Close', 'fileora' ); ?>"><?php fileora_theme_e_icon( 'x' ); ?></button>
		</div>
		<div class="pl-list" id="pl-list" role="listbox"></div>
		<div class="pl-foot"><span><kbd>↑</kbd><kbd>↓</kbd> <?php esc_html_e( 'move', 'fileora' ); ?></span><span><kbd>Enter</kbd> <?php esc_html_e( 'open', 'fileora' ); ?></span><span><kbd>Esc</kbd> <?php esc_html_e( 'close', 'fileora' ); ?></span></div>
	</div>
</div>

<?php if ( fileora_theme_core() ) : ?>
<div class="ov" id="suggest" hidden>
	<div class="ov-bg" data-close></div>
	<div class="modal-box" role="dialog" aria-modal="true" aria-labelledby="sg-title">
		<div class="modal-head">
			<div><h2 id="sg-title"><?php esc_html_e( 'What should we do with your files?', 'fileora' ); ?></h2><p><?php esc_html_e( 'Pick a tool. Your files go straight into it.', 'fileora' ); ?></p></div>
			<button class="icon-btn" type="button" data-close aria-label="<?php esc_attr_e( 'Close', 'fileora' ); ?>"><?php fileora_theme_e_icon( 'x' ); ?></button>
		</div>
		<div class="modal-body"><div class="sg-files" id="sg-files"></div><div id="sg-list"></div></div>
	</div>
</div>
<div class="page-drop" id="page-drop" hidden><div><?php fileora_theme_e_icon( 'upload' ); ?><strong><?php esc_html_e( 'Drop your files', 'fileora' ); ?></strong><span><?php esc_html_e( 'We’ll suggest the right tool.', 'fileora' ); ?></span></div></div>
<?php endif; ?>

<?php fileora_theme_a11y_widget(); ?>
<?php wp_footer(); ?>
</body>
</html>
