<?php
/**
 * The ATS Resume Builder page: a wide layout, so the form and the live
 * preview fit side by side. The builder ([fileora_resume_builder]) and the
 * guide under it come from the page content.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
while ( have_posts() ) :
	the_post();
	?>
	<main id="main">
		<article <?php post_class( 'resume-page' ); ?>>
			<header class="page-head wrap resume-head">
				<?php fileora_theme_crumbs( array( get_the_title() => '' ) ); ?>
				<h1><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="page-lede"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
			</header>
			<div class="wrap resume-body">
				<?php the_content(); ?>
			</div>
		</article>
	</main>
	<?php
endwhile;
get_footer();
