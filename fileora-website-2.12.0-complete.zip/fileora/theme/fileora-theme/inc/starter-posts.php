<?php
/**
 * Appearance → Starter content: imports the ready-written information pages
 * (starter-content/pages) and blog guides (starter-content/posts), written
 * in Markdown with a small header, as WordPress pages and posts with
 * categories, tags, featured images and SEO fields for Yoast SEO, Rank Math
 * or the theme's own meta tags.
 *
 * To add your own: put another .md file and its cover image in
 * starter-content/. Posts that already exist (same address) are skipped.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

/** Category descriptions (used on category pages and in their meta description). */
function fileora_starter_category_descriptions() {
	return array(
		'Aadhaar & ID' => __( 'Download, unlock and print Aadhaar, PAN, voter ID and other ID cards at the correct size.', 'fileora' ),
		'PDF Guides'   => __( 'Step-by-step guides to compress, convert, merge, split and fix PDF files, on a computer or a phone.', 'fileora' ),
		'Exam Forms'   => __( 'Photo, signature and document rules for online exam and job applications, and how to meet them.', 'fileora' ),
		'Image Guides' => __( 'Resize, compress, crop and convert photos for forms, websites and social media.', 'fileora' ),
	);
}

/** Starter content of one kind ('posts' or 'pages'): [ file => [meta..., body] ]. */
function fileora_starter_posts( $kind = 'posts' ) {
	$out = array();
	foreach ( (array) glob( FILEORA_THEME_DIR . '/starter-content/' . ( 'pages' === $kind ? 'pages' : 'posts' ) . '/*.md' ) as $file ) {
		$p = fileora_starter_parse( (string) file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( $p && ! empty( $p['title'] ) && ! empty( $p['slug'] ) ) {
			$p['kind']                         = 'pages' === $kind ? 'page' : 'post';
			$out[ $kind . '/' . basename( $file ) ] = $p;
		}
	}
	ksort( $out );
	return $out;
}

/** Splits the "---" header from the body. */
function fileora_starter_parse( $text ) {
	$text = str_replace( "\r\n", "\n", $text );
	if ( ! preg_match( '/^---\n(.*?)\n---\n(.*)$/s', $text, $m ) ) {
		return null;
	}
	$meta = array();
	foreach ( explode( "\n", $m[1] ) as $line ) {
		if ( preg_match( '/^([a-z_]+):\s*(.*)$/', $line, $kv ) ) {
			$meta[ $kv[1] ] = trim( $kv[2] );
		}
	}
	$meta['body'] = trim( $m[2] );
	return $meta;
}

/* ---------------------------------------------------------------------------
 * Markdown (the small subset used in the guides) → block editor markup.
 * ------------------------------------------------------------------------- */

function fileora_starter_inline( $s ) {
	$home  = untrailingslashit( home_url() );
	$codes = array();
	// Keep [fileora_…] shortcodes exactly as written.
	$s = preg_replace_callback(
		'/\[fileora_[a-z_]+(?:\s[^\]]*)?\]/',
		function ( $m ) use ( &$codes ) {
			$codes[] = $m[0];
			return "\x01" . ( count( $codes ) - 1 ) . "\x01";
		},
		$s
	);
	$s = esc_html( $s );
	$s    = str_replace( '{home}', $home, $s );
	$s    = preg_replace( '/\*\*(.+?)\*\*/', '<strong>$1</strong>', $s );
	$s    = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $s );
	$s    = preg_replace_callback(
		'/\[([^\]]+)\]\(([^)\s]+)\)/',
		function ( $m ) use ( $home ) {
			$url      = html_entity_decode( $m[2] );
			$external = 0 !== strpos( $url, $home ) && 0 !== strpos( $url, '/' ) && 0 !== strpos( $url, '#' );
			return '<a href="' . esc_url( $url ) . '"' . ( $external ? ' target="_blank" rel="noopener"' : '' ) . '>' . $m[1] . '</a>';
		},
		$s
	);
	return preg_replace_callback(
		'/\x01(\d+)\x01/',
		function ( $m ) use ( $codes ) {
			return $codes[ (int) $m[1] ];
		},
		$s
	);
}

function fileora_starter_list( array $lines ) {
	// Items with an optional nested list (indented "- " lines).
	$ordered = (bool) preg_match( '/^\d+\.\s/', $lines[0] );
	$items   = array();
	foreach ( $lines as $line ) {
		if ( preg_match( '/^\s{2,}-\s+(.*)$/', $line, $m ) && $items ) {
			$items[ count( $items ) - 1 ]['sub'][] = $m[1];
		} elseif ( preg_match( '/^(?:\d+\.|-)\s+(.*)$/', $line, $m ) ) {
			$items[] = array( 'text' => $m[1], 'sub' => array() );
		} elseif ( $items ) {
			$items[ count( $items ) - 1 ]['text'] .= ' ' . trim( $line );
		}
	}
	$tag  = $ordered ? 'ol' : 'ul';
	$html = '<!-- wp:list' . ( $ordered ? ' {"ordered":true}' : '' ) . ' --><' . $tag . ' class="wp-block-list">';
	foreach ( $items as $it ) {
		$html .= '<!-- wp:list-item --><li>' . fileora_starter_inline( $it['text'] );
		if ( $it['sub'] ) {
			$html .= '<!-- wp:list --><ul class="wp-block-list">';
			foreach ( $it['sub'] as $sub ) {
				$html .= '<!-- wp:list-item --><li>' . fileora_starter_inline( $sub ) . '</li><!-- /wp:list-item -->';
			}
			$html .= '</ul><!-- /wp:list -->';
		}
		$html .= '</li><!-- /wp:list-item -->';
	}
	return $html . '</' . $tag . '><!-- /wp:list -->';
}

function fileora_starter_table( array $lines ) {
	$rows = array();
	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( preg_match( '/^\|[\s:\-|]+\|$/', $line ) ) {
			continue; // separator row
		}
		$rows[] = array_map( 'trim', explode( '|', trim( $line, '|' ) ) );
	}
	if ( ! $rows ) {
		return '';
	}
	$head = array_shift( $rows );
	$html = '<!-- wp:table --><figure class="wp-block-table"><table class="has-fixed-layout"><thead><tr>';
	foreach ( $head as $c ) {
		$html .= '<th>' . fileora_starter_inline( $c ) . '</th>';
	}
	$html .= '</tr></thead><tbody>';
	foreach ( $rows as $r ) {
		$html .= '<tr>';
		foreach ( $r as $c ) {
			$html .= '<td>' . fileora_starter_inline( $c ) . '</td>';
		}
		$html .= '</tr>';
	}
	return $html . '</tbody></table></figure><!-- /wp:table -->';
}

function fileora_starter_cta( $slug, $title, $text ) {
	$url = home_url( '/' . sanitize_title( $slug ) . '/' );
	return '<!-- wp:html --><div class="tool-cta"><div><strong>' . esc_html( $title ) . '</strong><p>' . esc_html( $text ) . '</p></div><a href="' . esc_url( $url ) . '">' . esc_html__( 'Open the tool', 'fileora' ) . ' →</a></div><!-- /wp:html -->';
}

function fileora_starter_paragraph( $text, $class = '' ) {
	$attr = $class ? ' {"className":"' . $class . '"}' : '';
	return '<!-- wp:paragraph' . $attr . ' --><p' . ( $class ? ' class="' . $class . '"' : '' ) . '>' . fileora_starter_inline( $text ) . '</p><!-- /wp:paragraph -->';
}

/** Converts a guide body to block markup. */
function fileora_starter_blocks( $md ) {
	$out    = array();
	$blocks = preg_split( "/\n\s*\n/", trim( $md ) );
	$faq    = array();
	$flush  = function () use ( &$faq, &$out ) {
		foreach ( $faq as $qa ) {
			$out[] = '<!-- wp:details --><details class="wp-block-details"><summary>' . fileora_starter_inline( $qa[0] ) . '</summary><!-- wp:paragraph --><p>' . fileora_starter_inline( $qa[1] ) . '</p><!-- /wp:paragraph --></details><!-- /wp:details -->';
		}
		$faq = array();
	};
	foreach ( $blocks as $b ) {
		$lines = explode( "\n", rtrim( $b ) );
		$first = $lines[0];
		if ( 0 === strpos( $first, '??? ' ) ) {
			$faq[] = array( substr( $first, 4 ), trim( implode( ' ', array_slice( $lines, 1 ) ) ) );
			continue;
		}
		$flush();
		if ( preg_match( '/^(#{2,3})\s+(.*)$/', $first, $m ) ) {
			$level = strlen( $m[1] );
			$out[] = '<!-- wp:heading' . ( 3 === $level ? ' {"level":3}' : '' ) . ' --><h' . $level . ' class="wp-block-heading">' . fileora_starter_inline( $m[2] ) . '</h' . $level . '><!-- /wp:heading -->';
			if ( count( $lines ) > 1 ) {
				$out[] = fileora_starter_paragraph( implode( ' ', array_slice( $lines, 1 ) ) );
			}
		} elseif ( preg_match( '/^\[fileora_[a-z_]+(?:\s[^\]]*)?\]$/', trim( $first ) ) ) {
			$out[] = '<!-- wp:shortcode -->' . trim( $first ) . '<!-- /wp:shortcode -->';
		} elseif ( preg_match( '/^\[\[cta:([^|]+)\|([^|]+)\|([^\]]+)\]\]$/', trim( $first ), $m ) ) {
			$out[] = fileora_starter_cta( $m[1], $m[2], $m[3] );
		} elseif ( 0 === strpos( $first, '>' ) ) {
			$text  = trim( implode( ' ', array_map( function ( $l ) { return ltrim( $l, "> \t" ); }, $lines ) ) );
			$out[] = fileora_starter_paragraph( $text, 'callout' );
		} elseif ( 0 === strpos( $first, '|' ) ) {
			$out[] = fileora_starter_table( $lines );
		} elseif ( preg_match( '/^(?:-|\d+\.)\s/', $first ) ) {
			$out[] = fileora_starter_list( $lines );
		} else {
			$out[] = fileora_starter_paragraph( implode( ' ', $lines ) );
		}
	}
	$flush();
	return implode( "\n\n", $out );
}

/* ---------------------------------------------------------------------------
 * Import.
 * ------------------------------------------------------------------------- */

/**
 * Imports one post or page. Returns the post id, 0 when it already exists, or WP_Error.
 * A page whose address is taken by an unpublished draft (like WordPress's
 * default "Privacy Policy" draft) is filled and published instead.
 */
function fileora_starter_import_one( array $p, $status, $offset = 0 ) {
	$type     = isset( $p['kind'] ) && 'page' === $p['kind'] ? 'page' : 'post';
	$existing = get_page_by_path( $p['slug'], OBJECT, $type );
	$reuse    = 0;
	if ( $existing ) {
		if ( 'page' === $type && in_array( $existing->post_status, array( 'draft', 'auto-draft', 'pending' ), true ) ) {
			$reuse = (int) $existing->ID;
		} else {
			return 0;
		}
	}
	$cat_ids = array();
	if ( 'post' === $type ) {
		$descs = fileora_starter_category_descriptions();
		foreach ( array_filter( array_map( 'trim', explode( ',', isset( $p['category'] ) ? $p['category'] : '' ) ) ) as $name ) {
			$term = term_exists( $name, 'category' );
			if ( ! $term ) {
				$term = wp_insert_term( $name, 'category', array( 'description' => isset( $descs[ $name ] ) ? $descs[ $name ] : '' ) );
			}
			if ( ! is_wp_error( $term ) ) {
				$cat_ids[] = (int) $term['term_id'];
			}
		}
	}
	$desc = isset( $p['description'] ) ? $p['description'] : '';
	$seo  = isset( $p['seo_title'] ) ? $p['seo_title'] : '';
	$kw   = isset( $p['focus_keyword'] ) ? $p['focus_keyword'] : '';
	$args = array(
		'post_type'    => $type,
		'post_status'  => $status,
		'post_title'   => $p['title'],
		'post_name'    => $p['slug'],
		'post_excerpt' => 'post' === $type ? $desc : '',
		'post_content' => fileora_starter_blocks( $p['body'] ),
		'post_author'  => get_current_user_id(),
		'menu_order'   => isset( $p['order'] ) ? (int) $p['order'] : 0,
		'meta_input'   => array(
			'_fileora_meta_description' => $desc,
			'_fileora_seo_title'        => $seo,
			'_fileora_focus_keyword'    => $kw,
			// Yoast SEO
			'_yoast_wpseo_title'        => $seo ? $seo . ' %%sep%% %%sitename%%' : '',
			'_yoast_wpseo_metadesc'     => $desc,
			'_yoast_wpseo_focuskw'      => $kw,
			// Rank Math
			'rank_math_title'           => $seo ? $seo . ' %sep% %sitename%' : '',
			'rank_math_description'     => $desc,
			'rank_math_focus_keyword'   => $kw,
		),
	);
	if ( 'post' === $type ) {
		$args['post_category'] = $cat_ids;
		$args['post_date']     = wp_date( 'Y-m-d H:i:s', time() - $offset * HOUR_IN_SECONDS );
		$args['tags_input']    = array_filter( array_map( 'trim', explode( ',', isset( $p['tags'] ) ? $p['tags'] : '' ) ) );
	}
	if ( ! empty( $p['role'] ) ) {
		$args['meta_input']['_fileora_page_role'] = sanitize_key( $p['role'] );
	}
	if ( $reuse ) {
		$args['ID'] = $reuse;
		$id         = wp_update_post( $args, true );
	} else {
		$id = wp_insert_post( $args, true );
	}
	if ( is_wp_error( $id ) ) {
		return $id;
	}
	if ( 'page' === $type && 'privacy' === ( isset( $p['role'] ) ? $p['role'] : '' ) ) {
		update_option( 'wp_page_for_privacy_policy', $id );
	}
	if ( ! empty( $p['image'] ) ) {
		fileora_starter_attach_image( $id, $p['image'], $p['title'] );
	}
	return $id;
}

/** Copies a bundled cover image into the Media Library and sets it as the featured image. */
function fileora_starter_attach_image( $post_id, $file, $alt ) {
	$src = FILEORA_THEME_DIR . '/starter-content/images/' . basename( $file );
	if ( ! file_exists( $src ) ) {
		return;
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$tmp = wp_tempnam( basename( $file ) );
	if ( ! $tmp || ! copy( $src, $tmp ) ) {
		return;
	}
	$att = media_handle_sideload( array( 'name' => basename( $file ), 'tmp_name' => $tmp ), $post_id, $alt );
	if ( is_wp_error( $att ) ) {
		wp_delete_file( $tmp );
		return;
	}
	update_post_meta( $att, '_wp_attachment_image_alt', $alt );
	set_post_thumbnail( $post_id, $att );
}

/* ---------------------------------------------------------------------------
 * Admin screen.
 * ------------------------------------------------------------------------- */

add_action( 'admin_menu', 'fileora_starter_menu' );
function fileora_starter_menu() {
	add_theme_page( __( 'Starter content', 'fileora' ), __( 'Starter content', 'fileora' ), 'publish_posts', 'fileora-starter-posts', 'fileora_starter_page' );
}

/* ---------------------------------------------------------------------------
 * SEO packs: ready-written text, title, description and focus keyword for an
 * existing page (starter-content/seo/*.md, "template:" names the page).
 * ------------------------------------------------------------------------- */

function fileora_starter_seo_packs() {
	$out = array();
	foreach ( (array) glob( FILEORA_THEME_DIR . '/starter-content/seo/*.md' ) as $file ) {
		$p = fileora_starter_parse( (string) file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( $p && ! empty( $p['template'] ) ) {
			$out[ basename( $file, '.md' ) ] = $p;
		}
	}
	return $out;
}

/** The published page that uses a page template, or null. */
function fileora_starter_page_by_template( $template ) {
	$pages = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => 1,
			'meta_key'       => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'     => $template, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		)
	);
	return $pages ? $pages[0] : null;
}

add_action( 'admin_post_fileora_apply_seo_pack', 'fileora_starter_apply_pack' );
function fileora_starter_apply_pack() {
	if ( ! current_user_can( 'publish_pages' ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'fileora' ), 403 );
	}
	check_admin_referer( 'fileora_apply_seo_pack' );
	$key   = isset( $_POST['pack'] ) ? sanitize_key( wp_unslash( $_POST['pack'] ) ) : '';
	$packs = fileora_starter_seo_packs();
	$msg   = 'missing';
	if ( isset( $packs[ $key ] ) ) {
		$p    = $packs[ $key ];
		$page = fileora_starter_page_by_template( $p['template'] );
		if ( $page && current_user_can( 'edit_post', $page->ID ) ) {
			$seo  = isset( $p['seo_title'] ) ? $p['seo_title'] : '';
			$desc = isset( $p['description'] ) ? $p['description'] : '';
			$kw   = isset( $p['focus_keyword'] ) ? $p['focus_keyword'] : '';
			wp_update_post(
				array(
					'ID'           => $page->ID,
					'post_title'   => $p['title'],
					'post_excerpt' => isset( $p['excerpt'] ) ? $p['excerpt'] : $page->post_excerpt,
					'post_content' => fileora_starter_blocks( $p['body'] ),
				)
			);
			foreach (
				array(
					'_fileora_meta_description' => $desc,
					'_fileora_seo_title'        => $seo,
					'_fileora_focus_keyword'    => $kw,
					'_yoast_wpseo_title'        => $seo ? $seo . ' %%sep%% %%sitename%%' : '',
					'_yoast_wpseo_metadesc'     => $desc,
					'_yoast_wpseo_focuskw'      => $kw,
					'rank_math_title'           => $seo ? $seo . ' %sep% %sitename%' : '',
					'rank_math_description'     => $desc,
					'rank_math_focus_keyword'   => $kw,
				) as $mk => $mv
			) {
				update_post_meta( $page->ID, $mk, $mv );
			}
			$msg = 'applied';
		}
	}
	wp_safe_redirect( add_query_arg( array( 'page' => 'fileora-starter-posts', 'pack' => $msg ), admin_url( 'themes.php' ) ) );
	exit;
}

add_action( 'admin_post_fileora_import_starter', 'fileora_starter_handle' );
function fileora_starter_handle() {
	if ( ! current_user_can( 'publish_posts' ) || ! current_user_can( 'upload_files' ) ) {
		wp_die( esc_html__( 'You are not allowed to import content.', 'fileora' ), 403 );
	}
	check_admin_referer( 'fileora_import_starter' );
	$status = isset( $_POST['status'] ) && 'draft' === $_POST['status'] ? 'draft' : 'publish';
	$pick   = isset( $_POST['items'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['items'] ) ) : array();
	$all    = array_merge( fileora_starter_posts( 'pages' ), fileora_starter_posts( 'posts' ) );
	$done   = 0;
	$skip   = 0;
	$i      = 0;
	foreach ( $all as $key => $p ) {
		if ( ! in_array( $key, $pick, true ) ) {
			continue;
		}
		if ( 'page' === $p['kind'] && ! current_user_can( 'publish_pages' ) ) {
			++$skip;
			continue;
		}
		$r = fileora_starter_import_one( $p, $status, 'post' === $p['kind'] ? $i++ : 0 );
		if ( is_wp_error( $r ) || 0 === $r ) {
			++$skip;
		} else {
			++$done;
		}
	}
	wp_safe_redirect( add_query_arg( array( 'page' => 'fileora-starter-posts', 'imported' => $done, 'skipped' => $skip ), admin_url( 'themes.php' ) ) );
	exit;
}

function fileora_starter_rows( array $items ) {
	foreach ( $items as $key => $p ) {
		$existing = get_page_by_path( $p['slug'], OBJECT, $p['kind'] );
		$done     = $existing && 'publish' === $existing->post_status;
		echo '<tr><td><input type="checkbox" name="items[]" value="' . esc_attr( $key ) . '"' . ( $done ? ' disabled' : ' checked' ) . '></td>';
		echo '<td><b>' . esc_html( $p['title'] ) . '</b><br><span class="description">/' . esc_html( $p['slug'] ) . '/ · ' . esc_html( isset( $p['description'] ) ? $p['description'] : '' ) . '</span></td>';
		echo '<td>' . esc_html( isset( $p['focus_keyword'] ) ? $p['focus_keyword'] : '' ) . '</td><td>' . esc_html( isset( $p['category'] ) ? $p['category'] : '' ) . '</td>';
		echo '<td>' . ( $done ? '<a href="' . esc_url( get_edit_post_link( $existing ) ) . '">' . esc_html__( 'Imported', 'fileora' ) . '</a>' : ( $existing ? esc_html__( 'Draft exists: will be filled and published', 'fileora' ) : esc_html__( 'Not imported', 'fileora' ) ) ) . '</td></tr>';
	}
}

function fileora_starter_page() {
	echo '<div class="wrap"><h1>' . esc_html__( 'Starter content', 'fileora' ) . '</h1>';
	if ( isset( $_GET['imported'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		/* translators: 1: imported, 2: skipped */
		echo '<div class="notice notice-success"><p>' . esc_html( sprintf( __( '%1$d imported, %2$d skipped (they already exist).', 'fileora' ), absint( $_GET['imported'] ), isset( $_GET['skipped'] ) ? absint( $_GET['skipped'] ) : 0 ) ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}
	if ( isset( $_GET['pack'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		echo 'applied' === $_GET['pack'] ? '<div class="notice notice-success"><p>' . esc_html__( 'The SEO text, title, description and focus keyword were added to the page.', 'fileora' ) . '</p></div>' : '<div class="notice notice-error"><p>' . esc_html__( 'No page uses that template yet.', 'fileora' ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}
	echo '<p>' . esc_html__( 'Ready-written pages and guides. Edit them like any page or post after importing.', 'fileora' ) . '</p>';
	$packs = fileora_starter_seo_packs();
	if ( $packs ) {
		echo '<h2>' . esc_html__( 'SEO text for existing pages', 'fileora' ) . '</h2><p class="description">' . esc_html__( 'Adds ready-written text (shown under the tool list), an SEO title, a meta description, an intro line and a focus keyword to the page. It replaces the page’s current text, so copy anything you wrote yourself first.', 'fileora' ) . '</p><table class="widefat striped" style="max-width:1100px"><tbody>';
		foreach ( $packs as $k => $p ) {
			$page = fileora_starter_page_by_template( $p['template'] );
			echo '<tr><td><b>' . esc_html( $page ? get_the_title( $page ) : $p['title'] ) . '</b><br><span class="description">' . esc_html( $p['seo_title'] ) . '</span></td><td>' . esc_html( $p['focus_keyword'] ) . '</td><td>';
			if ( $page ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:0">';
				wp_nonce_field( 'fileora_apply_seo_pack' );
				echo '<input type="hidden" name="action" value="fileora_apply_seo_pack"><input type="hidden" name="pack" value="' . esc_attr( $k ) . '">';
				echo '<button class="button button-primary"' . ( '' !== trim( $page->post_content ) ? ' onclick="return confirm(\'' . esc_js( __( 'Replace the text that is on this page now?', 'fileora' ) ) . '\')"' : '' ) . '>' . esc_html( '' !== trim( (string) get_post_meta( $page->ID, '_fileora_focus_keyword', true ) ) ? __( 'Apply again', 'fileora' ) : __( 'Apply to the page', 'fileora' ) ) . '</button> <a href="' . esc_url( get_edit_post_link( $page ) ) . '">' . esc_html__( 'Edit page', 'fileora' ) . '</a></form>';
			} else {
				esc_html_e( 'No page uses this template yet.', 'fileora' );
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'fileora_import_starter' );
	echo '<input type="hidden" name="action" value="fileora_import_starter">';
	$head = '<thead><tr><th style="width:30px"></th><th>' . esc_html__( 'Title', 'fileora' ) . '</th><th>' . esc_html__( 'Focus keyword', 'fileora' ) . '</th><th>' . esc_html__( 'Category', 'fileora' ) . '</th><th>' . esc_html__( 'Status', 'fileora' ) . '</th></tr></thead>';
	echo '<h2>' . esc_html__( 'Information pages', 'fileora' ) . '</h2>';
	echo '<p class="description">' . esc_html__( 'About Us, FAQ, Security, Privacy Policy, Disclaimer, Accessibility, Contact and Sitemap. The Privacy Policy and Security pages describe how this site really handles files and visitor data: their tables update themselves from your tool and analytics settings (Fileora Core shortcodes). Read them before publishing, fill in Fileora → Settings → Privacy and Security pages, and adapt the legal text to your situation. They are not legal advice.', 'fileora' ) . '</p>';
	echo '<table class="widefat striped" style="max-width:1100px">' . $head . '<tbody>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	fileora_starter_rows( fileora_starter_posts( 'pages' ) );
	echo '</tbody></table>';
	echo '<h2>' . esc_html__( 'Blog guides', 'fileora' ) . '</h2><table class="widefat striped" style="max-width:1100px">' . $head . '<tbody>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	fileora_starter_rows( fileora_starter_posts( 'posts' ) );
	echo '</tbody></table>';
	echo '<p><label><input type="radio" name="status" value="publish" checked> ' . esc_html__( 'Publish now', 'fileora' ) . '</label> &nbsp; <label><input type="radio" name="status" value="draft"> ' . esc_html__( 'Save as drafts to review first', 'fileora' ) . '</label></p>';
	submit_button( __( 'Import selected', 'fileora' ) );
	echo '</form>';
	echo '<p class="description">' . esc_html__( 'Tip: set Settings → Permalinks to “Post name” before importing, and check sizes, fees and policies once a year.', 'fileora' ) . '</p></div>';
}

/** SEO title for posts when no SEO plugin is active. */
add_filter( 'document_title_parts', 'fileora_starter_title' );
function fileora_starter_title( $parts ) {
	if ( is_singular( array( 'post', 'page' ) ) && ! fileora_theme_seo_plugin() ) {
		$t = get_post_meta( get_queried_object_id(), '_fileora_seo_title', true );
		if ( $t ) {
			$parts['title'] = $t;
		}
	}
	return $parts;
}
