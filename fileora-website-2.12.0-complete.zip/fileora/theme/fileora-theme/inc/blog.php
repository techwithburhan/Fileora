<?php
/**
 * Blog: table of contents, share links, related posts, "tools used in this
 * guide", author box, and SEO tags (meta description, Open Graph, Article,
 * FAQ and breadcrumb structured data) when no SEO plugin is active.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

/** True when an SEO plugin writes the meta tags and structured data. */
function fileora_theme_seo_plugin() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || defined( 'THE_SEO_FRAMEWORK_VERSION' );
}

/* ---------------------------------------------------------------------------
 * Headings: give every H2/H3 in a post an id, and collect them for the TOC.
 * ------------------------------------------------------------------------- */

/**
 * Adds ids to the H2 and H3 headings of an HTML string.
 *
 * @return array{0:string,1:array} [ content, headings[ [level, id, text] ] ]
 */
function fileora_theme_heading_ids( $html ) {
	$used  = array();
	$items = array();
	$html  = preg_replace_callback(
		'#<h([23])([^>]*)>(.*?)</h\1>#is',
		function ( $m ) use ( &$used, &$items ) {
			$text = trim( wp_strip_all_tags( $m[3] ) );
			if ( '' === $text ) {
				return $m[0];
			}
			if ( preg_match( '/\sid=["\']([^"\']+)["\']/i', $m[2], $idm ) ) {
				$id = $idm[1];
			} else {
				$base = sanitize_title( $text );
				$base = '' === $base ? 'section' : $base;
				$id   = $base;
				$n    = 2;
				while ( isset( $used[ $id ] ) ) {
					$id = $base . '-' . $n++;
				}
				$m[2] .= ' id="' . esc_attr( $id ) . '"';
			}
			$used[ $id ] = true;
			$items[]     = array( (int) $m[1], $id, $text );
			return '<h' . $m[1] . $m[2] . '>' . $m[3] . '</h' . $m[1] . '>';
		},
		$html
	);
	return array( $html, $items );
}

add_filter( 'the_content', 'fileora_theme_content_ids', 20 );
function fileora_theme_content_ids( $content ) {
	if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}
	list( $content, $items ) = fileora_theme_heading_ids( $content );
	$GLOBALS['fileora_toc'] = $items;
	return $content;
}

/** The post content with heading ids, plus the TOC items. */
function fileora_theme_post_body() {
	ob_start();
	the_content();
	$html  = (string) ob_get_clean();
	$items = isset( $GLOBALS['fileora_toc'] ) ? $GLOBALS['fileora_toc'] : array();
	return array( $html, $items );
}

/** Table of contents (shown when a post has at least 3 sections). */
function fileora_theme_toc( array $items, $class = 'toc' ) {
	$h2 = array_filter(
		$items,
		function ( $i ) {
			return 2 === $i[0];
		}
	);
	if ( count( $h2 ) < 3 ) {
		return '';
	}
	$out = '<nav class="' . esc_attr( $class ) . '" aria-label="' . esc_attr__( 'On this page', 'fileora' ) . '"><h2>' . esc_html__( 'On this page', 'fileora' ) . '</h2><ol>';
	foreach ( $h2 as $i ) {
		$out .= '<li><a href="#' . esc_attr( $i[1] ) . '">' . esc_html( $i[2] ) . '</a></li>';
	}
	return $out . '</ol></nav>';
}

/* ---------------------------------------------------------------------------
 * Tools linked from a post.
 * ------------------------------------------------------------------------- */

/** Fileora tools the post links to, in the order they first appear. */
function fileora_theme_post_tools( $post = null, $max = 4 ) {
	if ( ! fileora_theme_core() ) {
		return array();
	}
	$post = get_post( $post );
	if ( ! $post ) {
		return array();
	}
	$by_url = array();
	foreach ( fileora_theme_tools() as $t ) {
		if ( 'ready' === $t['status'] ) {
			$by_url[ untrailingslashit( wp_parse_url( $t['url'], PHP_URL_PATH ) ) ] = $t;
		}
	}
	$found = array();
	if ( preg_match_all( '#href=["\']([^"\']+)["\']#i', $post->post_content, $m ) ) {
		$home = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		foreach ( $m[1] as $href ) {
			$host = wp_parse_url( $href, PHP_URL_HOST );
			if ( $host && $host !== $home ) {
				continue;
			}
			$path = untrailingslashit( (string) wp_parse_url( $href, PHP_URL_PATH ) );
			if ( isset( $by_url[ $path ] ) && ! isset( $found[ $by_url[ $path ]['id'] ] ) ) {
				$found[ $by_url[ $path ]['id'] ] = $by_url[ $path ];
			}
		}
	}
	return array_slice( array_values( $found ), 0, $max );
}

/* ---------------------------------------------------------------------------
 * Share links, related posts, author.
 * ------------------------------------------------------------------------- */

function fileora_theme_share() {
	$url   = rawurlencode( get_permalink() );
	$title = rawurlencode( wp_strip_all_tags( get_the_title() ) );
	$links = array(
		'WhatsApp' => 'https://wa.me/?text=' . $title . '%20' . $url,
		'X'        => 'https://twitter.com/intent/tweet?url=' . $url . '&text=' . $title,
		'Facebook' => 'https://www.facebook.com/sharer/sharer.php?u=' . $url,
		'LinkedIn' => 'https://www.linkedin.com/sharing/share-offsite/?url=' . $url,
		'Telegram' => 'https://t.me/share/url?url=' . $url . '&text=' . $title,
	);
	echo '<div class="share"><span>' . esc_html__( 'Share', 'fileora' ) . '</span>';
	foreach ( $links as $name => $href ) {
		echo '<a href="' . esc_url( $href ) . '" target="_blank" rel="noopener nofollow">' . esc_html( $name ) . '</a>';
	}
	echo '<button type="button" data-copy-link="' . esc_url( get_permalink() ) . '" data-done="' . esc_attr__( 'Link copied', 'fileora' ) . '">' . esc_html__( 'Copy link', 'fileora' ) . '</button></div>';
}

/** Up to $n posts sharing tags or categories with the current post. */
function fileora_theme_related_posts( $n = 3 ) {
	$id   = get_the_ID();
	$tags = wp_get_post_tags( $id, array( 'fields' => 'ids' ) );
	$cats = wp_get_post_categories( $id );
	$q    = new WP_Query(
		array(
			'post_type'           => 'post',
			'posts_per_page'      => $n,
			'post__not_in'        => array( $id ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'tax_query'           => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				'relation' => 'OR',
				array( 'taxonomy' => 'post_tag', 'terms' => $tags ? $tags : array( 0 ) ),
				array( 'taxonomy' => 'category', 'terms' => $cats ? $cats : array( 0 ) ),
			),
		)
	);
	if ( $q->post_count < $n ) {
		$more = get_posts( array( 'numberposts' => $n - $q->post_count, 'exclude' => array_merge( array( $id ), wp_list_pluck( $q->posts, 'ID' ) ), 'ignore_sticky_posts' => true ) );
		$q->posts      = array_merge( $q->posts, $more );
		$q->post_count = count( $q->posts );
	}
	return $q;
}

function fileora_theme_author_box() {
	$uid  = (int) get_the_author_meta( 'ID' );
	$bio  = get_the_author_meta( 'description' );
	$name = get_the_author();
	if ( ! $uid ) {
		return;
	}
	echo '<div class="author-box">' . get_avatar( $uid, 56, '', '' ) . '<div><span>' . esc_html__( 'Written by', 'fileora' ) . '</span><b><a href="' . esc_url( get_author_posts_url( $uid ) ) . '">' . esc_html( $name ) . '</a></b>';
	echo '<p>' . esc_html( $bio ? $bio : sprintf( /* translators: %s: site name */ __( 'Guides from the %s team on getting PDFs, photos and forms right the first time.', 'fileora' ), get_bloginfo( 'name' ) ) ) . '</p></div></div>';
}

/* ---------------------------------------------------------------------------
 * FAQ inside posts: <details><summary>Question</summary>Answer</details>
 * (the Details block in the editor) becomes FAQPage structured data.
 * ------------------------------------------------------------------------- */

function fileora_theme_post_faq( $content ) {
	$out = array();
	if ( preg_match_all( '#<details[^>]*>\s*<summary[^>]*>(.*?)</summary>(.*?)</details>#is', $content, $m, PREG_SET_ORDER ) ) {
		foreach ( $m as $qa ) {
			$q = trim( wp_strip_all_tags( $qa[1] ) );
			$a = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $qa[2] ) ) );
			if ( '' !== $q && '' !== $a ) {
				$out[] = array( 'q' => $q, 'a' => $a );
			}
		}
	}
	return $out;
}

/* ---------------------------------------------------------------------------
 * SEO tags for posts, pages, the blog and archives (no SEO plugin only).
 * ------------------------------------------------------------------------- */

/** Description for the current view. */
function fileora_theme_meta_description() {
	if ( is_page_template( 'page-blog.php' ) && ! has_excerpt( get_queried_object() ) ) {
		/* translators: %s: site name */
		return sprintf( __( 'Guides and tips from %s: PDFs, photos, government forms and documents, explained step by step.', 'fileora' ), get_bloginfo( 'name' ) );
	}
	if ( is_singular( array( 'post', 'page' ) ) && ! is_front_page() ) {
		$post = get_queried_object();
		$d    = get_post_meta( $post->ID, '_fileora_meta_description', true );
		if ( ! $d ) {
			$d = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_trim_words( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 28, '…' );
		}
		return trim( wp_strip_all_tags( $d ) );
	}
	if ( is_category() || is_tag() ) {
		$d = term_description();
		return $d ? trim( wp_strip_all_tags( $d ) ) : '';
	}
	if ( is_home() && ! is_front_page() ) {
		/* translators: %s: site name */
		return sprintf( __( 'Guides and tips from %s: PDFs, photos, government forms and documents, explained step by step.', 'fileora' ), get_bloginfo( 'name' ) );
	}
	return '';
}

add_action( 'wp_head', 'fileora_theme_blog_seo', 3 );
function fileora_theme_blog_seo() {
	if ( fileora_theme_seo_plugin() || is_front_page() || is_singular( 'fileora_tool' ) ) {
		return;
	}
	$desc = fileora_theme_meta_description();
	if ( $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	if ( ! is_singular( array( 'post', 'page' ) ) ) {
		return;
	}
	$post  = get_queried_object();
	$url   = get_permalink( $post );
	$title = wp_strip_all_tags( get_the_title( $post ) );
	$img   = has_post_thumbnail( $post ) ? wp_get_attachment_image_src( get_post_thumbnail_id( $post ), 'full' ) : null;
	if ( class_exists( 'Fileora_SEO_Fields' ) ) {
		// Fileora Core: the page's own share image, then the featured image, then the default from Fileora → SEO.
		$si  = Fileora_SEO_Fields::share_image( $post->ID );
		$img = $si ? array( $si['url'], $si['w'], $si['h'] ) : null;
	}
	$tags  = array(
		'og:type'        => is_singular( 'post' ) ? 'article' : 'website',
		'og:title'       => $title,
		'og:description' => $desc,
		'og:url'         => $url,
		'og:site_name'   => get_bloginfo( 'name' ),
		'og:locale'      => str_replace( '-', '_', get_bloginfo( 'language' ) ),
	);
	if ( $img ) {
		$tags['og:image']        = $img[0];
		$tags['og:image:width']  = $img[1];
		$tags['og:image:height'] = $img[2];
	}
	foreach ( $tags as $k => $v ) {
		if ( '' !== (string) $v ) {
			echo '<meta property="' . esc_attr( $k ) . '" content="' . esc_attr( $v ) . '">' . "\n";
		}
	}
	if ( is_singular( 'post' ) ) {
		echo '<meta property="article:published_time" content="' . esc_attr( get_the_date( 'c', $post ) ) . '">' . "\n";
		echo '<meta property="article:modified_time" content="' . esc_attr( get_the_modified_date( 'c', $post ) ) . '">' . "\n";
	}
	echo '<meta name="twitter:card" content="' . ( $img ? 'summary_large_image' : 'summary' ) . '">' . "\n";

	if ( is_singular( 'page' ) ) {
		// Pages: breadcrumbs, and FAQ structured data where the page has Details-block questions.
		$graph = array(
			array(
				'@type'           => 'BreadcrumbList',
				'itemListElement' => array(
					array( '@type' => 'ListItem', 'position' => 1, 'name' => get_bloginfo( 'name' ), 'item' => home_url( '/' ) ),
					array( '@type' => 'ListItem', 'position' => 2, 'name' => $title, 'item' => $url ),
				),
			),
		);
		$faq   = fileora_theme_post_faq( do_shortcode( $post->post_content ) );
		if ( $faq ) {
			$graph[] = array(
				'@type'      => 'FAQPage',
				'mainEntity' => array_map(
					function ( $qa ) {
						return array( '@type' => 'Question', 'name' => $qa['q'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $qa['a'] ) );
					},
					$faq
				),
			);
		}
		echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . '</script>' . "\n";
		return;
	}
	if ( ! is_singular( 'post' ) ) {
		return;
	}
	$graph   = array();
	$logo_id = (int) get_theme_mod( 'custom_logo' );
	$logo    = $logo_id ? wp_get_attachment_image_url( $logo_id, 'full' ) : '';
	$article = array(
		'@type'            => 'BlogPosting',
		'headline'         => $title,
		'description'      => $desc,
		'datePublished'    => get_the_date( 'c', $post ),
		'dateModified'     => get_the_modified_date( 'c', $post ),
		'mainEntityOfPage' => $url,
		'author'           => array( '@type' => 'Person', 'name' => get_the_author_meta( 'display_name', $post->post_author ), 'url' => get_author_posts_url( $post->post_author ) ),
		'publisher'        => array_filter( array( '@type' => 'Organization', 'name' => get_bloginfo( 'name' ), 'url' => home_url( '/' ), 'logo' => $logo ? array( '@type' => 'ImageObject', 'url' => $logo ) : null ) ),
		'wordCount'        => str_word_count( wp_strip_all_tags( $post->post_content ) ),
		'inLanguage'       => get_bloginfo( 'language' ),
	);
	if ( $img ) {
		$article['image'] = array( $img[0] );
	}
	$tag_names = wp_get_post_tags( $post->ID, array( 'fields' => 'names' ) );
	if ( $tag_names ) {
		$article['keywords'] = implode( ', ', $tag_names );
	}
	$graph[] = $article;

	$crumbs = array( array( get_bloginfo( 'name' ), home_url( '/' ) ) );
	$blog   = fileora_theme_blog_url();
	if ( $blog && $blog !== home_url( '/' ) ) {
		$crumbs[] = array( __( 'Blog', 'fileora' ), $blog );
	}
	$crumbs[] = array( $title, $url );
	$list     = array();
	foreach ( $crumbs as $i => $c ) {
		$list[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0], 'item' => $c[1] );
	}
	$graph[] = array( '@type' => 'BreadcrumbList', 'itemListElement' => $list );

	$faq = fileora_theme_post_faq( $post->post_content );
	if ( $faq ) {
		$graph[] = array(
			'@type'      => 'FAQPage',
			'mainEntity' => array_map(
				function ( $qa ) {
					return array( '@type' => 'Question', 'name' => $qa['q'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $qa['a'] ) );
				},
				$faq
			),
		);
	}
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . '</script>' . "\n";
}

/** Post categories as filter chips on the blog page. */
function fileora_theme_category_chips() {
	$cats = get_categories( array( 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 10 ) );
	$cats = array_filter(
		$cats,
		function ( $c ) {
			return 'uncategorized' !== $c->slug;
		}
	);
	if ( count( $cats ) < 1 ) {
		return;
	}
	$blog    = fileora_theme_blog_url();
	$current = is_category() ? get_queried_object_id() : 0;
	echo '<nav class="cat-chips" aria-label="' . esc_attr__( 'Topics', 'fileora' ) . '">';
	if ( $blog ) {
		echo '<a href="' . esc_url( $blog ) . '"' . ( $current ? '' : ' aria-current="page"' ) . '>' . esc_html__( 'All', 'fileora' ) . '</a>';
	}
	foreach ( $cats as $c ) {
		echo '<a href="' . esc_url( get_category_link( $c ) ) . '"' . ( $current === $c->term_id ? ' aria-current="page"' : '' ) . '>' . esc_html( $c->name ) . ' <span>' . (int) $c->count . '</span></a>';
	}
	echo '</nav>';
}

/**
 * Without Fileora Core, hide its shortcodes instead of printing them as text
 * (the information pages use them).
 */
add_action(
	'init',
	function () {
		foreach ( array( 'fileora_data_flow', 'fileora_privacy_facts', 'fileora_privacy', 'fileora_sitemap', 'fileora_last_updated', 'fileora', 'fileora_tools' ) as $tag ) {
			if ( ! shortcode_exists( $tag ) ) {
				add_shortcode( $tag, '__return_empty_string' );
			}
		}
	},
	99
);
