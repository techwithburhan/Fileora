<?php
/**
 * Icons. With Fileora Core active, the plugin prints its full icon sprite at
 * the top of the body (the theme declares add_theme_support( 'fileora' )).
 * Without the plugin, the theme prints the few interface icons it uses.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

function fileora_theme_core() {
	return function_exists( 'fileora_core_active' ) && fileora_core_active();
}

/** Markup for one icon (same markup as the plugin's). */
function fileora_theme_icon( $name, $class = 'ic' ) {
	return '<svg class="' . esc_attr( $class ) . '" aria-hidden="true" focusable="false"><use href="#i-' . esc_attr( $name ) . '"/></svg>';
}

function fileora_theme_e_icon( $name, $class = 'ic' ) {
	echo fileora_theme_icon( $name, $class ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts
}

add_action( 'wp_body_open', 'fileora_theme_sprite', 6 );
function fileora_theme_sprite() {
	if ( fileora_theme_core() ) {
		return;
	}
	$icons = array(
		'search'      => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
		'x'           => '<path d="M6 6l12 12M18 6 6 18"/>',
		'check'       => '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
		'upload'      => '<path d="M12 15V4M7.5 8.5 12 4l4.5 4.5"/><path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
		'sun'         => '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.6 4.6 6 6M18 18l1.4 1.4M2.5 12h2M19.5 12h2M4.6 19.4 6 18M18 6l1.4-1.4"/>',
		'moon'        => '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
		'menu'        => '<path d="M4 7h16M4 12h16M4 17h10"/>',
		'shield'      => '<path d="M12 3 4.5 6v5.5c0 4.6 3.2 8.2 7.5 9.5 4.3-1.3 7.5-4.9 7.5-9.5V6z"/><path d="m9 12 2 2 4-4"/>',
		'device'      => '<rect x="4" y="5" width="16" height="11" rx="1.5"/><path d="M2 19h20"/>',
		'server'      => '<rect x="4" y="4" width="16" height="7" rx="2"/><rect x="4" y="13" width="16" height="7" rx="2"/><path d="M8 7.5h.01M8 16.5h.01"/>',
		'lock'        => '<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5M12 14.5V17"/>',
		'clock'       => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
		'arrow-right' => '<path d="M5 12h14m-6-6 6 6-6 6"/>',
		'arrow-left'  => '<path d="M19 12H5m6-6-6 6 6 6"/>',
		'chev-down'   => '<path d="m6 9 6 6 6-6"/>',
		'chev-right'  => '<path d="m9 6 6 6-6 6"/>',
		'file'        => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
		'info'        => '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.5h.01"/>',
		'user'        => '<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5c1-3.6 4-5.5 7.5-5.5s6.5 1.9 7.5 5.5"/>',
		'star'        => '<path d="m12 3.5 2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
		'globe'       => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 3.7 5.7 3.7 9s-1.2 6.3-3.7 9c-2.5-2.7-3.7-5.7-3.7-9S9.5 5.7 12 3z"/>',
		'plus'        => '<path d="M12 5v14M5 12h14"/>',
	);
	echo '<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute;width:0;height:0;overflow:hidden" aria-hidden="true" focusable="false"><defs>';
	foreach ( $icons as $id => $inner ) {
		echo '<symbol id="i-' . esc_attr( $id ) . '" viewBox="0 0 24 24">' . $inner . '</symbol>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG
	}
	echo '</defs></svg>';
}
