<?php
/**
 * The accessibility button and panel: larger text, stronger contrast,
 * highlighted links, a readable font, extra text spacing, a larger cursor and
 * "stop animations". Choices are kept in the visitor's browser (localStorage
 * "fileora.a11y") and applied before the page is drawn (inc/setup.php).
 *
 * These options help some visitors; they don't replace accessible markup,
 * which the theme provides on its own.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

/** Published page with a Fileora role (about, contact, accessibility…), or 0. */
function fileora_theme_page_by_role( $role ) {
	foreach ( fileora_theme_info_pages() as $p ) {
		if ( $role === $p['role'] ) {
			return (int) $p['id'];
		}
	}
	return 0;
}

function fileora_theme_a11y_widget() {
	if ( ! fileora_theme_mod( 'a11y_widget' ) ) {
		return;
	}
	$statement = fileora_theme_page_by_role( 'accessibility' );
	$contact   = fileora_theme_page_by_role( 'contact' );
	$toggles   = array(
		'contrast' => array( __( 'High contrast', 'fileora' ), __( 'Darker text and stronger borders', 'fileora' ), '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17a8.5 8.5 0 0 0 0-17z" fill="currentColor" stroke="none"/>' ),
		'links'    => array( __( 'Highlight links', 'fileora' ), __( 'Underline and outline every link', 'fileora' ), '<path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1"/><path d="M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1"/>' ),
		'readable' => array( __( 'Readable font', 'fileora' ), __( 'A plain, wide font for easier reading', 'fileora' ), '<path d="M5 19 10.5 5h1L17 19M7.4 13.5h7.2"/><path d="M19 9v10"/>' ),
		'spacing'  => array( __( 'Text spacing', 'fileora' ), __( 'More space between lines, letters and words', 'fileora' ), '<path d="M4 6h16M4 12h16M4 18h16"/><path d="m7 3-2 3 2 3M17 3l2 3-2 3" stroke-width="1.4"/>' ),
		'cursor'   => array( __( 'Large cursor', 'fileora' ), __( 'A bigger mouse pointer', 'fileora' ), '<path d="M6 3.5 18 12l-5.2 1.1L15.5 19l-2.3 1-2.7-5.9L6 17.5z"/>' ),
		'motion'   => array( __( 'Stop animations', 'fileora' ), __( 'Turn off movement on the site', 'fileora' ), '<rect x="6.5" y="5.5" width="3.5" height="13" rx="1"/><rect x="14" y="5.5" width="3.5" height="13" rx="1"/>' ),
	);
	$svg = function ( $paths ) {
		return '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $paths . '</svg>';
	};
	?>
	<div class="a11y" data-a11y>
		<button class="a11y-fab" type="button" aria-expanded="false" aria-controls="a11y-panel" data-a11y-open>
			<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="4.6" r="2.1" fill="currentColor"/><path d="M4.5 8.2c2.5.7 5 1 7.5 1s5-.3 7.5-1M12 9.3V14m0 0-3 6.5M12 14l3 6.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
			<span class="sr"><?php esc_html_e( 'Accessibility options', 'fileora' ); ?></span>
		</button>
		<div class="a11y-panel" id="a11y-panel" role="dialog" aria-modal="false" aria-labelledby="a11y-title" hidden>
			<div class="a11y-head">
				<h2 id="a11y-title"><?php esc_html_e( 'Accessibility', 'fileora' ); ?></h2>
				<button class="icon-btn sm" type="button" data-a11y-close aria-label="<?php esc_attr_e( 'Close accessibility options', 'fileora' ); ?>"><?php echo $svg( '<path d="M6 6l12 12M18 6 6 18"/>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
			</div>
			<p class="a11y-intro"><?php esc_html_e( 'Adjust the site to suit you. Your choices are saved in this browser only.', 'fileora' ); ?></p>
			<div class="a11y-size" role="group" aria-labelledby="a11y-size-l">
				<span id="a11y-size-l"><?php esc_html_e( 'Text size', 'fileora' ); ?></span>
				<div class="a11y-seg">
					<button type="button" data-a11y-text="0" aria-pressed="true"><?php esc_html_e( 'Normal', 'fileora' ); ?></button>
					<button type="button" data-a11y-text="1" aria-pressed="false" aria-label="<?php esc_attr_e( 'Large text', 'fileora' ); ?>">A+</button>
					<button type="button" data-a11y-text="2" aria-pressed="false" aria-label="<?php esc_attr_e( 'Larger text', 'fileora' ); ?>">A++</button>
					<button type="button" data-a11y-text="3" aria-pressed="false" aria-label="<?php esc_attr_e( 'Largest text', 'fileora' ); ?>">A+++</button>
				</div>
			</div>
			<div class="a11y-grid">
				<?php foreach ( $toggles as $key => $t ) : ?>
					<button type="button" class="a11y-opt" data-a11y-toggle="<?php echo esc_attr( $key ); ?>" aria-pressed="false">
						<?php echo $svg( $t[2] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><b><?php echo esc_html( $t[0] ); ?></b><small><?php echo esc_html( $t[1] ); ?></small></span>
					</button>
				<?php endforeach; ?>
			</div>
			<div class="a11y-foot">
				<button type="button" class="btn btn-line btn-sm" data-a11y-reset><?php esc_html_e( 'Reset all', 'fileora' ); ?></button>
				<span>
					<?php if ( $statement ) : ?>
						<a href="<?php echo esc_url( get_permalink( $statement ) ); ?>"><?php esc_html_e( 'Accessibility statement', 'fileora' ); ?></a>
					<?php endif; ?>
					<?php if ( $contact ) : ?>
						<a href="<?php echo esc_url( get_permalink( $contact ) ); ?>"><?php esc_html_e( 'Report a barrier', 'fileora' ); ?></a>
					<?php endif; ?>
				</span>
			</div>
			<p class="a11y-status sr" role="status" aria-live="polite"></p>
		</div>
	</div>
	<?php
}
