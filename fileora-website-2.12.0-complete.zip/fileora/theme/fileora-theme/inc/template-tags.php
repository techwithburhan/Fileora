<?php
/**
 * Small helpers used by the templates.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

/** Tool groups from Fileora Core, or an empty list. */
function fileora_theme_groups() {
	static $groups = null;
	if ( null === $groups ) {
		$groups = fileora_theme_core() ? array_values( fileora_get_tool_groups() ) : array();
	}
	return $groups;
}

/** All visible tools (flat). */
function fileora_theme_tools() {
	static $tools = null;
	if ( null === $tools ) {
		$tools = fileora_theme_core() ? fileora_get_tools() : array();
	}
	return $tools;
}

/** Counts for the hero text: total ready tools and tools running in the browser. */
function fileora_theme_counts() {
	$all = 0;
	$browser = 0;
	foreach ( fileora_theme_tools() as $t ) {
		if ( 'ready' !== $t['status'] ) {
			continue;
		}
		++$all;
		if ( 'browser' === fileora_runs_on( $t ) ) {
			++$browser;
		}
	}
	return array( 'all' => $all, 'browser' => $browser );
}

/** The page using the “All tools” template, if any. */
function fileora_theme_all_tools_page() {
	return fileora_theme_template_page( 'page-all-tools.php' );
}

/** The first published page using a page template, or 0. */
function fileora_theme_template_page( $template ) {
	static $cache = array();
	if ( ! isset( $cache[ $template ] ) ) {
		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'meta_key'       => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => $template, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		$cache[ $template ] = $pages ? (int) $pages[0] : 0;
	}
	return $cache[ $template ];
}

function fileora_theme_all_tools_url( $anchor = '' ) {
	$id  = fileora_theme_all_tools_page();
	$url = $id ? get_permalink( $id ) : home_url( '/#tools' );
	if ( $anchor ) {
		$url = $id ? $url . '#' . $anchor : home_url( '/#' . $anchor );
	}
	return $url;
}

/** Link to the blog: the posts page, or the home page listing. */
function fileora_theme_blog_url() {
	$id = (int) get_option( 'page_for_posts' );
	if ( $id ) {
		return get_permalink( $id );
	}
	$page = fileora_theme_template_page( 'page-blog.php' );
	if ( $page ) {
		return get_permalink( $page );
	}
	return 'posts' === get_option( 'show_on_front' ) ? home_url( '/' ) : '';
}

/** Anchor id for a tool category. */
function fileora_theme_cat_anchor( array $group ) {
	return 'cat-' . sanitize_title( $group['slug'] );
}

/** Site logo: the Custom Logo, or the Fileora mark and the site name. */
function fileora_theme_logo( $class = 'logo' ) {
	$name = get_bloginfo( 'name' );
	echo '<a class="' . esc_attr( $class ) . '" href="' . esc_url( home_url( '/' ) ) . '" rel="home" aria-label="' . esc_attr( $name . ' ' . __( 'home', 'fileora' ) ) . '">';
	if ( has_custom_logo() ) {
		$logo = wp_get_attachment_image( (int) get_theme_mod( 'custom_logo' ), 'full', false, array( 'alt' => '', 'loading' => 'eager' ) );
		echo $logo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	} else {
		echo '<svg viewBox="0 0 32 32" aria-hidden="true"><rect class="lm-bg" width="32" height="32" rx="9"/><path d="M10 8.5h8.5l4 4V23a1.5 1.5 0 0 1-1.5 1.5H10A1.5 1.5 0 0 1 8.5 23V10A1.5 1.5 0 0 1 10 8.5z" fill="#fff"/><path d="M18.5 8.5v4h4" fill="#C9CCDA"/><rect x="11.5" y="15" width="8" height="2.2" rx="1.1" fill="#FFD43B"/><rect x="11.5" y="19" width="5.5" height="2.2" rx="1.1" fill="#C9CCDA"/></svg>';
		echo '<span>' . esc_html( $name ) . '</span>';
	}
	echo '</a>';
}

/** Tags shown on a tool card: new, where it runs, coming soon. */
function fileora_theme_tool_tags( array $t ) {
	$out = '';
	if ( ! empty( $t['new'] ) ) {
		$out .= '<span class="tag tag-new">' . esc_html__( 'New', 'fileora' ) . '</span>';
	}
	if ( 'ready' !== $t['status'] ) {
		$out .= '<span class="tag">' . fileora_theme_icon( 'clock' ) . esc_html__( 'Coming soon', 'fileora' ) . '</span>';
	} elseif ( 'browser' === fileora_runs_on( $t ) ) {
		$out .= '<span class="tag tag-local" title="' . esc_attr__( 'Your file never leaves your device', 'fileora' ) . '">' . fileora_theme_icon( 'device' ) . '<span class="tl">' . esc_html__( 'In browser', 'fileora' ) . '</span></span>';
	} else {
		$out .= '<span class="tag tag-srv" title="' . esc_attr__( 'Processed on our server, then deleted', 'fileora' ) . '">' . fileora_theme_icon( 'server' ) . '<span class="tl">' . esc_html__( 'Server', 'fileora' ) . '</span></span>';
	}
	if ( ! empty( $t['paid'] ) ) {
		$out .= '<span class="tag">' . fileora_theme_icon( 'star' ) . esc_html__( 'Pro', 'fileora' ) . '</span>';
	}
	return $out;
}

/** Breadcrumb trail (with BreadcrumbList data from Fileora Core on tool pages). */
function fileora_theme_crumbs( array $items ) {
	echo '<nav class="crumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'fileora' ) . '"><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'fileora' ) . '</a>';
	foreach ( $items as $label => $url ) {
		echo fileora_theme_icon( 'chev-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $url ) {
			echo '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
		} else {
			echo '<span aria-current="page">' . esc_html( $label ) . '</span>';
		}
	}
	echo '</nav>';
}

/** “12 March 2026 · 4 min read”. */
function fileora_theme_post_meta() {
	$words = str_word_count( wp_strip_all_tags( get_the_content() ) );
	$mins  = max( 1, (int) round( $words / 220 ) );
	echo '<div class="entry-meta"><time datetime="' . esc_attr( get_the_date( 'c' ) ) . '">' . esc_html( get_the_date() ) . '</time>';
	/* translators: %d: minutes */
	echo '<span>·</span><span>' . esc_html( sprintf( _n( '%d min read', '%d min read', $mins, 'fileora' ), $mins ) ) . '</span>';
	$cats = get_the_category();
	if ( $cats ) {
		echo '<span>·</span><a href="' . esc_url( get_category_link( $cats[0] ) ) . '">' . esc_html( $cats[0]->name ) . '</a>';
	}
	echo '</div>';
}

/** Parse “question\nanswer” blocks separated by blank lines. */
function fileora_theme_parse_faq( $text ) {
	$out = array();
	foreach ( preg_split( "/\R\s*\R/", trim( (string) $text ) ) as $block ) {
		$lines = preg_split( '/\R/', trim( $block ), 2 );
		if ( count( $lines ) === 2 && '' !== trim( $lines[0] ) ) {
			$out[] = array( 'q' => trim( $lines[0] ), 'a' => trim( $lines[1] ) );
		}
	}
	return $out;
}

/** Fill {tokens} in a Customizer text. */
function fileora_theme_tokens( $text ) {
	$c = fileora_theme_counts();
	return strtr(
		(string) $text,
		array(
			'{count}'   => number_format_i18n( $c['all'] ),
			'{browser}' => number_format_i18n( $c['browser'] ),
			'{year}'    => wp_date( 'Y' ),
			'{site}'    => get_bloginfo( 'name' ),
		)
	);
}

/** Quick-link tools from the Customizer list (ids or slugs). */
function fileora_theme_quick_tools() {
	if ( ! fileora_theme_core() ) {
		return array();
	}
	$out = array();
	foreach ( array_filter( array_map( 'trim', explode( ',', (string) fileora_theme_mod( 'quick_tools' ) ) ) ) as $key ) {
		$t = fileora_get_tool( sanitize_title( $key ) );
		if ( $t && $t['enabled'] && 'ready' === $t['status'] ) {
			$out[ $t['id'] ] = $t;
		}
	}
	return array_values( $out );
}

/** Pagination for archives. */
function fileora_theme_pagination() {
	$links = paginate_links(
		array(
			'type'      => 'array',
			'mid_size'  => 1,
			'prev_text' => fileora_theme_icon( 'arrow-left', 'ic ic-sm' ) . '<span class="sr">' . __( 'Previous', 'fileora' ) . '</span>',
			'next_text' => '<span class="sr">' . __( 'Next', 'fileora' ) . '</span>' . fileora_theme_icon( 'arrow-right', 'ic ic-sm' ),
		)
	);
	if ( $links ) {
		echo '<nav class="pagination" aria-label="' . esc_attr__( 'Pages', 'fileora' ) . '">' . implode( '', $links ) . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

/** "Website created by …" credit at the bottom of the footer (Customizer → Fileora → Footer). */
function fileora_theme_credit() {
	$name = trim( (string) fileora_theme_mod( 'credit_name' ) );
	if ( '' === $name ) {
		return;
	}
	$url  = esc_url( fileora_theme_mod( 'credit_url' ) );
	$text = trim( (string) fileora_theme_mod( 'credit_text' ) );
	echo '<span class="ftr-credit">' . esc_html( $text ) . ( $text ? ' ' : '' );
	if ( $url ) {
		echo '<a href="' . $url . '" target="_blank" rel="noopener">' . esc_html( $name ) . '<span class="screen-reader-text"> ' . esc_html__( '(opens in a new tab)', 'fileora' ) . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	} else {
		echo esc_html( $name );
	}
	echo '</span>';
}
