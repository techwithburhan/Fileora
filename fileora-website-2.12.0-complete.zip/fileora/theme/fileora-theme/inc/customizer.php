<?php
/**
 * Appearance → Customize → Fileora: homepage texts, sections, footer and colours.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

/** Default value of every theme setting. */
function fileora_theme_defaults() {
	return array(
		'hero_line1'     => __( 'Free PDF tools,', 'fileora' ),
		'hero_line2'     => __( 'done in seconds.', 'fileora' ),
		'hero_text'      => __( 'Merge, compress, convert, sign and edit PDFs and images. {count} free tools, and {browser} of them run right in your browser, so your files never leave your device.', 'fileora' ),
		'hero_note'      => __( 'No sign-up. No watermark. Free to use.', 'fileora' ),
		'quick_tools'    => 'merge, compress, pdf2word, sign, jpg2pdf, aadhaar',
		'show_tools'     => 1,
		'show_how'       => 1,
		'show_trust'     => 1,
		'show_blog'      => 1,
		'show_faq'       => 1,
		'tools_title'    => __( 'Every tool you need for PDFs and images', 'fileora' ),
		'tools_text'     => __( 'Pick a tool, drop your file, download the result. Tools marked “In browser” never upload anything.', 'fileora' ),
		'home_faq'       => fileora_theme_default_faq(),
		'home_meta'      => __( 'Free online PDF and image tools: merge, compress, convert, sign, protect and edit PDFs, and resize or compress photos. Most tools run in your browser, so files stay private.', 'fileora' ),
		'header_login'   => 0,
		'motion'         => 1,
		'a11y_widget'    => 1,
		'login_label'    => __( 'Log in', 'fileora' ),
		'signup_label'   => __( 'Sign up', 'fileora' ),
		'accent'         => '#FFD43B',
		'footer_about'   => __( 'Free PDF and image tools that respect your privacy. Most tools work in your browser, and files sent to our server are deleted automatically.', 'fileora' ),
		'footer_copy'    => '© {year} {site}. ' . __( 'All rights reserved.', 'fileora' ),
		'footer_titles'  => __( 'PDF tools|Convert|Images|Information', 'fileora' ),
		'contact_email'  => '',
		'credit_text'    => __( 'Website created by', 'fileora' ),
		'credit_name'    => '@techdeployers',
		'credit_url'     => 'https://www.techdeployers.com',
		'social_x'       => '',
		'social_facebook' => '',
		'social_instagram' => '',
		'social_linkedin' => '',
		'social_youtube' => '',
	);
}

function fileora_theme_default_faq() {
	return implode(
		"\n\n",
		array(
			__( "Are the tools really free?\nYes. Every tool marked free works without an account, without a watermark and without a trial period.", 'fileora' ),
			__( "Are my files safe?\nTools marked “In browser” process your file on your own device; it is never uploaded. Tools that need our server (for example Word to PDF) upload over an encrypted connection and the files are deleted automatically.", 'fileora' ),
			__( "Do I need to install anything?\nNo. Everything works in a modern browser on Windows, Mac, Linux, Android and iPhone.", 'fileora' ),
			__( "Is there a file size limit?\nYes, to keep the service fast for everyone. The limit is shown in each tool before you upload.", 'fileora' ),
		)
	);
}

/** One theme setting, with its default. */
function fileora_theme_mod( $key ) {
	$d = fileora_theme_defaults();
	return get_theme_mod( 'fileora_' . $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

add_action( 'customize_register', 'fileora_theme_customize' );
function fileora_theme_customize( WP_Customize_Manager $wp ) {
	$d = fileora_theme_defaults();
	$wp->add_panel( 'fileora', array( 'title' => __( 'Fileora', 'fileora' ), 'priority' => 30 ) );
	$sections = array(
		'fileora_home'   => __( 'Homepage', 'fileora' ),
		'fileora_header' => __( 'Header', 'fileora' ),
		'fileora_footer' => __( 'Footer', 'fileora' ),
		'fileora_colors' => __( 'Colours', 'fileora' ),
	);
	foreach ( $sections as $id => $title ) {
		$wp->add_section( $id, array( 'title' => $title, 'panel' => 'fileora' ) );
	}

	$text = function ( $key, $label, $section, $type = 'text', $desc = '' ) use ( $wp, $d ) {
		$sanitize = 'textarea' === $type ? 'sanitize_textarea_field' : ( 'email' === $type ? 'sanitize_email' : ( 'url' === $type ? 'esc_url_raw' : 'sanitize_text_field' ) );
		$wp->add_setting( 'fileora_' . $key, array( 'default' => $d[ $key ], 'sanitize_callback' => $sanitize, 'transport' => 'refresh' ) );
		$wp->add_control( 'fileora_' . $key, array( 'label' => $label, 'section' => $section, 'type' => $type, 'description' => $desc ) );
	};
	$check = function ( $key, $label, $section ) use ( $wp, $d ) {
		$wp->add_setting( 'fileora_' . $key, array( 'default' => $d[ $key ], 'sanitize_callback' => 'absint' ) );
		$wp->add_control( 'fileora_' . $key, array( 'label' => $label, 'section' => $section, 'type' => 'checkbox' ) );
	};

	$text( 'hero_line1', __( 'Headline, first line', 'fileora' ), 'fileora_home', 'text', __( 'The homepage H1. Put your main keywords here.', 'fileora' ) );
	$text( 'hero_line2', __( 'Headline, second line', 'fileora' ), 'fileora_home' );
	$text( 'hero_text', __( 'Text under the headline', 'fileora' ), 'fileora_home', 'textarea', __( '{count} becomes the number of tools, {browser} the number that run in the browser.', 'fileora' ) );
	$text( 'hero_note', __( 'Small note under the search box', 'fileora' ), 'fileora_home' );
	$text( 'quick_tools', __( 'Quick links under the search box', 'fileora' ), 'fileora_home', 'text', __( 'Tool ids or slugs, separated by commas, e.g. merge, compress, pdf2word.', 'fileora' ) );
	$text( 'tools_title', __( 'Tool catalogue heading', 'fileora' ), 'fileora_home' );
	$text( 'tools_text', __( 'Tool catalogue text', 'fileora' ), 'fileora_home', 'textarea' );
	$check( 'show_tools', __( 'Show the tool catalogue', 'fileora' ), 'fileora_home' );
	$check( 'show_how', __( 'Show “How it works”', 'fileora' ), 'fileora_home' );
	$check( 'show_trust', __( 'Show “Why Fileora”', 'fileora' ), 'fileora_home' );
	$check( 'show_blog', __( 'Show the latest blog posts', 'fileora' ), 'fileora_home' );
	$check( 'show_faq', __( 'Show the FAQ', 'fileora' ), 'fileora_home' );
	$text( 'home_faq', __( 'Homepage FAQ', 'fileora' ), 'fileora_home', 'textarea', __( 'Question on the first line, answer below it. Leave an empty line between questions.', 'fileora' ) );
	$text( 'home_meta', __( 'Homepage meta description', 'fileora' ), 'fileora_home', 'textarea', __( 'Used when no SEO plugin is active.', 'fileora' ) );

	$check( 'header_login', __( 'Show “Log in” and “Sign up” buttons', 'fileora' ), 'fileora_header' );
	$check( 'motion', __( 'Animate the header and footer (GSAP). Visitors who ask for less motion never see animations.', 'fileora' ), 'fileora_header' );
	$check( 'a11y_widget', __( 'Show the accessibility button (text size, contrast, link highlighting, spacing, stop animations)', 'fileora' ), 'fileora_header' );
	$text( 'login_label', __( 'Log in label', 'fileora' ), 'fileora_header' );
	$text( 'signup_label', __( 'Sign up label', 'fileora' ), 'fileora_header' );

	$text( 'footer_about', __( 'About text', 'fileora' ), 'fileora_footer', 'textarea' );
	$text( 'footer_titles', __( 'Column headings', 'fileora' ), 'fileora_footer', 'text', __( 'Four headings separated by |. Choose the links in Appearance → Menus (Footer column 1–4).', 'fileora' ) );
	$text( 'footer_copy', __( 'Copyright line', 'fileora' ), 'fileora_footer', 'text', __( '{year} and {site} are replaced automatically.', 'fileora' ) );
	$text( 'contact_email', __( 'Contact email', 'fileora' ), 'fileora_footer', 'email' );
	$text( 'credit_text', __( 'Credit line', 'fileora' ), 'fileora_footer', 'text', __( 'Shown at the bottom of every page, before the name. Leave the name empty to hide the credit.', 'fileora' ) );
	$text( 'credit_name', __( 'Credit name', 'fileora' ), 'fileora_footer' );
	$text( 'credit_url', __( 'Credit link', 'fileora' ), 'fileora_footer', 'url' );
	foreach ( array( 'x' => 'X (Twitter)', 'facebook' => 'Facebook', 'instagram' => 'Instagram', 'linkedin' => 'LinkedIn', 'youtube' => 'YouTube' ) as $k => $label ) {
		/* translators: %s: social network */
		$text( 'social_' . $k, sprintf( __( '%s link', 'fileora' ), $label ), 'fileora_footer', 'url' );
	}

	$wp->add_setting( 'fileora_accent', array( 'default' => $d['accent'], 'sanitize_callback' => 'sanitize_hex_color' ) );
	$wp->add_control( new WP_Customize_Color_Control( $wp, 'fileora_accent', array( 'label' => __( 'Highlight colour', 'fileora' ), 'description' => __( 'Buttons, step numbers and underlines. Pick a light colour: text on it is dark.', 'fileora' ), 'section' => 'fileora_colors' ) ) );
}

/** The highlight colour from the Customizer. */
add_action( 'wp_head', 'fileora_theme_accent_css', 20 );
function fileora_theme_accent_css() {
	$c = sanitize_hex_color( fileora_theme_mod( 'accent' ) );
	if ( ! $c || strtoupper( $c ) === '#FFD43B' ) {
		return;
	}
	printf( '<style id="fileora-accent">:root{--hl:%1$s;--hl-2:color-mix(in srgb,%1$s 86%%,#000)}</style>' . "\n", esc_html( $c ) );
}
