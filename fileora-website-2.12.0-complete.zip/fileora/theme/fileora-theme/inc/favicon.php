<?php
/**
 * Favicon: the Fileora mark in every size browsers and phones ask for.
 * A Site Icon set in Appearance → Customize → Site Identity always wins.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

function fileora_theme_favicon_url( $file ) {
	return FILEORA_THEME_URI . '/assets/images/favicon/' . $file;
}

/** Link tags in <head>, only while no Site Icon is set. */
function fileora_theme_favicon_tags() {
	if ( has_site_icon() ) {
		return;
	}
	$v = '?v=' . rawurlencode( FILEORA_THEME_VERSION );
	printf( '<link rel="icon" href="%s" sizes="48x48">' . "\n", esc_url( fileora_theme_favicon_url( 'favicon.ico' ) . $v ) );
	printf( '<link rel="icon" href="%s" type="image/svg+xml">' . "\n", esc_url( fileora_theme_favicon_url( 'favicon.svg' ) . $v ) );
	printf( '<link rel="icon" href="%s" type="image/png" sizes="96x96">' . "\n", esc_url( fileora_theme_favicon_url( 'favicon-96x96.png' ) . $v ) );
	printf( '<link rel="apple-touch-icon" href="%s" sizes="180x180">' . "\n", esc_url( fileora_theme_favicon_url( 'apple-touch-icon.png' ) . $v ) );
	printf( '<link rel="manifest" href="%s">' . "\n", esc_url( fileora_theme_favicon_url( 'site.webmanifest' ) ) );
}
add_action( 'wp_head', 'fileora_theme_favicon_tags', 2 );
add_action( 'admin_head', 'fileora_theme_favicon_tags', 2 );
add_action( 'login_head', 'fileora_theme_favicon_tags', 2 );

/** /favicon.ico: send the Fileora icon instead of the WordPress logo. */
function fileora_theme_favicon_ico() {
	if ( has_site_icon() ) {
		return; // WordPress redirects to the Site Icon itself.
	}
	wp_safe_redirect( fileora_theme_favicon_url( 'favicon.ico' ), 302 );
	exit;
}
add_action( 'do_faviconico', 'fileora_theme_favicon_ico', 5 );
