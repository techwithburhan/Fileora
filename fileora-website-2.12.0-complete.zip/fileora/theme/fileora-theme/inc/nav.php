<?php
/**
 * Navigation: the header menu, the "Tools" mega menu, the mobile drawer and
 * the footer columns.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

/** Header links: the "Header menu", or sensible defaults. */
function fileora_theme_primary_menu() {
	if ( has_nav_menu( 'primary' ) ) {
		wp_nav_menu(
			array(
				'theme_location' => 'primary',
				'container'      => false,
				'depth'          => 1,
				'items_wrap'     => '<ul>%3$s</ul>',
				'fallback_cb'    => false,
			)
		);
		return;
	}
	echo '<ul>';
	if ( fileora_theme_core() ) {
		echo '<li><a href="' . esc_url( fileora_theme_all_tools_url() ) . '">' . esc_html__( 'All tools', 'fileora' ) . '</a></li>';
		foreach ( fileora_theme_groups() as $g ) {
			if ( in_array( $g['module'], array( 'image' ), true ) ) {
				echo '<li><a href="' . esc_url( fileora_theme_all_tools_url( fileora_theme_cat_anchor( $g ) ) ) . '">' . esc_html( $g['name'] ) . '</a></li>';
			}
		}
	}
	$resume = function_exists( 'fileora_theme_resume_url' ) ? fileora_theme_resume_url() : '';
	if ( $resume ) {
		echo '<li class="menu-resume"><a href="' . esc_url( $resume ) . '"' . ( fileora_theme_is_resume_page() ? ' aria-current="page"' : '' ) . '>' . esc_html__( 'ATS Resume', 'fileora' ) . '</a></li>';
	}
	$blog = fileora_theme_blog_url();
	if ( $blog && wp_count_posts()->publish ) {
		echo '<li><a href="' . esc_url( $blog ) . '">' . esc_html__( 'Blog', 'fileora' ) . '</a></li>';
	}
	$contact = function_exists( 'fileora_theme_page_by_role' ) ? fileora_theme_page_by_role( 'contact' ) : 0;
	if ( $contact ) {
		echo '<li class="menu-contact"><a href="' . esc_url( get_permalink( $contact ) ) . '"' . ( is_page( $contact ) ? ' aria-current="page"' : '' ) . '>' . esc_html__( 'Contact us', 'fileora' ) . '</a></li>';
	}
	echo '</ul>';
}

/** The mega menu panel listing up to 8 tools per category. */
function fileora_theme_mega_menu() {
	$groups = fileora_theme_groups();
	if ( ! $groups ) {
		return;
	}
	echo '<div class="mega" id="mega" hidden><div class="wrap mega-grid">';
	foreach ( $groups as $g ) {
		echo '<div class="mega-col" data-cat="' . esc_attr( $g['color'] ) . '"><h4><span class="dot"></span>' . esc_html( $g['name'] ) . '</h4>';
		foreach ( array_slice( $g['tools'], 0, 8 ) as $t ) {
			echo '<a href="' . esc_url( $t['url'] ) . '"><span class="tile sm">' . fileora_theme_icon( $t['icon'] ) . '</span>' . esc_html( $t['name'] ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		if ( count( $g['tools'] ) > 8 ) {
			/* translators: %d: number of tools */
			echo '<a class="more" href="' . esc_url( fileora_theme_all_tools_url( fileora_theme_cat_anchor( $g ) ) ) . '">' . esc_html( sprintf( __( 'All %d tools', 'fileora' ), count( $g['tools'] ) ) ) . fileora_theme_icon( 'arrow-right', 'ic ic-sm' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</div>';
	}
	echo '</div></div>';
}

/** The mobile drawer. */
function fileora_theme_drawer() {
	?>
	<div class="drawer" id="drawer" hidden>
		<div class="drawer-bg" data-close></div>
		<div class="drawer-panel" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Menu', 'fileora' ); ?>">
			<div class="drawer-top">
				<?php fileora_theme_logo(); ?>
				<button class="icon-btn" type="button" data-close aria-label="<?php esc_attr_e( 'Close menu', 'fileora' ); ?>"><?php fileora_theme_e_icon( 'x' ); ?></button>
			</div>
			<div class="drawer-body">
				<button class="search-trigger" type="button" data-palette><?php fileora_theme_e_icon( 'search' ); ?><span><?php echo esc_html( fileora_theme_core() ? __( 'Search tools…', 'fileora' ) : __( 'Search…', 'fileora' ) ); ?></span></button>
				<?php foreach ( fileora_theme_groups() as $g ) : ?>
					<details data-cat="<?php echo esc_attr( $g['color'] ); ?>">
						<summary><span class="dot"></span><?php echo esc_html( $g['name'] ); ?><?php fileora_theme_e_icon( 'chev-down' ); ?></summary>
						<div>
							<?php foreach ( $g['tools'] as $t ) : ?>
								<a href="<?php echo esc_url( $t['url'] ); ?>"><span class="tile sm"><?php fileora_theme_e_icon( $t['icon'] ); ?></span><?php echo esc_html( $t['name'] ); ?></a>
							<?php endforeach; ?>
						</div>
					</details>
				<?php endforeach; ?>
				<nav class="drawer-links" aria-label="<?php esc_attr_e( 'Site', 'fileora' ); ?>"><?php fileora_theme_primary_menu(); ?></nav>
			</div>
			<?php if ( fileora_theme_mod( 'header_login' ) ) : ?>
				<div class="drawer-cta">
					<a class="btn btn-line" href="<?php echo esc_url( wp_login_url() ); ?>"><?php echo esc_html( fileora_theme_mod( 'login_label' ) ); ?></a>
					<?php if ( get_option( 'users_can_register' ) ) : ?>
						<a class="btn btn-ink" href="<?php echo esc_url( wp_registration_url() ); ?>"><?php echo esc_html( fileora_theme_mod( 'signup_label' ) ); ?></a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<?php
}

/**
 * One footer column: its menu, or, without a menu, links generated from the
 * tool categories (columns 1-3) and the site pages (column 4).
 */
function fileora_theme_footer_column( $n, $title ) {
	$loc = 'footer-' . $n;
	if ( has_nav_menu( $loc ) ) {
		echo '<nav aria-label="' . esc_attr( $title ) . '"><h2 class="ftr-h">' . esc_html( $title ) . '</h2>';
		wp_nav_menu( array( 'theme_location' => $loc, 'container' => false, 'depth' => 1, 'fallback_cb' => false ) );
		echo '</nav>';
		return;
	}
	$links = array();
	$groups = fileora_theme_groups();
	if ( $n <= 3 && $groups ) {
		$pick = fileora_theme_footer_groups();
		$pick = isset( $pick[ $n ] ) ? $pick[ $n ] : null;
		$want = array( 1 => 'pdf', 2 => 'converter', 3 => 'image' );
		if ( $pick && $pick['module'] !== $want[ $n ] ) {
			$title = $pick['name']; // a stand-in group keeps its own name
		}
		if ( $pick ) {
			foreach ( array_slice( $pick['tools'], 0, 6 ) as $t ) {
				$links[ $t['name'] ] = $t['url'];
			}
		}
	} elseif ( 4 === $n ) {
		// Information pages imported from Appearance → Starter content (or marked with _fileora_page_role).
		foreach ( fileora_theme_info_pages() as $p ) {
			if ( 'accessibility' === $p['role'] && fileora_theme_mod( 'a11y_widget' ) ) {
				continue; // reached from the accessibility button instead
			}
			$links[ get_the_title( $p['id'] ) ] = array( get_permalink( $p['id'] ), $p['desc'] );
		}
		if ( ! $links ) {
			$blog = fileora_theme_blog_url();
			if ( $blog ) {
				$links[ __( 'Blog', 'fileora' ) ] = $blog;
			}
			$privacy = get_privacy_policy_url();
			if ( $privacy ) {
				$links[ __( 'Privacy policy', 'fileora' ) ] = $privacy;
			}
		}
		$mail = sanitize_email( fileora_theme_mod( 'contact_email' ) );
		if ( $mail && ! in_array( 'contact', wp_list_pluck( fileora_theme_info_pages(), 'role' ), true ) ) {
			$links[ __( 'Contact', 'fileora' ) ] = 'mailto:' . $mail;
		}
	}
	if ( ! $links ) {
		return;
	}
	echo '<nav aria-label="' . esc_attr( $title ) . '"><h2 class="ftr-h">' . esc_html( $title ) . '</h2>';
	foreach ( $links as $label => $url ) {
		$title = is_array( $url ) ? $url[1] : '';
		$url   = is_array( $url ) ? $url[0] : $url;
		echo '<a href="' . esc_url( $url ) . '"' . ( $title ? ' title="' . esc_attr( $title ) . '"' : '' ) . '>' . esc_html( $label ) . '</a>';
	}
	echo '</nav>';
}

/**
 * The tool groups for footer columns 1–3: PDF, Convert and Images, each used
 * once. When a group has no visible tools (for example the converters while
 * the processing server is off), another unused group takes its place.
 */
function fileora_theme_footer_groups() {
	static $out = null;
	if ( null !== $out ) {
		return $out;
	}
	$out    = array();
	$groups = array_values(
		array_filter(
			fileora_theme_groups(),
			function ( $g ) {
				return ! empty( $g['tools'] );
			}
		)
	);
	$used = array();
	$want = array( 1 => 'pdf', 2 => 'converter', 3 => 'image' );
	foreach ( $want as $n => $module ) {
		foreach ( $groups as $i => $g ) {
			if ( $g['module'] === $module ) {
				$out[ $n ]  = $g;
				$used[ $i ] = true;
			}
		}
	}
	foreach ( $want as $n => $module ) {
		if ( isset( $out[ $n ] ) ) {
			continue;
		}
		foreach ( $groups as $i => $g ) {
			if ( empty( $used[ $i ] ) ) {
				$out[ $n ]  = $g;
				$used[ $i ] = true;
				break;
			}
		}
	}
	return $out;
}

/** Social links from the Customizer. */
function fileora_theme_social() {
	$nets = array( 'x' => 'X', 'facebook' => 'Facebook', 'instagram' => 'Instagram', 'linkedin' => 'LinkedIn', 'youtube' => 'YouTube' );
	$out  = '';
	foreach ( $nets as $k => $label ) {
		$url = fileora_theme_mod( 'social_' . $k );
		if ( $url ) {
			$out .= '<a href="' . esc_url( $url ) . '" rel="me noopener" target="_blank">' . esc_html( $label ) . '</a>';
		}
	}
	if ( $out ) {
		echo '<div class="social">' . $out . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

/** Published information pages in footer order: About, FAQ, Security, Privacy Policy, Disclaimer, Accessibility, Contact, Sitemap. */
function fileora_theme_info_pages() {
	static $out = null;
	if ( null !== $out ) {
		return $out;
	}
	$order = array(
		'about'      => __( 'Website purpose, services and background', 'fileora' ),
		'faq'        => __( 'Common questions about using the tools', 'fileora' ),
		'security'   => __( 'Browser processing, our server and data protection', 'fileora' ),
		'privacy'    => __( 'Data collection, processing and retention', 'fileora' ),
		'disclaimer' => __( 'Tool limitations and terms of use', 'fileora' ),
		'accessibility' => __( 'How the site works with assistive technology', 'fileora' ),
		'contact'    => __( 'Send us a message', 'fileora' ),
		'sitemap'    => __( 'All public pages and tools', 'fileora' ),
	);
	$found = array();
	$pages = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 20,
			'meta_key'       => '_fileora_page_role', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'no_found_rows'  => true,
		)
	);
	foreach ( $pages as $p ) {
		$role = get_post_meta( $p->ID, '_fileora_page_role', true );
		if ( isset( $order[ $role ] ) && ! isset( $found[ $role ] ) ) {
			$found[ $role ] = array( 'id' => $p->ID, 'desc' => $order[ $role ], 'role' => $role );
		}
	}
	$out = array();
	foreach ( array_keys( $order ) as $role ) {
		if ( isset( $found[ $role ] ) ) {
			$out[] = $found[ $role ];
		}
	}
	return $out;
}
