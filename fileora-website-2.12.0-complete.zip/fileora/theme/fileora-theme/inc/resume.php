<?php
/**
 * ATS Resume Builder support: the "ATS Resume" header link and the wide page
 * layout. The builder itself comes from the Fileora Core plugin
 * ([fileora_resume_builder]); without the plugin nothing here shows.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

/** The builder page's address, or '' when it doesn't exist. */
function fileora_theme_resume_url() {
	return class_exists( 'Fileora_Resume' ) ? (string) Fileora_Resume::url() : '';
}

/** True on the builder page. */
function fileora_theme_is_resume_page() {
	return class_exists( 'Fileora_Resume' ) && Fileora_Resume::page_id() && is_page( Fileora_Resume::page_id() );
}

/**
 * The builder page uses the wide layout (page-ats-resume-builder.php), even if
 * its address was changed in the editor.
 */
function fileora_theme_resume_template( $template ) {
	if ( fileora_theme_is_resume_page() ) {
		$wide = locate_template( 'page-ats-resume-builder.php' );
		if ( $wide ) {
			return $wide;
		}
	}
	return $template;
}
add_filter( 'page_template', 'fileora_theme_resume_template' );
