<?php
/**
 * Theme setup: supports, menus, scripts, styles, small head tags.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

add_action( 'after_setup_theme', 'fileora_theme_setup' );
function fileora_theme_setup() {
	load_theme_textdomain( 'fileora', FILEORA_THEME_DIR . '/languages' );
	// Tells Fileora Core that this theme places the tool workspace itself.
	add_theme_support( 'fileora' );
	add_theme_support( 'fileora-seo' );
	add_post_type_support( 'page', 'excerpt' ); // the intro line under the title of the All tools page // the theme writes meta descriptions and Open Graph tags for posts and pages
	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support( 'custom-logo', array( 'height' => 72, 'width' => 240, 'flex-height' => true, 'flex-width' => true ) );
	add_theme_support( 'editor-styles' );
	add_editor_style( array( 'assets/css/fonts.css', 'assets/css/editor.css' ) );
	set_post_thumbnail_size( 1200, 675, true );
	add_image_size( 'fileora-card', 720, 405, true );
	register_nav_menus(
		array(
			'primary'  => __( 'Header menu', 'fileora' ),
			'footer-1' => __( 'Footer column 1', 'fileora' ),
			'footer-2' => __( 'Footer column 2', 'fileora' ),
			'footer-3' => __( 'Footer column 3', 'fileora' ),
			'footer-4' => __( 'Footer column 4', 'fileora' ),
			'legal'    => __( 'Footer bottom links (privacy, terms)', 'fileora' ),
		)
	);
}

if ( ! isset( $content_width ) ) {
	$content_width = 760; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
}

add_action( 'wp_enqueue_scripts', 'fileora_theme_assets' );
function fileora_theme_assets() {
	$v = FILEORA_THEME_VERSION;
	// Fonts are served from the theme (no request to Google or another font service).
	wp_enqueue_style( 'fileora-fonts', FILEORA_THEME_URI . '/assets/css/fonts.css', array(), $v );
	wp_enqueue_style( 'fileora-theme', FILEORA_THEME_URI . '/assets/css/theme.css', array(), $v );
	wp_enqueue_script( 'fileora-theme', FILEORA_THEME_URI . '/assets/js/theme.js', array(), $v, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_localize_script( 'fileora-theme', 'FileoraTheme', fileora_theme_js_config() );
	if ( fileora_theme_mod( 'a11y_widget' ) ) {
		wp_enqueue_script( 'fileora-a11y', FILEORA_THEME_URI . '/assets/js/a11y.js', array(), $v, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	}
	if ( fileora_theme_mod( 'motion' ) ) {
		// GSAP 3 (GreenSock "Standard" no-charge licence), served from the theme.
		wp_enqueue_script( 'gsap', FILEORA_THEME_URI . '/assets/vendor/gsap.min.js', array(), '3.14.2', array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_enqueue_script( 'gsap-scrolltrigger', FILEORA_THEME_URI . '/assets/vendor/ScrollTrigger.min.js', array( 'gsap' ), '3.14.2', array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_enqueue_script( 'fileora-motion', FILEORA_THEME_URI . '/assets/js/motion.js', array( 'gsap', 'gsap-scrolltrigger' ), $v, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	}
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}

/** Data for theme.js: the tool list for search, menus and the homepage drop. */
function fileora_theme_js_config() {
	$tools = fileora_theme_core() ? fileora_catalog_data() : array();
	$light = array();
	foreach ( $tools as $t ) {
		$light[] = array(
			'id'     => $t['id'],
			'name'   => $t['name'],
			'desc'   => $t['desc'],
			'keys'   => $t['keys'],
			'url'    => $t['url'],
			'icon'   => $t['icon'],
			'cat'    => $t['cat'],
			'color'  => $t['color'],
			'runs'   => $t['runs'],
			'accept' => $t['accept'],
			'ready'  => ! empty( $t['ready'] ),
		);
	}
	$tool = null;
	if ( fileora_theme_core() && is_singular( 'fileora_tool' ) ) {
		$t    = fileora_get_tool( get_queried_object() );
		$tool = $t ? $t['id'] : null;
	}
	return array(
		'tools'    => $light,
		'tool'     => $tool,
		'search'   => esc_url_raw( home_url( '/' ) ),
		'allTools' => esc_url_raw( fileora_theme_all_tools_url() ),
		'i18n'     => array(
			'noTools'    => __( 'No tools match “%s”.', 'fileora' ),
			'searchBlog' => __( 'Search the blog for “%s”', 'fileora' ),
			'tools'      => __( 'Tools', 'fileora' ),
			'popular'    => __( 'Popular tools', 'fileora' ),
			'recent'     => __( 'Recently used', 'fileora' ),
			'browser'    => __( 'In browser', 'fileora' ),
			'server'     => __( 'Server', 'fileora' ),
			'files'      => __( '%d files', 'fileora' ),
			'noMatch'    => __( 'We don’t have a tool for this kind of file yet.', 'fileora' ),
			'best'       => __( 'Best matches', 'fileora' ),
			'more'       => __( 'More tools for these files', 'fileora' ),
		),
	);
}

/** Dark mode before first paint (avoids a white flash), and font preloads. */
add_action( 'wp_head', 'fileora_theme_head', 1 );
function fileora_theme_head() {
	foreach ( array( 'geist-sans-latin-400-normal', 'bricolage-grotesque-latin-800-normal' ) as $font ) {
		echo '<link rel="preload" href="' . esc_url( FILEORA_THEME_URI . '/assets/fonts/' . $font . '.woff2' ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
	}
	echo "<script>(function(){try{var t=localStorage.getItem('fileora.theme');t=t?JSON.parse(t):null;if(!t)t=matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';document.documentElement.setAttribute('data-theme',t);}catch(e){}})();</script>\n";
	// Accessibility choices before first paint, and the "motion" class that lets the header animate in (with a fallback if scripts never run).
	$motion = fileora_theme_mod( 'motion' ) ? 1 : 0;
	echo "<script>(function(){var d=document.documentElement,a={};try{a=JSON.parse(localStorage.getItem('fileora.a11y')||'{}')||{};}catch(e){}"
		. "if(a.text)d.classList.add('fo-a11y-text-'+a.text);['contrast','links','readable','spacing','motion','cursor'].forEach(function(k){if(a[k])d.classList.add('fo-a11y-'+k);});"
		. "if(" . $motion . "&&!a.motion&&!matchMedia('(prefers-reduced-motion: reduce)').matches){d.classList.add('fo-motion');setTimeout(function(){d.classList.add('fo-motion-done');},2500);}})();</script>\n";
	echo '<meta name="theme-color" content="#F2F3F8" media="(prefers-color-scheme: light)"><meta name="theme-color" content="#0E1020" media="(prefers-color-scheme: dark)">' . "\n";
}

/** Homepage meta description when no SEO plugin writes one. */
add_action( 'wp_head', 'fileora_theme_meta', 2 );
function fileora_theme_meta() {
	if ( ! is_front_page() || defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || class_exists( 'The_SEO_Framework\Load' ) ) {
		return;
	}
	$d = trim( (string) fileora_theme_mod( 'home_meta' ) );
	if ( '' !== $d ) {
		echo '<meta name="description" content="' . esc_attr( $d ) . '">' . "\n";
	}
}

add_filter( 'body_class', 'fileora_theme_body_class' );
function fileora_theme_body_class( $classes ) {
	$classes[] = 'fileora-theme';
	if ( ! fileora_theme_core() ) {
		$classes[] = 'fileora-no-core';
	}
	return $classes;
}

add_filter( 'excerpt_length', function () { return 26; } );
add_filter( 'excerpt_more', function () { return '…'; } );

/** Search results: tools first, then posts and pages. */
add_action( 'pre_get_posts', 'fileora_theme_search_query' );
function fileora_theme_search_query( $q ) {
	if ( is_admin() || ! $q->is_main_query() || ! $q->is_search() ) {
		return;
	}
	$types = array( 'post', 'page' );
	if ( fileora_theme_core() ) {
		array_unshift( $types, 'fileora_tool' );
	}
	$q->set( 'post_type', $types );
}

/**
 * Create the “All tools” page once, when the theme is switched on with
 * Fileora Core active. It uses the “All tools” page template.
 */
add_action( 'after_switch_theme', 'fileora_theme_create_pages' );
add_action( 'fileora_core_tools_synced', 'fileora_theme_create_pages' );
// Theme updates don't fire after_switch_theme: check once per theme version.
add_action(
	'admin_init',
	function () {
		if ( get_option( 'fileora_theme_pages' ) !== FILEORA_THEME_VERSION && current_user_can( 'publish_pages' ) ) {
			fileora_theme_create_pages();
			update_option( 'fileora_theme_pages', FILEORA_THEME_VERSION, false );
		}
	}
);
function fileora_theme_create_pages() {
	if ( fileora_theme_core() && ! fileora_theme_all_tools_page() ) {
		fileora_theme_ensure_page( 'all-tools', __( 'All tools', 'fileora' ), 'page-all-tools.php' );
	}
	// A blog listing at /blog/, unless Settings → Reading already has a posts page.
	if ( ! get_option( 'page_for_posts' ) && ! fileora_theme_template_page( 'page-blog.php' ) ) {
		fileora_theme_ensure_page( 'blog', __( 'Blog', 'fileora' ), 'page-blog.php' );
	}
}

/** Creates (or re-uses) a published page with a page template. */
function fileora_theme_ensure_page( $slug, $title, $template ) {
	$existing = get_page_by_path( $slug );
	if ( $existing ) {
		update_post_meta( $existing->ID, '_wp_page_template', $template );
		return $existing->ID;
	}
	$admins = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID' ) );
	return wp_insert_post(
		array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $title,
			'post_name'    => $slug,
			'post_author'  => $admins ? (int) $admins[0] : 0,
			'post_content' => '',
			'meta_input'   => array( '_wp_page_template' => $template ),
		)
	);
}

/** Admin-only reminder when the theme runs without the plugin. */
add_action( 'admin_notices', 'fileora_theme_admin_notice' );
function fileora_theme_admin_notice() {
	if ( fileora_theme_core() || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( $screen && ! in_array( $screen->id, array( 'dashboard', 'themes', 'plugins' ), true ) ) {
		return;
	}
	echo '<div class="notice notice-info"><p>' . esc_html__( 'The Fileora theme is active, but the Fileora Core plugin is not. The website works as a blog; activate Fileora Core to show the PDF and image tools.', 'fileora' ) . '</p></div>';
}
