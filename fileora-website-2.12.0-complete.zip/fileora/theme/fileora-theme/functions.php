<?php
/**
 * Fileora theme.
 *
 * The theme draws the website: header, homepage, tool catalogue, tool pages,
 * blog and footer. The tools themselves come from the Fileora Core plugin.
 * Every call into the plugin is guarded, so the theme keeps working as a
 * plain blog theme when the plugin is switched off.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

define( 'FILEORA_THEME_VERSION', '2.8.0' );
define( 'FILEORA_THEME_DIR', get_template_directory() );
define( 'FILEORA_THEME_URI', get_template_directory_uri() );

require FILEORA_THEME_DIR . '/inc/customizer.php';
require FILEORA_THEME_DIR . '/inc/icons.php';
require FILEORA_THEME_DIR . '/inc/template-tags.php';
require FILEORA_THEME_DIR . '/inc/nav.php';
require FILEORA_THEME_DIR . '/inc/blog.php';
require FILEORA_THEME_DIR . '/inc/starter-posts.php';
require FILEORA_THEME_DIR . '/inc/setup.php';
require FILEORA_THEME_DIR . '/inc/favicon.php';
require FILEORA_THEME_DIR . '/inc/a11y.php';
require FILEORA_THEME_DIR . '/inc/resume.php';
