---
title: Disclaimer
slug: disclaimer
role: disclaimer
order: 5
seo_title: Disclaimer and Terms of Use for Our Free Tools
description: The limits of our free online tools, checking your results, third-party services, availability, permitted use and limitation of liability.
focus_keyword: disclaimer
---
Please read this disclaimer before using [fileora_privacy field="site"]. By using the website and its tools, you accept it.

## General information

The website provides free online tools and general guides for working with PDF files and images. The guides and FAQ are for general information only. They are not legal, financial or official advice, and requirements set by government bodies, exam boards, banks or employers always take priority.

[fileora_privacy field="site"] is an independent website. It is not affiliated with, endorsed by or connected to UIDAI, any government department, exam board or the makers of the file formats and software it supports. Names such as Aadhaar, PDF, Word, Excel and PowerPoint are used only to describe what the tools work with.

## Tool accuracy and output limitations

We work hard to make the tools reliable, but we can’t guarantee that every result will be accurate, complete or suitable for your purpose. Results depend on:

- the file you provide (its quality, format, fonts, scans, passwords or damage);
- the options you choose;
- your browser, device and available memory, for tools that run in your browser;
- the availability of our processing server, for tools that use it;
- for AI tools, if offered, the behaviour of the AI provider, whose output can contain mistakes.

Conversions between formats (for example PDF to Word) may change layout or fonts. Text recognition (OCR) and AI summaries can contain errors. Compression reduces quality. Printed sizes depend on your printer settings.

## Your responsibility

Always review a result before you rely on it, submit it or delete your original. In particular, check that documents for official use (ID card prints, exam photos and signatures, application files) meet the current requirements of the organisation that asked for them. Keep a copy of your original files.

## Third-party services and links

Some features depend on services we don’t control, such as our hosting providers, content delivery networks and, where offered, AI providers. Their availability and behaviour can change. Our guides link to external websites for convenience; we are not responsible for their content, availability or privacy practices.

## Availability and technical errors

The tools are provided free of charge, “as is” and “as available”. They may be changed, limited, interrupted or withdrawn at any time, for example for maintenance, updates or abuse prevention. Server tools have file size and daily usage limits. We are not responsible for losses caused by interruptions, errors or data loss.

## Permitted use and intellectual property

You may use the tools for lawful personal and business purposes. Only process files you own or have the right to use. Don’t use the tools to remove protection from documents you are not allowed to open, to infringe copyright or other rights, to process illegal content, or to overload or attack the service.

The website’s design, text, guides and software are protected by copyright and belong to the website owner or their licensors. The open-source components we use remain under their own licences. Files you process remain yours.

## Limitation of liability

To the fullest extent permitted by applicable law, the website owner is not liable for any direct, indirect or consequential loss arising from the use of, or inability to use, the website, its tools or its content, including loss of data, documents or income. Nothing in this disclaimer limits liability that cannot be limited under applicable law.

## Changes

We may update this disclaimer and the website’s features at any time. The current version is always published on this page.

*Last updated: [fileora_last_updated]*

Questions? Write to [fileora_privacy field="email"].
