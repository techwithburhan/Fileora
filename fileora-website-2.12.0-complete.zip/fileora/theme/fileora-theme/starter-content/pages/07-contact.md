---
title: Contact
slug: contact
role: contact
order: 7
seo_title: Contact Us: Questions, Tool Problems and Privacy Requests
description: Send us a message about a tool that isn't working, a privacy or data request, accessibility, or anything else. We reply by email.
focus_keyword: contact us
---
Questions, ideas, a tool that isn't working, or a privacy request: send us a message and we will reply by email.

[fileora_contact]

## Before you write

- **A tool gave an error?** Tell us the tool, what kind of file you used (for example “scanned PDF, 12 pages, 8 MB”) and the error message. Please don’t attach the file itself.
- **Privacy or data requests:** choose “Privacy or data request” as the topic. Our [Privacy Policy]({home}/privacy-policy/) explains what we keep and for how long.
- **Accessibility:** if something is hard to use with your device or assistive technology, see our [Accessibility]({home}/accessibility/) page and tell us where you got stuck.

You can also write to [fileora_privacy field="email"].

## What happens to your message

We use your name, email address and message only to answer you. Messages are kept [fileora_privacy field="message_keep"] and then deleted. We never add you to a mailing list.
