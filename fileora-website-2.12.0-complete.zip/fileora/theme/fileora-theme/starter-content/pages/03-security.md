---
title: Security
slug: security
role: security
order: 3
seo_title: Security: How Your Files Are Processed and Protected
description: How our tools process your files, which tools run in your browser, what happens on our processing server, what we keep, and the safeguards we use.
focus_keyword: file security
---
This page explains, in plain language, how your files move when you use our tools, what we keep, and how we protect the site. It describes how the site actually works today; the tool table below is generated from the site’s current settings.

## How your files are processed

There are two ways a tool can work, and every tool page tells you which one it uses before you add a file.

### Tools marked “In browser”

**Your device → the tool runs in your browser → the result is saved on your device**

The file is opened and processed by your own browser, on your own device. It is not uploaded to our website, our processing server or any other service. The software the tool needs (for example the open-source pdf.js, pdf-lib and JSZip libraries) is downloaded from our website like any other part of the page; your file is not part of that download.

### Tools marked “Server”

**Your browser → our website (encrypted, HTTPS) → our processing server (encrypted, HTTPS) → the result back to your browser**

Some jobs need software that can’t run in a browser, such as an office suite for Word to PDF or text recognition for OCR. For these tools your file is sent to our website, which passes it on to our own processing server, hosted by [fileora_privacy field="host_server"]. When the result is ready, your browser downloads it from us.

### Which tools work which way

[fileora_data_flow]

## File storage and retention

**Our in-browser tools process files directly in your browser. We do not receive or store the contents of those files.**

For server tools:

- Your file and its result are kept on our processing server only while the task runs and until you download the result.
- The result can be downloaded once, with a private link that only your browser knows.
- After the download, both are deleted. Anything not downloaded is deleted automatically [fileora_privacy field="deletion"].
- Our website passes the file on without keeping a copy.
- Passwords you type into Protect PDF or Unlock PDF are used for that task only and are not stored.

We do keep some information that is not file content: visit statistics, the tool used, and, for each processing task, details such as the file name, size, time and whether it worked. Our [Privacy Policy]({home}/privacy-policy/) lists exactly what is recorded and for how long.

## Third-party services

- **Your files:** none of our PDF, image, converter, optimizer or security tools sends files to a third-party service. If an AI tool is listed in the table above, it sends the document’s text from our server to the AI provider named there, which handles it under its own terms and privacy policy.
- **Fallback for tool software:** if a tool’s software library can’t be loaded from our website, your browser may load the same library from a public content delivery network (cdnjs or jsDelivr). That request includes your IP address, as any web request does, but never your files.
- **Hosting:** the website is hosted by [fileora_privacy field="host_web"], and the processing server by [fileora_privacy field="host_server"].

### Keys and credentials

The secret key that connects our website to our processing server, and any key for an AI provider, are stored only on our servers. They are never included in the pages or code sent to your browser.

## Security measures

These are the safeguards in place on this site:

- **Encrypted connections:** pages and file transfers use HTTPS.
- **A private processing server:** it only accepts requests that carry our website’s secret key, and it is not used directly by browsers.
- **File checks:** uploads are checked for type and size before they are processed, and the processing server works on each task in its own temporary folder.
- **One-time results:** each result is tied to a random token known only to the browser that started the task.
- **Abuse limits:** server tools have a daily limit per visitor, and the HTML to PDF tool refuses addresses on private networks.
- **Access control:** administration is limited to named accounts with specific permissions; support staff see only what they need.
- **Careful code:** inputs are validated, output is escaped, and administrative actions are protected against forged requests.
- **Data minimisation:** detailed visit records are kept [fileora_privacy field="event_keep"], task records [fileora_privacy field="task_keep"]; after that only daily totals without visitor details remain.

We keep WordPress, its plugins and the processing server’s software up to date.

## What we don’t claim

No website connected to the internet can promise zero risk, and we don’t claim to be “100% safe”. What we can do is keep the data flow simple, keep as little as possible for as short a time as possible, and tell you honestly how it works. For sensitive documents, the tools marked “In browser” are the most private choice, because the file never leaves your device.

## Report a security issue

If you believe you have found a security problem, please email [fileora_privacy field="email"] with the details. Please don’t include other people’s personal data.

*Last updated: [fileora_last_updated]*
