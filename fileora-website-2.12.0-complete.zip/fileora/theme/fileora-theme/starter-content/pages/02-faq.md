---
title: FAQ
slug: faq
role: faq
order: 2
seo_title: FAQ: Using Our Free PDF and Image Tools
description: Answers about using the tools, where your files are processed, whether files are stored, privacy, supported browsers and how to get help.
focus_keyword: pdf tools faq
---
Can’t find your answer? Write to us at [fileora_privacy field="email"].

## General questions

??? What is this website?
A free collection of online tools for PDF files and images: merge, split, compress, convert, sign, protect, resize and more. You can use them in your browser without installing anything.

??? What tools and services are available?
PDF tools, image tools, file converters (Word, Excel, PowerPoint and web pages to PDF and back), optimizer tools (compress, repair, OCR, PDF/A) and security tools (protect, unlock, redact). The All tools page lists every tool with a short description.

??? How do I use the online tools?
Open a tool, drop your file into the box or tap the button to choose it, check the options, and press the button. When it is done, download the result. Many tools show a preview before you start.

??? Are the tools accessible on mobile devices?
Yes. Every tool works on Android phones, iPhones and tablets in a current browser. Some tools, such as Scan to PDF, can use your phone’s camera.

??? Do I need to create an account to use the tools?
No. You can use the tools without signing up or logging in.

## File processing and tools

??? How do I upload or select a file?
Drag the file into the box on the tool page, or tap the button and choose it from your device. On a phone you can pick files from your gallery or files app. Some tools accept several files at once.

??? Where is my file processed?
It depends on the tool, and each tool page tells you before you add a file. Tools marked “In browser” process the file on your own device. Tools marked “Server” send it over an encrypted connection to our own processing server. The table on our Security page lists every tool.

??? Does the website store uploaded files?
Files used with “In browser” tools never reach us, so there is nothing to store. Files sent to our processing server are kept only while the task runs and until you download the result, and are deleted automatically [fileora_privacy field="deletion"] if you don’t. We never keep copies of your files.

??? Can I use the tools without installing software?
Yes. Everything runs in your web browser. There is no app or extension to install.

??? What happens if a tool or the server fails?
You see a message explaining what went wrong, and your original file is not changed. If our processing server is unavailable, server tools say so and suggest tools that work in your browser; Compress PDF and Repair PDF use a browser version while the server is unavailable.

??? Why was a file-processing operation unsuccessful?
The most common reasons are a password-protected file (unlock it first, or type its password where the tool asks), a damaged or incomplete file, a file type the tool doesn’t accept, a file larger than the limit ([fileora_privacy field="max_mb"] MB for server tools), or the daily limit for server tools. Very large files can also be too heavy for older phones; try a computer.

## Privacy and security

??? Does the website store users’ files on its own servers?
Not for “In browser” tools: those files never leave your device. For “Server” tools, your file is stored temporarily on our processing server to do the job and is deleted after download or automatically [fileora_privacy field="deletion"].

??? Are files sent to third-party APIs?
No file is sent to a third-party service by our PDF, image, converter, optimizer or security tools. If AI tools are offered on this site, they send the document’s text to an AI provider, and the Security page names the provider. The software libraries the tools use are loaded from our own website.

??? What information does the website collect?
We record basic visit statistics in our own database: pages and tools used, time of visit, approximate location, device and browser, and, as described in our Privacy Policy, your IP address and the names of files used in tools. We never record the contents of your files.

??? Does the website record visitor analytics?
Yes, with our own first-party analytics. No third-party analytics service and no tracking cookies are used. If your browser sends “Do Not Track” or “Global Privacy Control”, nothing is recorded. Details are in our Privacy Policy.

??? How can I contact the website regarding privacy concerns?
Write to [fileora_privacy field="email"]. Tell us roughly when you visited and which tool you used, so we can find the records concerned.

## Technical support

??? What should I do if a tool does not work?
Reload the page, make sure your browser is up to date, and try again. If the tool still doesn’t start, an ad blocker or privacy extension may be blocking it: allow this site and reload. You can also try another browser or a smaller file.

??? Which browsers are supported?
Current versions of Chrome, Edge, Firefox, Safari and Samsung Internet on Windows, macOS, Linux, Android and iOS. Internet Explorer is not supported.

??? How can I report a technical issue?
Email [fileora_privacy field="email"] with the tool name, your device and browser, and the exact message you saw. Please don’t attach the file unless we ask for it and it contains nothing private.

??? How can I request assistance?
Write to [fileora_privacy field="email"]. We read every message and reply as soon as we can.
