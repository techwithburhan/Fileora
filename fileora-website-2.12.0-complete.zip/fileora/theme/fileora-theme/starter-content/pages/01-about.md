---
title: About Us
slug: about-us
role: about
order: 1
seo_title: About Us: Free PDF and Image Tools, Built for Privacy
description: Who we are, which free PDF and image tools we offer and how we handle your files: most tools run in your browser, the rest on our own server.
focus_keyword: free pdf tools
---
[fileora_privacy field="site"] is a collection of free online tools for everyday work with PDF files and images: merging and splitting PDFs, converting Word, Excel and PowerPoint files, compressing documents for upload limits, resizing photos for forms, printing ID cards at the right size, and much more.

We built it for people who need to get a document right quickly, often on a phone, without installing software, creating an account or wondering what happens to their files.

## What you can do here

[fileora_data_flow view="counts"]

The tools are grouped by what you want to do:

- **PDF tools:** merge, split, organize, rotate, crop, sign, number pages, add watermarks, print Aadhaar and other ID cards at real size, and more.
- **Image tools:** compress, resize, crop and convert photos, make passport and exam-form photos, remove hidden photo data, convert iPhone HEIC photos.
- **File converters:** Word, Excel, PowerPoint and web pages to PDF, and PDF back to Word, Excel or PowerPoint.
- **Optimizer and security tools:** compress, repair, OCR, PDF/A, password-protect, unlock and redact PDFs.

You can find every tool on the [All tools]({home}/all-tools/) page, or search for one from the top of any page.

## How to use the tools

1. Open the tool you need.
2. Drop your file into the box, or tap the button to choose it from your device.
3. Check the options. The defaults work for most files, and many tools show a preview.
4. Press the button and download your result.

There is nothing to install and no account to create. The tools work in current versions of Chrome, Edge, Firefox, Safari and Samsung Internet, on computers, tablets and phones.

## How we handle your files

We designed the site so that your files leave your device as rarely as possible:

- **Tools marked “In browser”** process your file on your own device, inside your browser. The file is never uploaded to us.
- **Tools marked “Server”** need software that can’t run in a browser, such as an office suite or text recognition. They send your file over an encrypted connection to our own processing server, which deletes it after you download the result, or automatically [fileora_privacy field="deletion"].

Every tool page shows which kind it is before you add a file. Our [Security]({home}/security/) page explains the data flow in detail, and our [Privacy Policy]({home}/privacy-policy/) explains what visitor information we record and for how long.

## What we care about

- **Usability:** clear steps, sensible defaults and tools that work on a phone.
- **Transparency:** we say where each file is processed and what we keep, and we update those pages when something changes.
- **Privacy-conscious design:** no sign-up, no file storage beyond what a task needs, no third-party analytics service.

## Contact

Questions, ideas or a tool you are missing? Write to us at [fileora_privacy field="email"].
