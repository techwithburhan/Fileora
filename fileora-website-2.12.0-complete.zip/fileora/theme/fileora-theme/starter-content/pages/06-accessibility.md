---
title: Accessibility
slug: accessibility
role: accessibility
order: 6
seo_title: Accessibility Statement: Assistive Technology Support
description: How our website and tools work with keyboards, screen readers and zoom, what we are still improving, and how to report an accessibility problem.
focus_keyword: accessibility statement
---
We want everyone to be able to use [fileora_privacy field="site"], including people who use a keyboard instead of a mouse, a screen reader, screen magnification, voice control or high-contrast settings. We aim to meet the Web Content Accessibility Guidelines (WCAG) 2.2 at level AA.

## What we have done

| Area | What it means for you |
|---|---|
| **Keyboard** | Every menu, button, tool option and dialog can be reached with Tab and used with Enter, Space and the arrow keys. A visible outline shows where you are. |
| **Skip link** | The first Tab on every page offers “Skip to content”, so you don’t have to pass the menu each time. |
| **Search shortcut** | Press `/` to open tool search; use the arrow keys to move and Enter to open a tool. |
| **Screen readers** | Pages use real headings, landmarks (header, navigation, main, footer) and lists. Buttons and icons have text labels, and progress and results of a tool are announced. |
| **Uploading files** | Every tool has a normal “Choose files” button; dragging and dropping is never required. |
| **Text size and zoom** | Pages can be zoomed to 200% and text resized without losing content or needing to scroll sideways. |
| **Colour and contrast** | Text meets the WCAG AA contrast ratio in light and dark mode. Colour is never the only way information is shown: statuses also have words or icons. |
| **Dark mode** | Switch between light and dark with the moon icon; the first visit follows your device setting. |
| **Less motion** | If your device asks for reduced motion, animations and smooth scrolling are switched off. |
| **Phones and tablets** | Pages and tools adapt from small phones to large screens, in portrait and landscape. |
| **No time limits** | Nothing on the site times out while you are working. Results stay available until you leave the page. |
| **Forms** | Every field has a visible label; errors are explained in words next to the field. |
| **Language** | The page language is set, so screen readers use the right pronunciation. |

## Known limitations

We are still improving these:

- **Tools where you mark a spot on the page**, such as Sign PDF, Crop Image and Blur Part of Image, are easiest with a mouse or touch screen. With a keyboard, Sign PDF and Crop Image use option fields for size and position, and the boxes in Blur Part of Image move with the arrow keys and resize with Shift + arrow keys, but placing them exactly takes longer.
- **The accessibility of a downloaded file** depends mostly on the original file. For example, a scanned PDF has no text for a screen reader until you run OCR PDF on it, and converting a document does not add missing headings or image descriptions.
- **Older blog posts and third-party content**, such as embedded videos, may not meet every guideline.

If one of these stops you from doing something, contact us and we will help you get the result another way.

## How we test

We check pages with automated accessibility tests (axe), by using them with the keyboard only, at 200% zoom and on small phone screens. Automated tests find only part of the problems, so your feedback matters, especially from people who use a screen reader or other assistive technology every day.

## Tell us about a problem

If something on the site is hard to use, please tell us which page or tool, what you were trying to do and, if you like, which browser and assistive technology you use. Use our [contact form]({home}/contact/) or write to [fileora_privacy field="email"]. We read every message and reply by email.

*Last reviewed: [fileora_last_updated]*
