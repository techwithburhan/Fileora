---
title: Privacy Policy
slug: privacy-policy
role: privacy
order: 4
seo_title: Privacy Policy: Files, Analytics and Your Rights
description: What we process when you use our tools, the difference between your files and visit statistics, how long we keep data and how to contact us.
focus_keyword: privacy policy
---
This Privacy Policy explains what information [fileora_privacy field="site"] processes when you visit the website or use its tools, why, and for how long. It describes how the site actually works. If you have questions, write to [fileora_privacy field="email"].

## Information we process

| Type of information | When | What happens to it |
|---|---|---|
| **File contents** | When you use a tool | “In browser” tools: processed on your device, never sent to us. “Server” tools: sent to our processing server, deleted after download or automatically [fileora_privacy field="deletion"]. |
| **What you type into a tool** | Options, page numbers, watermark text, passwords | Used only to perform the task. For “In browser” tools it stays on your device; for “Server” tools it is sent with the file and not stored. |
| **Visitor analytics** | When you open pages and use tools | Recorded in our own database, as described below. |
| **Processing task records** | When you use a “Server” tool | File name, number and size of files, tool, time, duration, result and error message; kept [fileora_privacy field="task_keep"]. |
| **IP address** | Every web request | Needed to deliver the website; how we store it is described below. |
| **Browser and device information** | Every web request | Device type, browser and operating system, read from your browser’s user agent. |
| **Contact form messages** | When you send us a message | Your name, email address, topic and message, used only to answer you; kept [fileora_privacy field="message_keep"]. |
| **Technical logs** | Every web request | Our hosting providers keep standard server logs (IP address, time, address requested) for security and troubleshooting, for a limited time. |
| **Information processed by third-party services** | Only where stated below | See “Third-party services”. |

We never record the contents of your files in analytics or logs.

## Browser-based processing

Tools marked “In browser” run entirely on your device. When you use them, your file is not uploaded to our website, our processing server or any other service. The table below is generated from the site’s current settings and shows which tools work this way.

[fileora_data_flow]

## Server processing

Tools marked “Server” send your file over an encrypted connection (HTTPS) to our website, which forwards it to our processing server, hosted by [fileora_privacy field="host_server"]. The server performs the task and keeps the file and result only until you download the result, or deletes them automatically [fileora_privacy field="deletion"]. Our website does not keep a copy. More details are on our [Security]({home}/security/) page.

## Third-party services

- **AI tools:** if the table above lists an AI tool, using it sends your document’s text from our server to Anthropic (the Claude API) to produce the result. Anthropic processes it under its own terms: [Anthropic Privacy Policy](https://www.anthropic.com/legal/privacy). No other tool sends files to a third party.
- **Tool software fallback:** if a tool’s software library can’t be loaded from our website, your browser may load it from cdnjs (Cloudflare) or jsDelivr. These services see your IP address but never your files.
- **Avatars:** blog comments and author boxes show profile pictures from Gravatar, a service of Automattic. Your browser loads them from Gravatar, which sees your IP address: [Automattic Privacy Policy](https://automattic.com/privacy/).
- **Hosting:** the website is hosted by [fileora_privacy field="host_web"], and the processing server by [fileora_privacy field="host_server"]. They process data on our behalf to run the services.

We do not sell your information and we do not use advertising or third-party analytics trackers.

## Website analytics

We use our own analytics, stored in our WordPress database. With the current settings it records:

[fileora_privacy_facts]

### Cookies and browser storage

Our analytics use no cookies. The site stores a few small items in your browser’s local storage or session storage:

| Item | Purpose |
|---|---|
| `fileora.vid`, `fileora.first` | Random visitor ID, to tell unique visitors from repeat visits |
| `fileora.sid`, `fileora.sts` | Visit ID and last activity, to group page views into a visit |
| `fileora.theme`, `fileora.recent` | Your light/dark mode choice and recently used tools |
| `fileora.notice.*` | Which announcements you have already closed |

You can delete these at any time in your browser settings. WordPress also sets cookies if you log in, or if you ask it to remember your name when you leave a comment.

## Data retention

- **File contents:** not kept. “In browser” files never reach us; “Server” files are deleted after download or automatically [fileora_privacy field="deletion"].
- **Visit statistics:** [fileora_privacy field="event_keep"]. After that only daily totals remain (counts per day and per tool, without visitor IDs, locations or IP addresses).
- **Processing task records:** [fileora_privacy field="task_keep"].
- **IP addresses in our records:** erased after [fileora_privacy field="ip_days"] days.
- **Server logs at our hosting providers:** a limited period set by each provider, for security and troubleshooting.
- **Contact form messages:** [fileora_privacy field="message_keep"].
- **Comments:** until they are deleted.

We keep analytics to understand which tools are used, to keep the service running well and to detect abuse.

## Your rights and choices

- Send “Do Not Track” or “Global Privacy Control” from your browser, and our analytics will not record your visits.
- Clear your browser’s storage for this site to remove your visitor ID.
- Depending on where you live, you may have rights over your personal data, such as access, correction or deletion, including under India’s Digital Personal Data Protection Act, 2023 or the EU General Data Protection Regulation. To use them, write to [fileora_privacy field="email"]. Tell us roughly when you visited and which tools you used, so we can find the records concerned.

The website is not intended for children. If you believe a child has given us personal information, please contact us.

## Changes to this policy

When the way we process information changes, we update this page and the date below. Significant changes are also announced on the website.

*Last updated: [fileora_last_updated]*
