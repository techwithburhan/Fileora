---
title: All Free Online PDF & Image Tools
seo_title: Free Online PDF Tools – Every PDF & Image Tool in One Place
description: All free online PDF tools in one place: merge, split, compress and convert PDFs, sign them and resize photos to KB. No sign-up; most run in your browser.
focus_keyword: free online pdf tools
template: page-all-tools.php
excerpt: Every free online PDF tool and image tool in one place. Merge, compress, convert and sign PDFs, resize photos for online forms and more: no sign-up, no watermark, and most tools run right in your browser.
---
## Free online PDF tools for every task

Fileora brings together free online PDF tools and image tools that you can use in a few clicks, on a computer or a phone. Merge several PDFs into one, split or reorder pages, compress a PDF to 100 KB for an online form, turn Word, Excel or PowerPoint files into PDF and back, add your signature, or resize a photo to 20 KB for an exam application. You don’t need an account, there is no watermark on your files, and you don’t install anything.

Tools marked **In browser** work entirely on your device: your file is never uploaded. Tools marked **Server** send your file over an encrypted connection to our processing server, which deletes it automatically [fileora_privacy field="deletion"]. Each tool says which kind it is before you start.

## Most popular PDF and image tools

- [Merge PDF]({home}/merge-pdf/): combine PDFs in the order you want.
- [Compress PDF]({home}/compress-pdf/): make a PDF smaller for email and upload limits.
- [PDF to Word]({home}/pdf-to-word/) and [Word to PDF]({home}/word-to-pdf/): convert documents in both directions.
- [JPG to PDF]({home}/jpg-to-pdf/): turn photos and scans into one PDF.
- [Sign PDF]({home}/sign-pdf/): draw, type or upload your signature and place it on the page.
- [Compress Image to KB]({home}/compress-image-to-20kb/): make a photo exactly 20, 50 or 100 KB.
- [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/): the right size for SSC, UPSC, IBPS and other forms.
- [Aadhaar Card Print]({home}/aadhaar-card-print/): print both sides of your e-Aadhaar at real card size.
- [PNG & JPG to SVG]({home}/png-to-svg/): turn a logo or signature into a sharp vector file.

## How to use the online PDF tools

1. Pick a tool from the list above, or search with the box at the top of every page (press `/`).
2. Choose or drop your files. Most tools show a preview, so you can check pages or set options first.
3. Press the button and download the result. Files from server tools are deleted automatically; files used in browser tools never leave your device.

## Why people use Fileora

| What you get | What it means |
|---|---|
| Free, no sign-up | Every tool works without an account and without a watermark. |
| Private by design | Most tools run in your browser, so your file stays on your device. |
| Works on mobile | Android phones, iPhones, tablets and computers, in any modern browser. |
| Made for Indian forms | Exact KB sizes for exam photos and signatures, Aadhaar printing, PDF size limits for government portals. |
| Large files | Files up to [fileora_privacy field="max_mb"] MB each on server tools; browser tools are limited only by your device. |

## Which tool should I use?

| I want to… | Use |
|---|---|
| Send one PDF instead of many | [Merge PDF]({home}/merge-pdf/) |
| Upload a PDF that is too big | [Compress PDF]({home}/compress-pdf/) |
| Edit the text of a PDF in Word | [PDF to Word]({home}/pdf-to-word/) |
| Make a PDF from phone photos | [JPG to PDF]({home}/jpg-to-pdf/) or [Scan to PDF]({home}/scan-to-pdf/) |
| Fill an online form with a photo under 50 KB | [Compress Image to KB]({home}/compress-image-to-20kb/) |
| Open a password-protected PDF I own | [Unlock PDF]({home}/unlock-pdf/) |
| Protect a PDF with a password | [Protect PDF]({home}/protect-pdf/) |

## Questions about the free PDF tools

??? Are all the PDF tools really free?
Yes. Every tool on this page is free to use, without an account, a trial period or a watermark.

??? Are my files safe?
Tools marked “In browser” process your file on your own device and never upload it. Tools marked “Server” send it over an encrypted connection to our processing server, which deletes it after you download the result or automatically [fileora_privacy field="deletion"]. Our Security page explains the details.

??? Can I use the PDF tools on my phone?
Yes. All tools work in Chrome, Safari, Firefox and Edge on Android phones, iPhones and tablets. Scan to PDF can also use your phone’s camera.

??? Do I need to install software?
No. Everything runs in your web browser, on Windows, Mac, Linux, Android and iPhone.

??? What is the difference between “In browser” and “Server” tools?
“In browser” tools do the work on your device, so nothing is uploaded. “Server” tools, such as Word to PDF or OCR, need software that can’t run in a browser, so the file is processed on our server and then deleted.
