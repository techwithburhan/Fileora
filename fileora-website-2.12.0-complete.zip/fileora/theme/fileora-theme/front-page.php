<?php
/**
 * Homepage: hero with search and a drop area, the tool catalogue, how it
 * works, why Fileora, latest posts and the FAQ. Texts and sections are set in
 * Appearance → Customize → Fileora → Homepage.
 *
 * If the homepage is a static page with content, that content is shown under
 * the hero.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

if ( 'posts' === get_option( 'show_on_front' ) && is_paged() ) {
	get_template_part( 'index' );
	return;
}

get_header();
$fileora_core  = fileora_theme_core();
$fileora_quick = fileora_theme_quick_tools();
$fileora_del   = $fileora_core ? fileora_deletion_text() : '';
?>
<main id="main">
	<section class="hero">
		<div class="wrap hero-in">
			<div>
				<h1 class="h-display">
					<span class="ln"><span><?php echo esc_html( fileora_theme_mod( 'hero_line1' ) ); ?></span></span>
					<?php if ( fileora_theme_mod( 'hero_line2' ) ) : ?><span class="ln"><span><?php echo esc_html( fileora_theme_mod( 'hero_line2' ) ); ?></span></span><?php endif; ?>
				</h1>
				<p class="lede"><?php echo esc_html( $fileora_core ? fileora_theme_tokens( fileora_theme_mod( 'hero_text' ) ) : get_bloginfo( 'description' ) ); ?></p>
				<button class="hero-search" type="button" data-palette>
					<?php fileora_theme_e_icon( 'search' ); ?>
					<span><?php echo esc_html( $fileora_core ? __( 'What do you want to do? Try “compress pdf”', 'fileora' ) : __( 'Search the site', 'fileora' ) ); ?></span>
					<kbd>/</kbd>
				</button>
				<?php if ( $fileora_quick ) : ?>
					<div class="quick">
						<?php foreach ( $fileora_quick as $t ) : ?>
							<a class="chip" data-cat="<?php echo esc_attr( $t['category'] ? $t['category']['color'] : 'organize' ); ?>" href="<?php echo esc_url( $t['url'] ); ?>"><?php fileora_theme_e_icon( $t['icon'] ); ?><?php echo esc_html( $t['name'] ); ?></a>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
				<?php if ( fileora_theme_mod( 'hero_note' ) ) : ?>
					<p class="hero-note"><?php fileora_theme_e_icon( 'shield' ); ?><?php echo esc_html( fileora_theme_mod( 'hero_note' ) ); ?></p>
				<?php endif; ?>
			</div>

			<div class="stage" id="stage" aria-label="<?php esc_attr_e( 'Drop files here', 'fileora' ); ?>">
				<span class="stage-cap"><?php fileora_theme_e_icon( 'device' ); ?><span id="stage-cap"><?php esc_html_e( 'Merging, right in your browser', 'fileora' ); ?></span></span>
				<div class="stage-scene" aria-hidden="true">
					<span class="st-badge" id="st-badge"></span>
					<span class="st-size" id="st-size"></span>
					<?php
					$fileora_sheet_colors = array( '#2F6BF3', '#E0464C', '#0E9F57' );
					foreach ( $fileora_sheet_colors as $fileora_i => $fileora_col ) :
						?>
						<div class="sheet" data-sheet="<?php echo (int) $fileora_i; ?>">
							<span class="sh-band" style="background:<?php echo esc_attr( $fileora_col ); ?>"></span>
							<i class="h"></i><i></i><i class="m"></i><i></i><i class="s"></i><i class="m"></i><i></i>
							<span class="sh-tag" style="background:<?php echo esc_attr( $fileora_col ); ?>">PDF</span>
							<?php if ( 1 === $fileora_i ) : ?><svg class="sh-sig" viewBox="0 0 120 40"><path d="M4 30c8-14 14-22 18-20s-6 22-2 22 10-18 16-18-2 14 4 14 8-10 12-10 0 8 6 8 10-6 16-6 8 4 14 2 12-6 20-8"/></svg><?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
				<?php if ( $fileora_core ) : ?>
					<div class="stage-drop">
						<span class="tile" style="--c:#FFD43B"><?php fileora_theme_e_icon( 'upload' ); ?></span>
						<p><strong><?php esc_html_e( 'Drop any file here', 'fileora' ); ?></strong><span><?php esc_html_e( 'PDF, Word, Excel, PowerPoint or images. We suggest the right tool.', 'fileora' ); ?></span></p>
						<label class="btn btn-hl file-btn"><?php esc_html_e( 'Choose files', 'fileora' ); ?><input type="file" id="home-files" multiple></label>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<?php
	if ( 'page' === get_option( 'show_on_front' ) ) {
		while ( have_posts() ) {
			the_post();
			if ( '' !== trim( get_the_content() ) ) {
				echo '<section class="sec" style="padding-top:48px"><div class="article prose">';
				the_content();
				echo '</div></section>';
			}
		}
	}

	if ( $fileora_core && fileora_theme_mod( 'show_tools' ) ) {
		get_template_part(
			'template-parts/catalog',
			null,
			array(
				'heading' => fileora_theme_mod( 'tools_title' ),
				'text'    => fileora_theme_mod( 'tools_text' ),
			)
		);
	}

	if ( ! $fileora_core && current_user_can( 'activate_plugins' ) ) :
		?>
		<section class="sec" style="padding-top:24px"><div class="wrap"><div class="notice-box"><?php fileora_theme_e_icon( 'info' ); ?><p><?php esc_html_e( 'Only you see this: activate the Fileora Core plugin to show the tool catalogue here.', 'fileora' ); ?> <a href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>"><?php esc_html_e( 'Plugins', 'fileora' ); ?></a></p></div></div></section>
	<?php endif; ?>

	<?php if ( $fileora_core && fileora_theme_mod( 'show_how' ) ) : ?>
		<section class="how" aria-labelledby="how-h">
			<div class="wrap">
				<div class="how-in">
					<div>
						<h2 class="h2" id="how-h"><?php esc_html_e( 'How it works', 'fileora' ); ?></h2>
					</div>
					<ol class="steps">
						<li><h3><?php esc_html_e( 'Pick a tool', 'fileora' ); ?></h3><p><?php esc_html_e( 'Search for what you need, or drop a file and we suggest a tool.', 'fileora' ); ?></p></li>
						<li><h3><?php esc_html_e( 'Add your files', 'fileora' ); ?></h3><p><?php esc_html_e( 'Choose the settings you want. You see a preview before anything happens.', 'fileora' ); ?></p></li>
						<li><h3><?php esc_html_e( 'Download', 'fileora' ); ?></h3><p><?php esc_html_e( 'Your result is ready in seconds. Keep going with another tool if you need to.', 'fileora' ); ?></p></li>
					</ol>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $fileora_core && fileora_theme_mod( 'show_trust' ) ) : ?>
		<section class="sec" aria-labelledby="trust-h">
			<div class="wrap">
				<div class="sec-head"><h2 class="h2" id="trust-h"><?php esc_html_e( 'Private by design', 'fileora' ); ?></h2></div>
				<div class="trust-grid">
					<div><span class="tile"><?php fileora_theme_e_icon( 'device' ); ?></span><h3><?php esc_html_e( 'Most tools stay on your device', 'fileora' ); ?></h3><p><?php esc_html_e( 'Tools marked “In browser” process files on your own computer or phone. Nothing is uploaded.', 'fileora' ); ?></p></div>
					<div><span class="tile"><?php fileora_theme_e_icon( 'clock' ); ?></span><h3><?php esc_html_e( 'Server files are deleted', 'fileora' ); ?></h3><p><?php /* translators: %s: e.g. "within 1 hour" */ echo esc_html( sprintf( __( 'When a tool needs our server, your file and its result are deleted %s.', 'fileora' ), $fileora_del ) ); ?></p></div>
					<div><span class="tile"><?php fileora_theme_e_icon( 'lock' ); ?></span><h3><?php esc_html_e( 'Encrypted transfers', 'fileora' ); ?></h3><p><?php esc_html_e( 'Uploads and downloads use an encrypted HTTPS connection. Each result can be downloaded once.', 'fileora' ); ?></p></div>
					<div><span class="tile"><?php fileora_theme_e_icon( 'check' ); ?></span><h3><?php esc_html_e( 'No sign-up, no watermark', 'fileora' ); ?></h3><p><?php esc_html_e( 'Use every free tool without an account. Your results are clean, with nothing added.', 'fileora' ); ?></p></div>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php
	if ( fileora_theme_mod( 'show_blog' ) || ! $fileora_core ) :
		$fileora_posts = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 3, 'ignore_sticky_posts' => true, 'no_found_rows' => true ) );
		if ( $fileora_posts->have_posts() ) :
			?>
			<section class="sec" aria-labelledby="blog-h" style="padding-top:<?php echo $fileora_core ? '0' : '48px'; ?>">
				<div class="wrap">
					<div class="sec-head">
						<h2 class="h2" id="blog-h"><?php esc_html_e( 'From the blog', 'fileora' ); ?></h2>
						<?php if ( fileora_theme_blog_url() ) : ?><a class="more-link" href="<?php echo esc_url( fileora_theme_blog_url() ); ?>"><?php esc_html_e( 'All posts', 'fileora' ); ?><?php fileora_theme_e_icon( 'arrow-right', 'ic ic-sm' ); ?></a><?php endif; ?>
					</div>
					<div class="posts">
						<?php
						while ( $fileora_posts->have_posts() ) {
							$fileora_posts->the_post();
							get_template_part( 'template-parts/post-card' );
						}
						wp_reset_postdata();
						?>
					</div>
				</div>
			</section>
			<?php
		endif;
	endif;
	?>

	<?php
	$fileora_faq = $fileora_core && fileora_theme_mod( 'show_faq' ) ? fileora_theme_parse_faq( fileora_theme_mod( 'home_faq' ) ) : array();
	if ( $fileora_faq ) :
		$fileora_mail = sanitize_email( fileora_theme_mod( 'contact_email' ) );
		?>
		<section class="sec" id="faq" style="padding-top:0">
			<div class="wrap">
				<?php
				get_template_part(
					'template-parts/faq',
					null,
					array(
						'items' => $fileora_faq,
						/* translators: %s: email link */
						'intro' => $fileora_mail ? sprintf( __( 'Something else? Write to %s.', 'fileora' ), '<a href="mailto:' . esc_attr( $fileora_mail ) . '">' . esc_html( $fileora_mail ) . '</a>' ) : '',
					)
				);
				?>
			</div>
		</section>
		<?php
		$fileora_ld = array(
			'@context'   => 'https://schema.org',
			'@type'      => 'FAQPage',
			'mainEntity' => array_map(
				function ( $qa ) {
					return array( '@type' => 'Question', 'name' => $qa['q'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $qa['a'] ) );
				},
				$fileora_faq
			),
		);
		echo '<script type="application/ld+json">' . wp_json_encode( $fileora_ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . '</script>';
	endif;
	?>
</main>
<?php
get_footer();
