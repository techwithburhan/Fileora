<?php
/**
 * Category, tag, author and date archives.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
$fileora_title = wp_strip_all_tags( get_the_archive_title() );
$fileora_blog  = fileora_theme_blog_url();
?>
<main id="main">
	<header class="page-head wrap">
		<?php fileora_theme_crumbs( $fileora_blog ? array( __( 'Blog', 'fileora' ) => $fileora_blog, $fileora_title => '' ) : array( $fileora_title => '' ) ); ?>
		<h1><?php echo esc_html( $fileora_title ); ?></h1>
		<?php the_archive_description( '<div class="prose" style="margin-top:12px;color:var(--muted)">', '</div>' ); ?>
		<?php if ( is_category() ) { fileora_theme_category_chips(); } ?>
	</header>
	<div class="wrap blog-list">
		<?php if ( have_posts() ) : ?>
			<div class="posts">
				<?php
				while ( have_posts() ) {
					the_post();
					get_template_part( 'template-parts/post-card' );
				}
				?>
			</div>
			<?php fileora_theme_pagination(); ?>
		<?php else : ?>
			<div class="empty"><h3><?php esc_html_e( 'No posts here yet', 'fileora' ); ?></h3></div>
		<?php endif; ?>
	</div>
</main>
<?php
get_footer();
