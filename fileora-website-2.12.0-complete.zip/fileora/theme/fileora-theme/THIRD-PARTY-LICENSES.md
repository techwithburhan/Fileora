# Third-party software in the Fileora theme

| Software | Version | Files | Licence |
|---|---|---|---|
| GSAP (GreenSock Animation Platform) and ScrollTrigger | 3.14.2 | `assets/vendor/gsap.min.js`, `assets/vendor/ScrollTrigger.min.js` | GreenSock Standard "No Charge" licence, free for commercial use: https://gsap.com/standard-license |
| Geist and Bricolage Grotesque fonts | – | `assets/fonts/` | SIL Open Font License 1.1 |
