<?php
/**
 * Blog listing (and the fallback for other views): newest post as a large
 * card, topic chips, then the other posts.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
$fileora_title = is_home() && get_option( 'page_for_posts' ) ? get_the_title( (int) get_option( 'page_for_posts' ) ) : __( 'Blog', 'fileora' );
$fileora_first = ! is_paged();
?>
<main id="main">
	<header class="page-head wrap">
		<?php fileora_theme_crumbs( array( $fileora_title => '' ) ); ?>
		<h1><?php echo esc_html( $fileora_title ); ?></h1>
		<p><?php echo esc_html( fileora_theme_meta_description() ? fileora_theme_meta_description() : get_bloginfo( 'description' ) ); ?></p>
		<?php fileora_theme_category_chips(); ?>
	</header>
	<div class="wrap blog-list">
		<?php if ( have_posts() ) : ?>
			<?php
			if ( $fileora_first ) {
				the_post();
				get_template_part( 'template-parts/post-card', null, array( 'featured' => true ) );
			}
			?>
			<div class="posts">
				<?php
				while ( have_posts() ) {
					the_post();
					get_template_part( 'template-parts/post-card' );
				}
				?>
			</div>
			<?php fileora_theme_pagination(); ?>
		<?php else : ?>
			<div class="empty"><span class="tile lg"><?php fileora_theme_e_icon( 'file' ); ?></span><h3><?php esc_html_e( 'Nothing here yet', 'fileora' ); ?></h3><p><?php esc_html_e( 'New articles will appear here.', 'fileora' ); ?></p></div>
		<?php endif; ?>
	</div>
</main>
<?php
get_footer();
