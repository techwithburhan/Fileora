<?php
/**
 * A page.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
while ( have_posts() ) :
	the_post();
	?>
	<main id="main">
		<article <?php post_class(); ?>>
			<header class="page-head article article-wide" style="padding-bottom:28px">
				<?php fileora_theme_crumbs( array( get_the_title() => '' ) ); ?>
				<h1><?php the_title(); ?></h1>
			</header>
			<div class="article article-wide">
				<?php if ( has_post_thumbnail() ) : ?><figure class="featured"><?php the_post_thumbnail(); ?></figure><?php endif; ?>
				<div class="prose"><?php the_content(); ?></div>
				<?php wp_link_pages( array( 'before' => '<nav class="pagination">', 'after' => '</nav>' ) ); ?>
				<?php
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
				?>
			</div>
		</article>
	</main>
	<?php
endwhile;
get_footer();
