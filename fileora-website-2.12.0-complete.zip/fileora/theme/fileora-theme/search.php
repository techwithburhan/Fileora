<?php
/**
 * Search results: matching tools as tool cards, then posts and pages.
 *
 * @package Fileora_Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
$fileora_tools = array();
$fileora_posts = array();
while ( have_posts() ) {
	the_post();
	if ( 'fileora_tool' === get_post_type() && fileora_theme_core() ) {
		$t = fileora_get_tool( get_post() );
		if ( $t && $t['enabled'] ) {
			$fileora_tools[] = $t;
		}
	} else {
		$fileora_posts[] = get_post();
	}
}
rewind_posts();
/* translators: %s: search words */
$fileora_title = sprintf( __( 'Results for “%s”', 'fileora' ), get_search_query() );
?>
<main id="main">
	<header class="page-head wrap">
		<?php fileora_theme_crumbs( array( __( 'Search', 'fileora' ) => '' ) ); ?>
		<h1><?php echo esc_html( $fileora_title ); ?></h1>
		<div style="margin-top:20px"><?php get_search_form(); ?></div>
	</header>
	<div class="wrap blog-list">
		<?php if ( $fileora_tools ) : ?>
			<h2 class="h2" style="font-size:1.5rem;margin-bottom:14px"><?php esc_html_e( 'Tools', 'fileora' ); ?></h2>
			<div class="grid" style="margin-bottom:40px">
				<?php
				foreach ( $fileora_tools as $t ) {
					get_template_part( 'template-parts/tool-card', null, array( 'tool' => $t, 'level' => 3 ) );
				}
				?>
			</div>
		<?php endif; ?>
		<?php if ( $fileora_posts ) : ?>
			<?php if ( $fileora_tools ) : ?><h2 class="h2" style="font-size:1.5rem;margin-bottom:14px"><?php esc_html_e( 'Articles and pages', 'fileora' ); ?></h2><?php endif; ?>
			<div class="posts">
				<?php
				global $post;
				foreach ( $fileora_posts as $post ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
					setup_postdata( $post );
					get_template_part( 'template-parts/post-card' );
				}
				wp_reset_postdata();
				?>
			</div>
		<?php endif; ?>
		<?php if ( ! $fileora_tools && ! $fileora_posts ) : ?>
			<div class="empty"><span class="tile lg"><?php fileora_theme_e_icon( 'search' ); ?></span><h3><?php esc_html_e( 'Nothing found', 'fileora' ); ?></h3><p><?php esc_html_e( 'Try different words, or browse all tools.', 'fileora' ); ?></p>
				<?php if ( fileora_theme_core() ) : ?><a class="btn btn-ink" href="<?php echo esc_url( fileora_theme_all_tools_url() ); ?>"><?php esc_html_e( 'All tools', 'fileora' ); ?></a><?php endif; ?>
			</div>
		<?php endif; ?>
		<?php fileora_theme_pagination(); ?>
	</div>
</main>
<?php
get_footer();
