# Fileora Setup & Admin Guide

**Fileora Core plugin 2.12.0 · Fileora theme 2.8.0 · Processing server 2.4** · updated 22 October 2026

Fileora is a WordPress website with **70 free PDF and image tools**: 51 run in the visitor's browser and the rest on your own processing server. This one file covers all three parts: the **Core plugin**, the **theme** and the **processing server**.

> [!WARNING]
> **Security first.** Never post your shared key, server passwords or private keys in chats, tickets or screenshots. A key that was ever pasted anywhere must be treated as public: create a new one ([8.16 The shared key](#816-the-shared-key)).

---

## Contents

| | Section | For |
|---|---|---|
| 1 | [At a glance](#1-at-a-glance) | everyone |
| 2 | [What's in the package](#2-whats-in-the-package) | everyone |
| 3 | [The tools](#3-the-tools) | everyone |
| 4 | [Install and update](#4-install-and-update) | site owner |
| 5 | [Fileora Core plugin](#5-fileora-core-plugin) | site owner, Support |
| 6 | [Fileora theme](#6-fileora-theme) | site owner, editors |
| 7 | [Hostinger setup: domain, DNS and the website](#7-hostinger-setup-domain-dns-and-the-website) | site owner |
| 8 | [AWS EC2 setup: the processing server](#8-aws-ec2-setup-the-processing-server) | server admin |
| 9 | [How the numbers are calculated](#9-how-the-numbers-are-calculated) | everyone reading reports |
| 10 | [Troubleshooting, backups and recovery](#10-troubleshooting-backups-and-recovery) | site owner, server admin |
| 11 | [For developers](#11-for-developers) | developers |
| 12 | [Version history and testing](#12-version-history-and-testing) | everyone |

---

## 1. At a glance

Browser tools finish on the visitor's device. Only server tools send the file to WordPress, which checks it and forwards it to your EC2 server with the shared key.

```mermaid
flowchart LR
    B["<b>The visitor's browser</b><br/>51 browser tools run here:<br/>the file never leaves the device"]
    W["<b>WordPress on Hostinger</b><br/>Theme: pages, blog, search<br/>Core plugin: tools, limits,<br/>analytics, monitoring"]
    S["<b>Processing server (EC2)</b><br/>api.fileora.in → Nginx → 127.0.0.1:8000<br/>LibreOffice, Ghostscript, qpdf, Tesseract"]
    B -- "server tools: file over HTTPS" --> W
    W -- "file + X-Fileora-Key" --> S
    S -- "result (deleted after download, or by the cleanup 1 hour after the task started)" --> W
    W -- "result" --> B
    W -. "health check every few minutes" .-> S
```

<details>
<summary>Same picture as plain text</summary>

```
 Visitor's browser
   │  Browser tools: the file is processed on the device. Nothing is uploaded.
   │  Server tools: the file is sent to WordPress over HTTPS
   ▼
 WordPress on Hostinger  (theme + Fileora Core)
   │  checks size, type and daily limit, then forwards the file
   │  with the secret header X-Fileora-Key
   ▼
 Processing server on EC2  (https://api.fileora.in → Nginx → 127.0.0.1:8000)
      converts the file in its own temporary folder, deletes the result after download;
      the automatic cleanup removes anything left 1 hour after the task started
```
</details>

---

## 2. What's in the package

Three parts, installed separately. The theme and the plugin are independent: switch the plugin off and the site stays a working blog; switch the theme and the tools still work inside any other theme.

| Part | File | Runs on | What it does |
|---|---|---|---|
| **Fileora Core plugin** 2.12.0 | `fileora-core-2.12.0.zip` | WordPress (Hostinger) | Tool registry and engine, settings, permissions, connection to the processing server, task records, visitor analytics, server monitoring, temporary-file cleanup controls, announcements, admin dashboards |
| **Fileora theme** 2.8.0 | `fileora-theme-2.8.0.zip` | WordPress (Hostinger) | The website: header with mega menu, homepage, tool catalogue, tool pages, search, blog, information pages, footer |
| **Processing server** 2.4 | `fileora-server-2.4.zip` (`server/` folder) | AWS EC2 (Ubuntu) | Python service with LibreOffice, Ghostscript, qpdf and Tesseract for tools a browser can't do (Word to PDF, OCR, Protect PDF); temporary files with automatic cleanup; monitoring figures |

`fileora-website-2.12.0-complete.zip` holds all three plus this guide, `TEST-REPORT.md` and `docs/` (the blog plan keyword sheet and the Keyword Planner upload file).

---

## 3. The tools

70 tools in 7 categories. **Browser** tools never upload the file and work without the processing server.

| Category | Tools | Runs on |
|---|---|---|
| **PDF Tools** (30) | Merge, Split, Organize, Rotate, Crop, Page numbers, Watermark, Sign, PDF to JPG, JPG to PDF, Scan to PDF, PDF to Markdown, Compare PDF, Aadhaar Card Print, ID Card Print, Interleave PDF, Split Pages in Half, Remove Blank Pages, Pages per Sheet, Booklet Maker, Bates Numbering, Header & Footer, Edit PDF Metadata, Flatten PDF, Extract Images, Resize PDF Pages, Reverse / Duplicate Pages, PDF to Text, Dark Mode PDF, Add Stamp | Browser |
| **Image Tools** (21) | Compress, Resize, Convert, Crop, JPG to PNG, PNG to JPG, Compress to 20 KB, Exam Photo & Signature Resizer, Passport Photo, HEIC to JPG, Remove EXIF, Watermark Image, Rotate, Blur / Pixelate, Combine Images, Favicon Generator, SVG to PNG, **PNG & JPG to SVG** *(new in 2.4)*, Colour Palette, Image to Base64, Add Border | Browser |
| **File Converter** (8) | Word, Excel, PowerPoint to PDF; PDF to Word, Excel, PowerPoint; HTML to PDF (from a web address); **HTML Code to PDF** (paste code, new in 2.10) | Server |
| **File Optimizer** (4) | Compress PDF and Repair PDF *(hybrid)*, OCR PDF, PDF to PDF/A | Server / hybrid |
| **File Security** (3) | Protect PDF, Unlock PDF, Redact PDF | Server |
| **File Edit** (2) | PDF Forms; Edit PDF *(pending: "coming soon", switched off)* | Server |
| **AI Tools** (2) | AI PDF Summarizer, Translate PDF *(paid, off by default)* | Server + AI API key |

- **Hybrid tools** use the server when it is healthy and fall back to the browser version otherwise.
- **Every tool is a WordPress page** of the type *Tool* at a root address (`/merge-pdf/`, `/png-to-svg/`). Edit its title, description, text and FAQ like any page, and switch it on or off.
- **Limits** (Fileora → Settings): 100 MB per file, 20 files per task, 30 server tasks per visitor per 24 hours. Administrators are never limited; failures caused by the server don't count.

### PNG & JPG to SVG (new in 2.4)

`/png-to-svg/` traces PNG, JPG and WebP into **real vector paths** with ImageTracer.js (public domain), in a Web Worker so the page stays responsive.

| Option | Choices |
|---|---|
| Picture type | *Logo / icon* (2–32 colours) or *Black & white* for signatures, stamps and line art |
| Black & white | automatic or manual darkness level; black or dark-blue ink |
| Detail | Low / Medium / High |
| Remove the background | on = transparent SVG |

Best for logos, icons and signatures; photos give heavy files and the result says so. Nothing is uploaded. The page comes with written content, 7 FAQs and its own SEO title and description (also saved for Yoast and Rank Math).

### HTML Code to PDF (new in 2.10)

`/html-code-to-pdf/` turns the visitor's **own HTML and CSS** into a PDF: paste code (or open an .html file), watch the **live preview**, download a PDF with real, selectable text. The older *HTML to PDF* tool still saves a public web page from its address.

| Option | Choices |
|---|---|
| Page size | A4 · US Letter · Fit content (one page the size of the content) |
| Orientation, Margins | Portrait/Landscape · None/Small (6 mm)/Normal (12 mm); an `@page` rule in the code wins |
| CSS media | Print (uses `@media print`, like "Save as PDF") · Screen |
| Background colours and images | on/off |
| Run JavaScript | off by default |
| File name | the PDF's name |

How it is kept safe:

- **Preview**: in a sandboxed frame with its own origin, so pasted code can't read this site, its cookies or storage. With JavaScript off, a Content-Security-Policy blocks every script and inline handler in the code.
- **PDF**: made on the processing server by headless Chromium (server 2.3). The code is sent as a small .html file (up to 5 MB). Scripts are off unless the visitor turns them on, and the page can only load from the **public internet**: private networks, localhost, cloud metadata addresses and `file:` are blocked (tested). Files are deleted after the job like every other server tool.
- Without the processing server, *Print with my browser instead* under the preview still works.
- The code is kept in the visitor's browser for the session (sessionStorage), so a reload doesn't lose it; nothing is stored on the site.

---

## 4. Install and update

Requirements: **WordPress 6.4+**, **PHP 7.4+** (8.1+ recommended) and **HTTPS**.

### 4.1 First install

1. **Plugins → Add New → Upload Plugin** → `fileora-core-2.5.1.zip` → Install → **Activate**. The tool pages are created automatically.
2. **Appearance → Themes → Add New → Upload Theme** → `fileora-theme-2.5.1.zip` → Install → **Activate**. An *All tools* page is created.
3. **Settings → Permalinks** → **Post name** → Save.
4. **Settings → General → Tagline**, for example *Free PDF Tools to Merge, Compress & Convert Online*.
5. **Fileora → Settings**: processing server `https://api.fileora.in` and the shared key → **Test the connection**.
6. **Fileora → Settings → Privacy and Security pages**: contact email, website hosting (Hostinger) and processing server (Amazon Web Services and its region, section 8.1).
7. **Appearance → Starter content**: import the eight information pages and the four blog guides.
8. **Fileora → Settings → Location database and check** → download DB-IP City Lite, so visits get a country, state and city.
9. **Appearance → Customize → Fileora**: homepage headline, quick links, FAQ, footer, contact email, social links, colour.
10. Set up a real cron job ([7.9 Real cron](#79-real-cron)) and purge LiteSpeed Cache once.

### 4.2 Updating to 2.12

1. **Processing server first**: update it to 2.4 (section 8.13: backup copy, `install.sh` or the quick code-only update, smoke test). 2.4 is compatible with plugin 2.11, so the site keeps working in between.
2. Upload **fileora-core-2.12.0.zip** with **Replace current with uploaded** (the theme is unchanged, 2.8.0). Opening any admin page adds the new monitoring columns to `wp_fileora_health` (automatic, nothing to do; older checks show *Not Available* for the new figures).
3. **Fileora → Settings → Processing server**: check *Monitoring method* (Automatic) and *Address to probe* (empty = the API's host), Save, then **Fileora → Server Monitoring → Check now**. The *Method* line says whether ping works from Hostinger or the TCP check is used (5.9).
4. **Fileora → Processing Tasks → Temporary files & cleanup**: *Temporary directory* must say **Verified** and *Automatic cleanup* **On**, expiry **1 h** (5.10).
5. Optional, on a staging copy: run the safety test `wp eval-file wp-content/plugins/fileora-core/tests/test-temp-cleanup.php` (5.10).

Rollback: server section 8.13; plugin: upload `fileora-core-2.11.0.zip` with *Replace current with uploaded* (data is kept; the new columns are ignored).

### Updating to 2.11

1. Coming from 2.9 or older: update the **processing server** to 2.3 first (section 8.13) – HTML Code to PDF and the four new OCR/AI languages need it. Then upload **fileora-core-2.11.0.zip** and **fileora-theme-2.8.0.zip** with **Replace current with uploaded**. Open any admin page once: the **ATS Resume Builder** page and its header link are created (section 5.8). Nothing on the site changes until you enable a day.
2. Go to **Fileora → SEO → 70-day blog plan** and enable **day 1** (or carry on where you are: days 1–69 are unchanged, day 70 is new). Then come back each day (section 5.7). The 60-day plan carries on as before (section 5.6); the two plans are independent.
3. Coming from a version older than 2.5? Also follow the steps below.

### Updating to 2.5 (from older versions)

1. Upload both zips with **Replace current with uploaded**. Statistics, pages and settings are kept.
2. **Appearance → Starter content → Information pages**: tick **Accessibility** and **Contact** → *Import selected*. They appear in the footer by themselves.
3. **Privacy Policy** (existing page): add the contact form, because it now collects a name, email address and message. In the *Information we process* table add the row *Contact form messages · When you send us a message · Your name, email address, topic and message, used only to answer you; kept `[fileora_privacy field="message_keep"]`.* and under *Data retention* the line *Contact form messages: `[fileora_privacy field="message_keep"]`.* (New installs already have this.)
4. **Fileora → Settings → Data retention**: check *Send contact messages to* and *Contact form messages* (days kept).
5. **Fileora → SEO → Site settings**: Google Search Console code (HTML tag), homepage title, default share image, organisation. Then work through **Pages overview**, weakest first.
6. Purge LiteSpeed Cache, then press **Mark as reviewed** on the Privacy and Security notice once you have checked the pages.

> [!NOTE]
> Since 2.3, **deleting the plugin keeps all data**, so you can also delete and re-upload. Data is removed only if Settings → *Data retention* → *Delete all Fileora data when the plugin is deleted* is ticked.

### 4.3 Coming from the old "Fileora" plugin

Activating Fileora Core imports the old settings and job history, switches the old plugin off and creates the tool pages at the same addresses. Delete the old plugin afterwards; never run both.

### 4.4 Using another theme

Each tool page shows its workspace inside any theme. To place tools anywhere:

```
[fileora tool="merge-pdf"]   one tool (by address or id)
[fileora_tools]              the whole catalogue, by category
```

---

## 5. Fileora Core plugin

**Visitor Analytics** has its own menu item below Dashboard and opens after login for everyone who may see reports. Everything else is under **Fileora**.

| Admin page | What you see and do |
|---|---|
| **Visitor Analytics** | Live dashboard, refreshed every minute without reloading ([5.1](#51-visitor-analytics)) |
| **Dashboard** | Active visitors, tool runs (30 days), completed and failed server tasks, success rate, average duration, availability, most-used tools, recent failures |
| **Server Monitoring** | Ping latency and packet loss (or a labelled TCP/HTTP check), reachability, API health, last successful check, CPU, memory, disk, network, uptime; graphs for 1 h / 6 h / 24 h / 7 d; availability with coverage; **Check now** ([5.9](#59-server-monitoring)) |
| **Processing Tasks** | *Task history*: every server task with filters, pages, CSV export and the state of its temporary files. *Temporary files & cleanup*: the task folders on the server, cleanup schedule and controls, history and audit log ([5.10](#510-processing-tasks-temporary-files-and-cleanup)) |
| **Tool Management** | All tools: on/off, where they run, status, uses in 30 days, order; **Restore missing pages** |
| **Tool Categories** | Category names, descriptions, colours and order |
| **Announcements** | Popups and bars for visitors ([5.2](#52-announcements)) |
| **Messages** | Messages sent with the contact form ([5.4](#54-contact-form-and-messages)) |
| **SEO** | Pages overview with a score per page, and site SEO settings ([5.5](#55-seo-controls)) |
| **Settings** | Server and key, limits, analytics and IP options, location database, data retention, privacy page details, Blog Editor and Support permissions, Support account, analytics storage |

### 5.1 Visitor Analytics

1. **Period**: last 1 minute, 30 minutes, 24 hours, 7, 30 or 90 days, or a **custom date range**. Every number, chart and table follows it.
2. **Numbers**: total visits, unique visitors (first-time visitors underneath), active now, page views, tool runs (browser + server, failures shown), files processed.
3. **Visitors by location**: doughnut by country, state or city; top 8 plus "Other".
4. **Real-time traffic**: visitors per minute for the last 30 minutes, split by the 4 busiest countries; spikes are pointed out.
5. **Traffic over time**: per minute, hour or day, with visits, unique visitors, page views, tool runs, files, failures and the 3 busiest locations per interval.
6. **Visitors vs. tool runs**: daily, weekly or monthly over 7 to 365 days, or the period above.
7. **Tool usage**: views, browser and server runs, failures, success %, files and average time per tool.
8. **Latest file processing** and **Visits**: searchable, filterable tables with pages.
9. **Export data (CSV)**: visits, events, file processing, traffic per interval, daily totals or tool usage.

Location needs the location database (Settings → *Location database and check*). Admin visits are not counted, so test from a phone or a private window.

### 5.2 Announcements

Fileora → Announcements → **Add announcement**: title, message and display settings.

| Setting | Choices |
|---|---|
| Show it | on/off (the post must be published) |
| Start / Expires | date and time, site time zone; empty = now / never |
| How often | once per visit, once per day, every page |
| Position | centre popup, top bar, bottom bar, small card bottom right |
| Look | light, dark, highlight colour, colour picker |
| Button | optional label and link |
| Who sees it | everyone, first-time, returning, logged-in or not; device type; every page, homepage, tool pages, blog posts |
| Delay | seconds after the page opens |

**Preview on the site** shows it to you only, even when it is off. At most one popup and one bar show at a time; Esc closes the popup, and it becomes a bottom sheet on phones.

### 5.3 Roles and permissions

Fileora uses WordPress capabilities, never role names:

| Capability | Allows | Given to |
|---|---|---|
| `fileora_view_reports` | Dashboard, analytics, monitoring, tasks | Administrator; Blog Editor if allowed; Support |
| `fileora_manage_tools` | Tool Management, tool pages, categories | Administrator |
| `fileora_manage_settings` | Fileora Settings | Administrator |
| `fileora_view_ip` | Visitors' IP addresses | Administrator; Support if allowed |
| `fileora_manage_announcements` | Announcements | Administrator |
| `fileora_export_data` | CSV export of analytics | Administrator |

- **Blog Editor** writes posts and uploads media; Settings decides whether they publish, edit others' posts, delete posts and see reports. Create one under **Users → Add New → Role: Blog Editor**.
- **Support** sees Visitor Analytics, Dashboard, Server Monitoring and Processing Tasks, and edits only their own profile.
- **Messages and SEO** need `fileora_manage_settings` (administrators).
- **Creating the Support user**: Fileora → Settings → *Support account* → username `Support`, an email address and the initial password; tick *Require a new password at first login*. The password is stored only as a WordPress hash, never in code, settings or logs. With WP-CLI: `wp fileora support-user --email=support@your-domain --password='…'`.

### 5.4 Contact form and messages

Put `[fileora_contact]` on any page (the starter **Contact** page already has it).

| | |
|---|---|
| Fields | Name, email, topic (general, a tool isn't working, privacy or data request, accessibility, business, something else), message. Labels, error messages in words next to each field, works with the keyboard and screen readers |
| Where messages go | Saved under **Fileora → Messages** *and* emailed to *Settings → Send contact messages to* (empty = the privacy email, else the admin email). If the host can't send email, nothing is lost; the message page says "Email notification: not sent". **Reply by email** opens your mail program |
| Spam protection | No captcha and no third party: a hidden honeypot field, at least 3 seconds to fill the form, at most 5 messages per hour from one connection. Works on cached pages |
| Retention | Deleted after *Settings → Contact form messages* days (default 180), shown on the Privacy Policy and Contact pages through `[fileora_privacy field="message_keep"]` |

> [!TIP]
> Hostinger's PHP mail often lands in spam. Install an SMTP plugin (for example *WP Mail SMTP*) with your Hostinger email account so notifications arrive reliably.

### 5.5 SEO controls

Every **post, page and tool** has an **SEO** box under the editor (in the block editor: open *Meta Boxes* at the bottom).

| Field | What it does |
|---|---|
| Focus keyword | The phrase people search for; drives the checklist. One per page |
| Search keywords (up to 10) | Other ways people search for the page, one per line. A live list under the field shows which ones the text already uses (new in 2.7) |
| Title ideas | Plan posts carry 10 alternative titles; **Use as SEO title** copies one into the SEO title field, e.g. to test a new title for a post with impressions but few clicks (new in 2.7) |
| SEO title | The blue headline in Google (30–60 characters; the site name is added) |
| Meta description | The text under it (120–160 characters); also used when shared |
| Image when shared | For WhatsApp, Facebook, X and LinkedIn (1200 × 630 px). Else the featured image, else the default image |
| Advanced: noindex | Keeps the page out of Google and out of the XML sitemap |
| Advanced: canonical URL | Only when the page copies another page |

The box shows a **Google preview**, length bars and a **checklist** that updates while you type: keyword in the title, description, address, first paragraph and a subheading; title and description length; at least 300 words; image alt text; an internal link; a warning when another page already uses the same keyword; and, when search keywords are filled in, that at least 8 of them (or all, if fewer) appear in the text.

**Fileora → SEO → Pages overview** lists every published page, post and tool with its keyword, title/description length, words, score and the first things to fix, weakest first. **Site settings**: verification codes for Google Search Console, Bing, Yandex and Pinterest (paste the code or the whole `<meta>` tag), homepage title, default share image, X account, and your organisation's name, logo and social profiles (Organization and WebSite structured data on the homepage).

**Ready-written SEO text** (Appearance → Starter content → *SEO text for existing pages*): one click fills the **All tools** page with an SEO title ("Free Online PDF Tools – Every PDF & Image Tool in One Place"), meta description, focus keyword *free online pdf tools*, an intro line under the heading, and about 650 words below the tool list: popular tools with links, how to use them, why Fileora, a "Which tool should I use?" table and 5 FAQs (FAQ structured data). It replaces the page's current text after asking. The page's checks then pass 11 of 12 (only "keyword in the page address" stays open: keep `/all-tools/`, because changing an indexed address loses its ranking). On the All tools page the checklist also counts the tool list itself, as Google sees it. Pages now have an *Excerpt* field: on the All tools page it is the intro line under the heading.

Tool pages without their own SEO title now use "*Tool* Online Free – Fast, No Sign-up". When Yoast, Rank Math, AIOSEO, SEOPress or The SEO Framework is active, Fileora shows a note in the box and leaves titles, descriptions and verification to that plugin.

### 5.6 The 60-day SEO plan (new in 2.6)

**Fileora → SEO → 60-day plan** turns the SEO strategy into one card per day. Open today's card, read what it changes, press **Enable day N**, then tick the tasks under **You**.

```mermaid
flowchart LR
  A[Open today's card] --> B[Enable day N]
  B --> C{What it creates}
  C -->|Tool pages, titles, menu| D[Live at once<br/>backup kept]
  C -->|Guides and pages| E[Drafts]
  E -->|Exam pages: tick<br/>'I checked the sizes'| F[Publish the drafts]
  D --> G[Do the 'You' tasks]
  F --> G
```

| Days | What the buttons do | What you do |
|---|---|---|
| 1–30 | Homepage title and description; clean sitemap (no users or tags, archives noindex); header menu; full text, FAQ and SEO fields for **41 tool pages**; 15 English guides | Connect `https://api.fileora.in`, Search Console and Bing, speed checks, brand profiles, listings, screenshots, weekly reviews |
| 31–60 | **9 exam pages** (IBPS, SBI, SSC CGL, SSC CHSL, UPSC, RRB NTPC, NEET, JEE Main, CUET) with the resizer pre-set; **5 KB pages** (10, 30, 50, 100, 200 KB) with the compressor pre-set; the **exam size list**; 3 more English and **6 Hindi guides** | Check exam sizes against notifications, outreach emails, YouTube creators, title rewrites, page-2 improvements, final KPI review |

- **One day at a time.** Day N opens N–1 days after day 1 was enabled. Tick *Let me work ahead* to open every day now.
- **Tool pages change live** (their old text, FAQ and SEO fields are kept as a backup). **Guides and pages are created as drafts**; press **Publish the drafts** after reading them.
- **Exam pages wait for you.** Each has an *I checked the sizes against the official notification* box. Exam sizes were collected in October 2026 from summaries of the 2026 notifications and some sources disagree (SSC signature 4 × 2 cm vs 6 × 2 cm), so these pages publish only after you tick it.
- **Undo this day** restores tool text and SEO fields, the homepage title, the menu and the sitemap setting, and moves the day's unpublished drafts to the trash. Guides and pages already published stay online.
- An existing page or post with the same address is never overwritten; that item is skipped.
- Published guides appear automatically under **"Guides for …"** on the tool pages they name, so new content links into the tools.
- Hindi guides get `lang="hi"` on their page, for browsers, screen readers and Google.
- Preset pages use the tool shortcode with a preset: `[fileora tool="examphoto" preset="ibps"]` or `[fileora tool="imgkb" target="50"]`. Presets live in `seo-plan/presets.php`; update them, and the page text, when a new notification changes the sizes.
- Content files (Markdown) are in `seo-plan/tools`, `seo-plan/guides` and `seo-plan/pages`; the schedule is `seo-plan/plan.php`.
- Fileora → SEO → Site settings has a new switch, **Sitemap and archives**, which day 1 turns on.
- Since 2.7 every guide also has **10 search keywords** in its SEO box.

### 5.7 The 70-day blog plan (new in 2.7, days 54–69 in 2.9, day 70 in 2.10)

**Fileora → SEO → 70-day blog plan** works like the 60-day plan: one card a day, **Enable day N**, read, publish. Each day creates **one blog post for one tool**, so after 70 days every tool has its own article.

| Category | Posts | Tools |
|---|---|---|
| **PDF Tools** | 30 | Merge, Split, Organize, Rotate, Crop, Page numbers, Watermark, Sign, PDF to JPG, JPG to PDF, Scan to PDF, PDF to Markdown, Compare, Aadhaar print, ID card print, Interleave, Split pages in half, Remove blank pages, Pages per sheet, Booklet, Bates numbering, Header & footer, Metadata, Flatten, Extract images, Resize pages, Reverse & insert, PDF to text, Dark mode, Image or stamp |
| **Image Tools** | 21 | Compress, Resize, Convert, Crop, JPG to PNG, PNG to JPG, Compress to KB, Exam photo & signature, Passport photo, HEIC to JPG, Remove location, Watermark, Rotate & flip, Blur, Combine, Favicon, SVG to PNG, PNG & JPG to SVG, Colour palette, Image to Base64, Add border |
| **File Optimizer** | 2 | Compress PDF, Repair PDF |
| **PDF Tools, days 54–69** (new in 2.9) | 16 | Word to PDF, Excel to PDF, PowerPoint to PDF, PDF to Word, PDF to Excel, PDF to PowerPoint, HTML to PDF (*save a webpage as PDF*), OCR PDF, PDF to PDF/A, Protect PDF, Unlock PDF, Redact PDF, PDF Forms, AI Summarizer, Translate PDF, Edit PDF |

| **PDF Tools, day 70** (new in 2.10) | 1 | HTML Code to PDF – the post *How to convert HTML to PDF*; the same day writes the new tool page's full text, FAQ and SEO fields |

Notes on days 54–70:

- **AI Summarizer (day 67) and Translate PDF (day 68)** need a Claude API key on the processing server (section 8.17), and their tool pages are switched off until then. Their posts are created as drafts and **stay drafts** – *Publish* skips them – until the tool is switched on in Fileora → Tool Management, so no reader lands on a tool they can't use. Both posts say plainly that the PDF's text is sent to the Claude API by Anthropic.
- **Edit PDF (day 69)**: the editor screen isn't built yet, so the post *How to edit a PDF* shows how to make each common edit with the tools that work today (sign, header and footer, image or stamp, page tools, redact, PDF to Word and back). It never links to the unfinished tool. When the editor is ready, update the post.
- Some posts sit close to a 60-day guide (Word to PDF on mobile, PDF to Word formatting, removing a PDF password, scanned PDFs). They target different searches; if Search Console later shows both pages for the same query, merge the weaker one into the stronger and redirect it.

Every post has:

- an SEO title (25–60 characters), meta description (120–160), URL slug and **focus keyword** in the title, description, first paragraph and a subheading;
- **10 search keywords**: the "how to …" form, the "… for free" form, online/phone/no-software variations and long-tail phrases, each used naturally in the text (checked before release);
- **10 title ideas**, no more than 3 starting with "How to";
- step-by-step instructions, a tool button, a quick-reference table, 4 FAQs (FAQ structured data) and links to the tool, related tools, the category page and **only earlier posts**, so no link points at a draft.

**Six posts refresh an older guide at the same address** (merge, split, sign, scan, HEIC to JPG, Aadhaar print). The card says so. The old text, title, SEO fields and categories are backed up; the post keeps its address, its ranking and its old category and gets the new one too. **Undo** puts the old version back. All other posts are created as **drafts**: press **Publish** on the card after reading.

The "You" tasks: publish, then **Request indexing** in Search Console; every 7th day a short check of impressions and keyword volumes; on day 70 a review of titles.

> [!NOTE]
> **Keyword volumes are not guaranteed.** The keywords were chosen from how people describe each task, not from measured search volume. Upload `docs/keyword-planner-upload.csv` to Google Keyword Planner (*Get search volume and forecasts*) and check Search Console after a few weeks; change any keyword in the post's SEO box if a better variation turns up. `docs/fileora-blog-plan-keywords.xlsx` lists all 70 posts with meta data, the 700 keywords and the 700 title ideas.

**Cover images (new in 2.8).** Every post has its own cover image (1200 × 675 JPG, about 60 KB, made for Fileora, no stock photos). When a day is enabled, its image is added to **Media → Library** (file name = the post's address, e.g. `how-to-merge-pdf-files.jpg`), attached to the post, given descriptive alt text and set as the **featured image**. So when you press Publish, the cover is already on the post, on the blog page and in the WhatsApp/Facebook/LinkedIn preview: nothing to upload by hand.

- **Days you enabled before updating** get their images automatically: open any admin page after the update (a few posts per page load), or press **Add the missing cover images** on the blog plan tab, which appears while any enabled post has no featured image.
- A refreshed older post keeps its old featured image as a backup; **Undo** puts it back. Undo never deletes an image from the Media Library, and enabling the day again reuses the same image instead of uploading a copy.
- To use your own picture instead, just change the featured image in the post editor.

Files: posts in `seo-plan/blog/*.md`, schedule in `seo-plan/blog-plan.php`, images and alt texts in `seo-plan/blog-images/`.

### 5.8 ATS Resume Builder (new in 2.11)

A separate section at **/ats-resume-builder/**, linked as **ATS Resume** in the header. Visitors pick a template, fill in a form and download their resume as a PDF.

| Part | What it does |
|---|---|
| **4 templates** | *Classic* (Times, centred name; government, banking, academic), *Modern* (Helvetica, coloured headings; most private-sector jobs), *Compact* (smaller margins and spacing; freshers, one page), *Minimal* (airy, no rules). All are single-column with standard headings, real text and standard PDF fonts – what ATS software reads best. Colour (navy, teal, maroon, black), text size and A4/US Letter for each. |
| **Form** | Personal details and links; Summary, Experience, Education, Skills, Projects, Certifications, Achievements, Languages. Sections can be moved up or down and left out; entries can be added, moved and removed; "I work here now" shows *Present*. *Fill with an example* shows a complete resume. |
| **Live preview** | The preview **is** the PDF: it is typeset with pdf-lib and drawn with pdf.js, so pages and line breaks match the download exactly. |
| **ATS check** | 11 checks on the text read back from the PDF: readable text, name, email, phone, standard sections (freshers: Projects instead of Experience), length, bullets per job, results with numbers, dates, summary length, unsupported characters. Shows the exact text ATS software reads. Optional **job-ad comparison**: paste a job description to see which of its key words (including names like "Power BI") the resume uses and which are missing. |
| **Output** | Download PDF (`name-resume.pdf`, clickable email and links, PDF title and author set); *Copy as plain text* for application forms; *Save a copy (.json)* and *Open a saved copy* to continue on another device. |
| **Privacy** | Nothing is uploaded: no server, no processing server. The resume stays in the browser tab (sessionStorage) and on the device only if the visitor ticks *Remember on this device* (localStorage). *Clear all* (two clicks) removes it. |

Notes:

- The site never claims a "100% ATS score": the page and the ATS check say plainly that no tool can promise one.
- The PDF fonts (Helvetica, Times) cover English and other Latin-alphabet languages; ₹ becomes "Rs." and characters such as Devanagari are left out with a warning in the ATS check.
- The page (with a guide and FAQ under the builder, SEO title, description, focus keyword and 10 search keywords) is created **once**; the header link is added **once** to the menu in the *Header* location, just before *Contact us*. Delete either and it is not added back. Without an assigned menu, the theme's default header shows the link while the page exists. The 60-day plan's header menu (day 2) now includes it too.
- The theme gives the page a wide layout (`page-ats-resume-builder.php`), also after its address is changed. With 9 or more header links, the header search shrinks to its icon below 1680 px so nothing overflows.
- Files: plugin `includes/class-resume.php`, `public/js/fileora-resume.js`, `public/css/fileora-resume.css`, `public/img/resume/*.png`; theme `page-ats-resume-builder.php`, `inc/resume.php`.

### 5.9 Server Monitoring

**Fileora → Server Monitoring** shows how the processing server is doing, measured from the WordPress host every few minutes (Settings → *Monitoring interval*, 5–60 minutes; the checks need a real cron job, 7.9).

| Part | What it shows |
|---|---|
| Time range | **1 hour · 6 hours · 24 hours · 7 days** (7-day graphs show 30-minute averages) |
| Network and API | Reachability now, latency and packet loss of the last check and the period's average, **last successful check**, API health (`/health`: up, HTTP code, response time), whether the schedule runs on time |
| Method line | Which measurement is used: **ICMP ping**, **TCP connect, port 443** or **HTTP /health response**, and why (for example "ICMP got no replies, so this is a TCP connect check") |
| Graphs | Network latency (one line per method; red marks = server unreachable), packet loss per check, `/health` response time (red = failed check), CPU, memory, disk, network in/out |
| Availability | 24 h / 7 d / 30 d with coverage, and a 30-day strip (9.1) |
| Server resources | CPU (5-minute average, cores, load), memory used, disk used and free, network in/out, server and service uptime, temporary files (from `GET /metrics`, needs the shared key) |
| Checks table | The newest 30 checks of the period with every value |

**How the network is measured** (Settings → *Monitoring method*):

- **Automatic** (recommended): ICMP ping with the system `ping` (3 packets by default, 2 s timeout each). If PHP on the host can't run `ping` (`exec()` disabled or no `ping` program, common on shared hosting) or the server doesn't answer pings (ICMP not allowed in the EC2 security group, 8.9), it measures the **TCP connect time** to the HTTPS port instead and says so.
- **ICMP only**, **TCP only**, or **HTTP /health only** force one method.
- *Address to probe*: empty = the host of the server address (`api.fileora.in`).

Nothing is invented: a value that couldn't be measured (server down, old server version, metrics not reachable) is shown as **Not Available** and leaves a gap in the graph. Checks are kept for *Data retention → Health checks* days (default 90, at least 30).

### 5.10 Processing Tasks: temporary files and cleanup

**Fileora → Processing Tasks** has two views.

**Task history** (as before) lists every task from the WordPress database, plus a *Temporary files* column: *Deleted in 45 min*, *Expired: deleted at the next run*, *Kept (cleanup is off)*, *Protected: in use*, *Deletion failed: will retry*, *Deleted after download*, or *Deleted … ago (Schedule / Manual delete)*.

**Temporary files & cleanup** reads the processing server live (section 8.12 explains the folder and the safety rules):

| Part | What you see and do |
|---|---|
| Status tiles | Automatic cleanup on/off/paused, expiry, interval and next run, last run and its result, successful/failed runs, files deleted and space freed, temporary storage now, expired files not deleted yet, free disk on the server |
| Cleanup schedule | **Delete expired temporary files automatically** (on/off), **Files expire after** (15 min – 24 h, default **1 h**), **Run the cleanup every** (1–60 min, default 5) → *Save on the server*; **Stop / Start schedule**; **Run cleanup now…** (with a confirmation step); job status, last and last successful run, next run, whether the temporary directory is verified |
| Temporary task folders | Task id and tool, safe file name (`<task id>.pdf`, never the visitor's file name), size, status, created, expires and time left, cleanup status, error; filter by *In use · Not expired · Expired · Kept · Deletion failed · Completed*; **Details**; **Delete** (confirmation page; never for a running task) |
| Failed deletions | Attempts, last error, **Retry** |
| Cleanup history | Each run that deleted something or failed, manual deletes, retries and setting changes: time, who, result, space freed |
| Admin actions (audit log) | Every change and refused attempt: time, user, IP address, action, task, result |

- Seeing this view needs *view reports* (Administrator, Support); changing anything needs *manage settings* (Administrator). Every action carries a WordPress nonce and is written to the audit log here and on the server.
- **Switching cleanup off** stops the scheduled deletion only. Nothing is deleted when you switch it off, running tasks and the rest of the service carry on, and results are still deleted after download. The page then shows the expired data being kept and, from the task records of the last 7 days, about how much more would be kept per day.
- The settings are stored on the processing server, so they survive restarts of the server and don't depend on WordPress cron.
- Filesystem paths are never shown; tasks are identified by their id.
- **Safety test** (staging site recommended): `wp eval-file wp-content/plugins/fileora-core/tests/test-temp-cleanup.php`. It adds a canary post, page and upload, checks the permissions, runs a real job, changes settings, runs the cleanup, deletes a task's files, stops and starts the schedule, then compares fingerprints of posts, post meta, users, comments, terms, task records and every file in `wp-content/uploads` (all must be unchanged) and removes its canaries.

---

## 6. Fileora theme

The theme draws the whole website. It works on its own as a blog theme; with Fileora Core it adds the tool catalogue, tool pages and search.

### 6.1 Customizing

| What | Where |
|---|---|
| Homepage headline (the page's H1), quick links, sections | Appearance → Customize → Fileora → Homepage. `{count}` and `{browser}` become live tool counts |
| Tool page text, line under the title, FAQ | Fileora → Tool Management → Edit. FAQ: question on one line, answer below, empty line between |
| Logo | Appearance → Customize → Site Identity |
| Favicon (browser tab icon) | Built in since theme 2.5.2: the Fileora mark in every size (ICO, SVG, 96 px, Apple 180 px, Android 192/512 px, maskable). To use your own, upload a square PNG of at least 512 × 512 px in Appearance → Customize → Site Identity → *Site Icon*; it replaces the built-in one everywhere |
| Highlight colour; category colours | Customizer; Tool Categories |
| Menus | Appearance → Menus: *Header*, *Footer column 1–4*, *Footer bottom links* (optional: without menus the theme builds links from your categories) |
| Accessibility button | On by default (Customize → Fileora → Header → *Show the accessibility button*). A round blue button at the bottom left opens a panel: text size (4 steps), high contrast, highlight links, readable font, text spacing, large cursor, stop animations, reset; with links to the Accessibility statement and Contact page. Choices are saved in the visitor's browser only. The Accessibility page is reached from this panel, so it is no longer listed in the footer |
| Header and footer animation | On by default (Customize → Fileora → Header → *Animate the header and footer*). GSAP 3.14 (served from the theme): header items slide in, a scroll-progress line under the header, menus and the mobile drawer open with motion, footer columns rise in, a soft colour glow drifts behind the footer, "Back to top" scrolls smoothly. Visitors whose device asks for reduced motion, or who choose *Stop animations*, see no movement |
| Contact us in the header | Added automatically after the menu links when a Contact page exists. If you use your own *Header menu* (Appearance → Menus), add the Contact page to it yourself |
| Footer credit | Appearance → Customize → Fileora → Footer: *Credit line* ("Website created by"), *Credit name* (@techdeployers) and *Credit link* (https://www.techdeployers.com). Empty name = no credit |

- Visitors can switch light and dark mode; the first visit follows their device.
- Fonts (Bricolage Grotesque, Geist; SIL Open Font License) are served from the theme itself, so no request goes to Google Fonts.
- Make code changes in a child theme so updates don't overwrite them.
- **Page width**: information pages (Privacy Policy, Contact, About…) use a wide 1120 px column; on phones every table in page text turns into one card per row, with the column names as labels.

### 6.2 Information pages

**Appearance → Starter content → Information pages → Import selected** creates eight editable pages, listed in the footer column *Information*:

| Page | Address | Contents |
|---|---|---|
| About Us | `/about-us/` | Purpose, tools, how files are handled, contact |
| FAQ | `/faq/` | 20 questions in four groups, with FAQ structured data |
| Security | `/security/` | Data flow for browser and server tools, storage, safeguards; no "100% safe" claims |
| Privacy Policy | `/privacy-policy/` | Files vs. analytics vs. logs, third parties, retention, rights (incl. India's DPDP Act 2023) |
| Disclaimer | `/disclaimer/` | Accuracy limits, user responsibility, liability "to the extent permitted by law" |
| Accessibility | `/accessibility/` | What the site does for keyboard, screen reader, zoom, contrast and reduced-motion users; known limitations; how to report a problem |
| Contact | `/contact/` | The contact form, tips for reporting a tool problem, privacy note |
| Sitemap | `/sitemap/` | All pages, tools and posts, updated automatically |

The pages **stay accurate by themselves** through shortcodes:

| Shortcode | Shows |
|---|---|
| `[fileora_data_flow]` | which tools run where, from the live tool settings |
| `[fileora_privacy_facts]` | what analytics record with the current settings |
| `[fileora_privacy field="…"]` | one value: `email`, `host_web`, `host_server`, `deletion`, `event_keep`, `task_keep`, `message_keep`, `ip_days`, `max_mb`, `site` |
| `[fileora_contact]` | the contact form |

When something they describe changes, administrators see a review notice with **Mark as reviewed**. The texts are a careful start, not legal advice.

### 6.3 Blog

- **Blog page** at `/blog/`: the newest post as a large card, topic chips, then the other posts.
- **Every post gets**: a table of contents, reading time, a progress bar, a "Tools used in this guide" box, share buttons (WhatsApp, X, Facebook, LinkedIn, Telegram, copy link), an author box and three related posts.
- **SEO without a plugin**: meta description, Open Graph tags and BlogPosting, Breadcrumb and FAQ structured data. With Yoast, Rank Math, AIOSEO, SEOPress or The SEO Framework active, the theme leaves this to that plugin.
- **Starter guides** (Appearance → Starter content → Blog guides): Aadhaar print, PDF to 100/200 KB, exam photo 20 KB, JPG to PDF on mobile. Review them once a year, because exam rules and fees change.

### 6.4 Accessibility

The site aims at WCAG 2.2 level AA. Built in:

| Area | What is there |
|---|---|
| Keyboard | Skip link, visible focus outline, every menu, option and dialog usable with Tab / Enter / Space / arrows; `/` opens tool search |
| Screen readers | Landmarks, one H1 and an ordered heading outline on every page, labelled buttons and icons, tool progress and results announced (live region) |
| Tools | A normal *Choose files* button (dragging is never required); marked areas (Blur, Crop) move with arrow keys, resize with Shift + arrows, Alt for fine steps, Delete removes |
| Visual | AA contrast in light and dark mode, text zoom to 200% without sideways scrolling, colour never the only signal |
| Motion | Animations and smooth scrolling off when the device asks for reduced motion |
| Forms | Visible labels, errors in words next to the field, focus moved to the first problem |

**Checked** with axe-core (WCAG 2.0/2.1/2.2 A and AA rules plus best practices) on 13 page types in light and dark mode: no violations. Automated tests don't find everything; the Accessibility page invites people to report problems.

---

## 7. Hostinger setup: domain, DNS and the website

WordPress (theme + Fileora Core) runs on Hostinger. The domain **fileora.in** points the website to Hostinger and the subdomain **api.fileora.in** to the processing server on AWS EC2 (section 8). Do these steps in order; each ends with a check.

> [!NOTE]
> Values marked `TO_BE_CONFIRMED` weren't available when this guide was written. Look them up with the command or screen given next to them and write them in; don't guess them.

### 7.1 What is where

| Item | Value | Where it comes from |
|---|---|---|
| Domain | `fileora.in` | Registered domain |
| Website address (canonical) | `https://www.fileora.in` | WordPress → Settings → General (`TO_BE_CONFIRMED` that both addresses there use `www`) |
| Website hosting | Hostinger, WordPress | hPanel → Websites |
| Website IP address (A record of `@`) | `TO_BE_CONFIRMED` | hPanel → Websites → fileora.in → Dashboard (website / server details) |
| DNS provider (nameservers) | `TO_BE_CONFIRMED` | `dig +short NS fileora.in` (Hostinger's nameservers = records are edited in hPanel) |
| API address | `https://api.fileora.in` | DNS record **A `api`** (7.3) + certificate on EC2 (8.8) |
| Processing server public IPv4 | `32.199.254.79` | EC2 → Instances → *Public IPv4 address* |
| Hostinger's outgoing IP (calls from WordPress to the API) | `TO_BE_CONFIRMED` | 7.10 |
| WordPress → processing server | `https://api.fileora.in` + shared key | Fileora → Settings (7.6) |

### 7.2 Nameservers and DNS records

```bash
dig +short NS fileora.in          # which DNS provider answers for the domain
```

If the answer shows Hostinger's nameservers, edit records in **hPanel → Domains → fileora.in → DNS / Nameservers → DNS records**. If it shows another provider (for example Cloudflare), edit them there: Hostinger's DNS page then has no effect.

The records Fileora needs:

| Type | Name | Points to / value | TTL | Purpose | Status |
|---|---|---|---|---|---|
| A | `@` | Hostinger website IP | default | `fileora.in` → WordPress | Set by Hostinger when the domain was connected to the website: value `TO_BE_CONFIRMED` |
| CNAME | `www` | `fileora.in` | default | `www.fileora.in` → WordPress | `TO_BE_CONFIRMED` (Hostinger may use an A record instead; either works) |
| **A** | **`api`** | **`32.199.254.79`** | 300 while setting up, later 3600 | `api.fileora.in` → Nginx on EC2 | **Required.** Added in 7.3; `TO_BE_CONFIRMED` that it exists |
| AAAA | `@`, `www` | Hostinger's IPv6, if hPanel shows one | default | IPv6 for the website | Optional, `TO_BE_CONFIRMED` |
| AAAA | `api` | none | – | – | **Don't add** unless the EC2 instance has an IPv6 address and Nginx and the security group allow IPv6. A wrong AAAA record breaks the API for IPv6 clients. |
| TXT | `@`, `_dmarc`, … | the values hPanel → Emails shows (SPF, DKIM, DMARC) | default | Email for the domain | Only if you use email on fileora.in: `TO_BE_CONFIRMED` |
| TXT | `@` | `google-site-verification=…` | default | Search Console | Only if Search Console is verified by DNS (Fileora → SEO also supports the HTML tag): `TO_BE_CONFIRMED` |
| CAA | `@` | `0 issue "letsencrypt.org"` | default | Allows Let's Encrypt to issue for `api` | Only needed if the domain already has CAA records |

No record is needed for port 8000: it is never reachable from outside.

### 7.3 Add the API record (api.fileora.in → EC2)

1. hPanel → **Domains** → fileora.in → **DNS / Nameservers** → **DNS records** → *Manage DNS records*.
2. **Type** A · **Name** `api` · **Points to** `32.199.254.79` · **TTL** 300 → **Add record**.
3. If an older A or CNAME record for `api` exists, delete it: there must be exactly one.
4. If the EC2 address isn't an Elastic IP (8.1), it changes when the instance is stopped and started; then update this record. An Elastic IP avoids that.

If the domain uses Cloudflare: set the `api` record to **DNS only** (grey cloud). The proxied mode changes the certificate, the client IP the server sees and the upload limits.

### 7.4 Check DNS propagation

New records usually answer within minutes; a changed record can take as long as its old TTL (up to 24 hours with some providers).

```bash
dig +short A api.fileora.in              # expect: 32.199.254.79
dig +short A api.fileora.in @8.8.8.8     # Google's resolver
dig +short A api.fileora.in @1.1.1.1     # Cloudflare's resolver
dig +short AAAA api.fileora.in           # expect: nothing
dig +short www.fileora.in                # the website: Hostinger
dig +trace api.fileora.in | tail -5      # follows the delegation from the root
```

Windows (Command Prompt): `nslookup api.fileora.in 8.8.8.8`. When all resolvers return `32.199.254.79`, go on.

### 7.5 HTTPS for the website, and why the API certificate is on EC2

- **Website**: hPanel → Websites → fileora.in → **Security → SSL** → install the free certificate for `fileora.in` and `www.fileora.in`, then switch on **Force HTTPS**. WordPress → Settings → General: both addresses start with `https://`.
- **API**: `api.fileora.in` points to EC2, not to Hostinger, so Hostinger's SSL page can't cover it. Its certificate is made on the EC2 server with certbot (8.8). Only do that once 7.4 shows the right address.

```bash
curl -sI https://www.fileora.in | head -3                                   # HTTP/2 200 (or 301 to the canonical address)
echo | openssl s_client -connect www.fileora.in:443 -servername www.fileora.in 2>/dev/null | openssl x509 -noout -subject -dates
```

### 7.6 Connect WordPress to the processing server

1. WordPress → **Fileora → Settings → Processing server**:
   - **Server address** `https://api.fileora.in` (after 8.8; until then `http://api.fileora.in` works for a test, but never use it for visitors' files).
   - **Shared key**: tick *Generate a new key on save* → **Save** → copy the key into `/etc/fileora/fileora.env` on the server (8.6).
   - **Monitoring method**: *Automatic* (ICMP ping, TCP if ping isn't possible; see 5.9).
2. Press **Test the connection**: it must say *Connection works: the server answered and accepted the shared key*.
3. **Fileora → Settings → Privacy and Security pages**: *Website hosting* "Hostinger", *Processing server* "Amazon Web Services, `TO_BE_CONFIRMED` region" (8.1 shows how to read the region).

WordPress needs no other configuration file or environment variable: everything is stored in Fileora → Settings (the option `fileora_core_settings`). The shared key is the only secret; it never appears in the page source or in logs.

### 7.7 PHP limits

hPanel → Websites → Manage → **Advanced → PHP Configuration → PHP options**. Fileora → Settings warns you when PHP's upload limit is below the Fileora file-size limit.

| Setting | Value |
|---|---|
| `upload_max_filesize` | 128M |
| `post_max_size` | 128M |
| `max_execution_time` | 300 |
| `memory_limit` | 256M |

### 7.8 LiteSpeed Cache

**LiteSpeed Cache → Cache → Excludes → Do Not Cache URIs** → add `/wp-json/fileora/` and save. Purge all after every update.

### 7.9 Real cron

WordPress runs scheduled tasks only when someone visits. Health checks (Server Monitoring), rollups and clean-up of old records need a real cron job:

1. In `wp-config.php`, above "That's all, stop editing!": `define( 'DISABLE_WP_CRON', true );`
2. hPanel → **Advanced → Cron Jobs** → every 5 minutes:

   ```
   wget -q -O - "https://www.fileora.in/wp-cron.php?doing_wp_cron" >/dev/null 2>&1
   ```

If cron isn't running, the Fileora dashboard and Server Monitoring show a warning. (The cleanup of temporary files runs on the processing server itself and doesn't depend on WordPress cron.)

### 7.10 Test DNS, HTTPS and the API from Hostinger

From WordPress: **Fileora → Settings → Test the connection**, then **Fileora → Server Monitoring → Check now**. The *Method* line shows whether ping works from Hostinger or the TCP check is used.

With SSH access to Hostinger (hPanel → Advanced → SSH Access; availability depends on the plan: `TO_BE_CONFIRMED`):

```bash
dig +short api.fileora.in || nslookup api.fileora.in
curl -s https://api.fileora.in/health | head -c 300; echo
curl -s -o /dev/null -w "%{http_code}\n" https://api.fileora.in/admin/cleanup   # 401: admin endpoints need the key
curl -s https://ifconfig.me; echo         # Hostinger's outgoing IP, for the optional allow-list in 8.9
```

Without SSH, the outgoing IP shows on the EC2 server after a **Check now**: `sudo tail -n 20 /var/log/nginx/access.log | grep /health` (first column). It can change if Hostinger moves the site, so recheck it before relying on an allow-list.

### 7.11 Troubleshooting DNS, SSL and the API

| Symptom | Cause | Fix |
|---|---|---|
| `dig api.fileora.in` returns nothing | Record missing, or added at a provider the nameservers don't point to | 7.2: check `dig NS`; add the A record where the nameservers are |
| Different answers from 8.8.8.8 and 1.1.1.1 | Still propagating | Wait for the old TTL; lower the TTL before future changes |
| Old IP after an EC2 stop/start | No Elastic IP | Allocate one (8.2), update the A record |
| Browser: "Your connection isn't private" on `api.fileora.in` | No certificate for `api` yet, or Nginx answers with another site's | 8.8: `sudo certbot --nginx -d api.fileora.in --redirect`; `server_name api.fileora.in` in Nginx |
| `cURL error 60: SSL … hostname 'api.fileora.in'` in WordPress | Same as above, or DNS points somewhere else | `dig +short api.fileora.in`; certificate subject (8.8) |
| `cURL error 28: Connection timed out` | Security group closes 443, Nginx stopped, or wrong IP | 8.9 and 8.11 |
| `cURL error 7: Failed to connect` | Nothing listens on 443/80 | `sudo systemctl status nginx`, `sudo ss -tlnp` (8.11) |
| 404 *Not Found* from nginx | Another server block answers | 8.7: the Fileora block must be `default_server` and the default site removed |
| 502 *Bad Gateway* | The Fileora service is down | `sudo systemctl restart fileora`; `sudo journalctl -u fileora -n 50` |
| *Key rejected* / HTTP 401 | Keys differ | 8.16 |
| 413 *Request Entity Too Large* | Upload above Nginx's limit | `client_max_body_size` (8.7) and `FILEORA_MAX_MB` (8.6) |
| certbot: *Timeout during connect* / *unauthorized* | Port 80 closed, DNS not yet pointing to EC2, or CAA record | 8.9, 7.4, 7.2 (CAA) |
| Website fine, tools say "server can't be reached" | Only the API path is broken | Check from Hostinger (7.10), then the EC2 checks (8.11) |

---

## 8. AWS EC2 setup: the processing server

The processing server runs the tools a browser can't (LibreOffice, Ghostscript, qpdf, Tesseract, Chromium). It is a FastAPI service on **`127.0.0.1:8000`** behind **Nginx**, which is the only public entrance (`https://api.fileora.in`).

### 8.1 The instance

| Item | Value | How to check it |
|---|---|---|
| Public IPv4 | `32.199.254.79` | EC2 → Instances; on the server: IMDS command below |
| Private IPv4 | `172.31.18.174` | `hostname -I` |
| Elastic IP | `TO_BE_CONFIRMED` | EC2 → Network & Security → **Elastic IPs**: is `32.199.254.79` listed? |
| Region | `TO_BE_CONFIRMED` | IMDS below, or the console's region menu |
| Instance type | `TO_BE_CONFIRMED` (recommended: **t3.medium**, 2 vCPU, 4 GB, with `FILEORA_WORKERS=2`) | IMDS below |
| Operating system | `TO_BE_CONFIRMED` (`install.sh` is written for **Ubuntu 24.04 LTS**; Nginx reported `nginx/1.28.3 (Ubuntu)`) | `lsb_release -ds` |
| Disk | `TO_BE_CONFIRMED` (recommended 30 GB gp3) | `df -h /` |
| SSH user | `ubuntu` (default on Ubuntu images) | the login that works in 8.3 |
| Key pair file | `TO_BE_CONFIRMED` (the `.pem` you downloaded at launch) | EC2 → Instances → *Key pair name* |
| Security group | `TO_BE_CONFIRMED` | IMDS below; rules in 8.9 |
| Upload folder of the service files | `~/Fileora/fileora/server` | the folder you unzipped the server package into |

Fill in the blanks from the server itself (instance metadata, IMDSv2):

```bash
TOKEN=$(curl -sX PUT http://169.254.169.254/latest/api/token -H "X-aws-ec2-metadata-token-ttl-seconds: 60")
for k in placement/region instance-type public-ipv4 local-ipv4 security-groups ami-id; do
  printf '%-16s %s\n' "$k" "$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/$k)"
done
lsb_release -ds; nproc; free -h | head -2; df -h /
```

### 8.2 Create the instance (new or rebuilt server)

Skip this if the server already runs; it is here for a rebuild.

1. AWS console → EC2 → choose the region → **Launch instance**: **Ubuntu Server 24.04 LTS**, **t3.medium**, a key pair (`.pem`, keep it safe), storage **30 GB gp3**.
2. Security group: the rules in 8.9.
3. EC2 → **Elastic IPs** → Allocate → Associate with the instance. Then point the DNS record `api` to it (7.3).

### 8.3 Log in with SSH

```bash
chmod 400 fileora-key.pem                                  # once; ssh refuses keys others can read
ssh -i fileora-key.pem ubuntu@32.199.254.79
# or, once DNS works:  ssh -i fileora-key.pem ubuntu@api.fileora.in
```

- **Windows**: the same command in PowerShell (OpenSSH is built in). If it says the key's permissions are too open: file → Properties → Security → Advanced → disable inheritance and leave only your own user.
- **Without your key**: EC2 → Instances → **Connect → EC2 Instance Connect** (needs port 22 open to AWS's Instance Connect range) or Session Manager if the SSM agent and role are set up.
- `Permission denied (publickey)`: wrong key file or user. `Connection timed out`: port 22 isn't open to your current IP (8.9).

### 8.4 Folders on the server

```
~/Fileora/fileora/server/         your uploaded copy of the server package (install.sh, deploy/, tests/)
/opt/fileora/app/                 the running code: app.py, temp_store.py, requirements.txt
/opt/fileora/venv/                Python virtual environment
/opt/fileora/browsers/            Chromium for HTML to PDF
/etc/fileora/fileora.env          settings and secrets (mode 600, owner root)
/etc/systemd/system/fileora.service   the service definition
/etc/nginx/sites-available/fileora-api   Nginx site (link in sites-enabled/)
/etc/letsencrypt/live/api.fileora.in/   certificate (after certbot)
/var/lib/fileora/                 the service's own folder (owner fileora)
  jobs/                           TEMPORARY files: one folder per task (8.12)
    .fileora-temp-root            marks the folder as Fileora's temp directory
  cleanup-settings.json           cleanup on/off, expiry, interval (changed from WordPress)
  cleanup-state.json              last/next run, counts, failed deletions
  cleanup-history.jsonl           last 300 cleanup runs and admin actions
```

The `fileora` system user owns `/var/lib/fileora`; the service can't write anywhere else (`ProtectSystem`, `ReadWritePaths=/var/lib/fileora`).

### 8.5 Install the service

```bash
# from your PC, in the folder with the zip and the .pem key
scp -i fileora-key.pem fileora-server-2.4.zip ubuntu@32.199.254.79:~/

# on the server
sudo apt update && sudo apt -y upgrade
sudo apt install -y unzip nginx certbot python3-certbot-nginx
# 2 GB swap: LibreOffice, OCR and Chromium need headroom on 4 GB (skip if `swapon --show` already lists one)
sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
mkdir -p ~/Fileora/fileora && unzip -o ~/fileora-server-2.4.zip -d ~/Fileora/fileora/    # gives ~/Fileora/fileora/server
cd ~/Fileora/fileora/server && sudo bash install.sh     # 10–20 minutes the first time; ends with the /health answer
```

`install.sh` installs LibreOffice, Ghostscript, qpdf, Tesseract with all 23 OCR languages, fonts, the virtual environment, Chromium, `/etc/fileora/fileora.env` (only if it doesn't exist) and the systemd service. It is safe to run again.

The service starts with:

```
/opt/fileora/venv/bin/uvicorn app:app --host 127.0.0.1 --port 8000 --workers 1 --timeout-keep-alive 30
```

`--workers 1` is intentional: tasks run in the process's own thread pool (`FILEORA_WORKERS`), and the cleanup protects tasks that this one process is using.

### 8.6 Settings and secrets (`/etc/fileora/fileora.env`)

```bash
sudo nano /etc/fileora/fileora.env          # edit (Ctrl+O, Enter, Ctrl+X)
sudo systemctl restart fileora              # apply
sudo ls -l /etc/fileora/fileora.env         # must be -rw------- root root
```

| Variable | Default | Meaning |
|---|---|---|
| `FILEORA_KEY` | – (required) | Shared key; must equal Fileora → Settings → Shared key |
| `FILEORA_WORKDIR` | `/var/lib/fileora/jobs` | Temporary task folders. Must be a folder used only by Fileora (8.12) |
| `FILEORA_STATEDIR` | parent of `FILEORA_WORKDIR` | Cleanup settings, state and history *(new in 2.4, optional)* |
| `FILEORA_TTL_MIN` | `60` | Expiry used until it is changed in WordPress (Processing Tasks → Temporary files & cleanup) *(2.4: only the starting value)* |
| `FILEORA_MAX_MB` | `200` (example file: `100`) | Max size per uploaded file |
| `FILEORA_WORKERS` | `2` | Tasks that run at the same time; about one per 2 GB RAM |
| `FILEORA_AI_MODEL` | `claude-haiku-5-5` | Model for AI Summarizer and Translate PDF |
| `ANTHROPIC_API_KEY` | empty | Only for the two AI tools (8.17) |
| `FILEORA_ALLOW_PRIVATE_URLS` | off | Never set in production (lets HTML to PDF load private addresses) |

Secrets live only in this file: never in the code, the zip, Git, chats, tickets or screenshots. A key that was ever shared must be replaced (8.16). Read it in a command without printing it: `KEY=$(sudo grep '^FILEORA_KEY=' /etc/fileora/fileora.env | cut -d= -f2-)` … `unset KEY`.

### 8.7 Nginx reverse proxy

Nginx receives `api.fileora.in` on port 80 (and 443 after certbot) and forwards everything to `127.0.0.1:8000`. This is the configuration set up on the server (`/etc/nginx/sites-available/fileora-api`); before certbot it looks like this:

```nginx
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name api.fileora.in 32.199.254.79;
    client_max_body_size 512m;
    client_body_timeout 300s;
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_request_buffering off;
        proxy_buffering off;
        proxy_connect_timeout 10s;
        proxy_send_timeout 600s;
        proxy_read_timeout 600s;
    }
}
```

Check what is really active (`TO_BE_CONFIRMED` until you run this):

```bash
sudo nginx -T 2>/dev/null | grep -nE "server_name|listen|proxy_pass|ssl_certificate "
ls -l /etc/nginx/sites-enabled/             # fileora-api only; no "default"
```

To (re)create it: `sudo cp ~/Fileora/fileora/server/deploy/nginx-api-proxy.conf /etc/nginx/sites-available/fileora-api`, replace `api.example.com` with `api.fileora.in`, `sudo ln -sf /etc/nginx/sites-available/fileora-api /etc/nginx/sites-enabled/`, `sudo rm -f /etc/nginx/sites-enabled/default`, then `sudo nginx -t && sudo systemctl reload nginx`. Keep the existing file if it works.

Optional hardening: `server_tokens off;` in the `http { }` block of `/etc/nginx/nginx.conf` hides the Nginx version in error pages.

### 8.8 HTTPS certificate: install and renewal

Only after `dig +short api.fileora.in` returns `32.199.254.79` (7.4) and port 80 is open (8.9):

```bash
sudo certbot --nginx -d api.fileora.in --redirect        # adds "listen 443 ssl" + certificate, redirects http → https
curl -s https://api.fileora.in/health | head -c 200; echo
```

Renewal is automatic (systemd timer, twice a day; certificates last 90 days):

```bash
systemctl list-timers | grep certbot                      # the timer is scheduled
sudo certbot renew --dry-run                              # renewal works
sudo certbot certificates                                 # names and expiry date
echo | openssl s_client -connect api.fileora.in:443 -servername api.fileora.in 2>/dev/null | openssl x509 -noout -subject -dates
```

Renewal needs port 80 open to the internet (Let's Encrypt's HTTP check). Certificate status on this server: `TO_BE_CONFIRMED` (run `sudo certbot certificates`).

### 8.9 Security group and firewall

The security group is the firewall. Rules Fileora needs (inbound):

| Type | Port | Source | Why |
|---|---|---|---|
| SSH | 22/tcp | **My IP** only (your office/home IP) | Administration |
| HTTP | 80/tcp | `0.0.0.0/0` and `::/0` | Let's Encrypt validation and renewal; redirect to HTTPS |
| HTTPS | 443/tcp | `0.0.0.0/0` and `::/0`, or only Hostinger's outgoing IP (7.10) | The API for WordPress |
| Custom ICMP – IPv4, *Echo Request* | – | Hostinger's outgoing IP | Optional: lets Server Monitoring use ping; without it the TCP check is used and labelled |
| ~~8000~~ | – | **never** | The service listens on 127.0.0.1 only |

Outbound: the default *all traffic* rule (needed for apt, pip, Let's Encrypt and the Anthropic API).

The rules on this server are `TO_BE_CONFIRMED`: EC2 → Instances → the instance → **Security** tab → *Inbound rules*, or with the AWS CLI: `aws ec2 describe-security-groups --group-names <name from 8.1> --query 'SecurityGroups[0].IpPermissions'`.

UFW (Ubuntu's host firewall) is off by default on EC2 images; the security group is enough. If you turn UFW on, allow SSH first: `sudo ufw allow OpenSSH && sudo ufw allow 'Nginx Full' && sudo ufw enable`.

### 8.10 Ports

| Port | Service | Purpose | Access | Source |
|---|---|---|---|---|
| 22/tcp | SSH (`sshd`) | Server administration | Restricted to your IP in the security group | Ubuntu default; rule `TO_BE_CONFIRMED` (8.9) |
| 80/tcp | HTTP (Nginx) | Let's Encrypt validation; redirect to HTTPS | Public | `listen 80 default_server` in `fileora-api` (8.7) |
| 443/tcp | HTTPS (Nginx) | API for WordPress: `https://api.fileora.in` | Public, or Hostinger's outgoing IP only | Added by certbot (8.8); `TO_BE_CONFIRMED` until certbot has run |
| 8000/tcp | Fileora service (uvicorn) | Nginx → service, on the same machine | `127.0.0.1` only, never in the security group | `--host 127.0.0.1 --port 8000` in `fileora.service` |
| ICMP echo | kernel | Ping for Server Monitoring | Hostinger's outgoing IP, optional | Security group, `TO_BE_CONFIRMED` |

Verify on the server (expected result in the comments):

```bash
sudo ss -tlnp
#   0.0.0.0:22 / [::]:22      sshd or systemd (ssh.socket)
#   0.0.0.0:80 / [::]:80      nginx
#   0.0.0.0:443 / [::]:443    nginx         (after certbot)
#   127.0.0.1:8000            uvicorn       (never 0.0.0.0:8000)
curl -s -m 5 -o /dev/null -w "%{http_code}\n" http://32.199.254.79:8000/health   # from your PC: must fail (timeout)
```

### 8.11 Check ports, services, logs and the API

```bash
# services
systemctl status fileora nginx --no-pager
systemctl is-active fileora nginx; systemctl is-enabled fileora nginx
# listening ports
sudo ss -tlnp | grep -E ':(22|80|443|8000)\b'
# logs
sudo journalctl -u fileora -n 100 --no-pager             # service (errors, start-up, cleanup)
sudo journalctl -u fileora -f                            # follow live
sudo journalctl -u fileora --since "1 hour ago" | grep -E "fileora-audit|fileora: cleanup"   # admin actions and cleanup problems
sudo tail -f /var/log/nginx/access.log /var/log/nginx/error.log
sudo tail -n 50 /var/log/letsencrypt/letsencrypt.log     # certificate problems
# API: inside, through Nginx, through HTTPS
curl -s http://127.0.0.1:8000/health | head -c 300; echo
curl -s -H "Host: api.fileora.in" http://127.0.0.1/health | head -c 300; echo
curl -s https://api.fileora.in/health | head -c 300; echo
# admin endpoints: 401 without the key, JSON with it
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8000/admin/cleanup
KEY=$(sudo grep '^FILEORA_KEY=' /etc/fileora/fileora.env | cut -d= -f2-)
curl -s -H "X-Fileora-Key: $KEY" http://127.0.0.1:8000/admin/cleanup | python3 -m json.tool | head -30
curl -s -H "X-Fileora-Key: $KEY" http://127.0.0.1:8000/metrics | python3 -m json.tool | head -30
unset KEY
# full end-to-end check: a real Protect PDF job, the admin endpoints, the cleanup state
sudo bash ~/Fileora/fileora/server/deploy/smoke_test.sh  # ends with "All good."
```

Automated tests of the cleanup (they work in their own throw-away folders under `/tmp`, never in `/var/lib/fileora`):

```bash
cd ~/Fileora/fileora/server
sudo /opt/fileora/venv/bin/pip install -q httpx           # once; only for the HTTP tests
/opt/fileora/venv/bin/python -m unittest discover -s tests -v
```

### 8.12 Temporary files and cleanup

Every task gets one folder `/var/lib/fileora/jobs/<task id>/` (a random 32-character id, so parallel tasks never share or overwrite files): `status.json` (tool, status, creation time, result name and size), the uploads (`in/`, removed as soon as the task ends) and the result (`result/`). The result is deleted right after it is downloaded; the **cleanup** deletes whatever is left once it is older than the **expiry: 1 hour after the task was created** by default.

- **Where it is controlled**: WordPress → **Fileora → Processing Tasks → Temporary files & cleanup** (5.10): on/off (start/stop the schedule), expiry, interval, *Run cleanup now*, per-task details, delete, retry, history. The settings are saved on the server in `/var/lib/fileora/cleanup-settings.json` and survive restarts.
- **How it runs**: a scheduler thread inside the service (no cron job); every *interval* (default 5 minutes) it looks for expired task folders.
- **Switched off**: nothing is deleted automatically, nothing else stops; results are still deleted after download. The dashboard shows how much expired data is kept and how much more would be kept per day.

What can and can't be deleted (implemented in `server/temp_store.py`, tested in `server/tests/`):

1. **One folder only**: `FILEORA_WORKDIR`, after a check at every run: absolute path, a real folder (not a symlink, no symlink in its path), not a system, home or web folder, no application files in it (`wp-config.php`, `wp-content`, `uploads`, `index.php`, `.git`, `app.py`, …), owned by the service user, and marked with `.fileora-temp-root`. If any check fails, the cleanup is **paused and deletes nothing**; the dashboard and `journalctl -u fileora` say why.
2. **Allow-list**: only entries named like a task id (32 lowercase hex characters) are eligible; anything else in the folder is left alone and only counted.
3. **Never active work**: tasks that are waiting or running, and tasks the service is using right now (upload, processing), are skipped; a download already in progress always completes.
4. **Age from creation time**: `now − created ≥ expiry`, with `created` from `status.json` (the folder's time if that is missing; a creation time in the future is not trusted).
5. **No path tricks**: the folder must sit directly in the verified folder on the same disk; symbolic links are never followed (a link is removed as a link, its target is untouched).
6. **Race-safe**: the folder is first renamed to `.trash-<id>` under the same lock that marks tasks as active, then removed with Python's symlink-safe recursive delete limited to that folder. A failed deletion is recorded, shown on the dashboard and retried at the next run (or with *Retry*).
7. **Manual delete** from the dashboard goes through the same checks (it may delete a finished task before it expires; never a running one).
8. WordPress posts, pages, media, uploads, users, the database and the task records in *Task history* are never touched: the cleanup only knows the temp folder. Proven by `server/tests/test_temp_store.py` (permanent files next to the temp folder are hashed before and after) and `plugin/fileora-core/tests/test-temp-cleanup.php` (database tables and `wp-content/uploads` fingerprinted before and after).

Look without changing anything:

```bash
sudo ls -la /var/lib/fileora/jobs | head        # .fileora-temp-root + task folders
sudo du -sh /var/lib/fileora/jobs               # space used by temporary files
sudo cat /var/lib/fileora/cleanup-settings.json; echo
sudo tail -n 3 /var/lib/fileora/cleanup-history.jsonl
```

**Cleanup paused** ("marker file missing" or "contains application files"): 2.4 marks the folder itself when it is new or holds only task folders. If it holds anything else, someone pointed `FILEORA_WORKDIR` at the wrong place or put files there. Check with `sudo ls -la /var/lib/fileora/jobs`, move foreign files away (never delete them blindly), restart the service (`sudo systemctl restart fileora`) and check again. Never point `FILEORA_WORKDIR` at a website, upload, home or database folder: the checks refuse such folders, by design.

Don't clean the folder by hand with `rm -rf`: use *Run cleanup now* or *Delete* on the dashboard, which keep the safety checks.

### 8.13 Update, rollback and backups

**Update to a new server version** (2.4: `app.py` + new `temp_store.py`; no new Python packages):

```bash
# from your PC
scp -i fileora-key.pem fileora-server-2.4.zip ubuntu@32.199.254.79:~/
# on the server
sudo cp -a /opt/fileora/app /opt/fileora/app.bak-$(date +%F)              # 1. keep the running version
sudo cp /etc/fileora/fileora.env /root/fileora.env.bak-$(date +%F)         #    and the settings
unzip -o ~/fileora-server-2.4.zip -d ~/Fileora/fileora/                     # 2. new files in ~/Fileora/fileora/server
cd ~/Fileora/fileora/server && sudo bash install.sh                        # 3. install (keeps fileora.env)
sudo bash deploy/smoke_test.sh                                             # 4. must end with "All good."
sudo journalctl -u fileora -n 20 --no-pager | grep -i "cleanup is paused" || echo "cleanup OK"
```

Quicker, code only (when `requirements.txt` didn't change, as in 2.4):

```bash
cd ~/Fileora/fileora/server
sudo install -m 644 app.py temp_store.py /opt/fileora/app/ && sudo systemctl restart fileora
curl -s http://127.0.0.1:8000/health | head -c 100; echo
```

Then update the WordPress plugin (section 4.2) and open **Server Monitoring** and **Processing Tasks → Temporary files & cleanup** once.

**Roll back** the server (back to the copy from step 1; 2.3 doesn't use `temp_store.py`, so the extra file can stay):

```bash
sudo install -m 644 /opt/fileora/app.bak-<date>/app.py /opt/fileora/app/app.py
sudo systemctl restart fileora && curl -s http://127.0.0.1:8000/health | head -c 100; echo
```

After a rollback to 2.3 the old cleanup is back (it deletes folders by age without the 2.4 checks); the 2.4 state files in `/var/lib/fileora` are simply ignored. Roll back the plugin by uploading the previous zip (section 10.3); the new columns of `wp_fileora_health` stay and are ignored.

**Backups**

| What | How | Why |
|---|---|---|
| `/etc/fileora/fileora.env` | Copy into a password manager (it holds the key) | The only secret on the server |
| `/etc/nginx/sites-available/fileora-api`, `/etc/letsencrypt/` | `sudo tar czf ~/fileora-config-$(date +%F).tgz /etc/nginx/sites-available/fileora-api /etc/letsencrypt /var/lib/fileora/cleanup-settings.json` and download it | Rebuild in minutes |
| The whole server | EC2 → Volumes → **Create snapshot**, or an AMI after setup; Data Lifecycle Manager for a schedule | Restore after a failure |
| `/var/lib/fileora/jobs` | **Not backed up**: temporary by design | – |

### 8.14 Restart and recovery

| Situation | Do this |
|---|---|
| Service misbehaves | `sudo systemctl restart fileora` – tasks that were waiting or running are marked failed (visitors run them again); nothing else is lost |
| Nginx config changed | `sudo nginx -t && sudo systemctl reload nginx` |
| Server reboot | `sudo reboot`; Nginx and fileora start by themselves (both *enabled*); check with 8.11 |
| 502 Bad Gateway | The service is down: `sudo journalctl -u fileora -n 50`, fix the cause (often `fileora.env`), `sudo systemctl restart fileora` |
| Disk full | `df -h /`; `sudo du -sh /var/lib/fileora/jobs`; *Run cleanup now* in WordPress; `sudo journalctl --vacuum-size=200M`; `sudo apt clean` |
| Cleanup paused | 8.12 |
| Certificate expired | `sudo certbot renew && sudo systemctl reload nginx`; check that port 80 is open |
| New public IP after stop/start | Update the DNS record (7.3), or attach an Elastic IP |
| Instance lost | Launch from your snapshot/AMI (or 8.2 + 8.5), restore `fileora.env`, attach the Elastic IP, run certbot; DNS stays the same |
| Key leaked | 8.16 |

### 8.15 Security recommendations

- **SSH**: key only (Ubuntu images have password login off; keep it off), port 22 open to your IP only, keep the `.pem` private.
- **Port 8000 is never public**: the service listens on `127.0.0.1`; don't add 8000 to the security group.
- **Admin endpoints need the key**: `/metrics`, `/admin/cleanup…` and `/admin/temp…` answer 401 without `X-Fileora-Key`; they never return file paths. `/health` is public by design and shows only which tools are ready and the queue length. To hide even that, allow only Hostinger's outgoing IP on 443 (8.9) or add `allow <ip>; deny all;` to the Nginx `location` (port 80 must stay open for certificate renewal).
- **Every admin action is audited**: in WordPress (who, when, IP address, what, result: Processing Tasks → Temporary files & cleanup) and on the server (`journalctl -u fileora | grep fileora-audit`).
- **Updates**: `sudo apt update && sudo apt -y upgrade` monthly (Ubuntu installs security updates daily with *unattended-upgrades*); reboot when `/var/run/reboot-required` exists.
- **Secrets**: only in `/etc/fileora/fileora.env` (600, root); replace any key that was ever shared.
- **Elastic IP** so DNS never points at someone else's server after a restart.
- **Backups**: a regular EBS snapshot (8.13).
- Optional: `server_tokens off;` in Nginx, CloudWatch alarm on *StatusCheckFailed*, fail2ban for SSH.

### 8.16 The shared key

The key proves that a request comes from your WordPress.

1. Fileora → Settings → **Shared key**: empty the field and **Save** to generate a new 48-character key.
2. Put the same value on the server in `/etc/fileora/fileora.env` as `FILEORA_KEY=…` (mode 600, owner root), then `sudo systemctl restart fileora`.
3. **Test the connection**: "Key accepted" means both sides match.

### 8.17 AI tools (optional)

AI PDF Summarizer and Translate PDF need `ANTHROPIC_API_KEY` in `/etc/fileora/fileora.env` (then `sudo systemctl restart fileora`). Without it they stay switched off. They are marked paid: decide on pricing first.

### 8.18 What WordPress needs from the server

| Needed for | Endpoint (header `X-Fileora-Key` unless noted) | Status |
|---|---|---|
| All server tools | `POST /jobs/{tool}`, `GET /jobs/{id}`, `GET /jobs/{id}/file`, `DELETE /jobs/{id}` | Available |
| Health checks | `GET /health` (no key) → `ok`, `tools{}`, `queue{}` | Available |
| Server Monitoring figures | `GET /metrics` → CPU, memory, disk, network, uptime, temp storage | Available (2.4) |
| Temporary files & cleanup | `GET /admin/cleanup`, `PUT /admin/cleanup/settings`, `POST /admin/cleanup/run`, `GET /admin/cleanup/history`, `GET /admin/temp`, `GET`/`DELETE /admin/temp/{id}`, `POST /admin/temp/{id}/retry` (+ `X-Fileora-Actor` for the audit log) | Available (2.4) |
| Edit PDF | an editing endpoint | Not built: shown as "coming soon" |
| AI tools | `POST /jobs/summarize`, `POST /jobs/translate` + `ANTHROPIC_API_KEY` | Code ready; needs key and pricing |

---

## 9. How the numbers are calculated

Every figure on the dashboards comes from records stored in your WordPress database or read live from the processing server; nothing is invented. The one estimate (storage kept per day with cleanup off, 9.6) is labelled as such.

### 9.1 Availability

```
Availability = successful health-check time ÷ total monitored time × 100
```

- Each check covers the time until the next one, but at most two monitoring intervals. A gap with no checks is **unmonitored**, neither up nor down.
- **Coverage** = monitored time ÷ length of the window. Low coverage means cron isn't running.
- A check succeeds when `/health` answers HTTP 200 in time and accepts the key.

### 9.5 Network probe and server figures

| Figure | How it is measured |
|---|---|
| Latency (ICMP) | Average round trip of the replies of one `ping -n -c 3 -W 2` (packets per check: Settings) |
| Latency (TCP) | Average time to open a TCP connection to the API port (443), 3 attempts, 3 s timeout each; DNS is resolved once, outside the timing |
| Latency (HTTP) | Time of the `/health` request (includes TLS and the service) |
| Packet loss | (sent − answered) ÷ sent × 100, per check; the period value is the average of the checks |
| Reachable | At least one reply/connection in the check |
| Last successful check | Newest check where `/health` answered and accepted the key |
| CPU | Busy share of all cores from `/proc/stat`, averaged over the last 5 minutes (sampled every 10 s on the server) |
| Memory used | (MemTotal − MemAvailable) ÷ MemTotal |
| Disk used | used ÷ (used + available), the same as `df -h`, for the disk with the temporary files |
| Network in/out | Bytes per second over the last 5 minutes, all interfaces except loopback |
| Uptime | Server: `/proc/uptime`; service: since the last start |
| 7-day graphs | 30-minute averages; gaps where nothing was measured |

### 9.6 Temporary storage

- **Temporary storage now**: size of all files in the task folders (symbolic links counted as links), read when the page opens.
- **Expired, not deleted yet**: task folders past their expiry that aren't in use.
- **Kept per day with cleanup off** (estimate): results of the last 7 days (fewer if the records are younger) that were never downloaded, from the task records, ÷ days. Downloaded results and AI text results are deleted at once and are left out.

### 9.2 Tasks and runs

| Term | Meaning |
|---|---|
| Server task | One request to the processing server; completed or failed with an error code (`unreachable`, `auth`, `server_error`, `abandoned` after 2 hours…) |
| Browser run | Reported by the visitor's browser when a browser tool finishes; never counted as a server task |
| Tool runs | Browser runs + server tasks |
| Success rate | Completed ÷ (completed + failed); running tasks excluded |
| Average duration | Upload to finished result, completed tasks only |

### 9.3 Visitors and visits

| Term | Meaning |
|---|---|
| Visitor ID | Random id in the browser's localStorage; no cookies |
| Visit | Random id per tab session; ends after 30 minutes without activity |
| Unique visitors | Distinct visitor ids among the period's visits |
| Active now | Visits with activity in the last 5 minutes (a "still here" signal at most once a minute) |
| Files processed | Files in successful runs |

- **Recorded per visit**: first and last activity, approximate location, IP address (full, shortened or none), landing page, referring site, device, browser and system. Per tool run: tool, result, duration, number of files and the first file name. **Never file contents or passwords.**
- Bots are ignored, Do Not Track and Global Privacy Control are respected, administrators are not counted.
- Every event carries a random id with a unique index, so retries are stored once.

### 9.4 History, retention and export

| Data | Kept | Notes |
|---|---|---|
| Visits, events, server tasks | at least 90 days, default 180; 0 = forever | Settings → Data retention; removed daily in batches |
| Daily totals (per day and per tool) | forever | Counts only, no visitor ids, locations or IPs; long-range charts keep working after old details are removed |
| IP addresses | 30 days by default (1–365) | The rest of the record stays |
| Health checks (incl. network probe and server figures) | 90 days (min. 30) | |
| Cleanup history (on the server) | last 300 entries | `/var/lib/fileora/cleanup-history.jsonl` |
| Admin actions (audit log) | last 200 entries | WordPress option `fileora_audit_log`; also in the PHP error log (`[Fileora] AUDIT`) and `journalctl -u fileora` |

- **CSV export** (Visitor Analytics → *Export data*) for 30 minutes to a custom range: times in site time and UTC, opens correctly in Excel, formula cells neutralised. Administrators only; IP addresses only when allowed and ticked. Each export is listed under Settings → *Analytics storage*.
- **Analytics storage** (Settings) shows rows and size per table, the oldest record, database errors while saving and recent exports.
- Summaries are cached 30 seconds (10 minutes for custom periods that ended over an hour ago).
- Database tables: `wp_fileora_sessions`, `wp_fileora_events`, `wp_fileora_tasks`, `wp_fileora_health`, `wp_fileora_daily`, `wp_fileora_daily_tools`.

---

## 10. Troubleshooting, backups and recovery

Most problems come from DNS, the shared key, PHP limits or cron.

### 10.1 Common errors

| Problem | Cause and fix |
|---|---|
| DNS, certificate or API connection errors | Section 7.11 (Hostinger side) and 8.14 (server side) |
| `cURL error 60: SSL … hostname 'api.fileora.in'` | The name doesn't reach EC2 or the certificate is for another name. Check `nslookup api.fileora.in`, `server_name api.fileora.in;` in Nginx, then `sudo certbot --nginx -d api.fileora.in`. |
| "The processing server can't be reached" | Wrong address, service stopped (`sudo systemctl status fileora`), Nginx stopped, or the security group blocks 443. |
| "Key rejected" | WordPress and `/etc/fileora/fileora.env` hold different keys. Copy again, restart the service. |
| Unlock PDF says "isn't password-protected" | The server runs an old `app.py`: update it. For e-Aadhaar the password is the first 4 letters of the name in capitals + year of birth (`RAVI1990`). |
| Large uploads fail at once | PHP limits too low, or Nginx `client_max_body_size`. |
| Monitoring shows low coverage | Real cron isn't running (7.9). |
| Server Monitoring says *TCP connect* instead of ping | Ping isn't possible from the web host or ICMP is blocked by the security group; the TCP figures are real. To use ping: allow ICMP Echo Request from Hostinger's IP (8.9), if the host can run `ping` at all. |
| Server resources: *Not Available* | Server older than 2.4, or the key is rejected; update (8.13) / fix the key (8.16) |
| Temporary files: *Cleanup is paused* | The temp directory couldn't be verified; nothing is deleted. Section 8.12 |
| Temporary files: *Deletion failed* | Shown with the error; *Retry*, or check `journalctl -u fileora` (usually file permissions after a manual change) |
| Visitor location shows "Unknown" | 1) Install the database: Settings → *Location database and check* → Download (or "Download now (wait)"), or upload the DB-IP City Lite `.mmdb.gz`. 2) Behind a proxy or CDN: in *Location check*, set **Visitor IP address comes from** to the header showing your real IP. 3) Press **Fill in locations now**. Test logged out. |
| "This tool couldn't load" | An ad blocker or extension blocks the script. The page offers a reload. |

### 10.2 Backups

- **WordPress**: files and database (Hostinger daily backups or UpdraftPlus). Fileora's data is in the `wp_fileora_*` tables and options starting with `fileora_`.
- **Server**: `/etc/fileora/fileora.env` (keep a copy in a password manager), the Nginx config, `/etc/letsencrypt` and `/var/lib/fileora/cleanup-settings.json`; never the temporary files. A snapshot after setup makes a rebuild a 5-minute job (8.13).

### 10.3 Recovery

| Situation | Do this |
|---|---|
| Tool pages deleted or addresses broken | Tool Management → **Restore missing pages**, then Settings → Permalinks → Save |
| Server instance lost | Launch from your AMI (or run `install.sh`), attach the Elastic IP, restore `fileora.env`, run certbot. DNS stays the same |
| Key leaked | Empty the key in Settings and Save; copy the new key to the server; restart the service |
| Plugin broken after an update | Deactivate Fileora Core (the site stays a blog) and upload the previous zip; data is kept |
| Theme broken | Activate another theme; tool pages keep working through the plugin |

---

## 11. For developers

Tools are defined in PHP and run in JavaScript; a new tool needs two small edits and gets its page automatically.

### 11.1 Folders

```
plugin/fileora-core/
  fileora-core.php              bootstrap
  includes/                     settings, permissions, tool registry, security, backend API, tasks,
                                analytics, history, reports, geo, announcements, support, content,
                                server monitor, network probe, temporary-file cleanup controls, REST,
                                SEO, admin, cleanup of old records, logger with audit log
  includes/lib/MaxMind/         location database reader (Apache 2.0)
  modules/<module>/module.php   tool definitions: pdf, image, converter, optimizer, security, editor, ai
  modules/<module>/<module>.js  browser tool code
  modules/<module>/pages/       hand-written starter pages (e.g. png-to-svg.php)
  public/js/src/*.js            the engine, built into public/js/fileora-engine.js
  public/vendor/                pdf-lib, pdf.js, JSZip, heic2any, ImageTracer.js (served locally)
  admin/                        views, styles, Chart.js
  tests/test-temp-cleanup.php   WP-CLI safety test: cleanup never touches WordPress content
theme/fileora-theme/
  functions.php, inc/           setup, customizer, icons, navigation, blog, starter content
  starter-content/              information pages and blog guides (Markdown) + covers
  template-parts/, assets/      cards, catalogue, FAQ; CSS, JS, self-hosted fonts
server/                         app.py (service), temp_store.py (temporary files, cleanup, metrics),
                                install.sh, requirements.txt, deploy/, tests/ (unittest)
tools/build-engine.sh           rebuilds the engine after editing public/js/src
```

### 11.2 Public functions

`fileora_get_tools()`, `fileora_get_tool_groups()`, `fileora_get_tool()`, `fileora_runs_on()`, `fileora_render_workspace()`, `fileora_tool_faq()`, `fileora_icon()`, `fileora_catalog_data()`, `fileora_deletion_text()`. A theme that places the workspace itself declares `add_theme_support( 'fileora' )`.

### 11.3 Hooks

| Hook | Use |
|---|---|
| `fileora_modules` | Add a module folder with your own tools |
| `fileora_engine_config` | Change the configuration sent to the browser |
| `fileora_max_mb`, `fileora_daily_limit` | Per-user limits (e.g. higher for members) |
| `fileora_pre_submit` | Last check before a server task (captcha, members only); return a `WP_Error` to refuse |
| `fileora_trust_upload` | Accept a file whose content doesn't match its extension |
| `fileora_client_ip` | Real visitor IP behind a proxy |
| `fileora_geo_lookup` | Supply a visitor's location yourself |
| `fileora_tool_title` | The `<title>` of tool pages |
| `fileora_job_created`, `fileora_job_finished` | React to server tasks (actions) |
| `fileora_core_tools_synced` | After tool pages were checked or created (action) |

### 11.4 Adding a tool

1. Add its definition to a module's `module.php`: id, slug, name, description, icon, accept, `exec` (browser, server or hybrid); optionally `seo_title`, `seo_desc` and `page` for a hand-written starter page.
2. Add `E.register({ id, accept, opts, run })` in the module's JS, or a handler in the server's `TOOLS` table.
3. Open any admin page: the tool page is created. Run `bash tools/build-engine.sh` only after editing `public/js/src`.

### 11.5 Uninstall

Deleting the plugin removes its scheduled events, the Blog Editor and Support roles and the capabilities. Tables and settings (including the audit log) are kept unless *Delete all Fileora data when the plugin is deleted* is ticked. Tool pages are kept as content. Nothing on the processing server is changed.

---

## 12. Version history and testing

Each version was tested on WordPress 7.1, PHP 8 and MariaDB with the processing service running locally, using automated Chromium browser tests; details are in `TEST-REPORT.md`.

| Version | Date | What changed | Tested |
|---|---|---|---|
| **2.12.0** (plugin), **2.4** (server) | 22 Oct 2026 | **Server Monitoring**: ICMP ping latency and packet loss with labelled TCP/HTTP fallback, reachability, last successful check, CPU, memory, disk, network and uptime from the server's new `/metrics` (key needed), graphs for 1 h / 6 h / 24 h / 7 d, *Not Available* instead of missing values. **Temporary files and automatic cleanup**: verified temp directory with marker, task-id allow-list, active-task protection, age-based expiry (default 1 hour from creation), race-safe deletion, failures retried; settings stored on the server; Processing Tasks → *Temporary files & cleanup* with schedule controls, filters, details, confirmed delete, retry, history, storage impact and audit log. README: separate **Hostinger** and **AWS EC2** parts with port table, checks, rollback and security | Server: 51 unittest tests (Python 3.13: 51 passed; 3.12: 50 passed, the real-job test skipped without pikepdf; 3.11: the 42 cleanup tests): expiry, active tasks, symlinks, path tricks, unverified/foreign/system folders, swapped root, failures + retry, settings persistence, permanent files hashed before/after, admin endpoints refuse requests without the key, real job end to end; smoke test. WordPress: safety test 26/26 (posts, post meta, users, comments, terms, task records and uploads unchanged; subscriber and missing nonce refused and audited); probe: ICMP, ICMP blocked → TCP, ICMP forced, TCP, HTTP; all 14 server tools end to end through WordPress; scheduled run deleted exactly the 2 expired folders and left the running task and a foreign folder alone; axe 0 on Server Monitoring (1 h, 6 h, 24 h, 7 d), Task history and Temporary files views at 1440 and 390 px |
| **2.11.0** (plugin), **2.8.0** (theme) | 22 Oct 2026 | **ATS Resume Builder** (section 5.8): separate page and *ATS Resume* header link; 4 single-column templates with colour, text size and paper; form with reorderable sections; live preview that is the real PDF; ATS check (11 checks + job-ad keyword comparison); PDF, plain text, save/open a copy; data only in the visitor's browser. Theme: wide page template, header link, header no longer overflows with 9+ links | 4 templates: PDF text read back in the right order with the name first, links clickable, 1 page (Minimal 2) for the example; reorder, hide, add/remove, "work here now", ₹ and Devanagari handling, plain text, save/open, session vs remember, two-click clear; job-ad comparison; axe 0 at 1440, 390 and dark; no sideways scroll at 390/1180–1920; page SEO 100%; link added once, before Contact |
| **2.10.0** (plugin), **2.7.0** (theme), **2.3** (server) | 21 Oct 2026 | **HTML Code to PDF** tool: code editor, live preview, A4/Letter/fit, margins, print or screen CSS, optional JavaScript, file name; PDF made by Chromium on the server with public-internet-only loading. Blog plan **day 70**: *How to convert HTML to PDF* + the tool page's text. Markdown content can now contain code blocks. **Fixes**: OCR, AI Summarizer and Translate now really support all 23 languages the site offers (Gujarati, Kannada, Malayalam and Punjabi were falling back to English); install.sh installs all OCR languages; HTML to PDF page points to the new tool for local files. Theme: **Copy code** button on code blocks in posts | Server: A4/Letter/landscape/fit/print vs screen CSS, JavaScript off and on, empty and wrong-type files; private addresses, localhost, metadata and `file:` blocked (a local listener saw no requests). Browser: example → PDF with selectable text, sandbox and CSP checks, code kept after reload, 390 px without sideways scroll, axe 0 on the tool, the post and the plan screen; day 70 applied (post 100%, tool page 100%), undo restores the tool page |
| **2.9.0** (plugin) | 21 Oct 2026 | **Blog plan days 54–69**: 16 posts for the server tools (Word, Excel, PowerPoint to PDF and back, HTML to PDF, OCR, PDF/A, Protect, Unlock, Redact, Forms, AI Summarizer, Translate, Edit) with 10 keywords, 10 title ideas and a cover image each; posts about a switched-off tool stay drafts until it's on. **Corrections**: Excel to PDF no longer shows an *Orientation* setting the server never used, and explains *Fit all columns*; PDF to PowerPoint no longer promises editable text (each page is a picture slide). Tool pages written by the 60-day plan are corrected automatically, only if you haven't edited them | 16 new posts: 0 errors, all 92–100% (PDF/A 92: a web address can't contain "/"), 16 covers attached; AI posts held as drafts, published once the tool was switched on; both tool pages corrected, an edited page left alone; Excel options in Chromium; axe 0 |
| **2.8.0** (plugin) | 21 Oct 2026 | **53 cover images** for the blog plan: added to the Media Library with alt text, attached and set as the featured image when a day is enabled; posts from days enabled earlier get theirs automatically or with one button; undo restores a refreshed post's old image. Plugin upgrade routine now runs after translations load (no WordPress 6.7 notice) | 53 posts: 53 images, each attached, featured, with alt text and all thumbnail sizes; undo and re-apply create no duplicates (53 items in the library); simulated earlier install filled in 53 covers in 7 admin page loads; cover, blog cards and `og:image` checked in Chromium; axe 0 |
| **2.7.0** (plugin) | 21 Oct 2026 | **53-day blog plan**: one post per tool (30 PDF Tools, 21 Image Tools, 2 File Optimizer) with 10 search keywords and 10 title ideas each; six posts refresh an older guide in place with backup and undo; **Search keywords** field with live coverage and **Title ideas** in the SEO box; new checklist item for search keywords; 10 search keywords added to all 24 guides | All 53 days applied: 47 drafts + 6 refreshes, 0 errors, every post 90%+ (average 99%), categories 30/21/2; undo restored the 6 refreshed posts exactly and trashed 47 drafts; re-apply and publish; links checked (no link to a later post); axe 0 on the blog plan screen and a post |
| **2.6.1** (plugin), **2.6.0** (theme) | 21 Oct 2026 | Accessibility button and panel; GSAP header and footer animation; *Contact us* in the header (and in the 60-day plan's header menu); footer: no second *Privacy policy* link, no Accessibility link, *Back to top*; footer columns never repeat the same tools | Chromium at 1440, 1280 (dark) and 390 px: panel opens, options apply and persist, Esc returns focus, axe 0 violations with the panel open; reduced motion = no animation; no sideways scroll |
| **2.6.0** (plugin), **2.5.3** (theme) | 21 Oct 2026 | **60-day SEO plan** (Fileora → SEO): one card per day with ready-written text for 41 tool pages, 24 guides (6 in Hindi), 9 exam pages, 5 KB pages and an exam size list; drafts, size checks before publishing, undo; tool presets on pages; sitemap and archive cleaning; “Guides for” links on tool pages; `lang="hi"` for Hindi guides. Theme: blog sidebar and author box are no longer nested landmarks | All 60 days applied, published and scored (every plan page 80%+), undo and re-apply, exam and KB presets run in Chromium at 390 px, axe 0 violations on the plan screen and new pages |
| **2.5.2** (theme) | 20 Oct 2026 | Favicon in every size, Apple and Android icons, web manifest; `/favicon.ico` shows the Fileora icon instead of the WordPress logo | Tags in the page head, `/favicon.ico` redirect, icons rendered at 16–512 px |
| **2.5.1** | 19 Oct 2026 | SEO text pack for the All tools page (title, description, keyword, intro, ~650 words, FAQ); the SEO checklist counts the tool list on that page; excerpt field for pages | Pack applied: score 91%, FAQ structured data present, axe 0 violations, no sideways scroll at 390 px |
| **2.5** | 19 Oct 2026 | Contact form with messages inbox; Accessibility and Contact pages; accessibility fixes (heading order, landmarks, keyboard labels); wider information pages, tables as cards on phones; SEO box for every page/post/tool with Google preview and checklist; Fileora → SEO overview and site settings; footer credit | axe on 13 page types (light + dark): 0 violations; every tool at 320/390/768/1024 px; contact form (validation, saving, rate limit); SEO tags, noindex, canonical, sitemap exclusion |
| **2.4** | 19 Oct 2026 | New **PNG & JPG to SVG** tool with its own SEO page; API address now `api.fileora.in` | Logo, signature, icon, several files, photo, Web Worker fallback, no outside requests, phone layout |
| **2.3** | 17 Oct 2026 | History kept 90+ days or forever, custom date range, traffic per minute/hour/day, tool usage, CSV export, daily totals, duplicate-proof events, data kept when the plugin is deleted | 32 accuracy checks against known test records; filters, export, permissions, phone layout |
| **2.2.1** | 17 Oct 2026 | Location fix: download or upload the database, IP source behind proxies, location check, fill in old visits | Proxy simulation, upload, backfill |
| **2.2** | 16 Oct 2026 | Visitor Analytics dashboard, announcements, Support role, six information pages | Analytics with 9 simulated locations, Support permissions, announcements, page structure |
| **2.1** | Oct 2026 | Blog with four SEO guides | Import, structured data, layout |

Also verified: all 65 default tools end to end through their WordPress pages; in-browser tools send no file data anywhere; the theme alone as a blog; the plugin with a default WordPress theme.

**Not verified here:** a real Hostinger + EC2 deployment (DNS, certificate, security group, ping from Hostinger to EC2: the values marked `TO_BE_CONFIRMED` in sections 7 and 8), real visitor locations in India, and HEIC conversion with a real iPhone photo.
