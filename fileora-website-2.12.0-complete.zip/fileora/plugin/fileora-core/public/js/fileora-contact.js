/* Fileora contact form: sends to /wp-json/fileora/v1/contact and shows field errors next to the fields. */
(function () {
  'use strict';
  var C = window.FileoraContact;
  if (!C) return;
  var start = Date.now();
  document.querySelectorAll('form.fo-contact').forEach(function (f) {
    var status = f.querySelector('.fo-c-status'), btn = f.querySelector('.fo-c-btn'), label = btn.textContent;
    function err(name, text) {
      var el = f.elements[name]; if (!el) return;
      var box = document.getElementById(el.id + '-err');
      if (text) { el.setAttribute('aria-invalid', 'true'); if (box) { box.textContent = text; box.hidden = false; } }
      else { el.removeAttribute('aria-invalid'); if (box) { box.textContent = ''; box.hidden = true; } }
    }
    function check() {
      var e = {};
      if (!f.elements.name.value.trim()) e.name = 'Please enter your name.';
      if (!f.elements.email.value.trim() || !f.elements.email.checkValidity()) e.email = 'Please enter a valid email address, for example name@example.com.';
      if (f.elements.message.value.trim().length < 10) e.message = 'Please write a little more (at least 10 characters).';
      return e;
    }
    ['name', 'email', 'message'].forEach(function (n) { f.elements[n].addEventListener('input', function () { if (f.elements[n].getAttribute('aria-invalid')) err(n, check()[n] || ''); }); });
    f.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var e = check();
      ['name', 'email', 'message'].forEach(function (n) { err(n, e[n] || ''); });
      var first = Object.keys(e)[0];
      if (first) { status.textContent = C.i18n.fix; f.elements[first].focus(); return; }
      btn.disabled = true; btn.textContent = C.i18n.sending; status.textContent = '';
      var body = { name: f.elements.name.value, email: f.elements.email.value, topic: f.elements.topic.value, message: f.elements.message.value, website: f.elements.website.value, page: location.href.split('#')[0], t: Date.now() - start };
      fetch(C.url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), credentials: 'same-origin' })
        .then(function (r) { return r.json().catch(function () { return {}; }); })
        .then(function (d) {
          if (d && d.ok) {
            f.reset(); start = Date.now();
            f.classList.add('is-sent');
            status.textContent = d.message;
            status.setAttribute('tabindex', '-1'); status.focus();
          } else if (d && d.errors) {
            Object.keys(d.errors).forEach(function (n) { err(n, d.errors[n]); });
            status.textContent = C.i18n.fix;
            var k = Object.keys(d.errors)[0]; if (f.elements[k]) f.elements[k].focus();
          } else {
            status.textContent = (d && d.message) || C.i18n.failed;
          }
        })
        .catch(function () { status.textContent = C.i18n.failed; })
        .then(function () { btn.disabled = false; btn.textContent = label; });
    });
  });
})();
