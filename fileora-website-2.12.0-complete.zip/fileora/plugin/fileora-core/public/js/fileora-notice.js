/* Fileora popup announcements. Data comes from window.FileoraNotices (printed by the plugin). */
(function () {
  'use strict';
  var D = window.FileoraNotices;
  if (!D || !D.items || !D.items.length) return;
  function get(st, k) { try { return window[st].getItem(k); } catch (e) { return null; } }
  function set(st, k, v) { try { window[st].setItem(k, v); } catch (e) { /* storage blocked: shown again next time */ } }
  function today() { var d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
  var mobile = matchMedia('(max-width: 900px), (pointer: coarse)').matches;
  // First-time visitor: no visitor id stored before this page (the analytics script sets one; FileoraTrack.isNew tells us).
  // First visit = the visit in which this browser was first seen.
  var isNew;
  if (window.FileoraTrack && !window.FileoraTrack.off) isNew = !!window.FileoraTrack.newVisit;
  else {
    var first = get('sessionStorage', 'fileora.firstvisit');
    if (first === null) { first = get('localStorage', 'fileora.seen') ? '0' : '1'; set('sessionStorage', 'fileora.firstvisit', first); }
    set('localStorage', 'fileora.seen', '1');
    isNew = first === '1';
  }

  function seen(n) {
    var k = 'fileora.notice.' + n.id + '.' + n.v;
    if (n.frequency === 'session') return get('sessionStorage', k) === '1';
    if (n.frequency === 'day') return get('localStorage', k) === today();
    return false;
  }
  function remember(n) {
    var k = 'fileora.notice.' + n.id + '.' + n.v;
    if (n.frequency === 'session') set('sessionStorage', k, '1');
    else if (n.frequency === 'day') set('localStorage', k, today());
  }
  function eligible(n) {
    var now = Date.now();
    if (n.start && now < n.start) return false;
    if (n.end && now > n.end) return false;
    if (n.device === 'mobile' && !mobile) return false;
    if (n.device === 'desktop' && mobile) return false;
    if (n.audience === 'new' && !isNew) return false;
    if (n.audience === 'returning' && isNew) return false;
    return n.preview || !seen(n);
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  function show(n) {
    var modal = n.position === 'center';
    var root = document.createElement('div');
    root.className = 'fon fon-' + n.position + ' fon-' + n.style;
    root.style.setProperty('--fon-accent', n.accent || '#FFD43B');
    var tid = 'fon-t-' + n.id;
    root.innerHTML = (modal ? '<div class="fon-bg" data-fon-close></div>' : '') +
      '<div class="fon-box" ' + (modal ? 'role="dialog" aria-modal="true"' : 'role="region"') + ' aria-labelledby="' + tid + '" tabindex="-1">' +
      '<button type="button" class="fon-x" data-fon-close aria-label="' + esc(D.close) + '">&times;</button>' +
      (n.preview ? '<span class="fon-pv">Preview</span>' : '') +
      '<h2 class="fon-title" id="' + tid + '">' + esc(n.title) + '</h2>' +
      '<div class="fon-body">' + n.html + '</div>' +
      (n.button && n.url ? '<p class="fon-cta"><a class="fon-btn" href="' + esc(n.url) + '">' + esc(n.button) + '</a></p>' : '') +
      '</div>';
    var last = document.activeElement;
    function close() {
      remember(n);
      root.classList.remove('fon-in');
      document.removeEventListener('keydown', key, true);
      setTimeout(function () { root.remove(); if (modal) document.documentElement.classList.remove('fon-lock'); }, 200);
      if (modal && last && last.focus) last.focus();
    }
    function key(e) {
      if (e.key === 'Escape') {
        // Esc closes the popup; a bar or card only when the focus is inside it.
        if (modal || root.contains(document.activeElement)) { e.stopPropagation(); close(); }
        return;
      }
      if (!modal || e.key !== 'Tab') return;
      var f = root.querySelectorAll('a[href], button');
      if (!f.length) return;
      if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
    }
    root.addEventListener('click', function (e) {
      if (e.target.closest('[data-fon-close]')) close();
      else if (e.target.closest('.fon-btn')) remember(n);
    });
    document.addEventListener('keydown', key, true);
    document.body.appendChild(root);
    if (modal) document.documentElement.classList.add('fon-lock');
    requestAnimationFrame(function () { root.classList.add('fon-in'); if (modal) root.querySelector('.fon-box').focus(); });
    // Frequency counts from the moment it was shown, even if the visitor just leaves.
    if (n.frequency !== 'always' && !n.preview) remember(n);
  }

  function start() {
    // At most one popup (centre) and one bar or card at a time.
    var used = {};
    D.items.forEach(function (n) {
      var slot = n.position === 'center' ? 'modal' : n.position;
      if (used[slot] || !eligible(n)) return;
      used[slot] = true;
      setTimeout(function () { show(n); }, Math.max(0, n.delay || 0) * 1000);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
