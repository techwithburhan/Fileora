/* Fileora ATS Resume Builder ([fileora_resume_builder]).
   Everything happens in the visitor's browser: the resume is typeset as a real-text PDF
   with pdf-lib (standard Helvetica/Times fonts, one column, so ATS software reads it top to
   bottom), previewed with pdf.js, and checked by reading the PDF's own text back.
   The data stays in sessionStorage (this tab), or localStorage when "Remember" is on. */
(function () {
  'use strict';
  var CFG = window.FileoraResume || {};
  var roots = document.querySelectorAll('[data-fo-resume]');
  if (!roots.length) return;

  /* ---------------- helpers ---------------- */
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  var lines = function (s) { return String(s || '').split(/\r?\n/).map(function (l) { return l.replace(/^\s*(?:[-*•·▪●◦►➢✓–]\s+)/, '').trim(); }).filter(Boolean); };
  var ICONS = {
    up: '<path d="m6 15 6-6 6 6"/>', down: '<path d="m6 9 6 6 6-6"/>', trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', download: '<path d="M12 4v11m0 0-4-4m4 4 4-4M5 20h14"/>', copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    chev: '<path d="m6 9 6 6 6-6"/>', check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>', alert: '<path d="M12 4 2.5 20h19z"/><path d="M12 10v4M12 17h.01"/>', info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>'
  };
  var ic = function (n) { return '<svg class="fo-ic fo-ic-sm" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + ICONS[n] + '</svg>'; };
  function loadScript(src) {
    return new Promise(function (res, rej) {
      var s = document.createElement('script'); s.src = src; s.async = true;
      s.onload = res; s.onerror = function () { rej(new Error('load ' + src)); };
      document.head.appendChild(s);
    });
  }
  var libs = null;
  function loadLibs() {
    if (!libs) {
      libs = Promise.all([
        window.PDFLib ? Promise.resolve() : loadScript(CFG.pdflib),
        window.pdfjsLib ? Promise.resolve() : loadScript(CFG.pdfjs)
      ]).then(function () {
        if (window.pdfjsLib && CFG.worker) window.pdfjsLib.GlobalWorkerOptions.workerSrc = CFG.worker;
        return { PDFLib: window.PDFLib, pdfjs: window.pdfjsLib };
      });
      libs.catch(function () { libs = null; });
    }
    return libs;
  }

  /* ---------------- templates and settings ---------------- */
  var TEMPLATES = {
    classic: { name: 'Classic', best: 'Government, banking, academic', family: 'times', margin: 54, nameSize: 20, center: true, upperHead: true, rule: true, headColor: 'ink', nameColor: 'ink', datesRight: true, gap: 1.0 },
    modern: { name: 'Modern', best: 'Most private-sector jobs', family: 'helv', margin: 50, nameSize: 22, center: false, upperHead: false, rule: true, headColor: 'accent', nameColor: 'accent', datesRight: true, gap: 1.0 },
    compact: { name: 'Compact', best: 'Freshers, one-page resumes', family: 'helv', margin: 36, nameSize: 18, center: false, upperHead: true, rule: true, headColor: 'ink', nameColor: 'ink', datesRight: true, gap: 0.78, small: 0.92 },
    minimal: { name: 'Minimal', best: 'Design, tech, startups', family: 'helv', margin: 56, nameSize: 24, center: false, upperHead: false, rule: false, headColor: 'ink', nameColor: 'ink', datesRight: false, gap: 1.25 }
  };
  var ACCENTS = { navy: ['Navy', [0.12, 0.23, 0.41]], teal: ['Teal', [0.06, 0.37, 0.36]], maroon: ['Maroon', [0.48, 0.12, 0.17]], black: ['Black', [0.08, 0.08, 0.1]] };
  var SIZES = { small: ['Small', 9.5], normal: ['Normal', 10.5], large: ['Large', 11.5] };
  var PAPERS = { a4: ['A4', [595.28, 841.89]], letter: ['US Letter', [612, 792]] };
  var SECTIONS = {
    summary: { title: 'Summary', kind: 'text' },
    experience: { title: 'Experience', kind: 'list', item: { role: '', company: '', location: '', start: '', end: '', current: false, bullets: '' } },
    education: { title: 'Education', kind: 'list', item: { degree: '', school: '', location: '', start: '', end: '', details: '' } },
    skills: { title: 'Skills', kind: 'lines' },
    projects: { title: 'Projects', kind: 'list', item: { name: '', link: '', start: '', end: '', bullets: '' } },
    certifications: { title: 'Certifications', kind: 'lines' },
    achievements: { title: 'Achievements', kind: 'lines' },
    languages: { title: 'Languages', kind: 'line' }
  };
  var ORDER = ['summary', 'experience', 'education', 'skills', 'projects', 'certifications', 'achievements', 'languages'];
  function blank() {
    return {
      v: 1, template: 'modern', accent: 'navy', size: 'normal', page: 'a4',
      basics: { name: '', headline: '', email: '', phone: '', location: '', links: '' },
      summary: '', experience: [clone(SECTIONS.experience.item)], education: [clone(SECTIONS.education.item)], projects: [],
      skills: '', certifications: '', achievements: '', languages: '',
      order: ORDER.slice(), hidden: {}
    };
  }
  var EXAMPLE = {
    basics: { name: 'Aditi Rao', headline: 'Data Analyst', email: 'aditi.rao@example.com', phone: '+91 98765 43210', location: 'Pune, Maharashtra', links: 'linkedin.com/in/aditi-rao-example\ngithub.com/aditi-example' },
    summary: 'Data analyst with 3 years of experience turning sales and operations data into clear dashboards and decisions. Skilled in SQL, Python and Power BI, with a record of cutting reporting time and finding cost savings.',
    experience: [
      { role: 'Data Analyst', company: 'BrightCart Retail Pvt. Ltd.', location: 'Pune', start: 'Jul 2023', end: '', current: true, bullets: 'Built a Power BI sales dashboard used by 40+ store managers every week\nAutomated monthly reports with Python and SQL, cutting preparation time from 2 days to 3 hours\nFound Rs. 18 lakh in yearly savings by analysing supplier delivery data' },
      { role: 'Junior Analyst (Intern)', company: 'Northwind Logistics', location: 'Mumbai', start: 'Jan 2023', end: 'Jun 2023', current: false, bullets: 'Cleaned and merged 1.2 million shipment records in SQL\nCreated Excel models to forecast weekly warehouse demand' }
    ],
    education: [{ degree: 'B.Sc. Statistics', school: 'Example College of Science', location: 'Pune', start: '2019', end: '2022', details: 'CGPA 8.6 / 10' }],
    projects: [{ name: 'Customer churn prediction', link: 'github.com/aditi-example/churn', start: '2022', end: '', bullets: 'Built a logistic regression model with 81% accuracy on 7,000 customer records' }],
    skills: 'Analysis: SQL, Python (pandas), Excel, Statistics\nVisualisation: Power BI, Tableau\nTools: Git, Jira, Google Sheets',
    certifications: 'Microsoft Certified: Power BI Data Analyst Associate (PL-300), 2024\nGoogle Data Analytics Professional Certificate, 2023',
    achievements: '', languages: 'English, Hindi, Marathi'
  };

  /* ---------------- storage (this tab, or this device when "Remember" is on) ---------------- */
  var KEY = 'fileora.resume.v1';
  var store = {
    load: function () {
      var raw = null, remember = false;
      try { raw = localStorage.getItem(KEY); remember = !!raw; } catch (e) { /* storage off */ }
      if (!raw) { try { raw = sessionStorage.getItem(KEY); } catch (e) { /* storage off */ } }
      try { return { data: raw ? normalize(JSON.parse(raw)) : null, remember: remember }; } catch (e) { return { data: null, remember: remember }; }
    },
    save: function (data, remember) {
      var s = JSON.stringify(data);
      try { sessionStorage.setItem(KEY, s); } catch (e) { /* storage off */ }
      try { if (remember) localStorage.setItem(KEY, s); else localStorage.removeItem(KEY); } catch (e) { /* storage off */ }
    },
    clear: function () {
      try { sessionStorage.removeItem(KEY); } catch (e) { /* ignore */ }
      try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
    }
  };
  /* Accepts saved copies (and older shapes) without trusting their structure. */
  function normalize(d) {
    var b = blank();
    if (!d || typeof d !== 'object') return b;
    var str = function (v, max) { return typeof v === 'string' ? v.slice(0, max || 5000) : ''; };
    ['template', 'accent', 'size', 'page'].forEach(function (k) { var ok = { template: TEMPLATES, accent: ACCENTS, size: SIZES, page: PAPERS }[k]; if (ok[d[k]]) b[k] = d[k]; });
    if (d.basics && typeof d.basics === 'object') Object.keys(b.basics).forEach(function (k) { b.basics[k] = str(d.basics[k], 500); });
    ['summary', 'skills', 'certifications', 'achievements', 'languages'].forEach(function (k) { b[k] = str(d[k]); });
    ['experience', 'education', 'projects'].forEach(function (k) {
      if (!Array.isArray(d[k])) return;
      b[k] = d[k].slice(0, 20).map(function (it) {
        var o = clone(SECTIONS[k].item);
        Object.keys(o).forEach(function (f) { o[f] = typeof o[f] === 'boolean' ? !!(it && it[f]) : str(it && it[f], f === 'bullets' || f === 'details' ? 4000 : 300); });
        return o;
      });
    });
    if (Array.isArray(d.order)) {
      var seen = {};
      b.order = d.order.filter(function (k) { if (!SECTIONS[k] || seen[k]) return false; seen[k] = 1; return true; });
      ORDER.forEach(function (k) { if (!seen[k]) b.order.push(k); });
    }
    if (d.hidden && typeof d.hidden === 'object') Object.keys(SECTIONS).forEach(function (k) { if (d.hidden[k]) b.hidden[k] = true; });
    return b;
  }

  /* ---------------- text for ATS-safe PDF fonts ---------------- */
  var REPLACE = { '₹': 'Rs.', ' ': ' ', ' ': ' ', ' ': ' ', ' ': ' ', ' ': ' ', '‐': '-', '‑': '-', '−': '-', '→': '->', '​': '', '﻿': '', '\t': ' ' };
  function makeClean(font, dropped) {
    var cache = {};
    return function (s) {
      s = String(s == null ? '' : s).normalize('NFKC');
      var out = '';
      for (var i = 0; i < s.length; i++) {
        var ch = s[i];
        var cp = s.codePointAt(i);
        if (cp > 0xffff) { ch = String.fromCodePoint(cp); i++; }
        if (REPLACE[ch] !== undefined) { out += REPLACE[ch]; continue; }
        if (!(ch in cache)) { try { font.encodeText(ch); cache[ch] = true; } catch (e) { cache[ch] = false; } }
        if (cache[ch]) out += ch; else dropped[ch] = true;
      }
      return out.replace(/ {2,}/g, ' ');
    };
  }
  var dateRange = function (a, b, current) { a = (a || '').trim(); b = current ? 'Present' : (b || '').trim(); return a && b ? a + ' – ' + b : a || b; };
  var hrefOf = function (s) { s = s.trim(); if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(s)) return 'mailto:' + s; if (/^https?:\/\//i.test(s)) return s; if (/^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(s)) return 'https://' + s; return ''; };
  var hasContent = function (d, k) {
    var s = SECTIONS[k];
    if (s.kind === 'list') return d[k].some(function (it) { return Object.keys(it).some(function (f) { return typeof it[f] === 'string' && it[f].trim(); }); });
    return !!String(d[k] || '').trim();
  };

  /* ---------------- the PDF typesetter ---------------- */
  async function buildPdf(d) {
    var L = window.PDFLib, rgb = L.rgb;
    var t = TEMPLATES[d.template] || TEMPLATES.modern;
    var doc = await L.PDFDocument.create();
    var F = t.family === 'times'
      ? { r: await doc.embedFont(L.StandardFonts.TimesRoman), b: await doc.embedFont(L.StandardFonts.TimesRomanBold), i: await doc.embedFont(L.StandardFonts.TimesRomanItalic) }
      : { r: await doc.embedFont(L.StandardFonts.Helvetica), b: await doc.embedFont(L.StandardFonts.HelveticaBold), i: await doc.embedFont(L.StandardFonts.HelveticaOblique) };
    var dropped = {}, clean = makeClean(F.r, dropped);
    var size = PAPERS[d.page] ? PAPERS[d.page][1] : PAPERS.a4[1];
    var base = (SIZES[d.size] || SIZES.normal)[1] * (t.small || 1);
    var ac = (ACCENTS[d.accent] || ACCENTS.navy)[1];
    var INK = rgb(0.09, 0.09, 0.12), GREY = rgb(0.33, 0.35, 0.42), ACC = rgb(ac[0], ac[1], ac[2]), RULE = rgb(0.8, 0.81, 0.86);
    var M = t.margin, W = size[0] - 2 * M, lh = function (s) { return s * 1.28; };
    var page, y, pages = [];
    var newPage = function () { page = doc.addPage(size); pages.push(page); y = size[1] - M; };
    var ensure = function (h) { if (y - h < M) newPage(); };
    var width = function (s, f, sz) { return f.widthOfTextAtSize(s, sz); };
    function link(x, yy, w, h, s) {
      var uri = hrefOf(s); if (!uri) return;
      var a = doc.context.obj({ Type: 'Annot', Subtype: 'Link', Rect: [x, yy - 2, x + w, yy + h], Border: [0, 0, 0], A: { Type: 'Action', S: 'URI', URI: L.PDFString.of(uri) } });
      page.node.addAnnot(doc.context.register(a));
    }
    /* words → lines that fit maxW; very long words are broken */
    function wrap(s, f, sz, maxW) {
      var out = [], cur = '';
      s.split(/\s+/).filter(Boolean).forEach(function (w) {
        while (width(w, f, sz) > maxW) {
          var k = w.length; while (k > 1 && width(w.slice(0, k), f, sz) > maxW) k--;
          if (cur) { out.push(cur); cur = ''; }
          out.push(w.slice(0, k)); w = w.slice(k);
        }
        var test = cur ? cur + ' ' + w : w;
        if (width(test, f, sz) <= maxW) cur = test; else { out.push(cur); cur = w; }
      });
      if (cur) out.push(cur);
      return out;
    }
    function para(s, o) {
      o = o || {};
      var f = o.font || F.r, sz = o.size || base, x = M + (o.indent || 0), maxW = W - (o.indent || 0);
      wrap(clean(s), f, sz, maxW).forEach(function (ln) {
        ensure(lh(sz));
        y -= sz;
        var xx = o.center ? M + (W - width(ln, f, sz)) / 2 : x;
        page.drawText(ln, { x: xx, y: y, size: sz, font: f, color: o.color || INK });
        y -= lh(sz) - sz;
      });
    }
    function bullets(list, sz) {
      var ind = sz * 1.15;
      list.forEach(function (b) {
        var ls = wrap(clean(b), F.r, sz, W - ind);
        ls.forEach(function (ln, i) {
          ensure(lh(sz));
          y -= sz;
          if (i === 0) page.drawText('•', { x: M + sz * 0.15, y: y, size: sz, font: F.r, color: INK });
          page.drawText(ln, { x: M + ind, y: y, size: sz, font: F.r, color: INK });
          y -= lh(sz) - sz;
        });
      });
    }
    function heading(title) {
      var sz = base + (t.upperHead ? 0.5 : 2);
      var txt = t.upperHead ? title.toUpperCase() : title;
      ensure(sz * 4.2 + base * 2.6); /* keep the heading with what follows */
      y -= base * 1.15 * t.gap;
      y -= sz;
      page.drawText(txt, { x: M, y: y, size: sz, font: F.b, color: t.headColor === 'accent' ? ACC : INK });
      y -= sz * 0.42;
      if (t.rule) { page.drawLine({ start: { x: M, y: y }, end: { x: M + W, y: y }, thickness: 0.7, color: t.headColor === 'accent' ? ACC : RULE }); }
      y -= base * 0.55 * t.gap;
    }
    /* one entry: "Title  ……  dates" then "Organisation, place" */
    function entry(title, sub, dates) {
      title = clean(title); sub = clean(sub); dates = clean(dates);
      var sz = base + 0.5;
      ensure(lh(sz) + lh(base) * 2);
      if (t.datesRight && dates) {
        var dw = width(dates, F.r, base), tl = wrap(title || ' ', F.b, sz, W - dw - 14);
        tl.forEach(function (ln, i) {
          ensure(lh(sz)); y -= sz;
          page.drawText(ln, { x: M, y: y, size: sz, font: F.b, color: INK });
          if (i === 0) page.drawText(dates, { x: M + W - dw, y: y, size: base, font: F.r, color: GREY });
          y -= lh(sz) - sz;
        });
        if (sub) para(sub, { font: F.i, color: GREY });
      } else {
        if (title) para(title, { font: F.b, size: sz });
        var meta = [sub, dates].filter(Boolean).join('  |  ');
        if (meta) para(meta, { font: F.i, color: GREY });
      }
      y -= base * 0.25;
    }

    newPage();
    var b = d.basics;
    /* name, headline, contact line */
    var nm = clean(b.name || 'Your Name'), nsz = t.nameSize;
    while (width(nm, F.b, nsz) > W && nsz > 12) nsz -= 1;
    y -= nsz;
    page.drawText(nm, { x: t.center ? M + (W - width(nm, F.b, nsz)) / 2 : M, y: y, size: nsz, font: F.b, color: t.nameColor === 'accent' ? ACC : INK });
    y -= nsz * 0.38;
    if (b.headline.trim()) { para(b.headline, { font: t.family === 'times' ? F.i : F.r, size: base + 1.5, center: t.center, color: t.nameColor === 'accent' ? ACC : GREY }); }
    var bits = [b.email, b.phone, b.location].concat(lines(b.links)).map(function (s) { return clean(String(s || '').trim()); }).filter(Boolean);
    if (bits.length) {
      var sep = '  |  ', csz = base - 0.5, rows = [[]], rw = 0;
      bits.forEach(function (s) {
        var w = width(s, F.r, csz) + (rows[rows.length - 1].length ? width(sep, F.r, csz) : 0);
        if (rw + w > W && rows[rows.length - 1].length) { rows.push([]); rw = 0; w = width(s, F.r, csz); }
        rows[rows.length - 1].push(s); rw += w;
      });
      y -= csz * 0.35;
      rows.forEach(function (row) {
        var full = row.join(sep), x = t.center ? M + (W - width(full, F.r, csz)) / 2 : M;
        ensure(lh(csz)); y -= csz;
        row.forEach(function (s, i) {
          if (i) { page.drawText(sep, { x: x, y: y, size: csz, font: F.r, color: GREY }); x += width(sep, F.r, csz); }
          var w = width(s, F.r, csz);
          page.drawText(s, { x: x, y: y, size: csz, font: F.r, color: GREY });
          link(x, y, w, csz, s);
          x += w;
        });
        y -= lh(csz) - csz;
      });
    }
    y -= base * 0.2;

    d.order.forEach(function (k) {
      if (d.hidden[k] || !hasContent(d, k)) return;
      heading(SECTIONS[k].title);
      if (k === 'summary') para(d.summary);
      else if (k === 'experience') d.experience.forEach(function (it) {
        if (!(it.role + it.company + it.bullets).trim()) return;
        entry(it.role, [it.company, it.location].filter(function (s) { return s.trim(); }).join(', '), dateRange(it.start, it.end, it.current));
        bullets(lines(it.bullets), base);
        y -= base * 0.45 * t.gap;
      });
      else if (k === 'education') d.education.forEach(function (it) {
        if (!(it.degree + it.school).trim()) return;
        entry(it.degree, [it.school, it.location].filter(function (s) { return s.trim(); }).join(', '), dateRange(it.start, it.end, false));
        if (it.details.trim()) bullets(lines(it.details), base);
        y -= base * 0.45 * t.gap;
      });
      else if (k === 'projects') d.projects.forEach(function (it) {
        if (!(it.name + it.bullets).trim()) return;
        entry(it.name, it.link, dateRange(it.start, it.end, false));
        bullets(lines(it.bullets), base);
        y -= base * 0.45 * t.gap;
      });
      else if (k === 'skills') lines(d.skills).forEach(function (ln) {
        var m = /^([^:]{1,40}):\s*(.+)$/.exec(ln);
        if (!m) return para(ln);
        var lab = clean(m[1] + ': '), lw = width(lab, F.b, base);
        var rest = wrap(clean(m[2]), F.r, base, W - lw);
        rest.forEach(function (r, i) {
          ensure(lh(base)); y -= base;
          if (i === 0) page.drawText(lab, { x: M, y: y, size: base, font: F.b, color: INK });
          page.drawText(r, { x: M + lw, y: y, size: base, font: F.r, color: INK });
          y -= lh(base) - base;
        });
      });
      else if (k === 'languages') para(lines(d.languages).join(', '));
      else bullets(lines(d[k]), base);
    });

    var title = (b.name || 'Resume').trim();
    doc.setTitle(title + (b.headline.trim() ? ' – ' + b.headline.trim() : '') + ' – Resume');
    doc.setAuthor(title);
    doc.setSubject('Resume');
    doc.setKeywords(lines(d.skills).join(', ').split(/[,:]/).map(function (s) { return s.trim(); }).filter(Boolean).slice(0, 30));
    doc.setCreator('Fileora ATS Resume Builder');
    doc.setProducer('Fileora (pdf-lib)');
    return { bytes: await doc.save(), pages: pages.length, dropped: Object.keys(dropped) };
  }

  /* ---------------- plain text (for application forms) ---------------- */
  function plainText(d) {
    var b = d.basics, out = [];
    out.push(b.name || 'Your Name'); if (b.headline) out.push(b.headline);
    var c = [b.email, b.phone, b.location].concat(lines(b.links)).filter(function (s) { return String(s || '').trim(); });
    if (c.length) out.push(c.join(' | '));
    d.order.forEach(function (k) {
      if (d.hidden[k] || !hasContent(d, k)) return;
      out.push('', SECTIONS[k].title.toUpperCase());
      if (k === 'summary') out.push(d.summary.trim());
      else if (SECTIONS[k].kind === 'list') d[k].forEach(function (it) {
        var head = k === 'experience' ? [it.role, [it.company, it.location].filter(Boolean).join(', ')] : k === 'education' ? [it.degree, [it.school, it.location].filter(Boolean).join(', ')] : [it.name, it.link];
        var dates = dateRange(it.start, it.end, it.current);
        var h = head.filter(function (s) { return s && s.trim(); }).join(' – ');
        if (!h && !dates) return;
        out.push(h + (dates ? ' (' + dates + ')' : ''));
        lines(it.bullets || it.details).forEach(function (l) { out.push('- ' + l); });
      });
      else if (k === 'languages') out.push(lines(d.languages).join(', '));
      else lines(d[k]).forEach(function (l) { out.push(k === 'skills' ? l : '- ' + l); });
    });
    return out.join('\n').trim() + '\n';
  }

  /* ---------------- ATS check ---------------- */
  var STOP = ('a an the and or of to in on for with at by from as is are be been was were will would can could should must may this that these those it its our your you we they their them he she his her who whom which what when where why how all any each both few more most other some such no nor not only own same so than too very just also into over under about above after again against before below between during through up down out off further then once here there etc per via within across using use used able ability strong good excellent great well work working works job role roles position candidate candidates team teams company years year experience experiences experienced knowledge skills skill including include includes required requirements require preferred plus responsibilities responsible ensure new day days based looking seeking opportunity apply join help make like least minimum must-have nice-to-have understanding related relevant environment fast-paced proven track record degree bachelor bachelors master masters equivalent field communication hiring hire hires us want wants need needs get getting make making take every other others plus bonus desired desirable familiarity familiar exposure hands-on solid deep good-to-have').split(' ');
  var STOPSET = {}; STOP.forEach(function (w) { STOPSET[w] = 1; });
  function jdKeywords(text) {
    var words = (text.toLowerCase().match(/[a-z][a-z0-9+#.\-/]*[a-z0-9+#]|[a-z]/g) || []).map(function (w) { return w.replace(/[.\-/]+$/, ''); });
    var freq = {}, order = [];
    var add = function (k, n) { if (!freq[k]) { freq[k] = 0; order.push(k); } freq[k] += n || 1; };
    /* names written with capitals in the ad ("Power BI", "Google Analytics", "Data Analyst") count as one keyword */
    (text.match(/\b[A-Z][A-Za-z0-9+#.]*(?:\s+[A-Z][A-Za-z0-9+#.]*){1,2}\b/g) || []).forEach(function (ph) {
      var ws = ph.toLowerCase().split(/\s+/).filter(function (w) { return !STOPSET[w]; });
      if (ws.length >= 2) add(ws.join(' '), 2);
    });
    words.forEach(function (w, i) {
      if (w.length < 2 || STOPSET[w] || /^\d+$/.test(w)) return;
      add(w);
      var nx = words[i + 1];
      if (nx && !STOPSET[nx] && nx.length > 1 && !/^\d+$/.test(nx)) add(w + ' ' + nx, 0.75);
    });
    return order.filter(function (k) { return k.indexOf(' ') < 0 ? freq[k] >= 1 : freq[k] >= 1.5; })
      .sort(function (a, b) { return freq[b] - freq[a] || b.length - a.length; })
      .filter(function (k, i, arr) { return !arr.slice(0, i).some(function (p) { return p.indexOf(' ') > 0 && p.split(' ').indexOf(k) >= 0 && freq[p] >= freq[k] * 0.9; }); })
      .slice(0, 24);
  }
  var hasWord = function (hay, k) { return new RegExp('(^|[^a-z0-9+#])' + k.replace(/[.*+?^${}()|[\]\\/#]/g, '\\$&') + '($|[^a-z0-9+#])').test(hay); };
  function checks(d, text, pages, dropped) {
    var out = [], tl = text.toLowerCase();
    var push = function (ok, title, detail) { out.push({ ok: ok, title: title, detail: detail || '' }); };
    var allBul = [];
    d.experience.forEach(function (it) { if (!d.hidden.experience) allBul = allBul.concat(lines(it.bullets)); });
    d.projects.forEach(function (it) { if (!d.hidden.projects) allBul = allBul.concat(lines(it.bullets)); });
    push(text.replace(/\s/g, '').length > 80 ? 'ok' : 'bad', 'The text can be read', text.replace(/\s/g, '').length > 80 ? 'ATS software can select and read every word in this PDF.' : 'Add more content: there is very little text yet.');
    push(d.basics.name.trim() && tl.indexOf(d.basics.name.trim().toLowerCase().split(/\s+/)[0]) >= 0 ? 'ok' : 'bad', 'Your name is at the top', d.basics.name.trim() ? '' : 'Add your full name.');
    push(/[^@\s]+@[^@\s]+\.[a-z]{2,}/i.test(text) ? 'ok' : 'bad', 'Email address', /[^@\s]+@[^@\s]+\.[a-z]{2,}/i.test(text) ? '' : 'Add an email address recruiters can reach.');
    push((text.replace(/[^\d]/g, ' ').match(/\d+/g) || []).join('').length >= 10 && /(\+?\d[\d\s-]{8,}\d)/.test(text) ? 'ok' : 'warn', 'Phone number', /(\+?\d[\d\s-]{8,}\d)/.test(text) ? '' : 'Add a phone number with the country code, like +91 98765 43210.');
    var core = ['experience', 'education', 'skills'].filter(function (k) { return !d.hidden[k] && hasContent(d, k); });
    var missing = ['experience', 'education', 'skills'].filter(function (k) { return core.indexOf(k) < 0; }).map(function (k) { return SECTIONS[k].title; });
    var fresher = missing.length === 1 && missing[0] === 'Experience' && hasContent(d, 'projects') && !d.hidden.projects;
    push(!missing.length || fresher ? 'ok' : 'warn', 'Standard sections', !missing.length ? 'Experience, Education and Skills use headings every ATS recognises.' : fresher ? 'No work experience yet: your Projects section takes its place. That is fine for freshers.' : 'Add: ' + missing.join(', ') + '.');
    push(pages === 1 ? 'ok' : pages === 2 ? 'warn' : 'bad', 'Length: ' + pages + (pages === 1 ? ' page' : ' pages'), pages === 1 ? 'One page suits most freshers and early careers.' : pages === 2 ? 'Two pages are fine with long experience. Freshers: try the Compact template or a smaller text size.' : 'More than two pages is long for most jobs. Keep the last 10 years and the most relevant work.');
    var thin = d.hidden.experience ? [] : d.experience.filter(function (it) { return (it.role + it.company).trim() && lines(it.bullets).length < 2; }).map(function (it) { return it.role || it.company; });
    push(thin.length ? 'warn' : 'ok', 'Bullet points under each job', thin.length ? 'Add at least two achievements for: ' + thin.join(', ') + '.' : 'Each job lists its achievements as bullet points.');
    var withNum = allBul.filter(function (s) { return /\d/.test(s); }).length;
    push(!allBul.length ? 'warn' : withNum / allBul.length >= 0.3 ? 'ok' : 'warn', 'Results with numbers', !allBul.length ? 'Add bullet points with what you achieved.' : withNum + ' of ' + allBul.length + ' bullet points have a number. ' + (withNum / allBul.length >= 0.3 ? 'Good: numbers make results concrete.' : 'Add numbers where you can: %, time saved, people, money.'));
    var undated = [];
    ['experience', 'education'].forEach(function (k) { if (!d.hidden[k]) d[k].forEach(function (it) { if ((it.role || it.degree || '').trim() && !dateRange(it.start, it.end, it.current)) undated.push(it.role || it.degree); }); });
    push(undated.length ? 'warn' : 'ok', 'Dates', undated.length ? 'Add dates for: ' + undated.join(', ') + '.' : 'Every job and degree has dates.');
    var sw = d.summary.trim() ? d.summary.trim().split(/\s+/).length : 0;
    push(d.hidden.summary || (sw >= 15 && sw <= 90) ? 'ok' : 'warn', 'Summary', d.hidden.summary ? 'Hidden.' : !sw ? 'A 2–4 line summary helps recruiters and ATS searches.' : sw > 90 ? 'Keep it under about 90 words.' : sw < 15 ? 'A little short: aim for 2–4 lines.' : sw + ' words.');
    push(dropped.length ? 'warn' : 'ok', 'Characters', dropped.length ? 'These characters can\'t be used in ATS-safe PDF fonts and were left out: ' + dropped.slice(0, 12).join(' ') + '. Write them in English letters.' : 'All characters work in the PDF fonts.');
    return out;
  }

  /* ---------------- the builder UI ---------------- */
  function Builder(root) {
    var uid = root.id || 'fo-resume';
    var saved = store.load();
    var d = saved.data || blank(), remember = saved.remember;
    var open = { basics: true, summary: true, experience: true, education: true, skills: true };
    var state = { seq: 0, last: null, pdfText: '', tab: 'preview', jd: '' };

    root.innerHTML =
      '<div class="fo-rs">' +
        '<section class="fo-rs-pick" aria-labelledby="' + uid + '-pick-h"><div class="fo-rs-pick-head"><h2 id="' + uid + '-pick-h">1. Choose a template</h2><p>All four are single-column and text-based, so ATS software reads them top to bottom. Switch at any time – your details stay.</p></div>' +
          '<div class="fo-rs-cards" role="radiogroup" aria-labelledby="' + uid + '-pick-h">' +
            Object.keys(TEMPLATES).map(function (k) {
              var t = TEMPLATES[k];
              return '<label class="fo-rs-card"><input type="radio" name="' + uid + '-tpl" value="' + k + '"' + (d.template === k ? ' checked' : '') + '>' +
                '<span class="fo-rs-thumb"><img src="' + esc(CFG.thumbs || '') + k + '.png?v=' + esc(CFG.v || '') + '" alt="" width="240" height="340" loading="lazy" onerror="this.remove()"></span>' +
                '<span class="fo-rs-card-t"><b>' + esc(t.name) + '</b><small>' + esc(t.best) + '</small></span></label>';
            }).join('') +
          '</div></section>' +
        '<div class="fo-rs-work">' +
          '<section class="fo-rs-form" aria-labelledby="' + uid + '-form-h"><div class="fo-rs-form-head"><h2 id="' + uid + '-form-h">2. Add your details</h2>' +
            '<div class="fo-rs-form-acts"><button type="button" class="fo-btn fo-btn-quiet fo-btn-sm" data-act="example">Fill with an example</button><button type="button" class="fo-btn fo-btn-quiet fo-btn-sm" data-act="clear">Clear all</button><a class="fo-btn fo-btn-line fo-btn-sm fo-rs-jump" href="#' + uid + '-panel">See the preview</a></div></div>' +
            '<p class="fo-rs-privacy">' + ic('info') + '<span>Your details stay in this browser and are never uploaded. <label class="fo-rs-remember"><input type="checkbox" data-act="remember"' + (remember ? ' checked' : '') + '> Remember on this device</label> (leave off on a shared computer).</span></p>' +
            '<div class="fo-rs-secs"></div>' +
          '</section>' +
          '<section class="fo-rs-panel" id="' + uid + '-panel" aria-labelledby="' + uid + '-panel-h"><h2 id="' + uid + '-panel-h" class="fo-rs-sr">3. Preview, check and download</h2>' +
            '<div class="fo-rs-style">' +
              '<div class="fo-rs-ctl"><span class="fo-opt-l" id="' + uid + '-acc-l">Colour</span><div class="fo-swatches" role="group" aria-labelledby="' + uid + '-acc-l">' + Object.keys(ACCENTS).map(function (k) { var c = ACCENTS[k][1]; return '<button type="button" data-accent="' + k + '" aria-pressed="' + (d.accent === k) + '" aria-label="' + ACCENTS[k][0] + '" title="' + ACCENTS[k][0] + '" style="background:rgb(' + c.map(function (v) { return Math.round(v * 255); }).join(',') + ')"></button>'; }).join('') + '</div></div>' +
              '<div class="fo-rs-ctl"><span class="fo-opt-l" id="' + uid + '-size-l">Text size</span><div class="fo-seg" role="group" aria-labelledby="' + uid + '-size-l">' + Object.keys(SIZES).map(function (k) { return '<button type="button" data-size="' + k + '" aria-pressed="' + (d.size === k) + '">' + SIZES[k][0] + '</button>'; }).join('') + '</div></div>' +
              '<div class="fo-rs-ctl"><span class="fo-opt-l" id="' + uid + '-page-l">Paper</span><div class="fo-seg" role="group" aria-labelledby="' + uid + '-page-l">' + Object.keys(PAPERS).map(function (k) { return '<button type="button" data-paper="' + k + '" aria-pressed="' + (d.page === k) + '">' + PAPERS[k][0] + '</button>'; }).join('') + '</div></div>' +
            '</div>' +
            '<div class="fo-rs-tabs" role="tablist" aria-label="Resume output">' +
              '<button type="button" role="tab" id="' + uid + '-t-prev" aria-controls="' + uid + '-p-prev" aria-selected="true" data-tab="preview">Preview</button>' +
              '<button type="button" role="tab" id="' + uid + '-t-ats" aria-controls="' + uid + '-p-ats" aria-selected="false" tabindex="-1" data-tab="ats">ATS check <span class="fo-rs-badge"></span></button>' +
            '</div>' +
            '<div class="fo-rs-tabp" role="tabpanel" id="' + uid + '-p-prev" aria-labelledby="' + uid + '-t-prev"><div class="fo-rs-pages" tabindex="0" aria-label="Resume preview, scrollable"><div class="fo-rs-wait"><span class="fo-pbar indet"><i></i></span>Preparing the preview…</div></div></div>' +
            '<div class="fo-rs-tabp" role="tabpanel" id="' + uid + '-p-ats" aria-labelledby="' + uid + '-t-ats" hidden>' +
              '<p class="fo-rs-ats-intro">No tool can promise a "100% ATS score" – every company uses a different system. These checks read the text of your actual PDF and look for what ATS software and recruiters need.</p>' +
              '<ul class="fo-rs-checks"></ul>' +
              '<div class="fo-rs-jd"><label class="fo-opt-l" for="' + uid + '-jd">Compare with a job description (optional)</label><textarea class="fo-ta" id="' + uid + '-jd" rows="5" placeholder="Paste the job ad here to see which of its words your resume already uses."></textarea><div class="fo-rs-jd-out" aria-live="polite"></div></div>' +
              '<details class="fo-rs-read"><summary>What ATS software reads from your PDF</summary><pre class="fo-rs-text" tabindex="0"></pre></details>' +
            '</div>' +
            '<div class="fo-rs-out">' +
              '<button type="button" class="fo-btn fo-btn-ink fo-btn-lg" data-act="pdf" disabled>' + ic('download') + 'Download PDF</button>' +
              '<button type="button" class="fo-btn fo-btn-line" data-act="copy">' + ic('copy') + 'Copy as plain text</button>' +
              '<button type="button" class="fo-btn fo-btn-quiet" data-act="save">Save a copy (.json)</button>' +
              '<button type="button" class="fo-btn fo-btn-quiet" data-act="open">Open a saved copy</button><input type="file" accept=".json,application/json" hidden data-open>' +
              '<p class="fo-rs-status" role="status" aria-live="polite"></p>' +
            '</div>' +
          '</section>' +
        '</div>' +
      '</div>';

    var secsEl = $('.fo-rs-secs', root), pagesEl = $('.fo-rs-pages', root), statusEl = $('.fo-rs-status', root), pdfBtn = $('[data-act="pdf"]', root);

    /* ----- form ----- */
    var fid = function (k) { return uid + '-' + k.replace(/\./g, '-'); };
    function field(label, k, v, o) {
      o = o || {};
      var id = fid(k), help = o.help ? '<small id="' + id + '-h">' + esc(o.help) + '</small>' : '';
      var ctl = o.ta
        ? '<textarea class="fo-ta" id="' + id + '" data-k="' + k + '" rows="' + (o.rows || 3) + '"' + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (o.help ? ' aria-describedby="' + id + '-h"' : '') + ' maxlength="4000">' + esc(v) + '</textarea>'
        : '<input class="fo-inp" id="' + id + '" data-k="' + k + '" type="' + (o.type || 'text') + '" value="' + esc(v) + '"' + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (o.ac ? ' autocomplete="' + o.ac + '"' : ' autocomplete="off"') + (o.help ? ' aria-describedby="' + id + '-h"' : '') + ' maxlength="300">';
      return '<div class="fo-rs-f' + (o.wide ? ' wide' : '') + '"><label class="fo-opt-l" for="' + id + '">' + esc(label) + '</label>' + ctl + help + '</div>';
    }
    function itemFields(k, it, i) {
      var p = k + '.' + i + '.';
      if (k === 'experience') return field('Job title', p + 'role', it.role, { ph: 'e.g. Sales Executive' }) + field('Company', p + 'company', it.company) + field('Location', p + 'location', it.location, { ph: 'City' }) +
        field('Start', p + 'start', it.start, { ph: 'Jun 2023' }) + (it.current ? '' : field('End', p + 'end', it.end, { ph: 'Mar 2025' })) +
        '<div class="fo-rs-f"><label class="fo-rs-check"><input type="checkbox" data-k="' + p + 'current"' + (it.current ? ' checked' : '') + '> I work here now</label></div>' +
        field('Achievements – one per line', p + 'bullets', it.bullets, { ta: true, rows: 4, wide: true, ph: 'Start with an action word and add a number:\nIncreased monthly sales by 18% in 6 months' });
      if (k === 'education') return field('Degree or course', p + 'degree', it.degree, { ph: 'e.g. B.Com, 12th (CBSE)' }) + field('College, university or school', p + 'school', it.school) + field('Location', p + 'location', it.location, { ph: 'City' }) +
        field('Start', p + 'start', it.start, { ph: '2019' }) + field('End', p + 'end', it.end, { ph: '2022' }) +
        field('Details (optional) – one per line', p + 'details', it.details, { ta: true, rows: 2, wide: true, ph: 'CGPA 8.2 / 10\nFinal-year project: …' });
      return field('Project name', p + 'name', it.name) + field('Link (optional)', p + 'link', it.link, { ph: 'github.com/you/project' }) + field('Start', p + 'start', it.start, { ph: '2024' }) + field('End', p + 'end', it.end, { ph: 'Present' }) +
        field('What you did – one per line', p + 'bullets', it.bullets, { ta: true, rows: 3, wide: true });
    }
    function secBody(k) {
      if (k === 'basics') {
        var b = d.basics;
        return '<div class="fo-rs-grid">' + field('Full name', 'basics.name', b.name, { ac: 'name' }) + field('Job title you want', 'basics.headline', b.headline, { ph: 'e.g. Data Analyst' }) +
          field('Email', 'basics.email', b.email, { type: 'email', ac: 'email' }) + field('Phone', 'basics.phone', b.phone, { type: 'tel', ac: 'tel', ph: '+91 98765 43210' }) +
          field('City, state', 'basics.location', b.location, { ac: 'address-level2' }) + field('Links – one per line (optional)', 'basics.links', b.links, { ta: true, rows: 2, ph: 'linkedin.com/in/your-name\ngithub.com/you' }) + '</div>';
      }
      var s = SECTIONS[k];
      if (s.kind === 'text') return field('2–4 lines about your experience and strengths', 'summary', d.summary, { ta: true, rows: 4, wide: true, help: 'Mention your role, years of experience and two or three key skills.' });
      if (s.kind === 'lines' || s.kind === 'line') {
        var meta = { skills: ['One group per line, or one skill per line', 'Languages: Python, SQL\nSoftware: Tally, MS Excel', 'Use the same words as the job ad where they are true for you.'], certifications: ['One per line', 'Google Data Analytics Certificate, 2024'], achievements: ['One per line', 'Won first prize at the state-level hackathon, 2024'], languages: ['Languages you speak', 'English, Hindi, Marathi'] }[k];
        return field(meta[0], k, d[k], { ta: s.kind === 'lines', rows: k === 'skills' ? 4 : 3, wide: true, ph: meta[1], help: meta[2] });
      }
      var list = d[k];
      return list.map(function (it, i) {
        var lab = SECTIONS[k].title.replace(/s$/, '') + ' ' + (i + 1);
        return '<fieldset class="fo-rs-item"><legend>' + esc(lab) + '</legend><div class="fo-rs-item-acts">' +
          '<button type="button" class="fo-rs-ib" data-act="item-up" data-sec="' + k + '" data-i="' + i + '"' + (i === 0 ? ' disabled' : '') + ' aria-label="Move ' + esc(lab) + ' up">' + ic('up') + '</button>' +
          '<button type="button" class="fo-rs-ib" data-act="item-down" data-sec="' + k + '" data-i="' + i + '"' + (i === list.length - 1 ? ' disabled' : '') + ' aria-label="Move ' + esc(lab) + ' down">' + ic('down') + '</button>' +
          '<button type="button" class="fo-rs-ib" data-act="item-rm" data-sec="' + k + '" data-i="' + i + '" aria-label="Remove ' + esc(lab) + '">' + ic('trash') + '</button></div>' +
          '<div class="fo-rs-grid">' + itemFields(k, it, i) + '</div></fieldset>';
      }).join('') + '<button type="button" class="fo-btn fo-btn-line fo-btn-sm" data-act="item-add" data-sec="' + k + '">' + ic('plus') + 'Add ' + esc(SECTIONS[k].title.replace(/s$/, '').toLowerCase()) + '</button>';
    }
    function renderForm(focusKey) {
      var keys = ['basics'].concat(d.order);
      secsEl.innerHTML = keys.map(function (k, idx) {
        var title = k === 'basics' ? 'Personal details' : SECTIONS[k].title, isOpen = !!open[k], bid = uid + '-sec-' + k;
        var tools = k === 'basics' ? '' :
          '<label class="fo-rs-show"><input type="checkbox" data-act="show" data-sec="' + k + '"' + (d.hidden[k] ? '' : ' checked') + '> Include</label>' +
          '<button type="button" class="fo-rs-ib" data-act="sec-up" data-sec="' + k + '"' + (idx <= 1 ? ' disabled' : '') + ' aria-label="Move ' + title + ' section up">' + ic('up') + '</button>' +
          '<button type="button" class="fo-rs-ib" data-act="sec-down" data-sec="' + k + '"' + (idx === keys.length - 1 ? ' disabled' : '') + ' aria-label="Move ' + title + ' section down">' + ic('down') + '</button>';
        return '<div class="fo-rs-sec' + (k !== 'basics' && d.hidden[k] ? ' is-off' : '') + '" data-sec="' + k + '"><div class="fo-rs-sec-h">' +
          '<button type="button" class="fo-rs-sec-t" aria-expanded="' + isOpen + '" aria-controls="' + bid + '" data-act="toggle" data-sec="' + k + '">' + ic('chev') + '<span>' + esc(title) + '</span></button>' + tools + '</div>' +
          '<div class="fo-rs-sec-b" id="' + bid + '"' + (isOpen ? '' : ' hidden') + '>' + secBody(k) + '</div></div>';
      }).join('');
      if (focusKey) {
        var el = null;
        try { el = root.querySelector(focusKey.charAt(0) === '[' ? focusKey : '[data-k="' + focusKey + '"]'); } catch (e) { el = null; }
        if (el && !el.disabled) el.focus();
        else if (el) { var alt = el.parentNode && el.parentNode.querySelector('button:not([disabled])'); if (alt) alt.focus(); }
      }
    }

    /* ----- state changes ----- */
    var saveT = 0, renderT = 0;
    function changed(now) {
      clearTimeout(saveT); saveT = setTimeout(function () { store.save(d, remember); }, 300);
      clearTimeout(renderT); renderT = setTimeout(render, now ? 0 : 450);
      pdfBtn.disabled = true;
    }
    function setPath(k, v) {
      var parts = k.split('.'), o = d;
      for (var i = 0; i < parts.length - 1; i++) o = o[/^\d+$/.test(parts[i]) ? +parts[i] : parts[i]];
      var last = parts[parts.length - 1];
      o[/^\d+$/.test(last) ? +last : last] = v;
    }
    function say(msg) { statusEl.textContent = ''; setTimeout(function () { statusEl.textContent = msg; }, 30); }
    function pressed(attr, val) { $$('[' + attr + ']', root).forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute(attr) === val)); }); }

    root.addEventListener('input', function (e) {
      var k = e.target.getAttribute('data-k');
      if (k) { setPath(k, e.target.type === 'checkbox' ? e.target.checked : e.target.value); if (e.target.type === 'checkbox') renderForm('[data-k="' + k + '"]'); changed(); return; }
      if (e.target.id === uid + '-jd') { state.jd = e.target.value; clearTimeout(state.jdT); state.jdT = setTimeout(renderJd, 250); }
    });
    root.addEventListener('change', function (e) {
      if (e.target.name === uid + '-tpl') { d.template = e.target.value; changed(true); say(TEMPLATES[d.template].name + ' template selected'); return; }
      var act = e.target.getAttribute('data-act');
      if (act === 'remember') { remember = e.target.checked; store.save(d, remember); say(remember ? 'Your resume will be remembered on this device.' : 'Your resume will be forgotten when you close this tab.'); }
      if (act === 'show') { var k = e.target.getAttribute('data-sec'); if (e.target.checked) delete d.hidden[k]; else d.hidden[k] = true; e.target.closest('.fo-rs-sec').classList.toggle('is-off', !e.target.checked); changed(true); }
      if (e.target.hasAttribute('data-open') && e.target.files[0]) {
        var f = e.target.files[0];
        if (f.size > 500000) return say('That file is too large to be a saved resume.');
        f.text().then(function (txt) { d = normalize(JSON.parse(txt)); syncControls(); renderForm(); changed(true); say('Opened ' + f.name); }).catch(function () { say('That file couldn’t be opened. Choose a .json file saved from this builder.'); });
        e.target.value = '';
      }
    });
    var clearArmed = 0;
    root.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b || !root.contains(b)) return;
      var act = b.getAttribute('data-act'), k = b.getAttribute('data-sec'), i = +b.getAttribute('data-i');
      if (b.hasAttribute('data-accent')) { d.accent = b.getAttribute('data-accent'); pressed('data-accent', d.accent); return changed(true); }
      if (b.hasAttribute('data-size')) { d.size = b.getAttribute('data-size'); pressed('data-size', d.size); return changed(true); }
      if (b.hasAttribute('data-paper')) { d.page = b.getAttribute('data-paper'); pressed('data-paper', d.page); return changed(true); }
      if (b.hasAttribute('data-tab')) return showTab(b.getAttribute('data-tab'), true);
      if (!act) return;
      if (act === 'toggle') { open[k] = !open[k]; b.setAttribute('aria-expanded', String(open[k])); $('#' + uid + '-sec-' + k, root).hidden = !open[k]; return; }
      if (act === 'sec-up' || act === 'sec-down') {
        var o = d.order, p = o.indexOf(k), q = p + (act === 'sec-up' ? -1 : 1);
        if (q < 0 || q >= o.length) return;
        o.splice(q, 0, o.splice(p, 1)[0]); renderForm('[data-act="' + act + '"][data-sec="' + k + '"]'); changed(true);
        return say(SECTIONS[k].title + ' moved ' + (act === 'sec-up' ? 'up' : 'down'));
      }
      if (act === 'item-add') { d[k].push(clone(SECTIONS[k].item)); open[k] = true; renderForm(k + '.' + (d[k].length - 1) + '.' + Object.keys(SECTIONS[k].item)[0]); return changed(); }
      if (act === 'item-rm') { d[k].splice(i, 1); renderForm('[data-act="item-add"][data-sec="' + k + '"]'); changed(true); return say('Removed'); }
      if (act === 'item-up' || act === 'item-down') {
        var j = i + (act === 'item-up' ? -1 : 1); if (j < 0 || j >= d[k].length) return;
        d[k].splice(j, 0, d[k].splice(i, 1)[0]); renderForm('[data-act="' + act + '"][data-sec="' + k + '"][data-i="' + j + '"]'); changed(true); return;
      }
      if (act === 'example') {
        var keep = { template: d.template, accent: d.accent, size: d.size, page: d.page };
        d = normalize(Object.assign(clone(EXAMPLE), keep)); open = { basics: true, summary: true, experience: true, education: true, skills: true, projects: true, certifications: true, languages: true };
        renderForm(); changed(true); return say('Example filled in. Replace it with your own details.');
      }
      if (act === 'clear') {
        if (Date.now() - clearArmed > 4000) { clearArmed = Date.now(); b.textContent = 'Click again to clear everything'; setTimeout(function () { b.textContent = 'Clear all'; }, 4000); return; }
        clearArmed = 0; b.textContent = 'Clear all';
        var t0 = d.template; d = blank(); d.template = t0; store.clear(); if (remember) store.save(d, true);
        renderForm(); changed(true); return say('Cleared. Your details were removed from this browser.');
      }
      if (act === 'pdf') return download();
      if (act === 'copy') {
        var txt = plainText(d);
        if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { say('Copied as plain text – paste it into application forms.'); }, function () { say('Copy isn’t allowed here. Use the ATS check tab to select the text.'); });
        else say('Copy isn’t available in this browser.');
        return;
      }
      if (act === 'save') { saveFile(new Blob([JSON.stringify(d, null, 1)], { type: 'application/json' }), fileBase() + '-resume.json'); return say('Saved a copy. Open it here later to keep editing.'); }
      if (act === 'open') { $('[data-open]', root).click(); }
    });
    /* tabs: arrow keys move between them */
    $('.fo-rs-tabs', root).addEventListener('keydown', function (e) {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      e.preventDefault(); showTab(state.tab === 'preview' ? 'ats' : 'preview', true, true);
    });
    function showTab(name, user, focus) {
      state.tab = name;
      $$('[data-tab]', root).forEach(function (t) { var on = t.getAttribute('data-tab') === name; t.setAttribute('aria-selected', String(on)); t.tabIndex = on ? 0 : -1; if (on && focus) t.focus(); });
      $('#' + uid + '-p-prev', root).hidden = name !== 'preview';
      $('#' + uid + '-p-ats', root).hidden = name !== 'ats';
      if (name === 'ats') renderChecks();
      if (name === 'preview' && state.last) render(); /* the panel was hidden, so its width may have changed */
    }
    function syncControls() {
      pressed('data-accent', d.accent); pressed('data-size', d.size); pressed('data-paper', d.page);
      var r = root.querySelector('input[name="' + uid + '-tpl"][value="' + d.template + '"]'); if (r) r.checked = true;
    }
    var fileBase = function () { return (d.basics.name || 'my').toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '-').slice(0, 40) || 'my'; };
    function saveFile(blob, name) {
      var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
    }

    /* ----- PDF, preview and checks ----- */
    async function render() {
      var seq = ++state.seq;
      try {
        var lib = await loadLibs();
        var out = await buildPdf(d);
        if (seq !== state.seq) return;
        var pdf = await lib.pdfjs.getDocument({ data: out.bytes.slice(0) }).promise;
        var text = [], canvases = [];
        var cw = Math.max(240, pagesEl.clientWidth - 2), dpr = Math.min(2, window.devicePixelRatio || 1);
        for (var n = 1; n <= pdf.numPages; n++) {
          var pg = await pdf.getPage(n);
          var vp0 = pg.getViewport({ scale: 1 }), vp = pg.getViewport({ scale: cw / vp0.width * dpr });
          var c = document.createElement('canvas'); c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
          c.style.width = cw + 'px'; c.setAttribute('role', 'img'); c.setAttribute('aria-label', 'Page ' + n + ' of ' + pdf.numPages + ' of your resume');
          await pg.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
          var tc = await pg.getTextContent();
          text.push(tc.items.map(function (it) { return it.str + (it.hasEOL ? '\n' : ''); }).join(''));
          canvases.push(c);
          if (seq !== state.seq) { pdf.destroy(); return; }
        }
        pdf.destroy();
        pagesEl.innerHTML = '';
        canvases.forEach(function (c, i) { var w = document.createElement('div'); w.className = 'fo-rs-page'; w.appendChild(c); var s = document.createElement('span'); s.className = 'fo-rs-pno'; s.textContent = (i + 1) + ' / ' + canvases.length; w.appendChild(s); pagesEl.appendChild(w); });
        state.last = out; state.pdfText = text.join('\n').replace(/[ \t]+\n/g, '\n').trim();
        pdfBtn.disabled = false;
        var res = checks(d, state.pdfText, out.pages, out.dropped), passed = res.filter(function (r) { return r.ok === 'ok'; }).length;
        $('.fo-rs-badge', root).textContent = passed + '/' + res.length;
        if (state.tab === 'ats') renderChecks();
      } catch (err) {
        if (seq !== state.seq) return;
        console.error(err);
        pagesEl.innerHTML = '<div class="fo-note fo-note-err">' + ic('alert') + '<span>The preview couldn’t be made. Check your connection and reload the page.</span></div>';
      }
    }
    function renderChecks() {
      if (!state.last) return;
      var res = checks(d, state.pdfText, state.last.pages, state.last.dropped);
      $('.fo-rs-checks', root).innerHTML = res.map(function (r) {
        return '<li class="' + r.ok + '"><span class="fo-rs-ci">' + ic(r.ok === 'ok' ? 'check' : 'alert') + '</span><div><b>' + esc(r.title) + '</b><span class="fo-rs-sr"> – ' + (r.ok === 'ok' ? 'passed' : r.ok === 'warn' ? 'could be better' : 'needs attention') + '</span>' + (r.detail ? '<p>' + esc(r.detail) + '</p>' : '') + '</div></li>';
      }).join('');
      $('.fo-rs-text', root).textContent = state.pdfText;
      renderJd();
    }
    function renderJd() {
      var box = $('.fo-rs-jd-out', root);
      if (!state.jd.trim()) { box.innerHTML = ''; return; }
      var keys = jdKeywords(state.jd), hay = state.pdfText.toLowerCase();
      if (!keys.length) { box.innerHTML = '<p>Paste a longer job description.</p>'; return; }
      var found = keys.filter(function (k) { return hasWord(hay, k); }), miss = keys.filter(function (k) { return found.indexOf(k) < 0; });
      box.innerHTML = '<p><b>' + found.length + ' of ' + keys.length + '</b> key words from the job ad are in your resume.</p>' +
        (found.length ? '<p class="fo-rs-kw-h">In your resume</p><ul class="fo-rs-kws ok">' + found.map(function (k) { return '<li>' + esc(k) + '</li>'; }).join('') + '</ul>' : '') +
        (miss.length ? '<p class="fo-rs-kw-h">Not in your resume yet</p><ul class="fo-rs-kws">' + miss.map(function (k) { return '<li>' + esc(k) + '</li>'; }).join('') + '</ul><p class="fo-rs-kw-note">Add a missing word only where it is true for you – in a bullet point, your skills or the summary.</p>' : '');
    }
    async function download() {
      if (!state.last) await render();
      if (!state.last) return;
      saveFile(new Blob([state.last.bytes], { type: 'application/pdf' }), fileBase() + '-resume.pdf');
      say('Your resume PDF is downloading.');
    }
    var rz = 0;
    window.addEventListener('resize', function () { clearTimeout(rz); rz = setTimeout(function () { if (state.last) render(); }, 250); });

    renderForm();
    render();
  }

  Array.prototype.forEach.call(roots, function (r) { try { Builder(r); } catch (e) { console.error(e); r.innerHTML = '<p class="fo-note">The resume builder couldn’t start. Please reload the page.</p>'; } });
})();
