/* ---------------- server tools (job API through WordPress) ---------------- */
const apiUrl = path => CFG.rest.replace(/\/$/, '') + path;
const apiHeaders = extra => Object.assign(CFG.nonce ? { 'X-WP-Nonce': CFG.nonce } : {}, extra || {});
function uploadForm(url, fd, onProgress) {
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest();
    x.open('POST', url);
    Object.entries(apiHeaders()).forEach(([k, v]) => x.setRequestHeader(k, v));
    x.upload.onprogress = e => { if (e.lengthComputable) onProgress(e.loaded / e.total); };
    x.onload = () => { let body = {}; try { body = JSON.parse(x.responseText); } catch (e) { /* not JSON */ } resolve({ status: x.status, body }); };
    x.onerror = () => reject(new UserError('We couldn’t reach the server. Check your connection and try again.'));
    x.send(fd);
  });
}
async function serverRun(t, items, o, ctx) {
  if (!CFG.rest || !CFG.backend) throw new NoServer();
  const fd = new FormData();
  items.forEach(it => fd.append('files[]', it.file, it.name));
  const rest = {};
  Object.entries(o).forEach(([k, v]) => { if ((!v || typeof v !== 'object') && !(t.localOpts && t.localOpts.includes(k))) rest[k] = v; });
  if (o.url) fd.append('url', /^https?:\/\//i.test(o.url) ? o.url : 'https://' + o.url);
  fd.append('options', JSON.stringify(rest));
  try { if (window.FileoraTrack && FileoraTrack.sid()) fd.append('fo_sid', FileoraTrack.sid()); } catch (e) { /* analytics off */ }
  const up = await uploadForm(apiUrl('/jobs/' + t.id), fd, f => ctx.progress(f * .3, items.length ? `Uploading ${Math.round(f * 100)}%` : 'Sending'));
  if (up.status === 503 && /connected/i.test(up.body.error || '')) throw new NoServer();
  if (up.status !== 202) throw new UserError(up.body.error || up.body.message || `The server couldn’t accept this request (error ${up.status}).`);
  const { job, token } = up.body;
  const headers = apiHeaders({ 'X-Fileora-Token': token || '' });
  const started = Date.now();
  let st = {}, wait = 800, misses = 0;
  for (;;) {
    await sleep(wait);
    wait = Math.min(3000, wait + 300);
    if (ctx.alive && !ctx.alive()) throw new Error('cancelled');
    let r;
    try { r = await fetch(apiUrl('/jobs/' + job + '?t=' + Date.now()), { headers, cache: 'no-store' }); }
    catch (e) { if (++misses > 20) throw new UserError('We lost the connection to the server. Please run the task again.'); continue; } /* brief network hiccup: keep polling */
    st = await r.json().catch(() => ({}));
    if (r.status === 502 && ++misses <= 20) continue;
    if (!r.ok) throw new UserError(st.error || 'We lost track of this task. Please run it again.');
    misses = 0;
    if (st.status === 'done') break;
    if (st.status === 'failed') throw new UserError(st.error || 'The server couldn’t process this file.');
    ctx.progress(.32 + Math.min(.55, (Date.now() - started) / 90000), st.status === 'queued' ? (st.ahead ? `Waiting in line, ${st.ahead} ahead of you` : 'Waiting in line') : `${t.verb} on the server`);
    if (Date.now() - started > 30 * 60000) throw new UserError('This is taking too long. Try a smaller file.');
  }
  if (st.kind === 'text') {
    ctx.result = { md: st.text, title: t.textTitle || 'Your text is ready' };
    return [{ name: st.name || 'fileora.txt', blob: new Blob([st.text], { type: 'text/plain' }) }];
  }
  ctx.progress(.92, 'Downloading the result');
  const r = await fetch(apiUrl('/jobs/' + job + '/file'), { headers, cache: 'no-store' });
  if (!r.ok) { const b = await r.json().catch(() => ({})); throw new UserError(b.error || 'The result couldn’t be downloaded. Please run the task again.'); }
  return [{ name: st.name, blob: await r.blob() }];
}
