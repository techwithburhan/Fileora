/* ---------------- public API and start-up ---------------- */
const API = {
  version: '2.0.0',
  /* Modules call this once per tool. */
  register(def) { if (def && def.id) { DEFS[def.id] = def; if (booted) boot(); } },
  defs: DEFS,
  config: CFG,
  goToTool,
  handoff: Handoff,
  instances: [],
  /* helpers for module scripts */
  h: {
    $, $$, esc, icon, fmtSize, baseName, extOf, clamp, sleep, toast, UserError,
    lib, libUrl, pdfjsDoc, renderPage, canvasToBlob, pdfOut, loadPdf, savePdf, vis, visRect, parseRanges, rangeLabel, PAGE, MM,
    decodeImage, canvasOf, imageCanvas, filterPixels, imageForPdf, embedCanvas, imagesToPdf, rasterize, textPng, textWidth,
    pdfLines, toMarkdown, diffLines, Img, IMG_EXT, sameType, renameImg, cropRect, imageNote, eachImage, encodeToSize, padJpeg,
    cropCanvas, LANGS, pageSizeOpt, orientOpt, marginOpt, kindOf
  }
};
window.FileoraEngine = API;

let booted = false, extrasDone = false;
function boot() {
  booted = true;
  $$('.fo-app[data-fo-tool]').forEach(root => {
    if (root.dataset.foMounted || !DEFS[root.dataset.foTool]) return;
    root.dataset.foMounted = '1';
    const ws = mountTool(root);
    if (ws) API.instances.push(ws);
  });
  if (extrasDone || !API.instances.length) return;
  extrasDone = true;
  /* files handed over from another tool or the homepage */
  if (/[?&]fo_handoff=1/.test(location.search) && API.instances[0]) {
    Handoff.take().then(files => { if (files && files.length) API.instances[0].addFiles(files); }).catch(() => {});
    try { history.replaceState(null, '', location.pathname + location.search.replace(/[?&]fo_handoff=1/, '').replace(/^&/, '?') + location.hash); } catch (e) { /* ignore */ }
  }
  /* a file dropped anywhere on a tool page goes into the tool */
  if (API.instances.length === 1) {
    const ws = API.instances[0];
    addEventListener('dragover', e => { if (e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files')) e.preventDefault(); });
    addEventListener('drop', e => { if (!e.dataTransfer || !e.dataTransfer.files.length || ws.root.contains(e.target)) return; e.preventDefault(); ws.addFiles(e.dataTransfer.files); ws.root.scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth', block: 'start' }); });
  }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
/* a tool whose module never loaded (blocked by an extension or offline) */
addEventListener('load', () => setTimeout(() => {
  $$('.fo-app[data-fo-tool]:not([data-fo-mounted])').forEach(root => { root.innerHTML = '<div class="fo-state"><h2>This tool couldn’t load</h2><p>Please reload the page. If it keeps happening, an ad blocker or a slow connection may be stopping it.</p></div>'; });
}, 4000));
