/* ---------------- options panel ----------------
   Field types: seg, select, text, password, textarea, number, range, toggle,
   color, pos, margins, signature, image (pick a picture), note (static text).
   A field may have show(o) to appear conditionally and help (string or fn). */
let optUid = 0;
const POS_LABEL = { tl: 'Top left', tc: 'Top centre', tr: 'Top right', ml: 'Middle left', mc: 'Centre', mr: 'Middle right', bl: 'Bottom left', bc: 'Bottom centre', br: 'Bottom right' };
const LABELLED = ['text', 'password', 'textarea', 'select', 'number', 'range'];
function optHtml(f, v, uid) {
  const id = uid + '-' + f.id;
  const tag = LABELLED.includes(f.type) ? 'label' : 'span';
  const lab = f.label && f.type !== 'toggle' && f.type !== 'note' ? `<${tag}${tag === 'label' ? ` for="${id}"` : ''} class="fo-opt-l">${esc(f.label)}</${tag}>` : '';
  switch (f.type) {
    case 'seg': return lab + `<div class="fo-seg${f.choices.length > 3 ? ' wrapit' : ''}" role="group" aria-label="${esc(f.label)}">${f.choices.map(([val, l]) => `<button type="button" data-val="${esc(val)}" aria-pressed="${String(v) === String(val)}">${esc(l)}</button>`).join('')}</div>`;
    case 'select': return lab + `<select class="fo-sel" id="${id}">${f.choices.map(([val, l]) => `<option value="${esc(val)}"${String(v) === String(val) ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
    case 'text': case 'password': return lab + `<input class="fo-inp" id="${id}" type="${f.type}" value="${esc(v || '')}" placeholder="${esc(f.placeholder || '')}" autocomplete="${f.type === 'password' ? 'new-password' : 'off'}" spellcheck="false"${f.maxlength ? ` maxlength="${f.maxlength}"` : ''}>`;
    case 'textarea': return lab + `<textarea class="fo-ta" id="${id}" placeholder="${esc(f.placeholder || '')}">${esc(v || '')}</textarea>`;
    case 'number': return lab + `<div class="fo-num"><input class="fo-inp" id="${id}" type="number" inputmode="decimal" value="${esc(v)}" min="${f.min ?? ''}" max="${f.max ?? ''}" step="${f.step ?? 'any'}">${f.suffix ? `<span>${esc(f.suffix)}</span>` : ''}</div>`;
    case 'range': return lab + `<div class="fo-rng"><input id="${id}" type="range" min="${f.min}" max="${f.max}" step="${f.step || 1}" value="${esc(v)}"><output>${esc(v)}${esc(f.suffix || '')}</output></div>`;
    case 'toggle': return `<label class="fo-sw"><span>${esc(f.label)}</span><input type="checkbox"${v ? ' checked' : ''}></label>`;
    case 'color': return lab + `<div class="fo-swatches" role="group" aria-label="${esc(f.label)}">${f.choices.map(c => `<button type="button" data-val="${c}" style="background:${c}" aria-pressed="${c === v}" aria-label="Colour ${c}"></button>`).join('')}${f.custom ? `<label class="fo-swatch-custom" title="Pick any colour"><input type="color" value="${esc(f.choices.includes(v) ? '#888888' : v)}" aria-label="Pick any colour"></label>` : ''}</div>`;
    case 'pos': { const cells = f.cells || ['tl', 'tc', 'tr', 'ml', 'mc', 'mr', 'bl', 'bc', 'br']; return lab + `<div class="fo-posgrid" role="group" aria-label="${esc(f.label)}">${cells.map(c => `<button type="button" data-val="${c}" aria-pressed="${c === v}" aria-label="${POS_LABEL[c]}" title="${POS_LABEL[c]}"><i></i></button>`).join('')}</div>`; }
    case 'margins': return lab + `<div class="fo-margins">${['top', 'right', 'bottom', 'left'].map(s => `<label>${s[0].toUpperCase() + s.slice(1)}<input class="fo-inp" type="number" min="0" max="300" inputmode="decimal" data-side="${s}" value="${esc(v[s])}"></label>`).join('')}</div>`;
    case 'image': return lab + `<div class="fo-imgpick"><div class="fo-imgpick-prev">${v && v.url ? `<img src="${v.url}" alt="">` : icon('image')}</div><div><button type="button" class="fo-btn fo-btn-line fo-btn-sm" data-imgpick>${v ? 'Change picture' : 'Choose a picture'}</button><small>${v ? esc(v.name) : 'PNG or JPG. Transparent PNG works best for logos and stamps.'}</small></div><input type="file" accept="image/png,image/jpeg,image/webp" hidden></div>`;
    case 'note': return `<div class="fo-note">${icon('info')}<span>${f.html ? f.html : esc(f.text)}</span></div>`;
    case 'signature': return lab + `<div class="fo-seg fo-sig-tabs" role="group" aria-label="Signature type"><button type="button" data-sigmode="draw" aria-pressed="true">Draw</button><button type="button" data-sigmode="type" aria-pressed="false">Type</button><button type="button" data-sigmode="upload" aria-pressed="false">Upload</button></div>
      <div class="fo-sig-draw"><div class="fo-sig-pad"><canvas aria-label="Signature pad. Draw your signature with a mouse, finger or stylus."></canvas><div class="hintline"></div><span class="ph">Sign above the line</span></div></div>
      <div class="fo-sig-typewrap" hidden><input class="fo-inp fo-sig-type" type="text" placeholder="Type your name" aria-label="Type your name" maxlength="40"></div>
      <div class="fo-sig-upwrap" hidden><button type="button" class="fo-btn fo-btn-line fo-btn-sm" data-sigup>Choose a picture of your signature</button><small>A photo or scan on white paper works. The white background is removed.</small><input type="file" accept="image/*" hidden></div>
      <div class="fo-sig-row"><div class="fo-swatches" role="group" aria-label="Ink colour"><button type="button" data-ink="#16182F" style="background:#16182F" aria-pressed="true" aria-label="Black ink"></button><button type="button" data-ink="#2337B8" style="background:#2337B8" aria-pressed="false" aria-label="Blue ink"></button></div><button type="button" class="fo-btn fo-btn-quiet fo-btn-sm" data-sigclear>Clear</button></div>`;
    default: return '';
  }
}
function renderOpts(box, fields, vals, onChange) {
  const uid = 'fo' + (++optUid);
  box.innerHTML = fields.map(f => `<div class="fo-opt" data-f="${f.id}">${optHtml(f, vals[f.id], uid)}${f.help ? '<p class="fo-opt-help"></p>' : ''}</div>`).join('');
  const refresh = () => fields.forEach(f => {
    const w = box.querySelector(`.fo-opt[data-f="${f.id}"]`); if (!w) return;
    if (f.show) w.hidden = !f.show(vals);
    const h = w.querySelector('.fo-opt-help'); if (h) h.textContent = typeof f.help === 'function' ? f.help(vals) : f.help;
  });
  fields.forEach(f => {
    const w = box.querySelector(`.fo-opt[data-f="${f.id}"]`); if (!w) return;
    const set = v => { vals[f.id] = v; refresh(); onChange && onChange(f.id, v); };
    switch (f.type) {
      case 'seg': case 'pos':
        w.addEventListener('click', e => { const b = e.target.closest('[data-val]'); if (!b) return; $$('[data-val]', w).forEach(x => x.setAttribute('aria-pressed', x === b)); set(b.dataset.val); }); break;
      case 'color':
        w.addEventListener('click', e => { const b = e.target.closest('[data-val]'); if (!b) return; $$('[data-val]', w).forEach(x => x.setAttribute('aria-pressed', x === b)); set(b.dataset.val); });
        w.addEventListener('input', e => { if (e.target.type === 'color') { $$('[data-val]', w).forEach(x => x.setAttribute('aria-pressed', 'false')); set(e.target.value); } }); break;
      case 'select': w.querySelector('select').addEventListener('change', e => set(e.target.value)); break;
      case 'text': case 'password': case 'textarea': w.querySelector('input,textarea').addEventListener('input', e => set(e.target.value)); break;
      case 'number': w.querySelector('input').addEventListener('input', e => { const n = parseFloat(e.target.value); if (!isNaN(n)) set(Math.min(f.max ?? Infinity, Math.max(f.min ?? -Infinity, n))); }); break;
      case 'range': { const inp = w.querySelector('input'), out = w.querySelector('output'); inp.addEventListener('input', () => { out.textContent = inp.value + (f.suffix || ''); set(+inp.value); }); break; }
      case 'toggle': w.querySelector('input').addEventListener('change', e => set(e.target.checked)); break;
      case 'margins': w.addEventListener('input', e => { const s = e.target.dataset.side; if (!s) return; set({ ...vals[f.id], [s]: Math.max(0, parseFloat(e.target.value) || 0) }); }); break;
      case 'image': initImagePick(w, f, vals, set); break;
      case 'signature': initSignature(w, set); break;
    }
  });
  refresh();
  return refresh;
}
function initImagePick(w, f, vals, set) {
  const inp = $('input[type=file]', w);
  w.addEventListener('click', e => { if (e.target.closest('[data-imgpick]')) { inp.value = ''; inp.click(); } });
  inp.addEventListener('change', async () => {
    const file = inp.files[0]; if (!file) return;
    if (kindOf(file) !== 'image') return toast('Choose a PNG, JPG or WebP picture.', 'error');
    try {
      const d = await decodeImage(file);
      const c = canvasOf(Math.min(d.w, 3000 * d.w / Math.max(d.w, d.h)), Math.min(d.h, 3000 * d.h / Math.max(d.w, d.h)));
      c.getContext('2d').drawImage(d.src, 0, 0, c.width, c.height); d.done();
      const png = await canvasToBlob(c, 'image/png');
      const prev = vals[f.id]; if (prev && prev.url) URL.revokeObjectURL(prev.url);
      const v = { name: file.name, bytes: await png.arrayBuffer(), w: c.width, h: c.height, url: URL.createObjectURL(png) };
      $('.fo-imgpick-prev', w).innerHTML = `<img src="${v.url}" alt="">`;
      $('[data-imgpick]', w).textContent = 'Change picture';
      $('small', w).textContent = file.name;
      set(v);
    } catch (e) { toast(e instanceof UserError ? e.message : 'That picture couldn’t be opened.', 'error'); }
  });
}
function initSignature(w, set) {
  const cv = $('canvas', w), pad = $('.fo-sig-pad', w), ph = $('.ph', w), typeIn = $('.fo-sig-type', w), upIn = $('.fo-sig-upwrap input', w);
  let mode = 'draw', ink = '#16182F', strokes = [], cur = null, dpr = 1, upload = null;
  const g = cv.getContext('2d');
  const size = () => { dpr = Math.min(2, devicePixelRatio || 1); const r = pad.getBoundingClientRect(); if (!r.width) return; cv.width = r.width * dpr; cv.height = r.height * dpr; redraw(); };
  const redraw = () => {
    g.clearRect(0, 0, cv.width, cv.height); g.lineCap = g.lineJoin = 'round'; g.strokeStyle = ink; g.lineWidth = 2.6 * dpr;
    for (const s of strokes) { g.beginPath(); s.forEach((p, i) => { if (!i) g.moveTo(p[0] * dpr, p[1] * dpr); else { const q = s[i - 1]; g.quadraticCurveTo(q[0] * dpr, q[1] * dpr, (p[0] + q[0]) / 2 * dpr, (p[1] + q[1]) / 2 * dpr); } }); if (s.length === 1) g.lineTo(s[0][0] * dpr + .1, s[0][1] * dpr); g.stroke(); }
    ph.hidden = strokes.length > 0;
  };
  const exportDraw = async () => {
    if (!strokes.length) return set(null);
    const pts = strokes.flat(), pd = 6;
    const x0 = Math.max(0, Math.min(...pts.map(p => p[0])) - pd), y0 = Math.max(0, Math.min(...pts.map(p => p[1])) - pd);
    const x1 = Math.max(...pts.map(p => p[0])) + pd, y1 = Math.max(...pts.map(p => p[1])) + pd;
    const sc = 3, c = canvasOf((x1 - x0) * sc, (y1 - y0) * sc);
    const k = c.getContext('2d'); k.lineCap = k.lineJoin = 'round'; k.strokeStyle = ink; k.lineWidth = 2.6 * sc;
    for (const s of strokes) { k.beginPath(); s.forEach((p, i) => { const X = (p[0] - x0) * sc, Y = (p[1] - y0) * sc; if (!i) k.moveTo(X, Y); else { const q = s[i - 1]; k.quadraticCurveTo((q[0] - x0) * sc, (q[1] - y0) * sc, ((p[0] + q[0]) / 2 - x0) * sc, ((p[1] + q[1]) / 2 - y0) * sc); } }); if (s.length === 1) k.lineTo((s[0][0] - x0) * sc + .1, (s[0][1] - y0) * sc); k.stroke(); }
    set({ bytes: await (await canvasToBlob(c, 'image/png')).arrayBuffer(), w: c.width, h: c.height });
  };
  const exportType = async () => {
    const t = typeIn.value.trim(); if (!t) return set(null);
    try { await document.fonts.load('600 110px Caveat'); } catch (e) { /* fallback */ }
    const c = document.createElement('canvas'), k = c.getContext('2d'), font = "600 110px Caveat, 'Segoe Script', 'Brush Script MT', cursive";
    k.font = font; const tw = k.measureText(t).width; c.width = Math.ceil(tw + 40); c.height = 150;
    k.font = font; k.fillStyle = ink; k.textBaseline = 'middle'; k.fillText(t, 20, 78);
    set({ bytes: await (await canvasToBlob(c, 'image/png')).arrayBuffer(), w: c.width, h: c.height });
  };
  /* a photo of a signature: make the paper transparent and trim it */
  const exportUpload = async () => {
    if (!upload) return set(null);
    const c = await imageCanvas(upload, 1600), k = c.getContext('2d', { willReadFrequently: true });
    const d = k.getImageData(0, 0, c.width, c.height), px = d.data;
    let x0 = c.width, y0 = c.height, x1 = 0, y1 = 0;
    for (let i = 0; i < px.length; i += 4) {
      const l = px[i] * .299 + px[i + 1] * .587 + px[i + 2] * .114;
      const a = l > 200 ? 0 : l < 120 ? 255 : Math.round((200 - l) / 80 * 255);
      px[i + 3] = a;
      if (a > 40) { const p = i / 4, x = p % c.width, y = (p / c.width) | 0; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    }
    if (x1 <= x0 || y1 <= y0) { toast('No signature found in that picture. Use dark ink on white paper.', 'error'); return set(null); }
    k.putImageData(d, 0, 0);
    const o = canvasOf(x1 - x0 + 12, y1 - y0 + 12); o.getContext('2d').drawImage(c, x0 - 6, y0 - 6, o.width, o.height, 0, 0, o.width, o.height);
    set({ bytes: await (await canvasToBlob(o, 'image/png')).arrayBuffer(), w: o.width, h: o.height });
  };
  const pos = e => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  cv.addEventListener('pointerdown', e => { e.preventDefault(); cv.setPointerCapture(e.pointerId); cur = [pos(e)]; strokes.push(cur); redraw(); });
  cv.addEventListener('pointermove', e => { if (!cur) return; const p = pos(e), q = cur[cur.length - 1]; if (Math.hypot(p[0] - q[0], p[1] - q[1]) > 1.2) { cur.push(p); redraw(); } });
  const end = () => { if (cur) { cur = null; exportDraw(); } };
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  typeIn.addEventListener('input', exportType);
  upIn.addEventListener('change', () => { upload = upIn.files[0] || null; $('.fo-sig-upwrap small', w).textContent = upload ? upload.name : ''; exportUpload(); });
  w.addEventListener('click', e => {
    const m = e.target.closest('[data-sigmode]');
    if (m) {
      mode = m.dataset.sigmode; $$('[data-sigmode]', w).forEach(b => b.setAttribute('aria-pressed', b === m));
      $('.fo-sig-draw', w).hidden = mode !== 'draw'; $('.fo-sig-typewrap', w).hidden = mode !== 'type'; $('.fo-sig-upwrap', w).hidden = mode !== 'upload';
      $('.fo-sig-row .fo-swatches', w).hidden = mode === 'upload';
      if (mode === 'draw') { size(); exportDraw(); } else if (mode === 'type') { typeIn.focus(); exportType(); } else exportUpload();
    }
    if (e.target.closest('[data-sigup]')) { upIn.value = ''; upIn.click(); }
    const i = e.target.closest('[data-ink]');
    if (i) { ink = i.dataset.ink; $$('[data-ink]', w).forEach(b => b.setAttribute('aria-pressed', b === i)); typeIn.style.color = ink; redraw(); mode === 'draw' ? exportDraw() : mode === 'type' ? exportType() : 0; }
    if (e.target.closest('[data-sigclear]')) { strokes = []; typeIn.value = ''; upload = null; redraw(); set(null); }
  });
  new ResizeObserver(size).observe(pad);
}
