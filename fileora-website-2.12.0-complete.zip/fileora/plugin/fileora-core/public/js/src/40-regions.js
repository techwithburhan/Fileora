/* ---------------- region editor ----------------
   Draggable, resizable boxes over a picture (ID card print, passport photo,
   blur). Coordinates are fractions (0..1) of the picture.
     regionEditor(host, { src, w, h, rects:[{id,label,x,y,w,h,ratio}], multi, onChange })
   ratio = width / height in picture pixels, locked while resizing.
   Keyboard: arrows move a box, Shift+arrows resize it, Delete removes it (multi). */
function regionEditor(host, cfg) {
  const st = { rects: cfg.rects.map(r => ({ ...r })), active: cfg.rects.length ? cfg.rects[0].id : null };
  const W = cfg.w, H = cfg.h, ar = W / H;
  host.innerHTML = `<div class="fo-reg" style="aspect-ratio:${W} / ${H}"><img src="${cfg.src}" alt="" draggable="false"><div class="fo-reg-layer"></div></div>
    <p class="fo-reg-help">${cfg.multi ? 'Drag on the picture to mark an area. Drag a box to move it, or its corner to resize it.' : 'Drag the boxes to move them, and their corners to resize them.'} With the keyboard: arrow keys move the selected box, Shift + arrows resize it${cfg.multi ? ', Delete removes it' : ''}.</p>`;
  const reg = $('.fo-reg', host), layer = $('.fo-reg-layer', host);
  const norm = r => {
    r.w = clamp(r.w, .02, 1); r.h = clamp(r.h, .02, 1);
    r.x = clamp(r.x, 0, 1 - r.w); r.y = clamp(r.y, 0, 1 - r.h);
    return r;
  };
  const fitRatio = (r, keep = 'w') => {
    if (!r.ratio) return r;
    const k = r.ratio / ar; /* normalized w/h for the pixel ratio */
    if (keep === 'w') r.h = r.w / k; else r.w = r.h * k;
    if (r.h > 1) { r.h = 1; r.w = k; } if (r.w > 1) { r.w = 1; r.h = 1 / k; }
    return r;
  };
  st.rects.forEach(r => norm(fitRatio(r)));
  const draw = () => {
    layer.innerHTML = st.rects.map(r => `<div class="fo-reg-box${r.id === st.active ? ' on' : ''}" data-id="${esc(r.id)}" tabindex="0" role="button" aria-label="${esc(r.label || 'Area')}: drag, or use the arrow keys to move it and Shift + arrow keys to resize it${cfg.multi ? '; Delete removes it' : ''}" style="left:${r.x * 100}%;top:${r.y * 100}%;width:${r.w * 100}%;height:${r.h * 100}%">
      ${r.label ? `<span class="fo-reg-lbl">${esc(r.label)}</span>` : ''}${cfg.multi ? `<button type="button" class="fo-reg-x" data-rm aria-label="Remove this area">${icon('x')}</button>` : ''}
      <i data-h="nw"></i><i data-h="ne"></i><i data-h="sw"></i><i data-h="se"></i></div>`).join('');
  };
  const emit = () => cfg.onChange && cfg.onChange(st.rects.map(r => ({ ...r })));
  draw();
  let drag = null;
  const pt = e => { const b = reg.getBoundingClientRect(); return { x: (e.clientX - b.left) / b.width, y: (e.clientY - b.top) / b.height }; };
  reg.addEventListener('pointerdown', e => {
    if (e.target.closest('[data-rm]')) return;
    const box = e.target.closest('.fo-reg-box'), p = pt(e);
    if (box) {
      const r = st.rects.find(x => x.id === box.dataset.id); st.active = r.id;
      drag = { r, mode: e.target.dataset.h || 'move', p0: p, r0: { ...r } };
    } else if (cfg.multi) {
      const r = { id: 'r' + Date.now().toString(36), x: p.x, y: p.y, w: .02, h: .02 };
      st.rects.push(r); st.active = r.id;
      drag = { r, mode: 'se', p0: p, r0: { ...r }, fresh: true };
    } else return;
    e.preventDefault(); reg.setPointerCapture(e.pointerId); draw();
  });
  reg.addEventListener('pointermove', e => {
    if (!drag) return;
    const p = pt(e), dx = p.x - drag.p0.x, dy = p.y - drag.p0.y, r = drag.r, o = drag.r0;
    if (drag.mode === 'move') { r.x = clamp(o.x + dx, 0, 1 - r.w); r.y = clamp(o.y + dy, 0, 1 - r.h); }
    else {
      const m = drag.mode;
      let x0 = o.x, y0 = o.y, x1 = o.x + o.w, y1 = o.y + o.h;
      if (m.includes('w')) x0 = clamp(o.x + dx, 0, x1 - .02); else x1 = clamp(x1 + dx, x0 + .02, 1);
      if (m.includes('n')) y0 = clamp(o.y + dy, 0, y1 - .02); else y1 = clamp(y1 + dy, y0 + .02, 1);
      r.x = x0; r.y = y0; r.w = x1 - x0; r.h = y1 - y0;
      if (r.ratio) { fitRatio(r, Math.abs(dx) * ar >= Math.abs(dy) ? 'w' : 'h'); if (m.includes('n')) r.y = y1 - r.h; if (m.includes('w')) r.x = x1 - r.w; }
      norm(r);
    }
    const el = $(`.fo-reg-box[data-id="${CSS.escape(r.id)}"]`, layer);
    if (el) Object.assign(el.style, { left: r.x * 100 + '%', top: r.y * 100 + '%', width: r.w * 100 + '%', height: r.h * 100 + '%' });
  });
  const end = () => {
    if (!drag) return;
    if (drag.fresh && (drag.r.w < .03 || drag.r.h < .03)) st.rects = st.rects.filter(x => x !== drag.r);
    drag = null; draw(); emit();
  };
  reg.addEventListener('pointerup', end); reg.addEventListener('pointercancel', end);
  reg.addEventListener('click', e => {
    const rm = e.target.closest('[data-rm]');
    if (rm) { const id = rm.closest('.fo-reg-box').dataset.id; st.rects = st.rects.filter(x => x.id !== id); draw(); emit(); }
  });
  reg.addEventListener('keydown', e => {
    const box = e.target.closest('.fo-reg-box'); if (!box) return;
    const r = st.rects.find(x => x.id === box.dataset.id); if (!r) return;
    const step = e.altKey ? .002 : .01; // Alt = fine steps
    const k = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
    if (k) {
      e.preventDefault();
      if (e.shiftKey) { r.w += k[0] * step * 2; r.h += k[1] * step * 2; if (r.ratio) fitRatio(r, k[0] ? 'w' : 'h'); }
      else { r.x += k[0] * step; r.y += k[1] * step; }
      norm(r); st.active = r.id; draw(); $(`.fo-reg-box[data-id="${CSS.escape(r.id)}"]`, layer).focus(); emit();
    } else if ((e.key === 'Delete' || e.key === 'Backspace') && cfg.multi) {
      e.preventDefault(); st.rects = st.rects.filter(x => x !== r); draw(); emit();
    }
  });
  return { get: () => st.rects.map(r => ({ ...r })), set: rects => { st.rects = rects.map(r => norm(fitRatio({ ...r }))); draw(); emit(); } };
}
/* Crops a normalized rectangle out of a canvas into a new canvas. */
function cropCanvas(src, r, outW, outH) {
  const sx = r.x * src.width, sy = r.y * src.height, sw = r.w * src.width, sh = r.h * src.height;
  const c = canvasOf(outW || sw, outH || sh), g = c.getContext('2d');
  g.imageSmoothingQuality = 'high';
  g.drawImage(src, sx, sy, sw, sh, 0, 0, c.width, c.height);
  return c;
}
