/* =====================================================================
   Fileora tool engine
   ---------------------------------------------------------------------
   Turns every <div class="fo-app" data-fo-tool="ID"> into a working tool.
   Tool behaviour comes from the module scripts (modules/<module>/*.js),
   which call FileoraEngine.register({...}). Names, descriptions and where
   a tool runs come from WordPress (window.FileoraConfig).

   Browser tools run here with pdf-lib, pdf.js and canvas; files never
   leave the device. Server tools are sent to WordPress, which forwards
   them to the Fileora processing server:
       POST {rest}/jobs/{tool}   multipart files[], options (JSON), url -> 202 {job, token}
       GET  {rest}/jobs/{job}    header X-Fileora-Token -> {status, ahead, kind, name, size, text, error}
       GET  {rest}/jobs/{job}/file
   ===================================================================== */
const CFG = Object.assign({ rest: '', nonce: '', maxFileMB: 100, maxFiles: 20, backend: false, deletionText: 'within 1 hour', tools: {}, catalog: [] }, window.FileoraConfig || {});
const DEFS = {};

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const icon = (n, cls = 'fo-ic') => `<svg class="${cls}" aria-hidden="true" focusable="false"><use href="#i-${n}"/></svg>`;
const HAS_GSAP = () => typeof window.gsap !== 'undefined';
const REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches;
const store = {
  get(k, d) { try { const v = localStorage.getItem('fileora.' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('fileora.' + k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } }
};
function fmtSize(b) { if (b < 1024) return b + ' B'; if (b < 1048576) return (b / 1024).toFixed(b < 10240 ? 1 : 0) + ' KB'; return (b / 1048576).toFixed(b < 10485760 ? 2 : 1) + ' MB'; }
function baseName(n) { return String(n).replace(/\.[^.]+$/, '') || 'file'; }
function extOf(n) { const m = /\.([^.]+)$/.exec(n || ''); return m ? m[1].toLowerCase() : ''; }
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const sleep = ms => new Promise(r => setTimeout(r, ms));

class UserError extends Error {}
class NoServer extends Error {}

/* accepted inputs */
const ACCEPT = {
  pdf: { ext: ['pdf'], input: '.pdf,application/pdf', noun: 'PDF', nouns: 'PDF files', kinds: ['pdf'] },
  image: { ext: ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'avif'], input: 'image/*', noun: 'image', nouns: 'images', kinds: ['image'] },
  pdfimage: { ext: ['pdf', 'jpg', 'jpeg', 'png', 'webp'], input: '.pdf,application/pdf,image/*', noun: 'PDF or image', nouns: 'PDF or images', kinds: ['pdf', 'image'] },
  heic: { ext: ['heic', 'heif', 'jpg', 'jpeg', 'png', 'webp'], input: '.heic,.heif,image/heic,image/heif', noun: 'HEIC photo', nouns: 'HEIC photos', kinds: ['heic', 'image'] },
  svg: { ext: ['svg'], input: '.svg,image/svg+xml', noun: 'SVG file', nouns: 'SVG files', kinds: ['svg'] },
  word: { ext: ['doc', 'docx', 'odt', 'rtf', 'txt'], input: '.doc,.docx,.odt,.rtf,.txt', noun: 'Word file', nouns: 'Word files', kinds: ['word'] },
  ppt: { ext: ['ppt', 'pptx', 'pps', 'ppsx', 'odp'], input: '.ppt,.pptx,.pps,.ppsx,.odp', noun: 'PowerPoint file', nouns: 'PowerPoint files', kinds: ['ppt'] },
  excel: { ext: ['xls', 'xlsx', 'ods', 'csv'], input: '.xls,.xlsx,.ods,.csv', noun: 'spreadsheet', nouns: 'spreadsheets', kinds: ['excel'] },
  url: { ext: [], input: '', noun: 'web address', nouns: 'web addresses', kinds: [] },
  html: { ext: ['html', 'htm'], input: '.html,.htm,text/html', noun: 'HTML file', nouns: 'HTML files', kinds: ['html'] }
};
function kindOf(f) {
  const e = extOf(f.name);
  if (e === 'pdf' || f.type === 'application/pdf') return 'pdf';
  if (e === 'svg' || f.type === 'image/svg+xml') return 'svg';
  if (e === 'heic' || e === 'heif' || /^image\/hei[cf]/.test(f.type)) return 'heic';
  if (ACCEPT.image.ext.includes(e) || /^image\//.test(f.type)) return 'image';
  for (const k of ['word', 'ppt', 'excel', 'html']) if (ACCEPT[k].ext.includes(e)) return k;
  return 'other';
}

const LANGS = [['en', 'English'], ['hi', 'Hindi'], ['bn', 'Bengali'], ['ta', 'Tamil'], ['te', 'Telugu'], ['mr', 'Marathi'], ['gu', 'Gujarati'], ['kn', 'Kannada'], ['ml', 'Malayalam'], ['pa', 'Punjabi'], ['ur', 'Urdu'], ['ar', 'Arabic'], ['zh', 'Chinese (Simplified)'], ['ja', 'Japanese'], ['ko', 'Korean'], ['fr', 'French'], ['de', 'German'], ['es', 'Spanish'], ['pt', 'Portuguese'], ['it', 'Italian'], ['ru', 'Russian'], ['tr', 'Turkish'], ['id', 'Indonesian']];
const pageSizeOpt = (v = 'a4') => ({ id: 'size', type: 'seg', label: 'Page size', value: v, choices: [['fit', 'Fit image'], ['a4', 'A4'], ['letter', 'US Letter']] });
const orientOpt = { id: 'orient', type: 'seg', label: 'Orientation', value: 'auto', choices: [['auto', 'Auto'], ['portrait', 'Portrait'], ['landscape', 'Landscape']], show: o => o.size !== 'fit' };
const marginOpt = { id: 'margin', type: 'seg', label: 'Margin', value: 'small', choices: [['none', 'None'], ['small', 'Small'], ['large', 'Large']] };

/* toasts */
function toast(msg, kind = 'info') {
  let box = $('.fo-toasts');
  if (!box) { box = document.createElement('div'); box.className = 'fo-toasts'; box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
  const el = document.createElement('div');
  el.className = 'fo-toast' + (kind === 'error' ? ' err' : '');
  el.innerHTML = icon(kind === 'error' ? 'alert' : kind === 'ok' ? 'check' : 'info') + `<span>${esc(msg)}</span>`;
  box.appendChild(el);
  if (HAS_GSAP() && !REDUCED) gsap.from(el, { y: 16, opacity: 0, duration: .3, ease: 'power2.out' });
  setTimeout(() => {
    if (HAS_GSAP() && !REDUCED) gsap.to(el, { opacity: 0, y: 8, duration: .25, onComplete: () => el.remove() }); else el.remove();
  }, kind === 'error' ? 5200 : 3200);
}

/* analytics (fileora-track.js) */
function track(e) { try { if (window.FileoraTrack) window.FileoraTrack.event(e); } catch (er) { /* ignore */ } }

/* files handed from one tool to the next (or from the homepage), kept briefly in IndexedDB */
const Handoff = {
  open() {
    return new Promise((res, rej) => {
      if (!window.indexedDB) return rej(new Error('no idb'));
      const r = indexedDB.open('fileora', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('handoff');
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    });
  },
  async put(files) {
    const db = await this.open();
    await new Promise((res, rej) => { const tx = db.transaction('handoff', 'readwrite'); tx.objectStore('handoff').put({ files, ts: Date.now() }, 'next'); tx.oncomplete = res; tx.onerror = () => rej(tx.error); });
    db.close();
  },
  async take() {
    const db = await this.open();
    const v = await new Promise((res, rej) => { const tx = db.transaction('handoff', 'readwrite'); const st = tx.objectStore('handoff'); const g = st.get('next'); g.onsuccess = () => { st.delete('next'); res(g.result); }; g.onerror = () => rej(g.error); });
    db.close();
    return v && Date.now() - v.ts < 15 * 60000 ? v.files : null;
  }
};
async function goToTool(id, files) {
  const t = CFG.catalog.find(x => x.id === id);
  if (!t) return;
  let ok = false;
  if (files && files.length) { try { await Handoff.put(files); ok = true; } catch (e) { /* private mode: open the tool without files */ } }
  location.href = t.url + (ok ? (t.url.includes('?') ? '&' : '?') + 'fo_handoff=1' : '');
}
