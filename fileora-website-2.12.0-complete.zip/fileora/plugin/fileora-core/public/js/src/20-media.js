/* ---------------- on-demand libraries ---------------- */
/* Libraries are served from this site (public/vendor), so no third party sees the visitor;
   public CDNs are only a fallback if the local copy can't load. */
const VENDOR = (CFG.vendor || '').replace(/\/?$/, '/');
const LIBS = {
  pdflib: [VENDOR + 'pdf-lib.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js'],
  pdfjs: [VENDOR + 'pdf.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'],
  jszip: [VENDOR + 'jszip.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js'],
  heic2any: [VENDOR + 'heic2any.min.js', 'https://cdn.jsdelivr.net/npm/heic2any@0.0.4/dist/heic2any.min.js'],
  imagetracer: [VENDOR + 'imagetracer.min.js', 'https://cdn.jsdelivr.net/npm/imagetracerjs@1.2.6/imagetracer_v1.2.6.js']
};
const libCache = {};
/* Full address of a library on this site (for Web Workers), or '' when there is no local copy. */
function libUrl(name) { return VENDOR === '/' ? '' : new URL(LIBS[name][0], location.href).href; }
function loadScript(src) {
  return new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = src; s.async = true; if (!src.startsWith(VENDOR)) s.crossOrigin = 'anonymous';
    s.onload = () => res(src);
    s.onerror = () => { s.remove(); rej(new Error('load failed')); };
    document.head.appendChild(s);
  });
}
function lib(name) {
  if (!libCache[name]) {
    libCache[name] = (async () => {
      let used = null;
      const urls = VENDOR === '/' ? LIBS[name].slice(1) : LIBS[name];
      for (const u of urls) { try { used = await loadScript(u); break; } catch (e) { /* try next */ } }
      if (!used) throw new Error('offline');
      if (name === 'pdfjs') window.pdfjsLib.GlobalWorkerOptions.workerSrc = used.replace('pdf.min.js', 'pdf.worker.min.js');
      return { pdflib: window.PDFLib, pdfjs: window.pdfjsLib, jszip: window.JSZip, heic2any: window.heic2any, imagetracer: window.ImageTracer }[name];
    })().catch(e => { delete libCache[name]; throw e; });
  }
  return libCache[name];
}

/* ---------------- PDF helpers ---------------- */
async function pdfjsDoc(file, password) {
  const pdfjs = await lib('pdfjs');
  const data = new Uint8Array(await file.arrayBuffer());
  return pdfjs.getDocument({ data, isEvalSupported: false, password: password || undefined }).promise;
}
async function renderPage(page, scale, opts = {}) {
  let vp = page.getViewport({ scale });
  const max = opts.maxPixels || 16e6;
  if (vp.width * vp.height > max) { scale *= Math.sqrt(max / (vp.width * vp.height)); vp = page.getViewport({ scale }); }
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.floor(vp.width)); c.height = Math.max(1, Math.floor(vp.height));
  const g = c.getContext('2d', { willReadFrequently: !!opts.read });
  g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
  await page.render({ canvasContext: g, viewport: vp }).promise;
  return c;
}
const canvasToBlob = (c, type, q) => new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('canvas')), type, q));
const pdfOut = (name, bytes, note) => ({ name, blob: new Blob([bytes], { type: 'application/pdf' }), note });
async function loadPdf(it, opts = {}) {
  const { PDFDocument } = await lib('pdflib');
  let doc;
  try { doc = await PDFDocument.load(await it.file.arrayBuffer(), { ignoreEncryption: true, updateMetadata: opts.updateMetadata !== false }); }
  catch (e) { throw new UserError(`${it.name} couldn’t be opened. It may be damaged, so try Repair PDF first.`); }
  if (doc.isEncrypted) throw new UserError(`${it.name} is password-protected. Unlock it first, then try again.`);
  return doc;
}
async function savePdf(doc, opts = {}) { if (opts.brand !== false) { doc.setProducer('Fileora'); doc.setCreator('Fileora'); } return doc.save(); }
function friendly(e) {
  const m = String(e && (e.message || e.name) || '');
  if (m === 'offline') return 'The PDF engine couldn’t load. Check your internet connection and try again.';
  if (/password|encrypt/i.test(m)) return 'This PDF is password-protected. Unlock it first, then try again.';
  if (/memory|allocation|too large/i.test(m)) return 'This file is too large for your device’s memory. Try a smaller file or a computer.';
  return 'Something went wrong while processing the file. If it may be damaged, try Repair PDF first.';
}
/* visual page geometry that respects /Rotate */
function vis(page) {
  const r = ((page.getRotation().angle % 360) + 360) % 360;
  const b = page.getCropBox();
  const W = b.width, H = b.height;
  const map = (u, v) => r === 90 ? { x: b.x + W - v, y: b.y + u } : r === 180 ? { x: b.x + W - u, y: b.y + H - v } : r === 270 ? { x: b.x + v, y: b.y + H - u } : { x: b.x + u, y: b.y + v };
  return { W: r % 180 ? H : W, H: r % 180 ? W : H, r, map, box: b };
}
/* an unrotated rectangle {x,y,width,height} for a visual rectangle (u0,v0)-(u1,v1) */
function visRect(V, u0, v0, u1, v1) {
  const a = V.map(u0, v0), b = V.map(u1, v1);
  return { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), width: Math.abs(a.x - b.x), height: Math.abs(a.y - b.y) };
}
function parseRanges(str, n) {
  const groups = [];
  for (const raw of String(str || '').split(/[,;]+/)) {
    const s = raw.trim().toLowerCase().replace(/\s+/g, '');
    if (!s) continue;
    let m, a, b;
    if ((m = /^(\d+)$/.exec(s))) { a = b = +m[1]; }
    else if ((m = /^(\d*)-(\d*|end|last)$/.exec(s))) { a = m[1] ? +m[1] : 1; b = (!m[2] || m[2] === 'end' || m[2] === 'last') ? n : +m[2]; }
    else throw new UserError(`“${raw.trim()}” isn’t a page range. Use something like 1-3, 5.`);
    if (a < 1 || b > n || a > b) throw new UserError(`Pages ${a}${a !== b ? '-' + b : ''} don’t exist. This PDF has ${n} page${n > 1 ? 's' : ''}.`);
    groups.push(Array.from({ length: b - a + 1 }, (_, i) => a - 1 + i));
  }
  return groups;
}
const rangeLabel = g => g.length === 1 ? `page-${g[0] + 1}` : (g[g.length - 1] - g[0] === g.length - 1 ? `pages-${g[0] + 1}-${g[g.length - 1] + 1}` : `part`);
const PAGE = { a4: [595.28, 841.89], letter: [612, 792], a3: [841.89, 1190.55], a5: [419.53, 595.28], legal: [612, 1008] };
const MM = 72 / 25.4;

/* ---------------- images ---------------- */
async function decodeImage(file) {
  try { const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); return { src: bmp, w: bmp.width, h: bmp.height, done: () => bmp.close() }; }
  catch (e) {
    const url = URL.createObjectURL(file); const img = new Image(); img.src = url;
    try { await img.decode(); } catch (er) { URL.revokeObjectURL(url); throw new UserError(`${file.name} couldn’t be read as an image.`); }
    return { src: img, w: img.naturalWidth, h: img.naturalHeight, done: () => URL.revokeObjectURL(url) };
  }
}
function canvasOf(w, h) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h)); return c; }
/* the whole image on a canvas (EXIF rotation applied), optionally capped to maxSide */
async function imageCanvas(file, maxSide, background) {
  const d = await decodeImage(file);
  const s = maxSide ? Math.min(1, maxSide / Math.max(d.w, d.h)) : 1;
  const c = canvasOf(d.w * s, d.h * s), g = c.getContext('2d');
  if (background) { g.fillStyle = background; g.fillRect(0, 0, c.width, c.height); }
  g.imageSmoothingQuality = 'high';
  g.drawImage(d.src, 0, 0, c.width, c.height); d.done();
  return c;
}
function filterPixels(g, w, h, mode) {
  const d = g.getImageData(0, 0, w, h), px = d.data, n = px.length;
  const lum = new Float32Array(n / 4);
  const hist = new Uint32Array(256);
  for (let i = 0, k = 0; i < n; i += 4, k++) { const l = px[i] * .299 + px[i + 1] * .587 + px[i + 2] * .114; lum[k] = l; hist[l | 0]++; }
  const total = n / 4; let acc = 0, lo = 0, hi = 255;
  for (let v = 0; v < 256; v++) { acc += hist[v]; if (acc > total * .02) { lo = v; break; } }
  acc = 0; for (let v = 255; v >= 0; v--) { acc += hist[v]; if (acc > total * .08) { hi = v; break; } }
  const span = Math.max(24, hi - lo);
  for (let i = 0, k = 0; i < n; i += 4, k++) {
    let v = (lum[k] - lo) / span; v = v < 0 ? 0 : v > 1 ? 1 : v;
    if (mode === 'doc') v = 1 / (1 + Math.exp(-11 * (v - .52)));
    else v = Math.pow(v, .92);
    const o = v * 255; px[i] = px[i + 1] = px[i + 2] = o;
  }
  g.putImageData(d, 0, 0);
}
async function imageForPdf(file, filter) {
  const d = await decodeImage(file);
  const s = Math.min(1, 4200 / Math.max(d.w, d.h));
  const w = Math.max(1, Math.round(d.w * s)), h = Math.max(1, Math.round(d.h * s));
  const png = (file.type === 'image/png' || extOf(file.name) === 'png') && (!filter || filter === 'none');
  const c = canvasOf(w, h);
  const g = c.getContext('2d', { willReadFrequently: !!filter && filter !== 'none' });
  if (!png) { g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); }
  g.drawImage(d.src, 0, 0, w, h); d.done();
  if (filter && filter !== 'none') filterPixels(g, w, h, filter);
  const blob = await canvasToBlob(c, png ? 'image/png' : 'image/jpeg', .9);
  c.width = c.height = 0;
  return { bytes: await blob.arrayBuffer(), w, h, png };
}
/* embeds any canvas as JPEG (opaque) or PNG (with transparency) */
async function embedCanvas(doc, c, png, q = .9) {
  const blob = await canvasToBlob(c, png ? 'image/png' : 'image/jpeg', q);
  const bytes = await blob.arrayBuffer();
  return png ? doc.embedPng(bytes) : doc.embedJpg(bytes);
}
async function imagesToPdf(items, o, ctx, filter) {
  const { PDFDocument } = await lib('pdflib');
  const doc = await PDFDocument.create();
  const margin = { none: 0, small: 20, large: 42 }[o.margin] ?? 20;
  for (let i = 0; i < items.length; i++) {
    ctx.progress(i / items.length, `Image ${i + 1} of ${items.length}`);
    const im = await imageForPdf(items[i].file, filter);
    const img = im.png ? await doc.embedPng(im.bytes) : await doc.embedJpg(im.bytes);
    let pw, ph;
    if (o.size === 'fit') { pw = im.w * .75 + margin * 2; ph = im.h * .75 + margin * 2; }
    else {
      [pw, ph] = PAGE[o.size] || PAGE.a4;
      const land = o.orient === 'landscape' || (o.orient !== 'portrait' && im.w > im.h);
      if (land) [pw, ph] = [ph, pw];
    }
    const bw = pw - margin * 2, bh = ph - margin * 2, sc = Math.min(bw / im.w, bh / im.h);
    const dw = im.w * sc, dh = im.h * sc;
    doc.addPage([pw, ph]).drawImage(img, { x: (pw - dw) / 2, y: (ph - dh) / 2, width: dw, height: dh });
  }
  ctx.progress(.96, 'Saving');
  return savePdf(doc);
}
/* every page as an image; transform(g, w, h) may change the pixels */
async function rasterize(file, dpi, q, prog, transform) {
  const pdf = await pdfjsDoc(file);
  const { PDFDocument } = await lib('pdflib');
  const out = await PDFDocument.create();
  const n = pdf.numPages;
  for (let i = 1; i <= n; i++) {
    prog && prog((i - 1) / n, `Page ${i} of ${n}`);
    const page = await pdf.getPage(i);
    const vp = page.getViewport({ scale: 1 });
    const c = await renderPage(page, dpi / 72, { read: !!transform });
    if (transform) transform(c.getContext('2d', { willReadFrequently: true }), c.width, c.height);
    const img = await embedCanvas(out, c, false, q);
    c.width = c.height = 0;
    out.addPage([vp.width, vp.height]).drawImage(img, { x: 0, y: 0, width: vp.width, height: vp.height });
    page.cleanup();
  }
  await pdf.destroy();
  return savePdf(out);
}
async function textPng(text, color, weight = 700) {
  try { await document.fonts.load(`${weight} 120px Geist`); } catch (e) { /* fallback font */ }
  const px = 120, font = `${weight} ${px}px Geist, 'Helvetica Neue', Arial, 'Noto Sans', 'Noto Sans Devanagari', sans-serif`;
  const c = document.createElement('canvas'), g = c.getContext('2d');
  g.font = font;
  const w = Math.ceil(g.measureText(text).width + px * .24), h = Math.ceil(px * 1.32);
  c.width = w; c.height = h;
  g.font = font; g.fillStyle = color; g.textBaseline = 'middle';
  g.fillText(text, px * .12, h / 2 + px * .04);
  const blob = await canvasToBlob(c, 'image/png');
  return { bytes: await blob.arrayBuffer(), w, h, px };
}
let measureCtx;
function textWidth(text, size) { measureCtx = measureCtx || document.createElement('canvas').getContext('2d'); measureCtx.font = `700 ${size}px Geist, 'Helvetica Neue', Arial, sans-serif`; return measureCtx.measureText(text).width; }

/* text lines from a PDF (pdf.js) */
async function pdfLines(file, prog, label) {
  const pdf = await pdfjsDoc(file);
  const pages = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    prog && prog((i - 1) / pdf.numPages, `${label} page ${i} of ${pdf.numPages}`);
    const page = await pdf.getPage(i);
    const tc = await page.getTextContent();
    const lines = [];
    for (const it of tc.items) {
      if (typeof it.str !== 'string' || !it.str) continue;
      const tr = it.transform, size = Math.hypot(tr[2], tr[3]) || it.height || 10, x = tr[4], y = tr[5];
      let ln = null;
      for (let k = lines.length - 1; k >= Math.max(0, lines.length - 8); k--) if (Math.abs(lines[k].y - y) < size * .45) { ln = lines[k]; break; }
      if (!ln) { ln = { y, x, parts: [] }; lines.push(ln); }
      ln.parts.push({ x, s: it.str, w: it.width, size });
    }
    for (const ln of lines) {
      ln.parts.sort((a, b) => a.x - b.x);
      let txt = '', end = null;
      for (const p of ln.parts) { if (end !== null && p.x - end > p.size * .22 && !/\s$/.test(txt) && !/^\s/.test(p.s)) txt += ' '; txt += p.s; end = p.x + p.w; }
      ln.text = txt.replace(/\s+/g, ' ').trim();
      ln.size = Math.max(...ln.parts.map(p => p.size));
      ln.x = ln.parts[0].x;
    }
    pages.push(lines.filter(l => l.text).sort((a, b) => b.y - a.y));
    page.cleanup();
  }
  await pdf.destroy();
  return pages;
}
function toMarkdown(pages, breaks) {
  const hist = new Map();
  pages.flat().forEach(l => { const k = Math.round(l.size * 2) / 2; hist.set(k, (hist.get(k) || 0) + l.text.length); });
  let body = 11, best = 0;
  hist.forEach((v, k) => { if (v > best) { best = v; body = k; } });
  const blocks = [];
  pages.forEach((lines, pi) => {
    if (pi && breaks) blocks.push({ t: 'hr' });
    let prev = null;
    for (const l of lines) {
      const r = l.size / body, gap = prev ? prev.y - l.y : 0, last = blocks[blocks.length - 1];
      const near = prev && gap < Math.max(l.size, prev.size) * 1.75;
      const bul = /^[•●▪◦‣∙·■□▸►\-–*]\s*(.+)/.exec(l.text), num = /^(\d{1,3}|[a-z])[.)]\s+.+/i.exec(l.text);
      if (r >= 1.18 && l.text.length < 140 && !bul) {
        const lvl = r >= 1.75 ? 1 : r >= 1.38 ? 2 : 3;
        if (last && last.t === 'h' && last.lvl === lvl && near) last.text += ' ' + l.text; else blocks.push({ t: 'h', lvl, text: l.text });
      } else if (bul) blocks.push({ t: 'li', text: bul[1] });
      else if (num && l.text.length > 3) blocks.push({ t: 'ol', text: l.text });
      else if (last && (last.t === 'p' || last.t === 'li' || last.t === 'ol') && near && pi === last.page) {
        last.text = /[A-Za-z]-$/.test(last.text) && /^[a-z]/.test(l.text) ? last.text.slice(0, -1) + l.text : last.text + ' ' + l.text;
      } else blocks.push({ t: 'p', text: l.text });
      const nb = blocks[blocks.length - 1]; if (nb) nb.page = pi;
      prev = l;
    }
  });
  const out = [];
  blocks.forEach((b, i) => {
    const nx = blocks[i + 1];
    if (b.t === 'h') out.push('#'.repeat(b.lvl) + ' ' + b.text, '');
    else if (b.t === 'hr') out.push('---', '');
    else if (b.t === 'li' || b.t === 'ol') { out.push((b.t === 'li' ? '- ' : '') + b.text); if (!nx || (nx.t !== 'li' && nx.t !== 'ol')) out.push(''); }
    else out.push(b.text, '');
  });
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
}
function diffLines(a, b) {
  let s = 0; while (s < a.length && s < b.length && a[s] === b[s]) s++;
  let ea = a.length, eb = b.length; while (ea > s && eb > s && a[ea - 1] === b[eb - 1]) { ea--; eb--; }
  const ops = [];
  for (let i = 0; i < s; i++) ops.push(['=', i, i]);
  const A = a.slice(s, ea), B = b.slice(s, eb), n = A.length, m = B.length;
  if (n * m > 9e6) { for (let i = 0; i < n; i++) ops.push(['-', s + i, -1]); for (let j = 0; j < m; j++) ops.push(['+', -1, s + j]); }
  else {
    const W = m + 1, L = new Uint16Array((n + 1) * W);
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i * W + j] = A[i] === B[j] ? L[(i + 1) * W + j + 1] + 1 : Math.max(L[(i + 1) * W + j], L[i * W + j + 1]);
    let i = 0, j = 0;
    while (i < n && j < m) {
      if (A[i] === B[j]) { ops.push(['=', s + i, s + j]); i++; j++; }
      else if (L[(i + 1) * W + j] >= L[i * W + j + 1]) { ops.push(['-', s + i, -1]); i++; }
      else { ops.push(['+', -1, s + j]); j++; }
    }
    while (i < n) { ops.push(['-', s + i, -1]); i++; }
    while (j < m) { ops.push(['+', -1, s + j]); j++; }
  }
  for (let k = 0; k < a.length - ea; k++) ops.push(['=', ea + k, eb + k]);
  return ops;
}

/* ---------------- image tool helpers ---------------- */
const IMG_EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
const sameType = file => IMG_EXT[file.type] ? file.type : 'image/jpeg';
const renameImg = (name, type, suffix) => baseName(name) + (suffix || '') + '.' + IMG_EXT[type];
const Img = {
  /* Draw an image region onto a canvas of the target size and encode it. */
  async render(file, { sx = 0, sy = 0, sw, sh, width, height, type, quality = 0.9, suffix }) {
    const img = await decodeImage(file);
    sw = sw || img.w; sh = sh || img.h;
    width = width || sw; height = height || sh;
    const c = canvasOf(width, height), g = c.getContext('2d');
    if (type === 'image/jpeg') { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); }
    g.imageSmoothingQuality = 'high';
    g.drawImage(img.src, sx, sy, sw, sh, 0, 0, c.width, c.height);
    img.done();
    const blob = await canvasToBlob(c, type, quality);
    return { blob, name: renameImg(file.name, type, suffix), width: c.width, height: c.height };
  },
  async compress(file, { quality = 0.72, maxSide = 0, type } = {}) {
    const img = await decodeImage(file); const w = img.w, h = img.h; img.done();
    const scale = maxSide ? Math.min(1, maxSide / Math.max(w, h)) : 1;
    const outType = type || (file.type === 'image/png' ? 'image/webp' : sameType(file));
    const out = await Img.render(file, { width: w * scale, height: h * scale, type: outType, quality, suffix: '-compressed' });
    if (out.blob.size >= file.size && scale === 1) return { blob: file, name: file.name, width: w, height: h, note: 'Already optimized, so we kept the original' };
    return out;
  },
  async resize(file, { width, height, percent, type } = {}) {
    const img = await decodeImage(file); const w = img.w, h = img.h; img.done();
    if (percent) { width = w * percent / 100; height = h * percent / 100; }
    else if (width && !height) height = h * width / w;
    else if (height && !width) width = w * height / h;
    if (!width || !height) throw new UserError('Give a width, a height or a percentage.');
    return Img.render(file, { width, height, type: type || sameType(file), quality: 0.92, suffix: '-' + Math.round(width) + 'x' + Math.round(height) });
  },
  async convert(file, type, { quality = 0.92 } = {}) {
    if (!IMG_EXT[type]) throw new UserError('Choose JPG, PNG or WebP.');
    return Img.render(file, { type, quality });
  },
  async crop(file, { x, y, width, height, type } = {}) {
    const img = await decodeImage(file); const w = img.w, h = img.h; img.done();
    x = Math.max(0, Math.round(x || 0)); y = Math.max(0, Math.round(y || 0));
    width = Math.min(w - x, Math.round(width)); height = Math.min(h - y, Math.round(height));
    if (!(width > 0 && height > 0)) throw new UserError('The crop area is outside the image.');
    return Img.render(file, { sx: x, sy: y, sw: width, sh: height, type: type || sameType(file), quality: 0.92, suffix: '-cropped' });
  }
};
function cropRect(w, h, o) {
  const ratio = { '1:1': 1, '4:5': 4 / 5, '4:3': 4 / 3, '3:2': 3 / 2, '16:9': 16 / 9, '9:16': 9 / 16 }[o.ratio] || w / h;
  let cw = w, ch = w / ratio;
  if (ch > h) { ch = h; cw = h * ratio; }
  const s = Math.max(.2, Math.min(1, (+o.size || 100) / 100));
  cw *= s; ch *= s;
  const col = (o.pos || 'mc')[1], row = (o.pos || 'mc')[0];
  return { x: Math.round(col === 'l' ? 0 : col === 'r' ? w - cw : (w - cw) / 2), y: Math.round(row === 't' ? 0 : row === 'b' ? h - ch : (h - ch) / 2), width: Math.round(cw), height: Math.round(ch) };
}
function imageNote(out, file) {
  if (out.note) return out.note;
  const dims = `${out.width} × ${out.height} px`;
  return out.blob.size < file.size ? `${dims}, ${Math.round((1 - out.blob.size / file.size) * 100)}% smaller (${fmtSize(file.size)} to ${fmtSize(out.blob.size)})` : `${dims}, ${fmtSize(out.blob.size)}`;
}
async function eachImage(items, ctx, fn) {
  const outs = [];
  for (let i = 0; i < items.length; i++) {
    ctx.progress(i / items.length, `Image ${i + 1} of ${items.length}`);
    const out = await fn(items[i].file, items[i], i);
    outs.push({ name: out.name, blob: out.blob, note: imageNote(out, items[i].file), good: out.blob.size < items[i].file.size });
  }
  return outs;
}
/*
 * Encodes a canvas as JPEG (or WebP) no bigger than maxBytes, as close to it as possible.
 * Lowers quality first; if the smallest quality is still too big and shrink is allowed,
 * scales the image down. Returns { blob, quality, width, height }.
 */
async function encodeToSize(src, maxBytes, { type = 'image/jpeg', minQ = 0.08, shrink = true } = {}) {
  let c = src;
  for (let round = 0; round < 12; round++) {
    let lo = minQ, hi = 0.95, best = null;
    const top = await canvasToBlob(c, type, hi);
    if (top.size <= maxBytes) return { blob: top, quality: hi, width: c.width, height: c.height };
    for (let i = 0; i < 8; i++) {
      const q = (lo + hi) / 2, b = await canvasToBlob(c, type, q);
      if (b.size <= maxBytes) { best = { blob: b, quality: q }; lo = q; } else hi = q;
    }
    if (!best) { const b = await canvasToBlob(c, type, minQ); if (b.size <= maxBytes) best = { blob: b, quality: minQ }; }
    if (best) return { ...best, width: c.width, height: c.height };
    if (!shrink || c.width < 24 || c.height < 24) break;
    const small = await canvasToBlob(c, type, minQ);
    const f = Math.max(.5, Math.min(.92, Math.sqrt(maxBytes / small.size) * .95));
    const n = canvasOf(c.width * f, c.height * f), g = n.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, n.width, n.height); g.imageSmoothingQuality = 'high';
    g.drawImage(c, 0, 0, n.width, n.height);
    c = n;
  }
  return null;
}
/* Pads a JPEG with a comment segment so it reaches minBytes (the picture doesn't change). */
async function padJpeg(blob, minBytes) {
  if (blob.size >= minBytes) return blob;
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let need = minBytes - bytes.length;
  const segs = [];
  while (need > 0) {
    const len = Math.min(65533, Math.max(1, need - 4));
    const seg = new Uint8Array(len + 4);
    seg[0] = 0xFF; seg[1] = 0xFE; seg[2] = (len + 2) >> 8; seg[3] = (len + 2) & 255;
    segs.push(seg); need -= seg.length;
  }
  return new Blob([bytes.slice(0, 2), ...segs, bytes.slice(2)], { type: 'image/jpeg' });
}
