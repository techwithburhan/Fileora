/* ---------------- workspace ----------------
   One per .fo-app element. A tool definition (registered by a module) says
   what the tool accepts and does:
     { id, accept, multi, min, max, ordered, camera, pages, cta, verb, tip,
       opts, validate(o, items, ws), run(items, o, ctx), server,
       overlay(it, o, ws), regions: { source, rects, multi }, onItems(ws),
       resultHtml(result, ws), thumbStyle(o),
       codeView(main, ws, api), onFiles(list, ws), codeFile(ws), localOpts }
   accept 'html' is the code mode: the tool shows its own editor (codeView) instead of a
   file drop zone, and codeFile(ws) turns the code into the File that is sent to the server.
   ctx passed to run(): { progress(f, label), pages, regions, source, result, alive(), ws }. */
let itemSeq = 0;
const PHASE_STEP = { empty: 1, ready: 2, working: 3, done: 4, error: 2, server: 2, unavailable: 1 };

function defaults(def) {
  const o = {};
  (def.opts || []).forEach(f => { if (f.id && 'value' in f) o[f.id] = f.value && typeof f.value === 'object' ? { ...f.value } : f.value; });
  return o;
}

function mountTool(root) {
  const id = root.dataset.foTool;
  const def = DEFS[id];
  const meta = CFG.tools[id] || {};
  if (!def) return null;
  const T = Object.assign({ min: 1, multi: false, opts: [], cta: 'Run', verb: 'Working', name: meta.name || id, desc: meta.desc || '' }, def, { name: meta.name || def.name || id, desc: meta.desc || def.desc || '' });
  const useServer = !!def.server && (!def.run || meta.runs === 'server');
  const accept = ACCEPT[T.accept] || ACCEPT.pdf;
  const maxFiles = T.max || (useServer && meta.maxFiles ? meta.maxFiles : 0);
  const WS = { root, tool: T, def, meta, useServer, items: [], pages: null, allPages: null, opts: defaults(T), phase: 'empty', outputs: [], result: null, error: '', urls: [], seq: 0, queue: Promise.resolve(), sigUrl: null, source: null, regions: null, refreshOpts: null, started: 0 };
  /* settings the page asks the tool to open with (data-fo-preset): { opts: {…} } or a tool's own preset hook */
  let preset = null;
  try { preset = root.dataset.foPreset ? JSON.parse(root.dataset.foPreset) : null; } catch (e) { preset = null; }
  if (preset) {
    if (typeof def.preset === 'function') { T.opts = (T.opts || []).map(f => ({ ...f })); def.preset(preset, WS, T); }
    else if (preset.opts) Object.keys(preset.opts).forEach(k => { if (k in WS.opts) WS.opts[k] = preset.opts[k]; });
    if (preset.tip) T.tip = preset.tip;
  }
  root.dataset.cat = meta.color || root.dataset.cat || 'organize';
  root.innerHTML = `<div class="fo-ws">
    <div class="fo-ws-top">
      <ol class="fo-ws-steps" aria-label="Progress"><li data-step="1"><i>1</i>${T.accept === 'url' ? 'Enter address' : T.accept === 'html' ? 'Add code' : 'Add files'}</li><li class="sep" aria-hidden="true"></li><li data-step="2"><i>2</i>Set options</li><li class="sep" aria-hidden="true"></li><li data-step="3"><i>3</i>Download</li></ol>
      <span class="fo-priv${useServer ? ' srv' : ''}" title="${useServer ? `Files are sent over HTTPS and deleted ${esc(CFG.deletionText)}` : 'Your files never leave this device'}">${useServer ? icon('shield') + '<span>Encrypted server processing</span>' : icon('device') + '<span>Runs in your browser</span>'}</span>
    </div>
    <div class="fo-ws-body">
      <section class="fo-ws-main" aria-live="polite"></section>
      <div class="fo-ws-side">
        <div class="fo-ws-opts"><h2></h2><p class="fo-ws-about"></p><div class="fo-opts"></div></div>
        <div class="fo-ws-cta"><button type="button" class="fo-btn fo-btn-ink fo-btn-lg fo-run" disabled>${esc(T.cta)}</button><p class="fo-ws-hint"></p></div>
      </div>
    </div>
    <input type="file" class="fo-file-in" multiple hidden><input type="file" class="fo-cam-in" accept="image/*" capture="environment" hidden>
  </div>`;
  const main = $('.fo-ws-main', root), runBtn = $('.fo-run', root), hint = $('.fo-ws-hint', root);
  WS.main = main;

  /* ---- state helpers ---- */
  const goodItems = () => WS.items.filter(i => !i.err);
  const mkItem = file => ({ id: 'f' + (++itemSeq), file, name: file.name, size: file.size, kind: kindOf(file), pages: null, thumb: null, err: null, note: '' });
  function clearOutputs() { WS.outputs.forEach(o => URL.revokeObjectURL(o.url)); WS.outputs = []; WS.result = null; }
  function clearItems() { WS.items = []; WS.pages = null; WS.allPages = null; WS.source = null; WS.regions = null; WS.seq++; WS.queue = Promise.resolve(); clearOutputs(); }
  function setPhase(p) { WS.phase = p; root.classList.toggle('is-done', p === 'done'); renderMain(); updateSteps(); updateCta(); }
  function updateSteps() {
    const st = PHASE_STEP[WS.phase] || 1;
    $$('.fo-ws-steps li[data-step]', root).forEach(li => { const n = +li.dataset.step; li.className = n < st ? 'done' : n === st ? 'on' : ''; });
  }
  const isUrl = v => { try { const u = new URL(/^https?:\/\//i.test(v) ? v : 'https://' + v); return /\./.test(u.hostname); } catch (e) { return false; } };
  function updateCta() {
    let ok = false, h = '';
    if (WS.phase === 'working') { runBtn.disabled = true; runBtn.textContent = T.verb + '…'; hint.textContent = 'Keep this page open until it finishes.'; return; }
    if (WS.phase === 'unavailable') { runBtn.disabled = true; runBtn.textContent = T.cta; hint.textContent = 'This tool is temporarily unavailable.'; return; }
    if (T.accept === 'url') { ok = isUrl(WS.opts.url || ''); h = ok ? '' : 'Enter a web address to continue.'; }
    else if (T.accept === 'html') { const n = (WS.opts.html || '').length; ok = !!(WS.opts.html || '').trim() && n <= 5242880; h = !n || ok ? (ok ? '' : 'Paste or type your HTML code to start.') : 'The code is larger than 5 MB.'; }
    else {
      const n = goodItems().length;
      const regOk = !T.regions || (T.regions.skip && T.regions.skip(WS)) || !!(WS.source && WS.source.url);
      ok = n >= T.min && (!T.pages || (WS.pages && WS.pages.length)) && regOk;
      if (!n) h = T.min > 1 ? `Add at least ${T.min} ${accept.nouns} to start.` : `Add ${T.multi ? accept.nouns : 'a ' + accept.noun} to start.`;
      else if (n < T.min) h = `Add ${T.min - n} more ${T.min - n === 1 ? accept.noun : accept.nouns}.`;
      else if (T.pages && !WS.pages) h = 'Loading pages…';
      else if (T.pages && !WS.pages.length) h = 'Keep at least one page.';
      else if (!regOk) h = WS.source && WS.source.err ? WS.source.err : 'Loading the preview…';
    }
    if (ok && T.validate) { const v = T.validate(WS.opts, goodItems(), WS); if (v) { h = v; ok = false; } }
    const done = WS.phase === 'done';
    runBtn.disabled = !ok;
    runBtn.className = 'fo-btn fo-btn-lg fo-run ' + (done ? 'fo-btn-line' : 'fo-btn-ink');
    runBtn.textContent = done ? 'Run again' : T.cta;
    hint.textContent = h || (done ? (T.opts.length ? 'Change an option, then run again.' : 'Runs the tool again on the same files.') : useServer ? `Files are deleted from the server ${CFG.deletionText}.` : 'Processed on your device. Nothing is uploaded.');
  }
  function setProgress(f, label) {
    const bar = $('.fo-pbar', main); if (!bar) return;
    bar.classList.toggle('indet', f < 0);
    if (f >= 0) bar.firstElementChild.style.width = Math.round(Math.min(1, f) * 100) + '%';
    if (label) $('.fo-plabel', main).textContent = label;
  }

  /* ---- options ---- */
  function renderOptsPanel() {
    $('.fo-ws-opts h2', root).textContent = T.opts.length ? 'Options' : 'About this tool';
    $('.fo-ws-about', root).textContent = T.tip || T.desc;
    if (!T.opts.length) { $('.fo-opts', root).innerHTML = `<div class="fo-note">${icon('info')}<span>No settings needed. Add your files and press “${esc(T.cta)}”.</span></div>`; return; }
    WS.refreshOpts = renderOpts($('.fo-opts', root), T.opts, WS.opts, onOptChange);
  }
  function onOptChange(fid) {
    updateCta();
    if (fid === 'signature') { if (WS.sigUrl) URL.revokeObjectURL(WS.sigUrl); WS.sigUrl = WS.opts.signature ? URL.createObjectURL(new Blob([WS.opts.signature.bytes], { type: 'image/png' })) : null; }
    if (T.overlay) refreshOverlays();
    if (T.thumbStyle) applyThumbStyle();
    if (T.reloadOn && T.reloadOn.includes(fid)) reloadMeta();
    if (T.onOpt) T.onOpt(fid, WS);
  }
  /* re-render the options panel with new values (e.g. after reading a file's metadata) */
  WS.setOpts = vals => { Object.assign(WS.opts, vals); renderOptsPanel(); updateCta(); };

  /* ---- previews ---- */
  function thumbHtml(it) {
    const ext = (extOf(it.name) || 'file').toUpperCase().slice(0, 4);
    const cat = it.kind === 'pdf' ? 'from' : it.kind === 'image' || it.kind === 'heic' || it.kind === 'svg' ? 'image' : it.kind === 'word' ? 'organize' : it.kind === 'excel' ? 'optimize' : 'to';
    const tag = `<span class="fo-ext" style="--c:var(--fo-c-${cat})">${esc(ext)}</span>`;
    if (!it.thumb) return icon(it.kind === 'image' ? 'image' : 'file') + tag;
    if (it.pw && T.overlay) {
      const r = it.pw / it.ph, c = .75;
      const sz = !T.multi ? '' : r < c ? `height:100%;width:${r / c * 100}%` : `width:100%;height:${c / r * 100}%`;
      return `<div class="fo-pg" style="${sz}"><img src="${it.thumb}" alt=""><div class="fo-ovl">${overlayHtml(it)}</div></div>${tag}`;
    }
    return `<img src="${it.thumb}" alt="">${tag}`;
  }
  function overlayHtml(it) { try { return T.overlay ? T.overlay(it, WS.opts, WS) || '' : ''; } catch (e) { return ''; } }
  function refreshOverlays() { WS.items.forEach(it => { const el = $(`[data-iid="${it.id}"] .fo-ovl`, main); if (el) el.innerHTML = overlayHtml(it); }); }
  function applyThumbStyle() { const g = $('.fo-files', main); if (g && T.thumbStyle) g.style.cssText = T.thumbStyle(WS.opts) || ''; }
  const metaText = it => it.err || [fmtSize(it.size), it.pages ? `${it.pages} page${it.pages > 1 ? 's' : ''}` : '', it.note].filter(Boolean).join(', ');
  const ordered = () => T.ordered || (T.multi && T.min > 1);
  function fileCard(it, i, ord) {
    const label = T.slots ? `<div class="fo-slot-label">${esc(T.slots[i] || '')}</div>` : '';
    return `<div class="fo-file" data-iid="${it.id}"${ord ? ' draggable="true"' : ''}>${label}
      ${ord && !T.slots ? `<span class="fo-ord">${i + 1}</span>` : ''}
      <button type="button" class="fo-file-x" data-remove="${it.id}" aria-label="Remove ${esc(it.name)}">${icon('x')}</button>
      <div class="fo-thumb"${it.pw && !T.multi ? ` style="--ar:${it.pw / it.ph}"` : ''}>${thumbHtml(it)}</div>
      <div class="fo-file-name" title="${esc(it.name)}">${esc(it.name)}</div>
      <div class="fo-file-meta${it.err ? ' err' : ''}">${esc(metaText(it))}</div>
      ${ord ? `<div class="fo-file-acts"><button type="button" data-move="-1" ${i === 0 ? 'disabled' : ''} aria-label="Move ${esc(it.name)} earlier">${icon('chev-left')}</button><button type="button" data-move="1" ${i === WS.items.length - 1 ? 'disabled' : ''} aria-label="Move ${esc(it.name)} later">${icon('chev-right')}</button></div>` : ''}
    </div>`;
  }
  const rotStyle = r => `transform:rotate(${r}deg) scale(${r % 180 ? .74 : 1})`;
  function pageCard(p, k) {
    return `<div class="fo-file" data-pkey="${p.key}" draggable="true">
      <span class="fo-ord">${k + 1}</span>
      <div class="fo-thumb">${p.thumb ? `<img src="${p.thumb}" alt="" style="${rotStyle(p.rot)}">` : icon('file')}</div>
      <div class="fo-file-name">Page ${p.i + 1}${p.rot ? `, turned ${p.rot}°` : ''}</div>
      <div class="fo-file-acts"><button type="button" data-pmove="-1" ${k === 0 ? 'disabled' : ''} aria-label="Move page ${p.i + 1} earlier">${icon('chev-left')}</button><button type="button" data-prot aria-label="Rotate page ${p.i + 1}">${icon('rotate-cw')}</button><button type="button" data-pdel aria-label="Delete page ${p.i + 1}">${icon('trash')}</button><button type="button" data-pmove="1" ${k === WS.pages.length - 1 ? 'disabled' : ''} aria-label="Move page ${p.i + 1} later">${icon('chev-right')}</button></div>
    </div>`;
  }
  const tile = () => `<span class="fo-tile fo-tile-lg">${icon(meta.icon || 'file')}</span>`;

  function renderMain() {
    if (WS.phase === 'unavailable') {
      main.innerHTML = `<div class="fo-state">${tile()}<h2>${esc(T.name)} is temporarily unavailable</h2><p>The processing server can’t run this tool right now. Please try again later.</p>${altsHtml()}</div>`;
    } else if ((WS.phase === 'empty' || WS.phase === 'ready') && T.accept === 'html' && T.codeView) {
      T.codeView(main, WS, { update: updateCta, run: () => { if (!runBtn.disabled) runTool(); } });
    } else if (WS.phase === 'empty' && T.accept === 'url') {
      main.innerHTML = `<div class="fo-dz">${tile()}<h2>Which page should we save?</h2><p>${esc(T.desc)}</p>
        <form class="fo-url-form"><label class="fo-opt-l" for="${root.id}-url">Web address</label><input class="fo-inp" id="${root.id}-url" type="url" inputmode="url" autocomplete="url" placeholder="https://example.com/article" value="${esc(WS.opts.url || '')}"><small>We open the page on our server and save it exactly as it looks.</small></form></div>`;
      const inp = $('input', main);
      inp.addEventListener('input', e => { WS.opts.url = e.target.value.trim(); updateCta(); });
      $('form', main).addEventListener('submit', e => { e.preventDefault(); if (!runBtn.disabled) runTool(); });
    } else if (WS.phase === 'empty') {
      const what = T.slots ? T.slots.length + ' ' + accept.nouns : T.multi ? accept.nouns : 'a ' + accept.noun;
      main.innerHTML = `<div class="fo-dz">${tile()}<h2>Drop ${esc(T.dropText || what)} here</h2><p>${esc(T.desc)}</p>
        <div class="fo-dz-actions"><button type="button" class="fo-btn fo-btn-ink fo-btn-lg" data-pick>${icon('upload')}Choose ${esc(T.multi ? accept.nouns : accept.noun)}</button>${T.camera ? `<button type="button" class="fo-btn fo-btn-line fo-btn-lg" data-cam>${icon('camera')}Take a photo</button>` : ''}</div>
        <small>${useServer ? `Up to ${CFG.maxFileMB} MB per file. Encrypted, and deleted from the server ${esc(CFG.deletionText)}.` : 'Processed on your device. Nothing is uploaded.'}</small></div>`;
    } else if (WS.phase === 'ready') {
      if (T.pages) {
        const it = WS.items[0];
        main.innerHTML = `<div class="fo-files-head"><h2>${esc(it.name)} <span>${WS.pages ? `${WS.pages.length} of ${it.pages} pages kept` : ''}</span></h2>
          <button type="button" class="fo-btn fo-btn-quiet fo-btn-sm" data-preset>${icon('rotate-ccw', 'fo-ic fo-ic-sm')}Reset pages</button><button type="button" class="fo-btn fo-btn-line fo-btn-sm" data-pick>Change file</button></div>
          ${WS.pages ? `<div class="fo-files">${WS.pages.map(pageCard).join('')}</div>` : `<div class="fo-files">${fileCard(it, 0, false)}</div><p class="fo-plabel">${it.err ? '' : 'Loading pages…'}</p>`}`;
      } else if (T.regions && WS.items.length) {
        main.innerHTML = `<div class="fo-files-head"><h2>${esc(WS.items.map(i => i.name).join(', '))}</h2>
          ${T.multi && (!maxFiles || WS.items.length < maxFiles) ? `<button type="button" class="fo-btn fo-btn-line fo-btn-sm" data-pick>${icon('plus', 'fo-ic fo-ic-sm')}Add another</button>` : ''}
          <button type="button" class="fo-btn fo-btn-quiet fo-btn-sm" data-clear>Remove</button></div><div class="fo-reg-host"></div>`;
        renderRegions();
      } else {
        const ord = ordered(), n = WS.items.length, total = WS.items.reduce((s, i) => s + i.size, 0);
        const canAdd = T.multi && (!maxFiles || n < maxFiles);
        main.innerHTML = `<div class="fo-files-head"><h2>${n} ${n === 1 ? accept.noun : accept.nouns} <span>(${fmtSize(total)})</span></h2>
          ${ord && n > 1 && !T.slots ? `<button type="button" class="fo-btn fo-btn-quiet fo-btn-sm" data-sort>${icon('sort', 'fo-ic fo-ic-sm')}Sort A to Z</button>` : ''}
          ${T.slots && n === 2 ? `<button type="button" class="fo-btn fo-btn-quiet fo-btn-sm" data-swap>${icon('rotate-cw', 'fo-ic fo-ic-sm')}Swap order</button>` : ''}
          ${canAdd ? `<button type="button" class="fo-btn fo-btn-line fo-btn-sm" data-pick>${icon('plus', 'fo-ic fo-ic-sm')}Add more</button>` : !T.multi ? `<button type="button" class="fo-btn fo-btn-line fo-btn-sm" data-pick>Change file</button>` : ''}
          <button type="button" class="fo-btn fo-btn-quiet fo-btn-sm" data-clear>${T.multi ? 'Remove all' : 'Remove'}</button></div>
          <div class="fo-files${T.multi ? '' : ' single'}">${WS.items.map((it, i) => fileCard(it, i, ord)).join('')}
          ${canAdd ? `<button type="button" class="fo-add-tile" data-pick>${icon('plus', 'fo-ic fo-ic-lg')}${T.slots ? esc(T.slots[n] ? 'Add: ' + T.slots[n] : 'Add more files') : 'Add more files'}</button>` : ''}</div>
          ${T.camera ? `<p class="fo-mt"><button type="button" class="fo-btn fo-btn-line fo-btn-sm" data-cam>${icon('camera', 'fo-ic fo-ic-sm')}Take another photo</button></p>` : ''}`;
        applyThumbStyle();
      }
    } else if (WS.phase === 'working') {
      main.innerHTML = `<div class="fo-state">${tile()}<h2>${esc(T.verb)}…</h2><p>${useServer ? 'Your files are processed securely, then deleted.' : 'This happens on your device, so it depends on its speed.'}</p><div class="fo-pbar"><i></i></div><p class="fo-plabel">Getting ready</p></div>`;
    } else if (WS.phase === 'done') {
      main.innerHTML = resultHtml();
    } else if (WS.phase === 'error') {
      const repair = T.accept === 'pdf' && id !== 'repair' && CFG.catalog.some(x => x.id === 'repair') && /damaged|opened|read/i.test(WS.error);
      main.innerHTML = `<div class="fo-state"><span class="fo-ok fo-err">${icon('alert')}</span><h2>That didn’t work</h2><p>${esc(WS.error)}</p>
        <div class="fo-res-actions"><button type="button" class="fo-btn fo-btn-ink" data-retry>Try again</button><button type="button" class="fo-btn fo-btn-line" data-again>${T.accept === 'html' ? 'Edit the code' : 'Choose other files'}</button>${repair ? `<button type="button" class="fo-btn fo-btn-quiet" data-next="repair">Repair the PDF</button>` : ''}</div></div>`;
    } else if (WS.phase === 'server') {
      main.innerHTML = `<div class="fo-state"><span class="fo-tile fo-tile-lg">${icon('server')}</span><h2>${esc(T.name)} needs the processing server</h2>
        <p>This tool runs on a processing server, and this website isn’t connected to one yet. Nothing was uploaded.</p>${altsHtml()}
        <div class="fo-res-actions"><button type="button" class="fo-btn fo-btn-line" data-retry>${T.accept === 'html' ? 'Back to my code' : 'Back to my files'}</button></div></div>`;
    }
  }
  function altsHtml() {
    const alts = CFG.catalog.filter(x => x.runs === 'browser' && x.ready && x.id !== id && (x.accept === T.accept || (T.accept === 'url' && x.accept === 'pdf'))).slice(0, 6);
    return alts.length ? `<div class="fo-next"><h4>These tools work right now, in your browser</h4><div>${alts.map(x => `<a class="fo-chip" data-cat="${esc(x.color)}" href="${esc(x.url)}">${icon(x.icon)}${esc(x.name)}</a>`).join('')}</div></div>` : '';
  }

  /* ---- region editor (ID cards, passport photos, blur) ---- */
  async function ensureSource() {
    if (!T.regions || WS.source || !goodItems().length || (T.regions.skip && T.regions.skip(WS))) return;
    const seq = WS.seq;
    WS.source = { loading: true };
    try {
      const src = await T.regions.source(WS);
      if (seq !== WS.seq) return;
      const url = URL.createObjectURL(await canvasToBlob(src.canvas, 'image/jpeg', .88)); WS.urls.push(url);
      WS.source = { canvas: src.canvas, url, w: src.canvas.width, h: src.canvas.height, info: src.info || null };
      WS.regions = T.regions.rects(WS, WS.source);
    } catch (e) {
      if (seq !== WS.seq) return;
      WS.source = { err: e instanceof UserError ? e.message : 'The preview couldn’t be made from this file.' };
    }
    if (WS.phase === 'ready') renderMain();
    updateCta();
  }
  function renderRegions() {
    const host = $('.fo-reg-host', main); if (!host) return;
    if (T.regions.skip && T.regions.skip(WS)) { host.innerHTML = `<div class="fo-files">${WS.items.map((it, i) => fileCard(it, i, false)).join('')}</div>${T.regions.skipNote ? `<p class="fo-plabel">${esc(T.regions.skipNote)}</p>` : ''}`; return; }
    if (!WS.source || WS.source.loading) { host.innerHTML = `<div class="fo-state fo-state-sm"><div class="fo-pbar indet"><i></i></div><p class="fo-plabel">Preparing the preview…</p></div>`; ensureSource(); return; }
    if (WS.source.err) { host.innerHTML = `<div class="fo-note fo-note-err">${icon('alert')}<span>${esc(WS.source.err)}</span></div>`; return; }
    regionEditor(host, { src: WS.source.url, w: WS.source.w, h: WS.source.h, rects: WS.regions || [], multi: !!T.regions.multi, onChange: r => { WS.regions = r; updateCta(); } });
    if (T.regions.after) host.insertAdjacentHTML('beforeend', T.regions.after(WS));
  }

  /* ---- results ---- */
  function resultHtml() {
    const outs = WS.outputs, r = WS.result || {};
    const title = r.title || (outs.length > 1 ? `${outs.length} files are ready` : 'Your file is ready');
    const isPdf = o => /\.pdf$/i.test(o.name), isImg = o => /\.(jpe?g|png|webp|gif|ico|svg)$/i.test(o.name), isRaster = o => /\.(jpe?g|png|webp|gif|ico)$/i.test(o.name);
    const iconFor = o => isPdf(o) ? ['file', 'from'] : isImg(o) ? ['image', 'image'] : /\.(md|txt)$/i.test(o.name) ? ['text', 'from'] : /\.zip$/i.test(o.name) ? ['zip', 'organize'] : ['file', 'organize'];
    const rows = outs.length > 1 ? `<div class="fo-outs">${outs.slice(0, 80).map(o => { const [ic, c] = iconFor(o); return `<div class="fo-out"><span class="fo-tile fo-tile-sm" data-cat="${c}">${icon(ic)}</span><div><b>${esc(o.name)}</b><small class="${o.good ? 'good' : ''}">${esc(o.note || fmtSize(o.blob.size))}</small></div>${isPdf(o) || isImg(o) ? `<a class="fo-icon-btn" href="${o.url}" target="_blank" rel="noopener" aria-label="Preview ${esc(o.name)}">${icon('eye', 'fo-ic fo-ic-sm')}</a>` : ''}<a class="fo-btn fo-btn-line fo-btn-sm" href="${o.url}" download="${esc(o.name)}">${icon('download', 'fo-ic fo-ic-sm')}Save</a></div>`; }).join('')}${outs.length > 80 ? `<p class="fo-plabel">And ${outs.length - 80} more in the ZIP file.</p>` : ''}</div>` : '';
    const o1 = outs[0];
    const sub = !o1 ? '' : outs.length === 1 ? `<p><b>${esc(o1.name)}</b><br><span class="${o1.good ? 'fo-good' : ''}">${esc(o1.note ? o1.note + ', ' + fmtSize(o1.blob.size) : fmtSize(o1.blob.size))}</span></p>` : `<p>${fmtSize(outs.reduce((s, o) => s + o.blob.size, 0))} in total.</p>`;
    const mainBtn = !o1 ? '' : outs.length === 1
      ? `<a class="fo-btn fo-btn-ink fo-btn-lg" href="${o1.url}" download="${esc(o1.name)}">${icon('download')}Download ${esc(extOf(o1.name).toUpperCase() || 'file')}</a>${isPdf(o1) || isImg(o1) ? `<a class="fo-btn fo-btn-line fo-btn-lg" href="${o1.url}" target="_blank" rel="noopener">${icon('eye')}Preview</a>` : ''}`
      : `<button type="button" class="fo-btn fo-btn-ink fo-btn-lg" data-zip>${icon('zip')}Download all as ZIP</button>`;
    const copyText = r.md || r.text;
    let extra = '';
    if (copyText) extra += (r.textNote ? `<p class="fo-plabel">${esc(r.textNote)}</p>` : '') + `<pre class="fo-md">${esc(copyText.length > 20000 ? copyText.slice(0, 20000) + '\n…' : copyText)}</pre>`;
    if (r.diff) extra += diffHtml(r);
    if (T.resultHtml) extra += T.resultHtml(r, WS) || '';
    const nextIds = (outs.length && outs.every(isPdf) ? ['compress', 'merge', 'sign', 'watermark', 'pagenum', 'protect', 'split'] : outs.length && outs.every(isRaster) ? ['imgcompress', 'imgkb', 'imgresize', 'imgcrop', 'jpg2pdf'] : [])
      .filter(x => x !== id && CFG.catalog.some(c => c.id === x && c.ready)).slice(0, 6);
    return `<div class="fo-state"><span class="fo-ok">${icon('check')}</span><h2>${esc(title)}</h2>${sub}
      <div class="fo-res-actions">${mainBtn}${copyText ? `<button type="button" class="fo-btn fo-btn-line fo-btn-lg" data-copy>${icon('copy')}Copy text</button>` : ''}</div>
      ${extra}${rows}
      ${nextIds.length ? `<div class="fo-next"><h4>Keep going with ${outs.length > 1 ? 'these files' : 'this file'}</h4><div>${nextIds.map(x => { const c = CFG.catalog.find(k => k.id === x); return `<button type="button" class="fo-chip" data-cat="${esc(c.color)}" data-next="${x}">${icon(c.icon)}${esc(c.name)}</button>`; }).join('')}</div></div>` : ''}
      <div class="fo-res-actions"><button type="button" class="fo-btn fo-btn-quiet" data-again>${icon('rotate-ccw', 'fo-ic fo-ic-sm')}Start over</button></div></div>`;
  }
  function diffHtml(r) {
    const rows = r.diff, show = new Array(rows.length).fill(false);
    rows.forEach((x, i) => { if (x.k !== 'ctx') for (let k = Math.max(0, i - 2); k <= Math.min(rows.length - 1, i + 2); k++) show[k] = true; });
    if (!r.add && !r.del) return `<div class="fo-diff"><div class="fo-diff-stats"><span>The text in both files is identical.</span><span>${esc(r.a)} and ${esc(r.b)}</span></div></div>`;
    let html = '', i = 0;
    const line = x => `<div class="fo-dl ${x.k}"><span class="pg">p${x.p}</span><span class="sg">${x.k === 'add' ? '+' : x.k === 'del' ? '−' : ''}</span><span>${esc(x.t)}</span></div>`;
    while (i < rows.length) {
      if (show[i]) { html += line(rows[i]); i++; continue; }
      let j = i; while (j < rows.length && !show[j]) j++;
      html += `<button type="button" class="fo-dl-skip" data-expand="${i}-${j}">Show ${j - i} unchanged line${j - i > 1 ? 's' : ''}</button>`;
      i = j;
    }
    return `<div class="fo-diff"><div class="fo-diff-stats"><span class="a">+${r.add} added</span><span class="r">−${r.del} removed</span><span>Original: ${esc(r.a)}</span></div><div class="fo-diff-body">${html}</div></div>`;
  }

  /* ---- adding files and reading them ---- */
  function accepts(f) { return accept.kinds.includes(kindOf(f)) || (T.acceptAlso && T.acceptAlso(f)); }
  function addFiles(list) {
    if (T.accept === 'url' || WS.phase === 'working' || WS.phase === 'unavailable') return;
    if (T.accept === 'html') { if (T.onFiles) { if (WS.phase !== 'empty') setPhase('empty'); T.onFiles([...list], WS); } return; }
    if (['done', 'error', 'server'].includes(WS.phase)) clearItems();
    let files = [...list];
    const bad = files.filter(f => !accepts(f));
    files = files.filter(accepts);
    if (bad.length) toast(`${T.name} works with ${accept.nouns}. Skipped ${bad.length === 1 ? bad[0].name : bad.length + ' files'}.`, 'error');
    if (useServer) {
      const big = files.filter(f => f.size > CFG.maxFileMB * 1048576);
      if (big.length) { toast(`${big[0].name} is larger than ${CFG.maxFileMB} MB.`, 'error'); files = files.filter(f => !big.includes(f)); }
    }
    if (!files.length) { if (WS.phase !== 'ready') setPhase(WS.items.length ? 'ready' : 'empty'); return; }
    if (!T.multi) { if (files.length > 1) toast(`${T.name} works on one file at a time, so we used ${files[0].name}.`); clearItems(); files = [files[0]]; }
    if (maxFiles) { const room = maxFiles - WS.items.length; if (files.length > room) { toast(`${T.name} takes up to ${maxFiles} files at a time.`); files = files.slice(0, Math.max(0, room)); } }
    if (T.regions) { WS.source = null; WS.regions = null; }
    const seq = WS.seq, items = files.map(mkItem);
    WS.items.push(...items);
    setPhase('ready');
    items.forEach(it => { WS.queue = WS.queue.then(() => loadMeta(it, seq)).catch(e => console.warn(e)); });
    WS.queue = WS.queue.then(() => { if (seq === WS.seq && T.onItems) return T.onItems(WS); }).catch(e => console.warn(e));
  }
  WS.addFiles = addFiles;
  function refreshItem(it) {
    const el = $(`[data-iid="${it.id}"]`, main); if (!el) return;
    const th = $('.fo-thumb', el);
    th.innerHTML = thumbHtml(it);
    if (it.pw && !T.multi) th.style.setProperty('--ar', it.pw / it.ph);
    const mt = $('.fo-file-meta', el); mt.textContent = metaText(it); mt.classList.toggle('err', !!it.err);
  }
  let warnedOffline = false;
  async function loadMeta(it, seq) {
    if (seq !== WS.seq) return;
    if (it.kind === 'image' || it.kind === 'svg') {
      it.thumb = URL.createObjectURL(it.file); WS.urls.push(it.thumb);
      try {
        if (it.kind === 'svg') { const d = await decodeImage(it.file); it.pw = d.w; it.ph = d.h; d.done(); }
        else { const b = await createImageBitmap(it.file, { imageOrientation: 'from-image' }); it.pw = b.width; it.ph = b.height; b.close(); }
        it.note = `${it.pw} × ${it.ph} px`;
      } catch (e) { it.err = useServer ? null : 'This image can’t be opened in this browser.'; }
      refreshItem(it); updateCta();
      if (T.regions && seq === WS.seq) ensureSource();
      return;
    }
    if (it.kind === 'heic') { it.note = 'HEIC photo'; refreshItem(it); updateCta(); return; }
    if (it.kind !== 'pdf') return;
    let pdf;
    try { pdf = await pdfjsDoc(it.file, WS.opts.pw); }
    catch (e) {
      if (seq !== WS.seq) return;
      if (e && e.message === 'offline') { if (!warnedOffline) { warnedOffline = true; toast('Previews need an internet connection the first time.', 'error'); } }
      else if (e && e.name === 'PasswordException') { it.locked = true; it.note = WS.opts.pw ? 'Wrong password' : 'Password-protected'; if (!useServer && !T.passwords) it.err = 'Password-protected. Unlock it first.'; }
      else if (id === 'repair') it.note = 'Damaged file';
      else if (!useServer) it.err = 'This file can’t be read as a PDF.';
      refreshItem(it); updateCta();
      if (T.pages && WS.items[0] === it) { WS.pages = null; renderMain(); }
      if (T.regions && seq === WS.seq) ensureSource();
      return;
    }
    try {
      if (seq !== WS.seq) return;
      it.locked = false;
      it.pages = pdf.numPages; refreshItem(it);
      const page = await pdf.getPage(1), vp1 = page.getViewport({ scale: 1 });
      it.pw = vp1.width; it.ph = vp1.height;
      const c = await renderPage(page, (T.multi ? 260 : 640) / vp1.width);
      if (seq !== WS.seq) return;
      const u = URL.createObjectURL(await canvasToBlob(c, 'image/jpeg', .82)); WS.urls.push(u); c.width = c.height = 0;
      it.thumb = u; refreshItem(it);
      page.cleanup();
      if (T.pages && WS.items[0] === it) await loadPages(it, pdf, seq);
    } catch (e) { console.warn(e); }
    finally { pdf.destroy(); updateCta(); if (T.regions && seq === WS.seq) ensureSource(); }
  }
  async function loadPages(it, pdf, seq) {
    WS.pages = Array.from({ length: pdf.numPages }, (_, i) => ({ i, rot: 0, thumb: null, key: 'p' + i }));
    WS.allPages = WS.pages.slice();
    renderMain(); updateCta();
    for (let i = 0; i < pdf.numPages; i++) {
      if (seq !== WS.seq) return;
      const page = await pdf.getPage(i + 1);
      const c = await renderPage(page, 170 / page.getViewport({ scale: 1 }).width);
      const url = URL.createObjectURL(await canvasToBlob(c, 'image/jpeg', .75)); WS.urls.push(url); c.width = c.height = 0;
      page.cleanup();
      if (seq !== WS.seq) return;
      const p = WS.allPages[i]; p.thumb = url;
      const el = $(`[data-pkey="${p.key}"] .fo-thumb`, main);
      if (el) el.innerHTML = `<img src="${url}" alt="" style="${rotStyle(p.rot)}">`;
    }
  }
  /* reads the files again (after a password was typed) */
  function reloadMeta() {
    clearTimeout(WS.reloadT);
    WS.reloadT = setTimeout(() => {
      if (!WS.items.length || WS.phase !== 'ready') return;
      const files = WS.items.map(i => i.file);
      clearItems(); addFiles(files);
    }, 450);
  }

  /* ---- running ---- */
  async function runTool() {
    if (WS.phase === 'working' || runBtn.disabled) return;
    const v = T.validate && T.validate(WS.opts, goodItems(), WS);
    if (v) { toast(v, 'error'); return; }
    const items = T.accept === 'html' && T.codeFile ? [mkItem(T.codeFile(WS))] : goodItems();
    clearOutputs(); WS.error = '';
    const seq = WS.seq;
    setPhase('working');
    WS.started = performance.now();
    const ctx = { progress: setProgress, pages: WS.pages && WS.pages.map(p => ({ i: p.i, rot: p.rot })), regions: WS.regions, source: WS.source, result: null, alive: () => seq === WS.seq, ws: WS };
    const exec = useServer ? 'server' : 'browser';
    try {
      const outs = useServer ? await serverRun(T, items, WS.opts, ctx) : await T.run(items, WS.opts, ctx);
      if (seq !== WS.seq) return;
      setProgress(1, 'Done');
      WS.outputs = (outs || []).map(o => ({ ...o, url: URL.createObjectURL(o.blob) }));
      WS.result = ctx.result;
      setPhase('done');
      track({ type: 'tool_run', tool: id, exec, status: 'done', ms: Math.round(performance.now() - WS.started), files: items.length, name: runName(items) });
      if (HAS_GSAP() && !REDUCED) gsap.from($('.fo-ok', main), { scale: .6, opacity: 0, duration: .45, ease: 'back.out(2.2)' });
      const top = root.getBoundingClientRect().top;
      if (top < 0) root.scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth', block: 'start' });
    } catch (e) {
      if (seq !== WS.seq) return;
      if (e instanceof NoServer) return setPhase('server');
      if (!(e instanceof UserError)) console.error(e);
      WS.error = e instanceof UserError ? e.message : friendly(e);
      setPhase('error');
      track({ type: 'tool_run', tool: id, exec, status: 'failed', ms: Math.round(performance.now() - WS.started), files: items.length, name: runName(items) });
    }
  }
  /* what the report shows as the file: the first file's name (+ how many more), or the web address's host */
  function runName(list) {
    if (list && list.length) return list[0].name + (list.length > 1 ? ' (+' + (list.length - 1) + ')' : '');
    try { return WS.opts.url ? new URL(/^https?:/i.test(WS.opts.url) ? WS.opts.url : 'https://' + WS.opts.url).host : ''; } catch (e) { return ''; }
  }
  async function downloadZip(btn) {
    btn.disabled = true; const old = btn.innerHTML; btn.textContent = 'Preparing ZIP…';
    try {
      const JSZip = await lib('jszip'), zip = new JSZip();
      const used = {};
      WS.outputs.forEach(o => { let n = o.name; if (used[n]) n = baseName(n) + '-' + (++used[n]) + (extOf(n) ? '.' + extOf(n) : ''); else used[n] = 1; zip.file(n, o.blob); });
      const blob = await zip.generateAsync({ type: 'blob' });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
      a.download = `fileora-${id}.zip`; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    } catch (e) { toast('The ZIP file couldn’t be created. Save the files one by one instead.', 'error'); }
    btn.disabled = false; btn.innerHTML = old;
  }
  function pickFiles(camera) {
    const inp = camera ? $('.fo-cam-in', root) : $('.fo-file-in', root);
    if (!camera) { inp.accept = accept.input; inp.multiple = !!T.multi; }
    inp.value = ''; inp.click();
  }
  const move = (arr, from, to) => { if (to < 0 || to >= arr.length || from === to) return; const [x] = arr.splice(from, 1); arr.splice(to, 0, x); };

  /* ---- events ---- */
  ['.fo-file-in', '.fo-cam-in'].forEach(s => $(s, root).addEventListener('change', e => { const f = [...e.target.files]; e.target.value = ''; if (f.length) addFiles(f); }));
  runBtn.addEventListener('click', runTool);
  main.addEventListener('click', e => {
    const b = e.target.closest('button, a'); if (!b || !main.contains(b)) return;
    const d = b.dataset;
    if ('pick' in d) return pickFiles(false);
    if ('cam' in d) return pickFiles(true);
    if ('clear' in d || 'again' in d) { clearItems(); return setPhase('empty'); }
    if ('retry' in d) return setPhase(WS.items.length ? 'ready' : 'empty');
    if ('sort' in d) { WS.items.sort((a, c) => a.name.localeCompare(c.name, undefined, { numeric: true })); return renderMain(); }
    if ('swap' in d) { WS.items.reverse(); return renderMain(); }
    if ('zip' in d) return downloadZip(b);
    if ('copy' in d) { const t = (WS.result && (WS.result.md || WS.result.text)) || ''; navigator.clipboard.writeText(t).then(() => toast('Copied to the clipboard', 'ok'), () => toast('Copy isn’t allowed here. Download the file instead.', 'error')); return; }
    if ('copyval' in d) { navigator.clipboard.writeText(d.copyval).then(() => toast(`Copied ${d.copyval}`, 'ok'), () => {}); return; }
    if ('next' in d) { e.preventDefault(); const files = WS.outputs.length ? WS.outputs.map(o => new File([o.blob], o.name, { type: o.blob.type || 'application/octet-stream' })) : WS.items.map(i => i.file); return goToTool(d.next, files); }
    if ('expand' in d) { const [a, c] = d.expand.split('-').map(Number); const rows = WS.result.diff.slice(a, c); b.outerHTML = rows.map(x => `<div class="fo-dl ctx"><span class="pg">p${x.p}</span><span class="sg"></span><span>${esc(x.t)}</span></div>`).join(''); return; }
    if ('remove' in d) { WS.items = WS.items.filter(i => i.id !== d.remove); if (T.regions) { WS.source = null; WS.regions = null; } if (!WS.items.length) { clearItems(); return setPhase('empty'); } renderMain(); return updateCta(); }
    if ('move' in d) { const el = b.closest('[data-iid]'), i = WS.items.findIndex(x => x.id === el.dataset.iid); move(WS.items, i, i + +d.move); renderMain(); const nb = $(`[data-iid="${el.dataset.iid}"] [data-move="${d.move}"]`, main); (nb && !nb.disabled ? nb : $(`[data-iid="${el.dataset.iid}"] [data-move]:not([disabled])`, main))?.focus(); return; }
    if ('preset' in d) { if (WS.allPages) { WS.pages = WS.allPages.map(p => (p.rot = 0, p)); renderMain(); updateCta(); } return; }
    const pel = b.closest('[data-pkey]');
    if (pel && WS.pages) {
      const k = WS.pages.findIndex(p => p.key === pel.dataset.pkey), p = WS.pages[k];
      if ('pmove' in d) { move(WS.pages, k, k + +d.pmove); renderMain(); $(`[data-pkey="${p.key}"] [data-pmove="${d.pmove}"]`, main)?.focus(); }
      else if ('prot' in d) { p.rot = (p.rot + 90) % 360; const img = $('.fo-thumb img', pel); if (img) img.style.cssText = rotStyle(p.rot); $('.fo-file-name', pel).textContent = `Page ${p.i + 1}${p.rot ? `, turned ${p.rot}°` : ''}`; }
      else if ('pdel' in d) { WS.pages.splice(k, 1); renderMain(); updateCta(); }
    }
  });
  /* drag to reorder (files and pages) */
  let dragKey = null;
  const keyOf = el => el.dataset.iid || el.dataset.pkey;
  main.addEventListener('dragstart', e => { const el = e.target.closest('.fo-file[draggable="true"]'); if (!el) return; dragKey = keyOf(el); el.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', dragKey); });
  main.addEventListener('dragover', e => {
    if (!dragKey) return;
    const el = e.target.closest('.fo-file[draggable="true"]'); e.preventDefault();
    $$('.drop-before,.drop-after', main).forEach(x => x.classList.remove('drop-before', 'drop-after'));
    if (!el || keyOf(el) === dragKey) return;
    const r = el.getBoundingClientRect(); el.classList.add(e.clientX < r.left + r.width / 2 ? 'drop-before' : 'drop-after');
  });
  main.addEventListener('drop', e => {
    if (!dragKey) return;
    e.preventDefault(); e.stopPropagation();
    const el = e.target.closest('.fo-file[draggable="true"]');
    if (el && keyOf(el) !== dragKey) {
      const arr = WS.pages && T.pages ? WS.pages : WS.items, kf = x => x.id || x.key;
      const from = arr.findIndex(x => kf(x) === dragKey);
      const [x] = arr.splice(from, 1);
      let to = arr.findIndex(y => kf(y) === keyOf(el));
      if (el.classList.contains('drop-after')) to++;
      arr.splice(to, 0, x);
    }
    dragKey = null; renderMain();
  });
  main.addEventListener('dragend', () => { dragKey = null; $$('.dragging,.drop-before,.drop-after', main).forEach(x => x.classList.remove('dragging', 'drop-before', 'drop-after')); });
  /* files dropped from the computer */
  root.addEventListener('dragover', e => { if (!dragKey && e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files')) { e.preventDefault(); root.classList.add('is-over'); } });
  root.addEventListener('dragleave', e => { if (!root.contains(e.relatedTarget)) root.classList.remove('is-over'); });
  root.addEventListener('drop', e => { root.classList.remove('is-over'); if (dragKey || !e.dataTransfer || !e.dataTransfer.files.length) return; e.preventDefault(); e.stopPropagation(); addFiles(e.dataTransfer.files); });

  /* ---- start ---- */
  renderOptsPanel();
  const unavailable = useServer && meta.available === false;
  setPhase(unavailable ? 'unavailable' : 'empty');
  if (useServer && !CFG.backend && !unavailable) WS.noBackend = true;
  root.classList.add('is-ready');
  return WS;
}
