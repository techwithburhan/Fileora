/* Fileora first-party visit counter.
   Keeps a random visitor id in localStorage and a visit id in sessionStorage
   (a visit ends after 30 minutes without activity). No cookies. Sends one
   event per page, tool runs reported by the tool engine, and a small
   "still here" ping once a minute while the tab is visible.
   Nothing is sent when the visitor's browser asks not to be tracked
   (Do Not Track / Global Privacy Control) and the site respects that. */
(function () {
  'use strict';
  var C = window.FileoraTrackConfig;
  if (!C || !C.url) return;
  var off = C.dnt && (navigator.doNotTrack === '1' || window.doNotTrack === '1' || navigator.globalPrivacyControl === true);
  var IDLE = 30 * 60 * 1000;

  function rid() {
    var a = new Uint8Array(16);
    (window.crypto || window.msCrypto).getRandomValues(a);
    var s = '';
    for (var i = 0; i < a.length; i++) s += ('0' + a[i].toString(16)).slice(-2);
    return s;
  }
  function get(st, k) { try { return window[st].getItem(k); } catch (e) { return null; } }
  function set(st, k, v) { try { window[st].setItem(k, v); return window[st].getItem(k) === v; } catch (e) { return false; } }

  var isNew = false;
  var vid = get('localStorage', 'fileora.vid');
  if (!/^[a-f0-9]{32}$/.test(vid || '')) {
    vid = rid(); isNew = true;
    if (!set('localStorage', 'fileora.vid', vid)) vid = ''; // storage blocked: the server falls back to a daily id
  }
  var sid = get('sessionStorage', 'fileora.sid');
  var last = +get('sessionStorage', 'fileora.sts') || 0;
  var fresh = false;
  if (!/^[a-f0-9]{32}$/.test(sid || '') || Date.now() - last > IDLE) {
    sid = rid(); fresh = true;
    if (!set('sessionStorage', 'fileora.sid', sid)) sid = vid ? rid() : '';
  }
  if (isNew && sid) set('localStorage', 'fileora.first', sid);
  var newVisit = isNew || (!!sid && get('localStorage', 'fileora.first') === sid);
  function touch() { set('sessionStorage', 'fileora.sts', String(Date.now())); }

  function send(e) {
    if (off) return;
    e.visitor = vid; e.sid = sid; touch();
    if (!e.eid) e.eid = rid().slice(0, 16); // event id: the server stores each event once
    var body = JSON.stringify(e);
    try { if (navigator.sendBeacon && navigator.sendBeacon(C.url, new Blob([body], { type: 'application/json' }))) return; } catch (x) { /* fall back to fetch */ }
    try { fetch(C.url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body, keepalive: true, credentials: 'same-origin' }); } catch (x) { /* ignore */ }
  }

  window.FileoraTrack = {
    event: send,
    sid: function () { return off ? '' : sid; },
    visitor: function () { return vid; },
    isNew: isNew,
    newVisit: newVisit,
    off: off
  };

  var pv = { type: 'page_view', page: C.page, tool: C.tool || '', url: location.pathname };
  if (fresh) { pv.ref = document.referrer || ''; pv['new'] = isNew ? 1 : 0; }
  send(pv);
  if (C.tool) send({ type: 'tool_view', tool: C.tool, url: location.pathname });

  /* "still here": once a minute while visible and the visitor was active in the last 30 minutes */
  var lastInput = Date.now();
  ['pointerdown', 'keydown', 'scroll', 'touchstart'].forEach(function (ev) { addEventListener(ev, function () { lastInput = Date.now(); }, { passive: true }); });
  setInterval(function () {
    if (document.visibilityState === 'visible' && Date.now() - lastInput < IDLE) send({ type: 'ping', url: location.pathname });
  }, 60000);
})();
