<?php
/**
 * Search-engine basics for tool pages: page title, meta description and
 * structured data (WebApplication, FAQPage, BreadcrumbList).
 *
 * When an SEO plugin (Yoast, Rank Math, All in One SEO, SEOPress, The SEO
 * Framework) is active, it owns the title and description; Fileora then only
 * adds the structured data. Tool pages are public posts, so WordPress's own
 * sitemap (wp-sitemap.xml) lists them automatically.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_SEO {

	public static function init() {
		add_filter( 'document_title_parts', array( __CLASS__, 'title' ), 20 );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 2 );
		add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'sitemap_args' ), 10, 2 );
	}

	public static function seo_plugin_active() {
		return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || defined( 'THE_SEO_FRAMEWORK_VERSION' );
	}

	private static function current_tool() {
		return is_singular( Fileora_Tool_Registry::POST_TYPE ) ? Fileora_Tool_Registry::by_post( get_queried_object_id() ) : null;
	}

	public static function title( $parts ) {
		if ( self::seo_plugin_active() ) {
			return $parts;
		}
		$tool = self::current_tool();
		if ( $tool ) {
			$parts['title'] = apply_filters( 'fileora_tool_title', self::title_for( $tool ), $tool );
		}
		return $parts;
	}

	/** A tool page's title: Fileora → SEO box, then the tool's own SEO title, then "<name> online, free". */
	public static function title_for( array $tool ) {
		$own = ! empty( $tool['post_id'] ) ? (string) get_post_meta( $tool['post_id'], '_fileora_seo_title', true ) : '';
		if ( '' !== $own ) {
			return $own;
		}
		$def = Fileora_Tool_Registry::definition( $tool['id'] );
		/* translators: %s: tool name */
		return ! empty( $def['seo_title'] ) ? $def['seo_title'] : sprintf( __( '%s Online Free – Fast, No Sign-up', 'fileora' ), $tool['name'] );
	}

	public static function description( array $tool ) {
		$own = ! empty( $tool['post_id'] ) ? (string) get_post_meta( $tool['post_id'], '_fileora_meta_description', true ) : '';
		if ( '' !== $own ) {
			return $own;
		}
		$def = Fileora_Tool_Registry::definition( $tool['id'] );
		if ( ! empty( $def['seo_desc'] ) ) {
			return $def['seo_desc'];
		}
		$extra = 'browser' === Fileora_Tool_Registry::runs_on( $tool )
			? __( 'Free, no sign-up, and your files never leave your device.', 'fileora' )
			: __( 'Free and no sign-up. Files are deleted automatically.', 'fileora' );
		return trim( $tool['desc'] . ' ' . $extra );
	}

	public static function head() {
		$tool = self::current_tool();
		if ( ! $tool ) {
			return;
		}
		$desc = self::description( $tool );
		if ( ! self::seo_plugin_active() ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
			echo '<meta property="og:type" content="website">' . "\n";
			echo '<meta property="og:title" content="' . esc_attr( wp_get_document_title() ) . '">' . "\n";
			echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
			echo '<meta property="og:url" content="' . esc_url( $tool['url'] ) . '">' . "\n";
		}
		$graph   = array();
		$graph[] = array(
			'@type'               => 'WebApplication',
			'name'                => $tool['name'],
			'url'                 => $tool['url'],
			'description'         => $tool['desc'],
			'applicationCategory' => 'UtilitiesApplication',
			'operatingSystem'     => 'Any',
			'browserRequirements' => 'Requires JavaScript',
			'offers'              => array(
				'@type'         => 'Offer',
				'price'         => '0',
				'priceCurrency' => 'USD',
			),
		);
		$faq = Fileora_Tool_Registry::parse_faq( get_post_meta( $tool['post_id'], Fileora_Tool_Registry::META_FAQ, true ) );
		if ( $faq ) {
			$graph[] = array(
				'@type'      => 'FAQPage',
				'mainEntity' => array_map(
					function ( $qa ) {
						return array(
							'@type'          => 'Question',
							'name'           => $qa['q'],
							'acceptedAnswer' => array(
								'@type' => 'Answer',
								'text'  => $qa['a'],
							),
						);
					},
					$faq
				),
			);
		}
		$crumbs = array(
			array(
				'@type'    => 'ListItem',
				'position' => 1,
				'name'     => get_bloginfo( 'name' ),
				'item'     => home_url( '/' ),
			),
		);
		if ( $tool['category'] ) {
			$crumbs[] = array(
				'@type'    => 'ListItem',
				'position' => 2,
				'name'     => $tool['category']['name'],
				'item'     => home_url( '/#cat-' . $tool['category']['slug'] ),
			);
		}
		$crumbs[] = array(
			'@type'    => 'ListItem',
			'position' => count( $crumbs ) + 1,
			'name'     => $tool['name'],
			'item'     => $tool['url'],
		);
		$graph[] = array(
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $crumbs,
		);
		echo '<script type="application/ld+json">' . wp_json_encode(
			array(
				'@context' => 'https://schema.org',
				'@graph'   => $graph,
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG
		) . "</script>\n";
	}

	/** Tool pages in the sitemap follow the catalog order. */
	public static function sitemap_args( $args, $post_type ) {
		if ( Fileora_Tool_Registry::POST_TYPE === $post_type ) {
			$args['orderby'] = 'menu_order';
			$args['order']   = 'ASC';
		}
		return $args;
	}
}
