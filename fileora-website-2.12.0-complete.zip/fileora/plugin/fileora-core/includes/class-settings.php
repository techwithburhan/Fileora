<?php
/**
 * Plugin settings, stored in one option: fileora_core_settings.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Core_Settings {

	const OPTION = 'fileora_core_settings';

	/** Detailed analytics and task records are kept at least this many days (0 = forever). */
	const MIN_RETENTION = 90;

	/** @var array|null Per-request cache. */
	private static $cache = null;

	public static function defaults() {
		return array(
			// Processing server.
			'service_url'          => 'http://127.0.0.1:8000',
			'service_key'          => '',
			// Limits.
			'max_mb'               => 100,
			'max_files'            => 20,
			'daily_limit'          => 30,  // server tasks per visitor per 24 h, 0 = no limit
			// Retention (days).
			'task_retention'       => 180, // 0 = keep forever, otherwise at least 90
			'event_retention'      => 180, // 0 = keep forever, otherwise at least 90
			'health_retention'     => 90,
			'delete_data'          => 0,   // delete tables and settings when the plugin is deleted
			'message_retention'    => 180, // days before contact form messages are deleted
			'contact_email'        => '',  // where contact form messages are emailed (empty = privacy email, else admin email)
			// Monitoring.
			'monitor_interval'     => 5,   // minutes between health checks
			'probe_method'         => 'auto', // auto | icmp | tcp | http (Server Monitoring network probe)
			'probe_host'           => '',     // host or IP to probe; empty = the host of the server address
			'probe_count'          => 3,      // ping packets / TCP connects per check
			// Analytics.
			'analytics'            => 1,
			'respect_dnt'          => 1,
			'exclude_admins'       => 1,
			'ip_mode'              => 'full', // full | anon | none
			'ip_retention'         => 30,     // days before stored IP addresses are erased
			'record_file_names'    => 1,
			'geo_source'           => 'auto', // auto | database | cloudflare | off
			'ip_source'            => 'auto', // auto | remote | cloudflare | forwarded | real
			'login_to_analytics'   => 1,      // open Visitor Analytics after logging in
			// Support role.
			'support_ip'           => 0,      // Support users may see IP addresses
			// Privacy and Security pages.
			'privacy_email'        => '',
			'host_web'             => '',
			'host_server'          => '',
			// Text shown to visitors.
			'deletion_text'        => 'within 1 hour',
			// Blog Editor role.
			'editor_publish'       => 1,
			'editor_delete'        => 0,
			'editor_others'        => 1,
			'editor_reports'       => 0,
		);
	}

	public static function get() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		}
		return self::$cache;
	}

	public static function value( $key ) {
		$s = self::get();
		return isset( $s[ $key ] ) ? $s[ $key ] : null;
	}

	public static function flush_cache() {
		self::$cache = null;
	}

	public static function update( array $values ) {
		$settings = array_merge( self::get(), $values );
		update_option( self::OPTION, $settings, false );
		self::flush_cache();
	}

	/** File size limit in MB for a user (0 = visitor). Filter it to give members more. */
	public static function max_mb( $user_id = 0 ) {
		return max( 1, (int) apply_filters( 'fileora_max_mb', (int) self::value( 'max_mb' ), (int) $user_id ) );
	}

	/** True when a processing server address and shared key are set. */
	public static function backend_configured() {
		$s = self::get();
		return '' !== trim( (string) $s['service_url'] ) && '' !== (string) $s['service_key'];
	}

	/**
	 * Called on activation: keeps existing values, imports the settings of the
	 * earlier single "Fileora" plugin once, and creates a shared key.
	 */
	public static function ensure_defaults() {
		$saved = get_option( self::OPTION, null );
		$settings = is_array( $saved ) ? wp_parse_args( $saved, self::defaults() ) : self::defaults();
		if ( ! is_array( $saved ) ) {
			$old = get_option( 'fileora_settings', null );
			if ( is_array( $old ) ) {
				foreach ( array( 'service_url', 'service_key', 'max_mb', 'max_files', 'daily_limit' ) as $k ) {
					if ( isset( $old[ $k ] ) && '' !== $old[ $k ] ) {
						$settings[ $k ] = $old[ $k ];
					}
				}
				if ( isset( $old['retention_days'] ) ) {
					$settings['task_retention'] = max( self::MIN_RETENTION, (int) $old['retention_days'] );
				}
				update_option( 'fileora_core_imported_disabled', isset( $old['disabled'] ) ? (array) $old['disabled'] : array(), false );
			}
		}
		if ( empty( $settings['service_key'] ) ) {
			$settings['service_key'] = wp_generate_password( 48, false, false );
		}
		update_option( self::OPTION, $settings, false );
		self::flush_cache();
	}

	public static function sanitize( $input ) {
		$d   = self::defaults();
		$old = self::get();
		$in  = is_array( $input ) ? $input : array();

		$url = isset( $in['service_url'] ) ? esc_url_raw( trim( $in['service_url'] ), array( 'http', 'https' ) ) : '';
		$key = isset( $in['service_key'] ) ? preg_replace( '/[^A-Za-z0-9_\-]/', '', $in['service_key'] ) : '';
		if ( ! empty( $in['new_key'] ) ) {
			$key = wp_generate_password( 48, false, false );
		}
		$int = function ( $k, $min, $max ) use ( $in, $d ) {
			$v = isset( $in[ $k ] ) ? absint( $in[ $k ] ) : $d[ $k ];
			return max( $min, min( $max, $v ) );
		};
		$keep = function ( $k ) use ( $in, $d ) {
			$v = isset( $in[ $k ] ) && '' !== $in[ $k ] ? absint( $in[ $k ] ) : $d[ $k ];
			return 0 === $v ? 0 : max( self::MIN_RETENTION, min( 3650, $v ) );
		};
		$flag = function ( $k ) use ( $in ) {
			return empty( $in[ $k ] ) ? 0 : 1;
		};
		$interval = isset( $in['monitor_interval'] ) ? absint( $in['monitor_interval'] ) : $d['monitor_interval'];
		if ( ! in_array( $interval, array( 5, 10, 15, 30, 60 ), true ) ) {
			$interval = $d['monitor_interval'];
		}

		$out = array(
			'service_url'      => $url ? untrailingslashit( $url ) : $old['service_url'],
			'service_key'      => strlen( $key ) >= 24 ? $key : $old['service_key'],
			'max_mb'           => $int( 'max_mb', 1, 2048 ),
			'max_files'        => $int( 'max_files', 1, 100 ),
			'daily_limit'      => $int( 'daily_limit', 0, 100000 ),
			'task_retention'   => $keep( 'task_retention' ),
			'event_retention'  => $keep( 'event_retention' ),
			'health_retention' => $int( 'health_retention', 30, 730 ),
			'delete_data'      => $flag( 'delete_data' ),
			'message_retention' => $int( 'message_retention', 30, 730 ),
			'contact_email'    => isset( $in['contact_email'] ) ? sanitize_email( $in['contact_email'] ) : '',
			'monitor_interval' => $interval,
			'probe_method'     => isset( $in['probe_method'] ) && in_array( $in['probe_method'], array( 'auto', 'icmp', 'tcp', 'http' ), true ) ? $in['probe_method'] : $d['probe_method'],
			'probe_host'       => isset( $in['probe_host'] ) && Fileora_Net_Probe::valid_host( trim( $in['probe_host'] ) ) ? trim( $in['probe_host'] ) : '',
			'probe_count'      => $int( 'probe_count', 1, 10 ),
			'analytics'        => $flag( 'analytics' ),
			'respect_dnt'      => $flag( 'respect_dnt' ),
			'exclude_admins'   => $flag( 'exclude_admins' ),
			'deletion_text'    => isset( $in['deletion_text'] ) && '' !== trim( $in['deletion_text'] ) ? sanitize_text_field( $in['deletion_text'] ) : $d['deletion_text'],
			'editor_publish'   => $flag( 'editor_publish' ),
			'editor_delete'    => $flag( 'editor_delete' ),
			'editor_others'    => $flag( 'editor_others' ),
			'editor_reports'   => $flag( 'editor_reports' ),
			'ip_mode'          => isset( $in['ip_mode'] ) && in_array( $in['ip_mode'], array( 'full', 'anon', 'none' ), true ) ? $in['ip_mode'] : $d['ip_mode'],
			'ip_retention'     => $int( 'ip_retention', 1, 365 ),
			'record_file_names' => $flag( 'record_file_names' ),
			'geo_source'       => isset( $in['geo_source'] ) && in_array( $in['geo_source'], array( 'auto', 'database', 'cloudflare', 'off' ), true ) ? $in['geo_source'] : $d['geo_source'],
			'login_to_analytics' => $flag( 'login_to_analytics' ),
			'ip_source'        => isset( $in['ip_source'] ) && in_array( $in['ip_source'], array( 'auto', 'remote', 'cloudflare', 'forwarded', 'real' ), true ) ? $in['ip_source'] : $d['ip_source'],
			'support_ip'       => $flag( 'support_ip' ),
			'privacy_email'    => isset( $in['privacy_email'] ) ? sanitize_email( $in['privacy_email'] ) : '',
			'host_web'         => isset( $in['host_web'] ) ? sanitize_text_field( $in['host_web'] ) : '',
			'host_server'      => isset( $in['host_server'] ) ? sanitize_text_field( $in['host_server'] ) : '',
		);
		self::$cache = null;
		return $out;
	}
}
