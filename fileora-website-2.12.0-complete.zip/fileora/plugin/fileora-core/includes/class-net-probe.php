<?php
/**
 * Network probe for Server Monitoring: latency, packet loss and reachability
 * of the processing server, measured from the WordPress host.
 *
 * Methods (Settings → Monitoring method):
 *   icmp  ICMP echo with the system "ping" (needs PHP exec() and a ping binary)
 *   tcp   TCP connect time to the server's HTTPS/HTTP port
 *   http  the response time of the /health request itself
 *   auto  ICMP when it works; TCP when PHP can't run ping or the server
 *         doesn't answer pings (e.g. ICMP not allowed in the EC2 security
 *         group); the record says which method was used and why.
 *
 * Nothing is estimated: a measurement that didn't run is stored as NULL.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Net_Probe {

	const METHODS = array( 'auto', 'icmp', 'tcp', 'http' );

	/**
	 * Host (name or IP) and port to probe, from the settings.
	 *
	 * @return array{host:string, port:int}
	 */
	public static function target() {
		$url    = (string) Fileora_Core_Settings::value( 'service_url' );
		$parts  = wp_parse_url( $url );
		$host   = trim( (string) Fileora_Core_Settings::value( 'probe_host' ) );
		$scheme = isset( $parts['scheme'] ) ? strtolower( $parts['scheme'] ) : 'https';
		return array(
			'host' => '' !== $host ? $host : ( isset( $parts['host'] ) ? trim( $parts['host'], '[]' ) : '' ),
			'port' => isset( $parts['port'] ) ? (int) $parts['port'] : ( 'http' === $scheme ? 80 : 443 ),
		);
	}

	/** A host name or an IPv4/IPv6 address, and nothing else (it is passed to ping). */
	public static function valid_host( $host ) {
		$host = (string) $host;
		if ( '' === $host || strlen( $host ) > 253 ) {
			return false;
		}
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return true;
		}
		return (bool) preg_match( '/^(?=.{1,253}$)([A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)(\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$/', $host );
	}

	/** Can this PHP run the system ping? (exec allowed and a ping binary present) */
	public static function icmp_available() {
		if ( ! function_exists( 'exec' ) ) {
			return false;
		}
		$disabled = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );
		if ( in_array( 'exec', $disabled, true ) ) {
			return false;
		}
		return '' !== self::ping_binary();
	}

	private static function ping_binary() {
		foreach ( array( '/usr/bin/ping', '/bin/ping', '/sbin/ping', '/usr/sbin/ping' ) as $p ) {
			if ( @is_executable( $p ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- open_basedir may forbid the check
				return $p;
			}
		}
		return '';
	}

	/**
	 * Runs the probe.
	 *
	 * @param array $health Result of Fileora_Backend_API::check() (used by the "http" method).
	 * @return array{method:string, sent:int|null, received:int|null, loss:float|null, avg_ms:float|null, min_ms:float|null, max_ms:float|null, reachable:bool|null, icmp:string, note:string, port:int}
	 */
	public static function run( array $health ) {
		$method = (string) Fileora_Core_Settings::value( 'probe_method' );
		$method = in_array( $method, self::METHODS, true ) ? $method : 'auto';
		$count  = max( 1, min( 10, (int) Fileora_Core_Settings::value( 'probe_count' ) ) );
		$t      = self::target();
		if ( 'http' === $method ) {
			return self::from_http( $health, $t['port'], 'off', '' );
		}
		if ( ! self::valid_host( $t['host'] ) ) {
			return self::from_http( $health, $t['port'], 'off', __( 'No valid server address to probe; the /health response time is used instead.', 'fileora' ) );
		}
		$icmp_state = 'off';
		$note       = '';
		if ( 'icmp' === $method || 'auto' === $method ) {
			if ( self::icmp_available() ) {
				$icmp = self::ping( $t['host'], $count );
				if ( $icmp['received'] > 0 || 'icmp' === $method ) {
					$icmp['icmp'] = $icmp['received'] > 0 ? 'ok' : $icmp['state'];
					return $icmp;
				}
				$icmp_state = $icmp['state'];
				$note       = 'no-reply' === $icmp['state']
					? __( 'No ICMP replies (ping is probably blocked by the EC2 security group), so a TCP check is used.', 'fileora' )
					: __( 'ping could not run on this host, so a TCP check is used.', 'fileora' );
			} else {
				$icmp_state = 'unavailable';
				$note       = __( 'PHP on this web host can’t run ping (exec() is disabled or there is no ping program), so a TCP check is used.', 'fileora' );
				if ( 'icmp' === $method ) {
					return self::empty_result( 'icmp', $t['port'], 'unavailable', __( 'ICMP was chosen, but PHP on this web host can’t run ping. Choose Automatic or TCP.', 'fileora' ) );
				}
			}
		}
		$tcp         = self::tcp( $t['host'], $t['port'], $count );
		$tcp['icmp'] = $icmp_state;
		$tcp['note'] = $note;
		return $tcp;
	}

	private static function empty_result( $method, $port, $icmp, $note ) {
		return array(
			'method'    => $method,
			'sent'      => null,
			'received'  => null,
			'loss'      => null,
			'avg_ms'    => null,
			'min_ms'    => null,
			'max_ms'    => null,
			'reachable' => null,
			'icmp'      => $icmp,
			'note'      => $note,
			'port'      => (int) $port,
		);
	}

	private static function from_http( array $health, $port, $icmp, $note ) {
		$r = self::empty_result( 'http', $port, $icmp, $note );
		if ( empty( $health['http'] ) && empty( $health['error'] ) ) {
			return $r; // no health check ran (no server address)
		}
		$ok             = ! empty( $health['http'] );
		$r['sent']      = 1;
		$r['received']  = $ok ? 1 : 0;
		$r['loss']      = $ok ? 0.0 : 100.0;
		$r['reachable'] = $ok;
		if ( $ok ) {
			$r['avg_ms'] = (float) $health['latency_ms'];
			$r['min_ms'] = $r['avg_ms'];
			$r['max_ms'] = $r['avg_ms'];
		}
		return $r;
	}

	/** ICMP echo with the system ping. */
	public static function ping( $host, $count ) {
		$r = self::empty_result( 'icmp', 0, 'error', '' );
		// Resolve here, so ping never waits on DNS; exactly $count packets, 1 s apart, 2 s to answer each.
		$ip = filter_var( $host, FILTER_VALIDATE_IP ) ? $host : gethostbyname( $host );
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			$r['note'] = __( 'The address of the server could not be resolved.', 'fileora' );
			return $r;
		}
		$cmd = 'LC_ALL=C ' . self::ping_binary() . ( false !== strpos( $ip, ':' ) ? ' -6' : '' ) . ' -n -c ' . (int) $count . ' -W 2 ' . escapeshellarg( $ip ) . ' 2>&1';
		$out = array();
		$code = 0;
		exec( $cmd, $out, $code ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec -- host is validated and escaped
		$parsed = self::parse_ping( implode( "\n", $out ) );
		if ( null === $parsed ) {
			$r['state'] = 'error';
			$r['note']  = substr( preg_replace( '/\s+/', ' ', implode( ' ', array_slice( $out, -2 ) ) ), 0, 160 );
			return $r;
		}
		$r              = array_merge( $r, $parsed );
		$r['reachable'] = $parsed['received'] > 0;
		$r['state']     = $parsed['received'] > 0 ? 'ok' : 'no-reply';
		return $r;
	}

	/**
	 * Reads the summary of iputils or BusyBox ping output.
	 *
	 * @return array{sent:int, received:int, loss:float, avg_ms:float|null, min_ms:float|null, max_ms:float|null}|null
	 */
	public static function parse_ping( $text ) {
		if ( ! preg_match( '/(\d+) packets transmitted, (\d+) (?:packets )?received/', $text, $m ) ) {
			return null;
		}
		$sent = (int) $m[1];
		$recv = (int) $m[2];
		if ( $sent < 1 ) {
			return null;
		}
		$out = array(
			'sent'     => $sent,
			'received' => $recv,
			'loss'     => round( ( $sent - $recv ) / $sent * 100, 1 ),
			'avg_ms'   => null,
			'min_ms'   => null,
			'max_ms'   => null,
		);
		if ( $recv > 0 && preg_match( '#(?:rtt|round-trip) min/avg/max(?:/mdev)? = ([\d.]+)/([\d.]+)/([\d.]+)#', $text, $t ) ) {
			$out['min_ms'] = (float) $t[1];
			$out['avg_ms'] = (float) $t[2];
			$out['max_ms'] = (float) $t[3];
		}
		return $out;
	}

	/** TCP connect time: connects $count times, 3 s timeout each. DNS is resolved once, outside the timing. */
	public static function tcp( $host, $port, $count ) {
		$r = self::empty_result( 'tcp', $port, 'off', '' );
		if ( ! function_exists( 'stream_socket_client' ) ) {
			$r['note'] = __( 'PHP can’t open network connections on this host.', 'fileora' );
			return $r;
		}
		$ip = filter_var( $host, FILTER_VALIDATE_IP ) ? $host : gethostbyname( $host );
		if ( $ip === $host && ! filter_var( $host, FILTER_VALIDATE_IP ) ) {
			$ip = $host; // no IPv4 address: let the connection resolve it (IPv6-only hosts)
		}
		$addr  = false !== strpos( $ip, ':' ) ? '[' . $ip . ']' : $ip;
		$times = array();
		for ( $i = 0; $i < $count; $i++ ) {
			$t0    = microtime( true );
			$errno = 0;
			$err   = '';
			$sock  = @stream_socket_client( 'tcp://' . $addr . ':' . (int) $port, $errno, $err, 3, STREAM_CLIENT_CONNECT ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( $sock ) {
				$times[] = ( microtime( true ) - $t0 ) * 1000;
				fclose( $sock ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			} elseif ( '' === $r['note'] ) {
				$r['note'] = substr( (string) $err, 0, 160 );
			}
		}
		$r['sent']      = $count;
		$r['received']  = count( $times );
		$r['loss']      = round( ( $count - count( $times ) ) / $count * 100, 1 );
		$r['reachable'] = count( $times ) > 0;
		if ( $times ) {
			$r['avg_ms'] = round( array_sum( $times ) / count( $times ), 2 );
			$r['min_ms'] = round( min( $times ), 2 );
			$r['max_ms'] = round( max( $times ), 2 );
		}
		return $r;
	}

	/** Human label of a method, e.g. "ICMP ping" or "TCP connect, port 443". */
	public static function label( $method, $port = 0 ) {
		switch ( $method ) {
			case 'icmp':
				return __( 'ICMP ping', 'fileora' );
			case 'tcp':
				/* translators: %d: port number */
				return sprintf( __( 'TCP connect, port %d', 'fileora' ), (int) $port );
			case 'http':
				return __( 'HTTP /health response', 'fileora' );
		}
		return __( 'Not Available', 'fileora' );
	}
}
