<?php
/**
 * Front end: tool workspaces, shortcodes, scripts and the page-view beacon.
 *
 *   [fileora tool="merge-pdf"]   a tool's workspace (by slug or id), in any page or post
 *   [fileora_tools]              the tool catalog grouped by category
 *
 * On a tool page (/merge-pdf/) the Fileora theme places the workspace itself
 * (it declares add_theme_support( 'fileora' )). With any other theme the
 * workspace and FAQ are added around the page content automatically.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Core_Frontend {

	/** @var array Tools rendered on this page (id => tool). */
	private static $mounted = array();

	public static function init() {
		add_shortcode( 'fileora', array( __CLASS__, 'shortcode_tool' ) );
		add_shortcode( 'fileora_tools', array( __CLASS__, 'shortcode_catalog' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ), 5 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'tracking' ), 20 );
		add_action( 'wp_body_open', array( __CLASS__, 'sprite_early' ) );
		add_action( 'wp_footer', array( __CLASS__, 'footer' ), 5 );
		add_filter( 'the_content', array( __CLASS__, 'tool_page_content' ), 8 );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
	}

	public static function register_assets() {
		$v = FILEORA_CORE_VERSION;
		wp_register_style( 'fileora-tools', FILEORA_CORE_URL . 'public/css/fileora-tools.css', array(), $v );
		wp_register_script( 'fileora-engine', FILEORA_CORE_URL . 'public/js/fileora-engine.js', array(), $v, true );
		foreach ( Fileora_Tool_Registry::modules() as $mid => $m ) {
			if ( ! empty( $m['script'] ) ) {
				$src = preg_match( '#^https?://#', $m['script'] ) ? $m['script'] : $m['url'] . $m['script'];
				wp_register_script( 'fileora-mod-' . $mid, $src, array( 'fileora-engine' ), $v, true );
			}
		}
		// Load the workspace styles in the head where we know a tool will be shown (avoids a flash of unstyled content).
		$post = get_queried_object();
		if ( is_singular( Fileora_Tool_Registry::POST_TYPE ) || ( $post instanceof WP_Post && ( has_shortcode( $post->post_content, 'fileora' ) || has_shortcode( $post->post_content, 'fileora_tools' ) ) ) ) {
			wp_enqueue_style( 'fileora-tools' );
		}
	}

	/** Light tool list for menus, search and "keep going" suggestions. */
	public static function catalog_data() {
		$out = array();
		foreach ( Fileora_Tool_Registry::visible() as $t ) {
			$out[] = array(
				'id'     => $t['id'],
				'name'   => $t['name'],
				'desc'   => $t['desc'],
				'keys'   => $t['keys'],
				'url'    => $t['url'],
				'icon'   => $t['icon'],
				'cat'    => $t['category'] ? $t['category']['name'] : '',
				'color'  => $t['category'] ? $t['category']['color'] : 'organize',
				'runs'   => Fileora_Tool_Registry::runs_on( $t ),
				'accept' => $t['accept'],
				'ready'  => 'ready' === $t['status'],
			);
		}
		return $out;
	}

	/** Page type for analytics. */
	public static function page_type() {
		if ( is_singular( Fileora_Tool_Registry::POST_TYPE ) ) {
			return 'tool';
		}
		if ( is_front_page() ) {
			return 'home';
		}
		if ( is_singular( 'post' ) ) {
			return 'post';
		}
		if ( is_page() ) {
			return 'page';
		}
		if ( is_search() ) {
			return 'search';
		}
		if ( is_archive() || is_home() ) {
			return 'archive';
		}
		return 'other';
	}

	/** The page-view beacon (and the API the tool engine uses to report runs). */
	public static function tracking() {
		$s = Fileora_Core_Settings::get();
		if ( empty( $s['analytics'] ) || is_admin() || is_preview() ) {
			return;
		}
		if ( ! empty( $s['exclude_admins'] ) && current_user_can( 'manage_options' ) ) {
			return;
		}
		$tool = is_singular( Fileora_Tool_Registry::POST_TYPE ) ? Fileora_Tool_Registry::by_post( get_queried_object() ) : null;
		wp_enqueue_script( 'fileora-track', FILEORA_CORE_URL . 'public/js/fileora-track.js', array(), FILEORA_CORE_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_localize_script(
			'fileora-track',
			'FileoraTrackConfig',
			array(
				'url'  => esc_url_raw( rest_url( Fileora_Core_REST::NS . '/events' ) ),
				'page' => self::page_type(),
				'tool' => $tool ? $tool['id'] : '',
				'dnt'  => ! empty( $s['respect_dnt'] ),
			)
		);
	}

	/**
	 * The workspace for one tool: a container the engine turns into the
	 * interactive tool. Pending tools get a "coming soon" panel instead.
	 */
	public static function render_workspace( $tool, $preset = null ) {
		if ( ! is_array( $tool ) ) {
			$tool = fileora_get_tool( $tool );
		}
		if ( ! $tool ) {
			return '';
		}
		$color = $tool['category'] ? $tool['category']['color'] : 'organize';
		if ( 'ready' !== $tool['status'] ) {
			wp_enqueue_style( 'fileora-tools' );
			self::$mounted[ '_sprite' ] = true;
			return '<div class="fo-app fo-pending" data-cat="' . esc_attr( $color ) . '"><div class="fo-state">'
				. '<span class="fo-tile fo-tile-lg">' . Fileora_Icons::icon( $tool['icon'] ) . '</span>'
				. '<h3>' . esc_html( sprintf( __( '%s is coming soon', 'fileora' ), $tool['name'] ) ) . '</h3>'
				. '<p>' . esc_html__( 'We are still building this tool. It can’t process files yet.', 'fileora' ) . '</p></div></div>';
		}
		self::$mounted[ $tool['id'] ] = $tool;
		wp_enqueue_style( 'fileora-tools' );
		wp_enqueue_script( 'fileora-mod-' . $tool['module'] );
		$runs = Fileora_Tool_Registry::runs_on( $tool );
		$what = Fileora_Tool_Registry::accept_noun( $tool['accept'], true );

		ob_start();
		?>
		<div class="fo-app" id="fo-app-<?php echo esc_attr( $tool['id'] ); ?>" data-fo-tool="<?php echo esc_attr( $tool['id'] ); ?>" data-cat="<?php echo esc_attr( $color ); ?>"<?php echo $preset ? ' data-fo-preset="' . esc_attr( wp_json_encode( $preset ) ) . '"' : ''; ?>>
			<div class="fo-boot">
				<div class="fo-dz">
					<span class="fo-tile fo-tile-lg"><?php echo Fileora_Icons::icon( $tool['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<h3><?php echo 'url' === $tool['accept'] ? esc_html__( 'Which page should we save?', 'fileora' ) : esc_html( sprintf( __( 'Drop %s here', 'fileora' ), $what ) ); ?></h3>
					<p class="fo-muted"><?php echo esc_html( 'browser' === $runs ? __( 'Loading the tool…', 'fileora' ) : __( 'Loading the tool…', 'fileora' ) ); ?></p>
				</div>
				<noscript><p class="fo-note"><?php esc_html_e( 'This tool needs JavaScript. Please turn it on in your browser and reload the page.', 'fileora' ); ?></p></noscript>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	public static function shortcode_tool( $atts ) {
		$atts = shortcode_atts( array( 'tool' => '', 'preset' => '', 'target' => '' ), $atts, 'fileora' );
		$tool = fileora_get_tool( sanitize_title( $atts['tool'] ) );
		if ( ! $tool || ( ! $tool['enabled'] && ! current_user_can( 'fileora_manage_tools' ) ) ) {
			return current_user_can( 'edit_posts' ) ? '<p><em>' . esc_html( sprintf( __( 'Fileora: no tool called “%s”.', 'fileora' ), $atts['tool'] ) ) . '</em></p>' : '';
		}
		// Settings the tool opens with: a named preset (seo-plan/presets.php) or a KB target.
		$preset = null;
		if ( '' !== $atts['preset'] ) {
			$all    = Fileora_SEO_Plan::presets();
			$preset = isset( $all[ $atts['preset'] ] ) ? $all[ $atts['preset'] ] : null;
		} elseif ( '' !== $atts['target'] && is_numeric( $atts['target'] ) ) {
			$kb     = (int) $atts['target'];
			$std    = array( 20, 50, 100, 200, 500 );
			$preset = array( 'opts' => in_array( $kb, $std, true ) ? array( 'target' => (string) $kb ) : array( 'target' => 'custom', 'custom' => $kb ) );
		}
		return self::render_workspace( $tool, $preset );
	}

	/** A simple catalog for themes other than the Fileora theme. */
	public static function shortcode_catalog() {
		wp_enqueue_style( 'fileora-tools' );
		self::$mounted['_sprite'] = true;
		$html = '<div class="fo-catalog">';
		foreach ( Fileora_Tool_Registry::grouped() as $g ) {
			$html .= '<section class="fo-cat" data-cat="' . esc_attr( $g['color'] ) . '"><h3><span class="fo-dot"></span>' . esc_html( $g['name'] ) . '</h3><div class="fo-grid">';
			foreach ( $g['tools'] as $t ) {
				$html .= '<a class="fo-card" href="' . esc_url( $t['url'] ) . '"><span class="fo-tile">' . Fileora_Icons::icon( $t['icon'] ) . '</span><span><b>' . esc_html( $t['name'] ) . '</b><small>' . esc_html( $t['desc'] ) . '</small></span></a>';
			}
			$html .= '</div></section>';
		}
		return $html . '</div>';
	}

	/** Other themes: add the workspace before, and the FAQ after, a tool page's content. */
	public static function tool_page_content( $content ) {
		if ( current_theme_supports( 'fileora' ) || ! is_singular( Fileora_Tool_Registry::POST_TYPE ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		$tool = Fileora_Tool_Registry::by_post( get_the_ID() );
		if ( ! $tool ) {
			return $content;
		}
		$faq  = Fileora_Tool_Registry::parse_faq( get_post_meta( get_the_ID(), Fileora_Tool_Registry::META_FAQ, true ) );
		$html = self::render_workspace( $tool ) . $content;
		if ( $faq ) {
			$html .= '<h2>' . esc_html__( 'Questions, answered', 'fileora' ) . '</h2>';
			foreach ( $faq as $qa ) {
				$html .= '<details class="fo-faq"><summary>' . esc_html( $qa['q'] ) . '</summary><p>' . esc_html( $qa['a'] ) . '</p></details>';
			}
		}
		return $html;
	}

	public static function body_class( $classes ) {
		if ( is_singular( Fileora_Tool_Registry::POST_TYPE ) ) {
			$classes[] = 'fileora-tool-page';
		}
		return $classes;
	}

	/** The Fileora theme uses the icons everywhere, so print them at the top of the body. */
	public static function sprite_early() {
		if ( current_theme_supports( 'fileora' ) ) {
			Fileora_Icons::print_sprite();
		}
	}

	/** Engine configuration and icons, once a workspace was rendered. */
	public static function footer() {
		if ( ! self::$mounted ) {
			return;
		}
		Fileora_Icons::print_sprite();
		$tools = array_filter( self::$mounted, 'is_array' );
		if ( ! $tools ) {
			return;
		}
		$s      = Fileora_Core_Settings::get();
		$config = array(
			'rest'         => esc_url_raw( untrailingslashit( rest_url( Fileora_Core_REST::NS ) ) ),
			'nonce'        => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
			'maxFileMB'    => Fileora_Core_Settings::max_mb( get_current_user_id() ),
			'maxFiles'     => (int) $s['max_files'],
			'backend'      => Fileora_Core_Settings::backend_configured(),
			'deletionText' => (string) $s['deletion_text'],
			'siteName'     => get_bloginfo( 'name' ),
			'tools'        => array(),
			'catalog'      => self::catalog_data(),
			'vendor'       => FILEORA_CORE_URL . 'public/vendor/',
		);
		foreach ( $tools as $id => $t ) {
			$config['tools'][ $id ] = array(
				'id'        => $id,
				'name'      => $t['name'],
				'desc'      => $t['desc'],
				'icon'      => $t['icon'],
				'cat'       => $t['category'] ? $t['category']['name'] : '',
				'color'     => $t['category'] ? $t['category']['color'] : 'organize',
				'runs'      => Fileora_Tool_Registry::runs_on( $t ),
				'exec'      => $t['exec'],
				'accept'    => $t['accept'],
				'maxFiles'  => 'browser' === Fileora_Tool_Registry::runs_on( $t ) ? 0 : min( (int) $s['max_files'], max( 1, (int) $t['max_files'] ) ),
				'available' => 'browser' === $t['exec'] ? true : Fileora_Server_Monitor::tool_available( $id ),
				'url'       => $t['url'],
			);
		}
		/**
		 * Filter the tool engine configuration.
		 */
		$config = apply_filters( 'fileora_engine_config', $config );
		wp_print_inline_script_tag( 'window.FileoraConfig=' . wp_json_encode( $config, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) . ';', array( 'id' => 'fileora-config' ) );
	}
}
