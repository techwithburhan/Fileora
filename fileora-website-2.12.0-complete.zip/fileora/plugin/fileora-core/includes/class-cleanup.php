<?php
/**
 * Housekeeping (WP-Cron). Files themselves are deleted by the processing
 * server; this closes stuck task records and removes old records according
 * to Settings → Data retention.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Core_Cleanup {

	const HOURLY = 'fileora_core_hourly';
	const DAILY  = 'fileora_core_daily';

	public static function init() {
		add_action( self::HOURLY, array( __CLASS__, 'hourly' ) );
		add_action( self::DAILY, array( __CLASS__, 'daily' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOURLY ) ) {
			wp_schedule_event( time() + 300, 'hourly', self::HOURLY );
		}
		if ( ! wp_next_scheduled( self::DAILY ) ) {
			wp_schedule_event( time() + 900, 'daily', self::DAILY );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOURLY );
		wp_clear_scheduled_hook( self::DAILY );
	}

	public static function hourly() {
		Fileora_Task_Manager::fail_stale( 2 * HOUR_IN_SECONDS );
		Fileora_History::rollup();
		if ( Fileora_Geo::db_info() && Fileora_Geo::missing_count() ) {
			Fileora_Geo::backfill( 1000 );
		}
	}

	public static function daily() {
		$s = Fileora_Core_Settings::get();
		Fileora_History::rollup();
		if ( (int) $s['task_retention'] > 0 ) {
			Fileora_Task_Manager::purge( max( Fileora_Core_Settings::MIN_RETENTION, (int) $s['task_retention'] ) );
		}
		Fileora_Analytics::purge( (int) $s['event_retention'] > 0 ? max( Fileora_Core_Settings::MIN_RETENTION, (int) $s['event_retention'] ) : 0 );
		Fileora_Server_Monitor::purge( max( 30, (int) $s['health_retention'] ) );
		Fileora_Analytics::erase_old_ips( max( 1, (int) $s['ip_retention'] ) );
		Fileora_Contact::purge( max( 30, (int) $s['message_retention'] ) );
		Fileora_Task_Manager::erase_old_ips( max( 1, (int) $s['ip_retention'] ) );
	}
}
