<?php
/**
 * The small Markdown subset used by the bundled SEO content (seo-plan/*.md),
 * turned into block-editor markup.
 *
 * Supported: ## / ### headings, paragraphs, - and 1. lists (one nested level),
 * | tables |, > callouts, **bold**, `code`, [links](url), {home} for the site
 * address, ??? Question + answer lines (FAQ), [[cta:slug|Title|Text]] tool
 * buttons and [fileora …] shortcodes on their own line.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

class Fileora_Markdown {

	/** Reads a file with a "---" header. Returns array( meta…, 'body' => … ) or null. */
	public static function parse_file( $file ) {
		if ( ! is_readable( $file ) ) {
			return null;
		}
		return self::parse( (string) file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	}

	public static function parse( $text ) {
		$text = str_replace( "\r\n", "\n", $text );
		if ( ! preg_match( '/^---\n(.*?)\n---\n(.*)$/s', $text, $m ) ) {
			return null;
		}
		$meta = array();
		foreach ( explode( "\n", $m[1] ) as $line ) {
			if ( preg_match( '/^([a-z_]+):\s*(.*)$/', $line, $kv ) ) {
				$meta[ $kv[1] ] = trim( $kv[2] );
			}
		}
		$meta['body'] = trim( $m[2] );
		return $meta;
	}

	public static function inline( $s ) {
		$home  = untrailingslashit( home_url() );
		$codes = array();
		$s     = preg_replace_callback(
			'/\[fileora(?:_[a-z_]+)?(?:\s[^\]]*)?\]/',
			function ( $m ) use ( &$codes ) {
				$codes[] = $m[0];
				return "\x01" . ( count( $codes ) - 1 ) . "\x01";
			},
			$s
		);
		$s = esc_html( $s );
		$s = str_replace( '{home}', $home, $s );
		$s = preg_replace( '/\*\*(.+?)\*\*/', '<strong>$1</strong>', $s );
		$s = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $s );
		$s = preg_replace_callback(
			'/\[([^\]]+)\]\(([^)\s]+)\)/',
			function ( $m ) use ( $home ) {
				$url      = html_entity_decode( $m[2] );
				$external = 0 !== strpos( $url, $home ) && 0 !== strpos( $url, '/' ) && 0 !== strpos( $url, '#' );
				return '<a href="' . esc_url( $url ) . '"' . ( $external ? ' target="_blank" rel="noopener"' : '' ) . '>' . $m[1] . '</a>';
			},
			$s
		);
		return preg_replace_callback(
			'/\x01(\d+)\x01/',
			function ( $m ) use ( $codes ) {
				return $codes[ (int) $m[1] ];
			},
			$s
		);
	}

	private static function para( $text, $class = '' ) {
		$attr = $class ? ' {"className":"' . $class . '"}' : '';
		return '<!-- wp:paragraph' . $attr . ' --><p' . ( $class ? ' class="' . $class . '"' : '' ) . '>' . self::inline( $text ) . '</p><!-- /wp:paragraph -->';
	}

	private static function lst( array $lines ) {
		$ordered = (bool) preg_match( '/^\d+\.\s/', $lines[0] );
		$items   = array();
		foreach ( $lines as $line ) {
			if ( preg_match( '/^\s{2,}-\s+(.*)$/', $line, $m ) && $items ) {
				$items[ count( $items ) - 1 ]['sub'][] = $m[1];
			} elseif ( preg_match( '/^(?:\d+\.|-)\s+(.*)$/', $line, $m ) ) {
				$items[] = array( 'text' => $m[1], 'sub' => array() );
			} elseif ( $items ) {
				$items[ count( $items ) - 1 ]['text'] .= ' ' . trim( $line );
			}
		}
		$tag  = $ordered ? 'ol' : 'ul';
		$html = '<!-- wp:list' . ( $ordered ? ' {"ordered":true}' : '' ) . ' --><' . $tag . ' class="wp-block-list">';
		foreach ( $items as $it ) {
			$html .= '<!-- wp:list-item --><li>' . self::inline( $it['text'] );
			if ( $it['sub'] ) {
				$html .= '<!-- wp:list --><ul class="wp-block-list">';
				foreach ( $it['sub'] as $sub ) {
					$html .= '<!-- wp:list-item --><li>' . self::inline( $sub ) . '</li><!-- /wp:list-item -->';
				}
				$html .= '</ul><!-- /wp:list -->';
			}
			$html .= '</li><!-- /wp:list-item -->';
		}
		return $html . '</' . $tag . '><!-- /wp:list -->';
	}

	private static function table( array $lines ) {
		$rows = array();
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( preg_match( '/^\|[\s:\-|]+\|$/', $line ) ) {
				continue;
			}
			$rows[] = array_map( 'trim', explode( '|', trim( $line, '|' ) ) );
		}
		if ( ! $rows ) {
			return '';
		}
		$head = array_shift( $rows );
		$html = '<!-- wp:table --><figure class="wp-block-table"><table class="has-fixed-layout"><thead><tr>';
		foreach ( $head as $c ) {
			$html .= '<th>' . self::inline( $c ) . '</th>';
		}
		$html .= '</tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$html .= '<tr>';
			foreach ( $r as $c ) {
				$html .= '<td>' . self::inline( $c ) . '</td>';
			}
			$html .= '</tr>';
		}
		return $html . '</tbody></table></figure><!-- /wp:table -->';
	}

	public static function cta( $slug, $title, $text ) {
		$url = home_url( '/' . sanitize_title( $slug ) . '/' );
		return '<!-- wp:html --><div class="tool-cta"><div><strong>' . esc_html( $title ) . '</strong><p>' . esc_html( $text ) . '</p></div><a href="' . esc_url( $url ) . '">' . esc_html__( 'Open the tool', 'fileora' ) . ' →</a></div><!-- /wp:html -->';
	}

	/**
	 * Converts a body to block markup.
	 *
	 * @param string $md       Markdown.
	 * @param bool   $faq_out  True: FAQ entries are returned separately instead of as <details> blocks.
	 * @return string|array   Markup, or array( 'html' => …, 'faq' => array( array( q, a ) ) ) when $faq_out.
	 */
	public static function blocks( $md, $faq_out = false ) {
		$out    = array();
		$faqs   = array();
		// Fenced code (```lang … ```) may contain blank lines, so it is set aside before splitting into blocks.
		$codes = array();
		$md    = preg_replace_callback(
			'/^```([a-z0-9-]*)[ \t]*\n(.*?)\n```[ \t]*$/ms',
			function ( $m ) use ( &$codes ) {
				$codes[] = array( $m[1], $m[2] );
				return "\n@@FOCODE" . ( count( $codes ) - 1 ) . "@@\n";
			},
			str_replace( "\r\n", "\n", $md )
		);
		$blocks = preg_split( "/\n\s*\n/", trim( $md ) );
		$faq    = array();
		$flush  = function () use ( &$faq, &$out, &$faqs, $faq_out ) {
			foreach ( $faq as $qa ) {
				if ( $faq_out ) {
					$faqs[] = $qa;
					continue;
				}
				$out[] = '<!-- wp:details --><details class="wp-block-details"><summary>' . self::inline( $qa[0] ) . '</summary><!-- wp:paragraph --><p>' . self::inline( $qa[1] ) . '</p><!-- /wp:paragraph --></details><!-- /wp:details -->';
			}
			$faq = array();
		};
		foreach ( $blocks as $b ) {
			$lines = explode( "\n", rtrim( $b ) );
			$first = $lines[0];
			if ( 0 === strpos( $first, '??? ' ) ) {
				$faq[] = array( trim( substr( $first, 4 ) ), trim( implode( ' ', array_slice( $lines, 1 ) ) ) );
				continue;
			}
			$flush();
			if ( preg_match( '/^@@FOCODE(\d+)@@$/', trim( $first ), $m ) && isset( $codes[ (int) $m[1] ] ) ) {
				$code  = $codes[ (int) $m[1] ][1]; // plain core code block, so it stays valid in the block editor
				$out[] = '<!-- wp:code --><pre class="wp-block-code"><code>' . esc_html( $code ) . '</code></pre><!-- /wp:code -->';
			} elseif ( preg_match( '/^(#{2,3})\s+(.*)$/', $first, $m ) ) {
				if ( $faq_out && preg_match( '/^(FAQ|Questions)/i', $m[2] ) ) {
					continue; // the FAQ heading belongs to the tool page's own FAQ section
				}
				$level = strlen( $m[1] );
				$out[] = '<!-- wp:heading' . ( 3 === $level ? ' {"level":3}' : '' ) . ' --><h' . $level . ' class="wp-block-heading">' . self::inline( $m[2] ) . '</h' . $level . '><!-- /wp:heading -->';
				if ( count( $lines ) > 1 ) {
					$out[] = self::para( implode( ' ', array_slice( $lines, 1 ) ) );
				}
			} elseif ( preg_match( '/^\[fileora(?:_[a-z_]+)?(?:\s[^\]]*)?\]$/', trim( $first ) ) ) {
				$out[] = '<!-- wp:shortcode -->' . trim( $first ) . '<!-- /wp:shortcode -->';
			} elseif ( preg_match( '/^\[\[cta:([^|]+)\|([^|]+)\|([^\]]+)\]\]$/', trim( $first ), $m ) ) {
				$out[] = self::cta( $m[1], $m[2], $m[3] );
			} elseif ( 0 === strpos( $first, '>' ) ) {
				$text  = trim( implode( ' ', array_map( function ( $l ) { return ltrim( $l, "> \t" ); }, $lines ) ) );
				$out[] = self::para( $text, 'callout' );
			} elseif ( 0 === strpos( $first, '|' ) ) {
				$out[] = self::table( $lines );
			} elseif ( preg_match( '/^(?:-|\d+\.)\s/', $first ) ) {
				$out[] = self::lst( $lines );
			} else {
				$out[] = self::para( implode( ' ', $lines ) );
			}
		}
		$flush();
		$html = implode( "\n\n", $out );
		return $faq_out ? array( 'html' => $html, 'faq' => $faqs ) : $html;
	}
}
