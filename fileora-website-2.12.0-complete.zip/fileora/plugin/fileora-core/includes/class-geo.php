<?php
/**
 * Approximate visitor location (country, region, city) for Visitor Analytics.
 *
 * No third-party lookup service is called. The location comes from either:
 *   - a local IP database file (.mmdb) in wp-content/uploads/fileora-geo/:
 *     DB-IP "IP to City Lite" (free, CC BY 4.0, downloaded from Settings and
 *     updated monthly) or a MaxMind GeoLite2/GeoIP2 City file you upload; or
 *   - the location headers Cloudflare adds when the site runs behind it
 *     (CF-IPCountry, and with "Add visitor location headers": CF-Region, CF-IPCity).
 *
 * Settings → Visitor location chooses the source (auto = database if present,
 * otherwise Cloudflare headers).
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Geo {

	const CRON     = 'fileora_geo_update';
	const JOB      = 'fileora_geo_download_job';
	const BACKFILL = 'fileora_geo_backfill';
	const STATUS   = 'fileora_geo_status';

	/** @var \MaxMind\Db\Reader|false|null */
	private static $reader = null;

	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'scheduled_update' ) );
		add_action( self::JOB, array( __CLASS__, 'run_download_job' ) );
		add_action( self::BACKFILL, array( __CLASS__, 'backfill_job' ) );
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
	}

	public static function schedules( $s ) {
		$s['fileora_monthly'] = array(
			'interval' => 30 * DAY_IN_SECONDS,
			'display'  => __( 'Once a month (Fileora)', 'fileora' ),
		);
		return $s;
	}

	public static function dir() {
		$u = wp_upload_dir( null, false );
		return trailingslashit( $u['basedir'] ) . 'fileora-geo';
	}

	/** The database file in use (the newest .mmdb in the folder), or ''. */
	public static function db_file() {
		$files = glob( self::dir() . '/*.mmdb' );
		if ( ! $files ) {
			return '';
		}
		usort(
			$files,
			function ( $a, $b ) {
				return filemtime( $b ) <=> filemtime( $a );
			}
		);
		return $files[0];
	}

	private static function reader() {
		if ( null !== self::$reader ) {
			return self::$reader;
		}
		self::$reader = false;
		$file         = self::db_file();
		if ( ! $file ) {
			return false;
		}
		if ( ! class_exists( '\MaxMind\Db\Reader' ) ) {
			foreach ( array( 'Reader/InvalidDatabaseException', 'Reader/Decoder', 'Reader/Metadata', 'Reader/Util', 'Reader' ) as $f ) {
				require_once FILEORA_CORE_DIR . 'includes/lib/MaxMind/Db/' . $f . '.php';
			}
		}
		try {
			self::$reader = new \MaxMind\Db\Reader( $file );
		} catch ( \Throwable $e ) {
			Fileora_Core_Log::error( 'geo database could not be opened: ' . $e->getMessage() );
			self::$reader = false;
		}
		return self::$reader;
	}

	/** Information about the database file for the settings page. */
	public static function db_info() {
		$file = self::db_file();
		if ( ! $file ) {
			return null;
		}
		$info = array(
			'file'  => basename( $file ),
			'size'  => filesize( $file ),
			'date'  => filemtime( $file ),
			'type'  => '',
			'dbip'  => false !== stripos( basename( $file ), 'dbip' ),
		);
		$r = self::reader();
		if ( $r ) {
			$meta         = $r->metadata();
			$info['type'] = $meta->databaseType;
			$info['date'] = $meta->buildEpoch;
		}
		return $info;
	}

	/**
	 * Location of an IP address.
	 *
	 * @return array{country:string,region:string,city:string}
	 */
	public static function lookup( $ip ) {
		$empty = array( 'country' => '', 'region' => '', 'city' => '' );
		/**
		 * Supply a location yourself, e.g. from your CDN. Return an array with
		 * country (2-letter code), region and city to skip the built-in lookup.
		 */
		$pre = apply_filters( 'fileora_geo_lookup', null, $ip );
		if ( is_array( $pre ) ) {
			return array_merge( $empty, array_intersect_key( $pre, $empty ) );
		}
		$source = (string) Fileora_Core_Settings::value( 'geo_source' );
		if ( 'off' === $source || ! $ip ) {
			return $empty;
		}
		if ( in_array( $source, array( 'auto', 'database' ), true ) && self::reader() ) {
			$r = self::from_database( $ip );
			if ( $r['country'] || 'database' === $source ) {
				return $r;
			}
		}
		if ( in_array( $source, array( 'auto', 'cloudflare' ), true ) ) {
			return self::from_headers();
		}
		return $empty;
	}

	private static function from_database( $ip ) {
		$out = array( 'country' => '', 'region' => '', 'city' => '' );
		try {
			$rec = self::reader()->get( $ip );
		} catch ( \Throwable $e ) {
			return $out;
		}
		if ( ! is_array( $rec ) ) {
			return $out;
		}
		if ( isset( $rec['country']['iso_code'] ) ) {
			$out['country'] = strtoupper( (string) $rec['country']['iso_code'] );
		}
		if ( isset( $rec['subdivisions'][0]['names']['en'] ) ) {
			$out['region'] = (string) $rec['subdivisions'][0]['names']['en'];
		}
		if ( isset( $rec['city']['names']['en'] ) ) {
			$out['city'] = (string) $rec['city']['names']['en'];
		}
		return self::clean( $out );
	}

	private static function from_headers() {
		$h   = function ( $k ) {
			return isset( $_SERVER[ $k ] ) ? sanitize_text_field( wp_unslash( $_SERVER[ $k ] ) ) : '';
		};
		$cc  = strtoupper( $h( 'HTTP_CF_IPCOUNTRY' ) );
		$out = array(
			'country' => preg_match( '/^[A-Z]{2}$/', $cc ) && ! in_array( $cc, array( 'XX', 'T1' ), true ) ? $cc : '',
			'region'  => $h( 'HTTP_CF_REGION' ),
			'city'    => $h( 'HTTP_CF_IPCITY' ),
		);
		return self::clean( $out );
	}

	private static function clean( array $r ) {
		$r['region'] = mb_substr( $r['region'], 0, 80 );
		$r['city']   = mb_substr( $r['city'], 0, 80 );
		return $r;
	}

	/** English name of a country code ("IN" → "India"). */
	public static function country_name( $code ) {
		static $names = null;
		if ( null === $names ) {
			$names = include FILEORA_CORE_DIR . 'includes/data/countries.php';
		}
		$code = strtoupper( (string) $code );
		if ( '' === $code ) {
			return __( 'Unknown', 'fileora' );
		}
		return isset( $names[ $code ] ) ? $names[ $code ] : $code;
	}

	/** "Mumbai, Maharashtra, India". */
	public static function label( $country, $region = '', $city = '' ) {
		$parts = array_filter( array( $city, $region, $country ? self::country_name( $country ) : '' ) );
		return $parts ? implode( ', ', array_unique( $parts ) ) : __( 'Unknown', 'fileora' );
	}

	/* ------------------------------------------------------------------
	 * DB-IP City Lite download (monthly).
	 * ---------------------------------------------------------------- */

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'fileora_monthly', self::CRON );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::CRON );
	}

	/** Monthly update, only when the database in use is a DB-IP file downloaded by Fileora. */
	public static function scheduled_update() {
		$file = self::db_file();
		if ( $file && preg_match( '/dbip-(city|country)-lite/i', basename( $file ), $m ) ) {
			self::download_dbip( strtolower( $m[1] ) );
		}
	}

	/**
	 * Downloads this month's DB-IP Lite database: "city" (about 60 MB
	 * compressed, 130 MB on disk) or "country" (about 4 MB, countries only).
	 *
	 * @return true|WP_Error
	 */
	public static function download_dbip( $edition = 'city' ) {
		$edition = 'country' === $edition ? 'country' : 'city';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 600 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		$dir = self::dir();
		if ( ! wp_mkdir_p( $dir ) ) {
			return new WP_Error( 'dir', __( 'The uploads folder is not writable.', 'fileora' ) );
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			file_put_contents( $dir . '/index.php', "<?php // Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			file_put_contents( $dir . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
		$tmp   = null;
		$month = '';
		foreach ( array( 0, 1 ) as $back ) {
			$month = gmdate( 'Y-m', strtotime( gmdate( 'Y-m-01' ) . " -{$back} month" ) );
			$tmp   = download_url( 'https://download.db-ip.com/free/dbip-' . $edition . '-lite-' . $month . '.mmdb.gz', 600 );
			if ( ! is_wp_error( $tmp ) ) {
				break;
			}
		}
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		$target = $dir . '/dbip-' . $edition . '-lite-' . $month . '.mmdb';
		$in     = gzopen( $tmp, 'rb' );
		$out    = fopen( $target . '.part', 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		if ( ! $in || ! $out ) {
			wp_delete_file( $tmp );
			return new WP_Error( 'write', __( 'Could not unpack the database.', 'fileora' ) );
		}
		while ( ! gzeof( $in ) ) {
			fwrite( $out, gzread( $in, 1048576 ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		}
		gzclose( $in );
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		wp_delete_file( $tmp );
		$check = self::validate_file( $target . '.part' );
		if ( is_wp_error( $check ) ) {
			wp_delete_file( $target . '.part' );
			return $check;
		}
		rename( $target . '.part', $target ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
		self::use_only( $target );
		self::schedule();
		return true;
	}

	/** Keeps only $file in the folder, so it is the database in use. */
	private static function use_only( $file ) {
		foreach ( (array) glob( self::dir() . '/*.mmdb' ) as $old ) {
			if ( $old !== $file ) {
				wp_delete_file( $old );
			}
		}
		touch( $file );
		self::$reader = null;
		// Fill in the locations of visits recorded before the database was installed.
		wp_clear_scheduled_hook( self::BACKFILL );
		wp_schedule_single_event( time() + 5, self::BACKFILL );
	}

	/** Checks that a file is a readable MaxMind-format database with location data. */
	public static function validate_file( $path ) {
		foreach ( array( 'Reader/InvalidDatabaseException', 'Reader/Decoder', 'Reader/Metadata', 'Reader/Util', 'Reader' ) as $f ) {
			require_once FILEORA_CORE_DIR . 'includes/lib/MaxMind/Db/' . $f . '.php';
		}
		try {
			$r    = new \MaxMind\Db\Reader( $path );
			$type = (string) $r->metadata()->databaseType;
			$r->close();
		} catch ( \Throwable $e ) {
			return new WP_Error( 'invalid', __( 'This is not a valid .mmdb location database.', 'fileora' ) );
		}
		if ( ! preg_match( '/city|country/i', $type ) ) {
			/* translators: %s: database type */
			return new WP_Error( 'type', sprintf( __( 'This database (%s) has no country or city data. Use a City or Country database.', 'fileora' ), $type ) );
		}
		return true;
	}

	/* ------------------------------------------------------------------
	 * Download in the background, with a status for the settings page.
	 * ---------------------------------------------------------------- */

	public static function status() {
		$s = get_option( self::STATUS );
		return is_array( $s ) ? $s : array();
	}

	private static function set_status( $state, $message = '', $edition = '' ) {
		update_option( self::STATUS, array( 'state' => $state, 'message' => $message, 'edition' => $edition, 'time' => time() ), false );
	}

	/** Starts the download in a background request, so it isn't cut off by the page's time limit. */
	public static function queue_download( $edition ) {
		$edition = 'country' === $edition ? 'country' : 'city';
		self::set_status( 'running', '', $edition );
		wp_clear_scheduled_hook( self::JOB, array( $edition ) );
		wp_schedule_single_event( time(), self::JOB, array( $edition ) );
		spawn_cron();
	}

	public static function run_download_job( $edition = 'city' ) {
		$r = self::download_dbip( $edition );
		if ( is_wp_error( $r ) ) {
			self::set_status( 'error', $r->get_error_message(), $edition );
		} else {
			self::set_status( 'done', '', $edition );
		}
	}

	/** Uploaded .mmdb or .mmdb.gz file from the settings page. */
	public static function install_upload( array $file ) {
		if ( ! empty( $file['error'] ) || empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error( 'upload', __( 'The upload failed. Check the file size limit (Settings → PHP upload limit) and try again.', 'fileora' ) );
		}
		$orig = wp_basename( (string) $file['name'] );
		if ( ! preg_match( '/^(.+)\.mmdb(\.gz)?$/i', $orig, $nm ) ) {
			return new WP_Error( 'type', __( 'Upload an .mmdb file (or .mmdb.gz).', 'fileora' ) );
		}
		// sanitize_file_name() would add "_" to the double extension, so clean the base name only.
		$name = preg_replace( '/[^A-Za-z0-9._-]/', '-', $nm[1] ) . '.mmdb' . ( empty( $nm[2] ) ? '' : '.gz' );
		if ( ! preg_match( '/\.mmdb(\.gz)?$/i', $name ) ) {
			return new WP_Error( 'type', __( 'Upload an .mmdb file (or .mmdb.gz).', 'fileora' ) );
		}
		$dir = self::dir();
		if ( ! wp_mkdir_p( $dir ) ) {
			return new WP_Error( 'dir', __( 'The uploads folder is not writable.', 'fileora' ) );
		}
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			file_put_contents( $dir . '/index.php', "<?php // Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			file_put_contents( $dir . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
		$target = $dir . '/' . preg_replace( '/\.gz$/i', '', $name );
		if ( preg_match( '/\.gz$/i', $name ) ) {
			$in  = gzopen( $file['tmp_name'], 'rb' );
			$out = fopen( $target . '.part', 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
			if ( ! $in || ! $out ) {
				return new WP_Error( 'write', __( 'Could not unpack the file.', 'fileora' ) );
			}
			while ( ! gzeof( $in ) ) {
				fwrite( $out, gzread( $in, 1048576 ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
			}
			gzclose( $in );
			fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		} elseif ( ! move_uploaded_file( $file['tmp_name'], $target . '.part' ) ) {
			return new WP_Error( 'write', __( 'Could not save the file.', 'fileora' ) );
		}
		$check = self::validate_file( $target . '.part' );
		if ( is_wp_error( $check ) ) {
			wp_delete_file( $target . '.part' );
			return $check;
		}
		rename( $target . '.part', $target ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
		self::use_only( $target );
		return true;
	}

	/* ------------------------------------------------------------------
	 * Filling in missing locations.
	 * ---------------------------------------------------------------- */

	/** Visits without a location that still have an IP address. */
	public static function missing_count() {
		global $wpdb;
		$s = Fileora_Analytics::sessions_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$s} WHERE country = '' AND ip <> ''" );
	}

	/**
	 * Looks up visits recorded without a location (e.g. before the database
	 * was installed) and updates them, their events and their tasks.
	 *
	 * @return int Visits that got a location.
	 */
	public static function backfill( $limit = 3000 ) {
		global $wpdb;
		if ( ! self::reader() ) {
			return 0;
		}
		$s     = Fileora_Analytics::sessions_table();
		$e     = Fileora_Analytics::table();
		$t     = Fileora_Task_Manager::table();
		$found = 0;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT sid, ip FROM {$s} WHERE country = '' AND ip <> '' ORDER BY last_seen DESC LIMIT %d", $limit ) );
		foreach ( $rows as $r ) {
			$g = self::from_database( $r->ip );
			if ( ! $g['country'] ) {
				continue;
			}
			$wpdb->update( $s, $g, array( 'sid' => $r->sid ) );
			$wpdb->query( $wpdb->prepare( "UPDATE {$e} SET country = %s, region = %s, city = %s WHERE sid = %s AND country = ''", $g['country'], $g['region'], $g['city'], $r->sid ) );
			$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET country = %s, region = %s, city = %s WHERE sid = %s AND country = ''", $g['country'], $g['region'], $g['city'], $r->sid ) );
			delete_transient( 'fo_ss_' . substr( $r->sid, 0, 20 ) );
			++$found;
		}
		// Server tasks without a visit (e.g. analytics blocked) but with an IP address.
		$tasks = $wpdb->get_results( $wpdb->prepare( "SELECT id, ip FROM {$t} WHERE country = '' AND ip <> '' LIMIT %d", $limit ) );
		foreach ( $tasks as $r ) {
			$g = self::from_database( $r->ip );
			if ( $g['country'] ) {
				$wpdb->update( $t, $g, array( 'id' => $r->id ) );
			}
		}
		// phpcs:enable
		$keys = $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_fo\\_rep\\_%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		foreach ( $keys as $k ) {
			delete_transient( substr( $k, strlen( '_transient_' ) ) );
		}
		return $found;
	}

	public static function backfill_job() {
		self::backfill();
	}

	/**
	 * What the current request looks like, for Settings → Location check.
	 *
	 * @return array
	 */
	public static function diagnose() {
		Fileora_Core_Security::reset_ip();
		$ip = Fileora_Core_Security::client_ip();
		return array(
			'candidates' => Fileora_Core_Security::ip_candidates(),
			'ip'         => $ip,
			'public'     => Fileora_Core_Security::is_public_ip( $ip ),
			'cloudflare' => Fileora_Core_Security::from_cloudflare( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' ),
			'result'     => self::lookup( $ip ),
			'db'         => self::db_info(),
			'missing'    => self::missing_count(),
		);
	}

	public static function delete_db() {
		foreach ( (array) glob( self::dir() . '/*.mmdb' ) as $f ) {
			wp_delete_file( $f );
		}
		self::$reader = null;
	}
}
