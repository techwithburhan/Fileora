<?php
/**
 * The 60-day SEO plan: one card per day under Fileora → SEO → 60-day plan.
 * "Enable day N" applies that day's ready-written work (titles, descriptions,
 * tool page text and FAQ, guides, pages, sitemap and menu settings); new posts
 * and pages are created as drafts and published with one more click. Every
 * change keeps a backup, so "Undo" puts the site back as it was.
 *
 * Content lives in seo-plan/: plan.php (the schedule), home.php, presets.php,
 * tools/*.md, guides/*.md and pages/*.md.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

class Fileora_SEO_Plan {

	const OPTION = 'fileora_seo_plan';
	const BACKUP = '_fileora_plan_backup';
	const TOOLS  = '_fileora_plan_tools';
	const IMAGE  = '_fileora_plan_image'; // on a Media Library item: the blog slug its cover image belongs to
	const DAYS   = 60;

	/** The plans: the 60-day SEO plan and the 70-day blog plan share this engine. */
	const PLANS = array(
		'seo'  => array( 'option' => 'fileora_seo_plan', 'file' => 'plan.php', 'tab' => 'plan', 'days' => 60, 'source' => '_fileora_plan_day' ),
		'blog' => array( 'option' => 'fileora_blog_plan', 'file' => 'blog-plan.php', 'tab' => 'blog', 'days' => 70, 'source' => '_fileora_blog_day' ),
	);

	/** Which plan the current request works on. */
	public static $plan = 'seo';

	public static function use_plan( $plan ) {
		self::$plan = isset( self::PLANS[ $plan ] ) ? $plan : 'seo';
	}

	private static function cfg( $key ) {
		return self::PLANS[ self::$plan ][ $key ];
	}

	public static function days() {
		return (int) self::cfg( 'days' );
	}

	public static function init() {
		foreach ( array( 'apply', 'undo', 'publish', 'check', 'settings', 'images' ) as $a ) {
			add_action( 'admin_post_fileora_plan_' . $a, array( __CLASS__, 'handle_' . $a ) );
		}
		add_filter( 'the_content', array( __CLASS__, 'tool_guides' ), 20 );
		add_filter( 'wp_sitemaps_add_provider', array( __CLASS__, 'sitemap_provider' ), 10, 2 );
		add_filter( 'wp_sitemaps_taxonomies', array( __CLASS__, 'sitemap_taxonomies' ) );
		add_filter( 'wp_robots', array( __CLASS__, 'robots' ), 20 );
		add_filter( 'language_attributes', array( __CLASS__, 'lang' ), 20, 2 );
		add_action( 'admin_init', array( __CLASS__, 'auto_images' ) );
	}

	/* ------------------------------------------------------------------
	 * Cover images for blog posts (seo-plan/blog-images/<slug>.jpg)
	 * ---------------------------------------------------------------- */

	/** Alt texts, keyed by slug. */
	public static function image_alts() {
		static $alts = null;
		if ( null === $alts ) {
			$file = self::dir() . 'blog-images/images.php';
			$alts = file_exists( $file ) ? include $file : array();
			$alts = is_array( $alts ) ? $alts : array();
		}
		return $alts;
	}

	/** The Media Library item already made from a slug's cover, or 0. */
	private static function image_id( $slug ) {
		$ids = get_posts(
			array(
				'post_type'   => 'attachment',
				'post_status' => 'inherit',
				'numberposts' => 1,
				'fields'      => 'ids',
				'meta_key'    => self::IMAGE, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'  => $slug, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);
		$id = $ids ? (int) $ids[0] : 0;
		return ( $id && file_exists( (string) get_attached_file( $id ) ) ) ? $id : 0;
	}

	/**
	 * Puts the cover image for $slug in the Media Library (once), attaches it to the post,
	 * sets the alt text and makes it the featured image. Returns the attachment ID or 0.
	 */
	public static function cover( $post_id, $slug ) {
		$file = self::dir() . 'blog-images/' . sanitize_file_name( $slug ) . '.jpg';
		if ( ! $post_id || ! file_exists( $file ) ) {
			return 0;
		}
		$alts  = self::image_alts();
		$title = get_the_title( $post_id );
		$id    = self::image_id( $slug );
		if ( ! $id ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$tmp = wp_tempnam( $slug . '.jpg' );
			if ( ! $tmp || ! copy( $file, $tmp ) ) {
				return 0;
			}
			$id = media_handle_sideload( array( 'name' => $slug . '.jpg', 'tmp_name' => $tmp ), $post_id, $title );
			if ( is_wp_error( $id ) ) {
				wp_delete_file( $tmp );
				return 0;
			}
			update_post_meta( $id, self::IMAGE, $slug );
		} elseif ( (int) wp_get_post_parent_id( $id ) !== (int) $post_id ) {
			wp_update_post( array( 'ID' => $id, 'post_parent' => (int) $post_id ) );
		}
		if ( ! empty( $alts[ $slug ] ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', wp_slash( $alts[ $slug ] ) );
		}
		set_post_thumbnail( $post_id, $id );
		return (int) $id;
	}

	/** Gives every post the blog plan already made its cover image, if it has none. Returns [added, left]. */
	public static function backfill_images( $limit = 0 ) {
		$prev = self::$plan;
		self::use_plan( 'blog' );
		$added = 0;
		$left  = 0;
		foreach ( self::state()['days'] as $n => $ds ) {
			foreach ( (array) ( isset( $ds['items'] ) ? $ds['items'] : array() ) as $i => $r ) {
				$sched = self::schedule();
				$item  = isset( $sched[ $n ]['auto'][ $i ] ) ? $sched[ $n ]['auto'][ $i ] : null;
				if ( ! $item || 'blog' !== $item[0] || empty( $r['post'] ) || ! get_post( (int) $r['post'] ) || has_post_thumbnail( (int) $r['post'] ) ) {
					continue;
				}
				if ( $limit && $added >= $limit ) {
					++$left;
					continue;
				}
				$p = self::item( 'blog', $item[1] );
				if ( $p && self::cover( (int) $r['post'], $p['slug'] ) ) {
					++$added;
				}
			}
		}
		self::use_plan( $prev );
		return array( $added, $left );
	}

	/** False when a post names a tool (needs_tool: slug) that is switched off on this site. */
	public static function tool_ready( array $p ) {
		if ( empty( $p['needs_tool'] ) ) {
			return true;
		}
		$post = self::tool_post( sanitize_title( $p['needs_tool'] ) );
		return $post && 'publish' === $post->post_status;
	}

	/** Writes a tool page's plan text: content, excerpt, FAQ and SEO fields. */
	private static function write_tool( $post, array $p ) {
		$b   = Fileora_Markdown::blocks( $p['body'], true );
		$faq = implode(
			"\n\n",
			array_map(
				function ( $qa ) {
					return $qa[0] . "\n" . $qa[1];
				},
				$b['faq']
			)
		);
		$upd = array( 'ID' => $post->ID, 'post_content' => $b['html'] );
		if ( ! empty( $p['excerpt'] ) ) {
			$upd['post_excerpt'] = $p['excerpt'];
		}
		wp_update_post( wp_slash( $upd ) );
		if ( '' !== $faq ) {
			update_post_meta( $post->ID, Fileora_Tool_Registry::META_FAQ, wp_slash( $faq ) );
		}
		self::seo_meta( $post->ID, $p );
	}

	/**
	 * Corrections to tool pages the 60-day plan wrote earlier (2.9: Excel to PDF had a setting the
	 * server never used; PDF to PowerPoint promised editable text. 2.10: HTML to PDF now points to
	 * HTML Code to PDF for local files). A page is only rewritten when its text is still exactly
	 * what the plan wrote, so your own edits are never touched.
	 */
	const TOOL_FIXES = array(
		'excel-to-pdf'      => 'f79191ec452585549ad6126866147ce3',
		'pdf-to-powerpoint' => '5beb293b8c3aeb334fe083a3d5a72cff',
		'html-to-pdf'       => '794372c54df00a9474e8cb5ba7dfa5d4',
	);

	public static function fix_tool_pages() {
		$fixed = array();
		foreach ( self::TOOL_FIXES as $slug => $hash ) {
			$post = self::tool_post( $slug );
			$p    = self::item( 'tool', $slug );
			if ( $post && $p && md5( trim( $post->post_content ) ) === $hash ) {
				self::write_tool( $post, $p );
				$fixed[] = $slug;
			}
		}
		return $fixed;
	}

	/** After an update: give posts from days enabled earlier their images, a few per admin page load. */
	public static function auto_images() {
		if ( FILEORA_CORE_VERSION !== get_option( 'fileora_plan_fixes' ) && current_user_can( 'edit_posts' ) ) {
			update_option( 'fileora_plan_fixes', FILEORA_CORE_VERSION, false );
			self::fix_tool_pages();
		}
		if ( wp_doing_ajax() || FILEORA_CORE_VERSION === get_option( 'fileora_blog_images' ) || ! current_user_can( 'upload_files' ) ) {
			return;
		}
		list( , $left ) = self::backfill_images( 8 );
		if ( ! $left ) {
			update_option( 'fileora_blog_images', FILEORA_CORE_VERSION, false );
		}
	}

	public static function handle_images() {
		self::guard( 'images' );
		self::use_plan( 'blog' );
		list( $added ) = self::backfill_images();
		update_option( 'fileora_blog_images', FILEORA_CORE_VERSION, false );
		wp_safe_redirect( add_query_arg( array( 'page' => 'fileora-seo', 'tab' => 'blog', 'msg' => 'images', 'n' => $added ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/** Hindi guides declare lang="hi" so browsers, screen readers and Google read them correctly. */
	public static function lang( $output, $doctype = 'html' ) {
		if ( 'html' !== $doctype || is_admin() || ! is_singular() ) {
			return $output;
		}
		$lang = get_post_meta( get_queried_object_id(), '_fileora_lang', true );
		if ( ! $lang ) {
			return $output;
		}
		return preg_replace( '/lang="[^"]*"/', 'lang="' . esc_attr( $lang ) . '"', $output, 1 );
	}

	/* ------------------------------------------------------------------
	 * Data
	 * ---------------------------------------------------------------- */

	public static function dir() {
		return FILEORA_CORE_DIR . 'seo-plan/';
	}

	public static function schedule() {
		static $all = array();
		if ( ! isset( $all[ self::$plan ] ) ) {
			$s                  = include self::dir() . self::cfg( 'file' );
			$all[ self::$plan ] = is_array( $s ) ? $s : array();
		}
		return $all[ self::$plan ];
	}

	public static function state() {
		$s = get_option( self::cfg( 'option' ), array() );
		$s = is_array( $s ) ? $s : array();
		return array_merge( array( 'start' => 0, 'ahead' => 0, 'days' => array() ), $s );
	}

	private static function save_state( array $s ) {
		update_option( self::cfg( 'option' ), $s, false );
	}

	public static function day_state( $n ) {
		$s = self::state();
		$d = isset( $s['days'][ $n ] ) ? $s['days'][ $n ] : array();
		return array_merge( array( 'status' => '', 'at' => 0, 'items' => array(), 'checks' => array(), 'backup' => array() ), $d );
	}

	/** The plan day it is today: day 1 until day 1 is enabled, then one more every day. */
	public static function today() {
		$s = self::state();
		if ( ! $s['start'] ) {
			return 1;
		}
		return min( self::days(), 1 + (int) floor( ( time() - (int) $s['start'] ) / DAY_IN_SECONDS ) );
	}

	public static function unlocked( $n ) {
		$s = self::state();
		return $n <= self::today() || ! empty( $s['ahead'] );
	}

	/** A content file: tools/merge-pdf.md etc. */
	public static function item( $type, $ref ) {
		$folder = array( 'tool' => 'tools', 'guide' => 'guides', 'page' => 'pages', 'blog' => 'blog' );
		if ( ! isset( $folder[ $type ] ) ) {
			return null;
		}
		$p = Fileora_Markdown::parse_file( self::dir() . $folder[ $type ] . '/' . sanitize_file_name( $ref ) . '.md' );
		if ( $p && empty( $p['slug'] ) ) {
			$p['slug'] = $ref;
		}
		return $p;
	}

	public static function home() {
		$h = include self::dir() . 'home.php';
		return is_array( $h ) ? $h : array();
	}

	public static function presets() {
		static $p = null;
		if ( null === $p ) {
			$p = include self::dir() . 'presets.php';
			$p = is_array( $p ) ? $p : array();
		}
		return $p;
	}

	/* ------------------------------------------------------------------
	 * Front end: sitemap, archives, guides under each tool
	 * ---------------------------------------------------------------- */

	public static function clean_archives() {
		$s = Fileora_SEO_Fields::settings();
		return ! empty( $s['clean_archives'] );
	}

	public static function sitemap_provider( $provider, $name ) {
		return ( 'users' === $name && self::clean_archives() ) ? false : $provider;
	}

	public static function sitemap_taxonomies( $taxonomies ) {
		if ( self::clean_archives() ) {
			unset( $taxonomies['post_tag'] );
		}
		return $taxonomies;
	}

	public static function robots( $robots ) {
		if ( self::clean_archives() && ! Fileora_SEO_Fields::seo_plugin() && ( is_tag() || is_author() || is_search() || is_date() ) ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
			unset( $robots['max-image-preview'] );
		}
		return $robots;
	}

	/** "Guides for this tool": published guides that name the tool, under its page text. */
	public static function tool_guides( $content ) {
		if ( ! is_singular( Fileora_Tool_Registry::POST_TYPE ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		$tool = Fileora_Tool_Registry::by_post( get_queried_object() );
		if ( ! $tool ) {
			return $content;
		}
		$posts = get_posts(
			array(
				'post_type'      => array( 'post', 'page' ),
				'post_status'    => 'publish',
				'posts_per_page' => 6,
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => self::TOOLS,
						'value'   => '|' . $tool['slug'] . '|',
						'compare' => 'LIKE',
					),
				),
			)
		);
		if ( ! $posts ) {
			return $content;
		}
		$html = '<section class="tool-guides"><h2>' . esc_html( sprintf( /* translators: %s: tool name */ __( 'Guides for %s', 'fileora' ), $tool['name'] ) ) . '</h2><ul>';
		foreach ( $posts as $p ) {
			$html .= '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></li>';
		}
		return $content . $html . '</ul></section>';
	}

	/* ------------------------------------------------------------------
	 * What a day will do (preview) and doing it
	 * ---------------------------------------------------------------- */

	private static function tool_post( $slug ) {
		$tool = Fileora_Tool_Registry::by_slug( $slug );
		if ( ! $tool ) {
			$tool = Fileora_Tool_Registry::get( $slug );
		}
		return ( $tool && ! empty( $tool['post_id'] ) ) ? get_post( (int) $tool['post_id'] ) : null;
	}

	private static function existing( $slug, $type ) {
		$p = get_page_by_path( $slug, OBJECT, $type );
		return ( $p && 'trash' !== $p->post_status ) ? $p : null;
	}

	/** One line per item: what Enable will do. */
	public static function describe( $n, array $item ) {
		$type = $item[0];
		$ref  = isset( $item[1] ) ? $item[1] : '';
		$ds   = self::day_state( $n );
		switch ( $type ) {
			case 'home':
				$h = self::home();
				return array( 'label' => __( 'Homepage title and description', 'fileora' ), 'detail' => isset( $h['title'] ) ? $h['title'] : '', 'warn' => '' );
			case 'sitemap':
				return array( 'label' => __( 'Clean sitemap and archives', 'fileora' ), 'detail' => __( 'Removes users and tags from the sitemap; author, tag, date and search pages get “noindex”.', 'fileora' ), 'warn' => '' );
			case 'menu':
				return array( 'label' => __( 'Header menu', 'fileora' ), 'detail' => implode( ', ', array_map( array( __CLASS__, 'menu_label' ), (array) $ref ) ), 'warn' => has_nav_menu( 'primary' ) ? __( 'Replaces the menu shown in the header (your old menu is kept and comes back with Undo).', 'fileora' ) : '' );
			case 'tool':
				$p    = self::item( 'tool', $ref );
				$post = self::tool_post( $ref );
				if ( ! $p || ! $post ) {
					return array( 'label' => $ref, 'detail' => __( 'This tool is not on the site, so it is skipped.', 'fileora' ), 'warn' => 'skip' );
				}
				$warn = '';
				$tool = Fileora_Tool_Registry::by_post( $post );
				if ( 'done' !== $ds['status'] && trim( $post->post_content ) !== trim( Fileora_Tool_Registry::default_content( $tool ) ) ) {
					$warn = __( 'You have changed this page’s text. It will be replaced; a backup is kept and Undo restores it.', 'fileora' );
				}
				if ( 'publish' !== $post->post_status ) {
					$warn = trim( $warn . ' ' . __( 'The tool is switched off, so the new text shows once you switch it on.', 'fileora' ) );
				}
				/* translators: %s: tool name */
				return array( 'label' => sprintf( __( 'Tool page: %s', 'fileora' ), get_the_title( $post ) ), 'detail' => $p['seo_title'], 'warn' => $warn, 'url' => get_permalink( $post ) );
			case 'blog':
				$p = self::item( 'blog', $ref );
				if ( ! $p ) {
					return array( 'label' => $ref, 'detail' => __( 'Content file missing.', 'fileora' ), 'warn' => 'skip' );
				}
				$ex   = self::existing( $p['slug'], 'post' );
				$mine = $ex && (int) get_post_meta( $ex->ID, self::cfg( 'source' ), true ) === (int) $n;
				/* translators: %s: title */
				return array(
					'label'  => sprintf( __( 'Blog post: %s', 'fileora' ), $p['title'] ),
					'detail' => '/' . $p['slug'] . '/' . ( $ex ? '' : ' · ' . __( 'created as a draft', 'fileora' ) ) . ' · ' . __( '10 search keywords, 10 title ideas', 'fileora' ) . ( file_exists( self::dir() . 'blog-images/' . $p['slug'] . '.jpg' ) ? ' · ' . __( 'cover image', 'fileora' ) : '' ),
					'warn'   => trim(
						( ( $ex && ! $mine && 'done' !== $ds['status'] ) ? __( 'An older post already has this address. Its text, title and SEO fields will be replaced by this new version; a backup is kept and Undo restores it.', 'fileora' ) : '' )
						/* translators: %s: tool name */
						. ( self::tool_ready( $p ) ? '' : ' ' . sprintf( __( 'The %s tool is switched off on this site, so this post stays a draft until you switch it on (Fileora → Tool Management). It needs an API key on the processing server first.', 'fileora' ), self::tool_post( sanitize_title( $p['needs_tool'] ) ) ? get_the_title( self::tool_post( sanitize_title( $p['needs_tool'] ) ) ) : $p['needs_tool'] ) )
					),
					'url'    => $ex ? get_permalink( $ex ) : '',
					'post'   => $ex ? $ex->ID : 0,
				);
			case 'guide':
			case 'page':
				$p = self::item( $type, $ref );
				if ( ! $p ) {
					return array( 'label' => $ref, 'detail' => __( 'Content file missing.', 'fileora' ), 'warn' => 'skip' );
				}
				$ex    = self::existing( $p['slug'], 'guide' === $type ? 'post' : 'page' );
				$mine  = $ex && (int) get_post_meta( $ex->ID, self::cfg( 'source' ), true ) === (int) $n;
				/* translators: %s: title */
				$label = ( 'guide' === $type ? __( 'Guide: %s', 'fileora' ) : __( 'Page: %s', 'fileora' ) );
				$extra = $ex ? '' : ' · ' . __( 'created as a draft', 'fileora' );
				return array(
					'label'  => sprintf( $label, $p['title'] ),
					'detail' => '/' . $p['slug'] . '/' . $extra . ( ! empty( $p['verify'] ) ? ' · ' . __( 'check the sizes before publishing', 'fileora' ) : '' ),
					'warn'   => ( $ex && ! $mine ) ? __( 'A page with this address already exists, so it is skipped.', 'fileora' ) : '',
					'url'    => $ex ? get_permalink( $ex ) : '',
					'edit'   => $ex ? get_edit_post_link( $ex->ID, 'raw' ) : '',
					'verify' => ! empty( $p['verify'] ),
					'post'   => $ex ? $ex->ID : 0,
				);
		}
		return array( 'label' => $type, 'detail' => '', 'warn' => '' );
	}

	public static function menu_label( $slug ) {
		$map = array( 'all-tools' => __( 'All tools', 'fileora' ), 'blog' => __( 'Blog', 'fileora' ), 'image-tools' => __( 'Image tools', 'fileora' ), 'contact' => __( 'Contact us', 'fileora' ), 'ats-resume' => __( 'ATS Resume', 'fileora' ) );
		if ( isset( $map[ $slug ] ) ) {
			return $map[ $slug ];
		}
		$t = Fileora_Tool_Registry::by_slug( $slug );
		return $t ? $t['name'] : $slug;
	}

	/** Applies one day. Returns the log. */
	public static function apply( $n ) {
		$sched = self::schedule();
		if ( empty( $sched[ $n ] ) ) {
			return array();
		}
		$state = self::state();
		$ds    = self::day_state( $n );
		$log   = array();
		foreach ( (array) $sched[ $n ]['auto'] as $i => $item ) {
			$r   = self::apply_item( $n, $item, $ds );
			$log[ $i ] = $r;
		}
		$ds['status'] = 'done';
		$ds['at']     = time();
		$ds['items']  = $log;
		$state        = self::state(); // apply_item may have changed settings, not the plan state
		if ( ! $state['start'] ) {
			$state['start'] = time();
		}
		$state['days'][ $n ] = $ds;
		self::save_state( $state );
		Fileora_Tool_Registry::flush_cache();
		return $log;
	}

	private static function apply_item( $n, array $item, array &$ds ) {
		$type = $item[0];
		$ref  = isset( $item[1] ) ? $item[1] : '';
		switch ( $type ) {
			case 'home':
				$h   = self::home();
				$seo = get_option( Fileora_SEO_Fields::OPTION, array() );
				$seo = is_array( $seo ) ? $seo : array();
				$ds['backup']['home'] = array(
					'title' => isset( $seo['home_title'] ) ? $seo['home_title'] : '',
					'meta'  => get_theme_mod( 'fileora_home_meta', null ),
				);
				$seo['home_title'] = $h['title'];
				update_option( Fileora_SEO_Fields::OPTION, $seo );
				set_theme_mod( 'fileora_home_meta', $h['description'] );
				return array( 'ok' => 1 );

			case 'sitemap':
				$seo = get_option( Fileora_SEO_Fields::OPTION, array() );
				$seo = is_array( $seo ) ? $seo : array();
				$ds['backup']['sitemap'] = ! empty( $seo['clean_archives'] );
				$seo['clean_archives']   = 1;
				update_option( Fileora_SEO_Fields::OPTION, $seo );
				return array( 'ok' => 1 );

			case 'menu':
				return self::apply_menu( (array) $ref, $ds );

			case 'tool':
				$p    = self::item( 'tool', $ref );
				$post = self::tool_post( $ref );
				if ( ! $p || ! $post ) {
					return array( 'skip' => 1 );
				}
				$backups       = get_post_meta( $post->ID, self::BACKUP, true );
				$backups       = is_array( $backups ) ? $backups : array();
				$backups[ $n ] = array(
					'content' => $post->post_content,
					'excerpt' => $post->post_excerpt,
					'faq'     => get_post_meta( $post->ID, Fileora_Tool_Registry::META_FAQ, true ),
					'title'   => get_post_meta( $post->ID, '_fileora_seo_title', true ),
					'desc'    => get_post_meta( $post->ID, '_fileora_meta_description', true ),
					'kw'      => get_post_meta( $post->ID, '_fileora_focus_keyword', true ),
				);
				update_post_meta( $post->ID, self::BACKUP, $backups );
				self::write_tool( $post, $p );
				return array( 'ok' => 1, 'post' => $post->ID );


			case 'blog':
				$p = self::item( 'blog', $ref );
				if ( ! $p ) {
					return array( 'skip' => 1 );
				}
				$ex = self::existing( $p['slug'], 'post' );
				if ( $ex && (int) get_post_meta( $ex->ID, self::cfg( 'source' ), true ) === (int) $n ) {
					return array( 'ok' => 1, 'post' => $ex->ID, 'created' => 1, 'image' => has_post_thumbnail( $ex->ID ) ? (int) get_post_thumbnail_id( $ex->ID ) : self::cover( $ex->ID, $p['slug'] ) );
				}
				if ( $ex ) {
					// An older guide on the same subject: refresh it in place, so one strong page keeps its address.
					$backups                  = get_post_meta( $ex->ID, self::BACKUP, true );
					$backups                  = is_array( $backups ) ? $backups : array();
					$backups[ 'blog:' . $n ] = array(
						'title'   => $ex->post_title,
						'content' => $ex->post_content,
						'excerpt' => $ex->post_excerpt,
						'cats'    => wp_get_post_categories( $ex->ID ),
						'thumb'   => (int) get_post_thumbnail_id( $ex->ID ),
						'meta'    => array_map(
							function ( $k ) use ( $ex ) {
								return get_post_meta( $ex->ID, $k, true );
							},
							array_combine( self::meta_keys(), self::meta_keys() )
						),
					);
					update_post_meta( $ex->ID, self::BACKUP, $backups );
					wp_update_post( wp_slash( array( 'ID' => $ex->ID, 'post_title' => $p['title'], 'post_content' => Fileora_Markdown::blocks( $p['body'] ), 'post_excerpt' => isset( $p['description'] ) ? $p['description'] : $ex->post_excerpt ) ) );
					update_post_meta( $ex->ID, self::TOOLS, isset( $p['tools'] ) ? '|' . implode( '|', array_map( 'sanitize_title', explode( ',', $p['tools'] ) ) ) . '|' : '' );
					if ( ! empty( $p['category'] ) ) {
						wp_set_post_categories( $ex->ID, self::categories( $p['category'] ), true ); // add the tool category, keep the old ones
					}
					self::seo_meta( $ex->ID, $p );
					return array( 'ok' => 1, 'post' => $ex->ID, 'updated' => 1, 'image' => self::cover( $ex->ID, $p['slug'] ) );
				}
				$type  = 'guide'; // a new post is created exactly like a guide, plus its cover image
				$cover = $p['slug'];
				// fall through
			case 'guide':
			case 'page':
				$p = isset( $p ) && $p ? $p : self::item( $type, $ref );
				if ( ! $p ) {
					return array( 'skip' => 1 );
				}
				$ptype = 'guide' === $type ? 'post' : 'page';
				$ex    = self::existing( $p['slug'], $ptype );
				if ( $ex ) {
					return (int) get_post_meta( $ex->ID, self::cfg( 'source' ), true ) === (int) $n ? array( 'ok' => 1, 'post' => $ex->ID, 'created' => 1 ) : array( 'skip' => 1, 'post' => $ex->ID );
				}
				$args = array(
					'post_type'    => $ptype,
					'post_status'  => 'draft',
					'post_title'   => $p['title'],
					'post_name'    => $p['slug'],
					'post_excerpt' => isset( $p['excerpt'] ) ? $p['excerpt'] : ( 'post' === $ptype && isset( $p['description'] ) ? $p['description'] : '' ),
					'post_content' => Fileora_Markdown::blocks( $p['body'] ),
					'post_author'  => get_current_user_id(),
					'meta_input'   => array(
						self::cfg( 'source' ) => (int) $n,
						self::TOOLS  => isset( $p['tools'] ) ? '|' . implode( '|', array_map( 'sanitize_title', explode( ',', $p['tools'] ) ) ) . '|' : '',
					),
				);
				if ( 'post' === $ptype ) {
					$args['post_category'] = self::categories( isset( $p['category'] ) ? $p['category'] : '' );
					$args['tags_input']    = array();
				}
				if ( ! empty( $p['parent'] ) ) {
					$parent = self::existing( $p['parent'], 'page' );
					if ( $parent ) {
						$args['post_parent'] = $parent->ID;
					}
				}
				$id = wp_insert_post( wp_slash( $args ), true );
				if ( is_wp_error( $id ) ) {
					return array( 'error' => $id->get_error_message() );
				}
				self::seo_meta( $id, $p );
				if ( ! empty( $p['lang'] ) ) {
					update_post_meta( $id, '_fileora_lang', sanitize_key( $p['lang'] ) );
				}
				if ( ! empty( $cover ) ) {
					return array( 'ok' => 1, 'post' => $id, 'created' => 1, 'image' => self::cover( $id, $cover ) );
				}
				return array( 'ok' => 1, 'post' => $id, 'created' => 1 );
		}
		return array( 'skip' => 1 );
	}

	/** Post meta a refreshed blog post backs up (and Undo puts back). */
	private static function meta_keys() {
		return array( '_fileora_meta_description', '_fileora_seo_title', '_fileora_focus_keyword', '_fileora_keywords', '_fileora_title_ideas', '_yoast_wpseo_title', '_yoast_wpseo_metadesc', '_yoast_wpseo_focuskw', 'rank_math_title', 'rank_math_description', 'rank_math_focus_keyword', self::TOOLS );
	}

	private static function seo_meta( $id, array $p ) {
		$desc = isset( $p['description'] ) ? $p['description'] : '';
		$seo  = isset( $p['seo_title'] ) ? $p['seo_title'] : '';
		$kw   = isset( $p['focus_keyword'] ) ? $p['focus_keyword'] : '';
		foreach ( array(
			'_fileora_meta_description' => $desc,
			'_fileora_seo_title'        => $seo,
			'_fileora_focus_keyword'    => $kw,
			'_yoast_wpseo_title'        => $seo ? $seo . ' %%sep%% %%sitename%%' : '',
			'_yoast_wpseo_metadesc'     => $desc,
			'_yoast_wpseo_focuskw'      => $kw,
			'rank_math_title'           => $seo ? $seo . ' %sep% %sitename%' : '',
			'rank_math_description'     => $desc,
			'rank_math_focus_keyword'   => $kw,
		) as $k => $v ) {
			update_post_meta( $id, $k, wp_slash( $v ) );
		}
		$list = function ( $key ) use ( $p ) {
			return isset( $p[ $key ] ) ? implode( "\n", array_slice( array_values( array_filter( array_map( 'trim', explode( '|', $p[ $key ] ) ) ) ), 0, 10 ) ) : '';
		};
		foreach ( array( '_fileora_keywords' => $list( 'keywords' ), '_fileora_title_ideas' => $list( 'titles' ) ) as $k => $v ) {
			if ( '' !== $v ) {
				update_post_meta( $id, $k, wp_slash( $v ) );
			}
		}
	}

	private static function categories( $names ) {
		$ids = array();
		foreach ( array_filter( array_map( 'trim', explode( ',', $names ) ) ) as $name ) {
			$term = term_exists( $name, 'category' );
			if ( ! $term ) {
				$term = wp_insert_term( $name, 'category' );
			}
			if ( ! is_wp_error( $term ) ) {
				$ids[] = (int) $term['term_id'];
			}
		}
		return $ids;
	}

	private static function menu_url( $slug ) {
		if ( 'blog' === $slug ) {
			$page = (int) get_option( 'page_for_posts' );
			if ( $page ) {
				return get_permalink( $page );
			}
			$p = self::existing( 'blog', 'page' );
			return $p ? get_permalink( $p ) : home_url( '/blog/' );
		}
		if ( 'contact' === $slug ) {
			$p = function_exists( 'fileora_theme_page_by_role' ) && fileora_theme_page_by_role( 'contact' ) ? get_post( fileora_theme_page_by_role( 'contact' ) ) : self::existing( 'contact', 'page' );
			return $p ? get_permalink( $p ) : home_url( '/contact/' );
		}
		if ( 'ats-resume' === $slug ) {
			return class_exists( 'Fileora_Resume' ) ? Fileora_Resume::url() : '';
		}
		if ( 'image-tools' === $slug ) {
			$p = self::existing( 'all-tools', 'page' );
			return ( $p ? get_permalink( $p ) : home_url( '/all-tools/' ) ) . '#cat-image-tools';
		}
		if ( 'all-tools' === $slug ) {
			$p = self::existing( 'all-tools', 'page' );
			return $p ? get_permalink( $p ) : home_url( '/all-tools/' );
		}
		$t = Fileora_Tool_Registry::by_slug( $slug );
		return $t && ! empty( $t['post_id'] ) ? get_permalink( (int) $t['post_id'] ) : home_url( '/' . $slug . '/' );
	}

	private static function apply_menu( array $slugs, array &$ds ) {
		$locations                = get_theme_mod( 'nav_menu_locations', array() );
		$locations                = is_array( $locations ) ? $locations : array();
		$ds['backup']['menu_loc'] = isset( $locations['primary'] ) ? (int) $locations['primary'] : 0;
		$name                     = __( 'Header (SEO plan)', 'fileora' );
		$menu                     = wp_get_nav_menu_object( $name );
		$menu_id                  = $menu ? (int) $menu->term_id : (int) wp_create_nav_menu( $name );
		if ( is_wp_error( $menu_id ) || ! $menu_id ) {
			return array( 'error' => 'menu' );
		}
		foreach ( (array) wp_get_nav_menu_items( $menu_id ) as $old ) {
			wp_delete_post( $old->ID, true );
		}
		$classes = array( 'contact' => 'menu-contact', 'ats-resume' => 'menu-resume' );
		foreach ( $slugs as $i => $slug ) {
			$url = self::menu_url( $slug );
			if ( '' === $url ) {
				continue; // e.g. the resume builder page was removed
			}
			wp_update_nav_menu_item(
				$menu_id,
				0,
				array(
					'menu-item-title'    => self::menu_label( $slug ),
					'menu-item-url'      => $url,
					'menu-item-status'   => 'publish',
					'menu-item-type'     => 'custom',
					'menu-item-position' => $i + 1,
					'menu-item-classes'  => isset( $classes[ $slug ] ) ? $classes[ $slug ] : '',
				)
			);
		}
		$ds['backup']['menu_id'] = $menu_id;
		$locations['primary']    = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );
		return array( 'ok' => 1 );
	}

	/** Puts back everything one day changed. */
	public static function undo( $n ) {
		$sched = self::schedule();
		$ds    = self::day_state( $n );
		if ( 'done' !== $ds['status'] || empty( $sched[ $n ] ) ) {
			return;
		}
		foreach ( (array) $sched[ $n ]['auto'] as $i => $item ) {
			$type = $item[0];
			$r    = isset( $ds['items'][ $i ] ) ? $ds['items'][ $i ] : array();
			if ( 'home' === $type && isset( $ds['backup']['home'] ) ) {
				$seo               = get_option( Fileora_SEO_Fields::OPTION, array() );
				$seo               = is_array( $seo ) ? $seo : array();
				$seo['home_title'] = $ds['backup']['home']['title'];
				update_option( Fileora_SEO_Fields::OPTION, $seo );
				if ( null === $ds['backup']['home']['meta'] ) {
					remove_theme_mod( 'fileora_home_meta' );
				} else {
					set_theme_mod( 'fileora_home_meta', $ds['backup']['home']['meta'] );
				}
			} elseif ( 'sitemap' === $type && isset( $ds['backup']['sitemap'] ) ) {
				$seo                   = get_option( Fileora_SEO_Fields::OPTION, array() );
				$seo                   = is_array( $seo ) ? $seo : array();
				$seo['clean_archives'] = $ds['backup']['sitemap'] ? 1 : 0;
				update_option( Fileora_SEO_Fields::OPTION, $seo );
			} elseif ( 'menu' === $type && isset( $ds['backup']['menu_loc'] ) ) {
				$locations            = get_theme_mod( 'nav_menu_locations', array() );
				$locations            = is_array( $locations ) ? $locations : array();
				$locations['primary'] = (int) $ds['backup']['menu_loc'];
				if ( ! $locations['primary'] ) {
					unset( $locations['primary'] );
				}
				set_theme_mod( 'nav_menu_locations', $locations );
			} elseif ( 'tool' === $type && ! empty( $r['post'] ) ) {
				$backups = get_post_meta( (int) $r['post'], self::BACKUP, true );
				if ( is_array( $backups ) && isset( $backups[ $n ] ) ) {
					$b = $backups[ $n ];
					wp_update_post( wp_slash( array( 'ID' => (int) $r['post'], 'post_content' => $b['content'], 'post_excerpt' => $b['excerpt'] ) ) );
					update_post_meta( (int) $r['post'], Fileora_Tool_Registry::META_FAQ, wp_slash( (string) $b['faq'] ) );
					update_post_meta( (int) $r['post'], '_fileora_seo_title', wp_slash( (string) $b['title'] ) );
					update_post_meta( (int) $r['post'], '_fileora_meta_description', wp_slash( (string) $b['desc'] ) );
					update_post_meta( (int) $r['post'], '_fileora_focus_keyword', wp_slash( (string) $b['kw'] ) );
					unset( $backups[ $n ] );
					update_post_meta( (int) $r['post'], self::BACKUP, $backups );
				}
			} elseif ( 'blog' === $type && ! empty( $r['updated'] ) && ! empty( $r['post'] ) ) {
				$backups = get_post_meta( (int) $r['post'], self::BACKUP, true );
				if ( is_array( $backups ) && isset( $backups[ 'blog:' . $n ] ) ) {
					$b = $backups[ 'blog:' . $n ];
					wp_update_post( wp_slash( array( 'ID' => (int) $r['post'], 'post_title' => $b['title'], 'post_content' => $b['content'], 'post_excerpt' => $b['excerpt'] ) ) );
					foreach ( (array) $b['meta'] as $k => $v ) {
						if ( '' === $v || null === $v ) {
							delete_post_meta( (int) $r['post'], $k );
						} else {
							update_post_meta( (int) $r['post'], $k, wp_slash( $v ) );
						}
					}
					if ( ! empty( $b['thumb'] ) && get_post( (int) $b['thumb'] ) ) {
						set_post_thumbnail( (int) $r['post'], (int) $b['thumb'] );
					} elseif ( get_post_meta( (int) get_post_thumbnail_id( (int) $r['post'] ), self::IMAGE, true ) ) {
						delete_post_thumbnail( (int) $r['post'] ); // the plan's cover goes; it stays in the Media Library for next time
					}
					if ( isset( $b['cats'] ) && is_array( $b['cats'] ) ) {
						wp_set_post_categories( (int) $r['post'], array_map( 'intval', $b['cats'] ) );
					}
					unset( $backups[ 'blog:' . $n ] );
					update_post_meta( (int) $r['post'], self::BACKUP, $backups );
				}
			} elseif ( in_array( $type, array( 'guide', 'page', 'blog' ), true ) && ! empty( $r['created'] ) && ! empty( $r['post'] ) && 'draft' === get_post_status( (int) $r['post'] ) ) {
				wp_trash_post( (int) $r['post'] ); // published guides and pages stay: removing a live address would hurt more than help
			}
		}
		$state = self::state();
		unset( $state['days'][ $n ] );
		self::save_state( $state );
		Fileora_Tool_Registry::flush_cache();
	}

	/** Publishes the day's drafts. Pages that need a size check wait until it is ticked. Returns array( published, waiting ). */
	public static function publish( $n ) {
		$sched = self::schedule();
		$ds    = self::day_state( $n );
		$done  = 0;
		$wait  = 0;
		foreach ( (array) $sched[ $n ]['auto'] as $i => $item ) {
			$r = isset( $ds['items'][ $i ] ) ? $ds['items'][ $i ] : array();
			if ( ! in_array( $item[0], array( 'guide', 'page', 'blog' ), true ) || empty( $r['created'] ) || empty( $r['post'] ) ) {
				continue;
			}
			$p = self::item( $item[0], $item[1] );
			if ( $p && ! empty( $p['verify'] ) && empty( $ds['checks'][ 'v:' . $item[1] ] ) ) {
				++$wait;
				continue;
			}
			if ( $p && ! self::tool_ready( $p ) ) {
				++$wait; // the post is about a tool that is switched off: publishing it would send readers to a page they can't use
				continue;
			}
			$post = get_post( (int) $r['post'] );
			if ( $post && 'draft' === $post->post_status ) {
				wp_publish_post( $post->ID );
				++$done;
			}
		}
		return array( $done, $wait );
	}

	/* ------------------------------------------------------------------
	 * Admin actions
	 * ---------------------------------------------------------------- */

	private static function guard( $action ) {
		if ( ! current_user_can( 'fileora_manage_settings' ) || ! current_user_can( 'publish_posts' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'fileora' ), 403 );
		}
		check_admin_referer( 'fileora_plan_' . $action );
		self::use_plan( isset( $_POST['plan'] ) ? sanitize_key( wp_unslash( $_POST['plan'] ) ) : 'seo' );
		return isset( $_POST['day'] ) ? max( 1, min( self::days(), absint( $_POST['day'] ) ) ) : 0;
	}

	private static function back( $n, $msg ) {
		wp_safe_redirect( add_query_arg( array( 'page' => 'fileora-seo', 'tab' => self::cfg( 'tab' ), 'day' => $n, 'msg' => $msg ), admin_url( 'admin.php' ) ) . '#day-' . $n );
		exit;
	}

	public static function handle_apply() {
		$n = self::guard( 'apply' );
		if ( ! self::unlocked( $n ) ) {
			self::back( $n, 'locked' );
		}
		self::apply( $n );
		self::back( $n, 'applied' );
	}

	public static function handle_undo() {
		$n = self::guard( 'undo' );
		self::undo( $n );
		self::back( $n, 'undone' );
	}

	public static function handle_publish() {
		$n             = self::guard( 'publish' );
		list( $d, $w ) = self::publish( $n );
		self::back( $n, $w ? 'waiting' : ( $d ? 'published' : 'nothing' ) );
	}

	public static function handle_check() {
		$n     = self::guard( 'check' );
		$key   = isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '';
		$state = self::state();
		if ( '' !== $key ) {
			$ds = self::day_state( $n );
			if ( ! empty( $ds['checks'][ $key ] ) ) {
				unset( $ds['checks'][ $key ] );
			} else {
				$ds['checks'][ $key ] = time();
			}
			$state['days'][ $n ] = $ds;
			self::save_state( $state );
		}
		self::back( $n, '' );
	}

	public static function handle_settings() {
		self::guard( 'settings' );
		$state          = self::state();
		$state['ahead'] = empty( $_POST['ahead'] ) ? 0 : 1;
		self::save_state( $state );
		self::back( self::today(), 'saved' );
	}

	/* ------------------------------------------------------------------
	 * Admin screen (a tab of Fileora → SEO)
	 * ---------------------------------------------------------------- */

	private static function button( $action, $n, $label, $class = 'button', $extra = '', $aria = '' ) {
		return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="fo-plan-f">'
			. wp_nonce_field( 'fileora_plan_' . $action, '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="fileora_plan_' . esc_attr( $action ) . '"><input type="hidden" name="plan" value="' . esc_attr( self::$plan ) . '"><input type="hidden" name="day" value="' . (int) $n . '">' . $extra
			. '<button class="' . esc_attr( $class ) . '"' . ( $aria ? $aria : '' ) . ( 'undo' === $action ? ' data-confirm="' . esc_attr__( 'Undo this day? Changed pages get their earlier text back and drafts it created go to the trash. Guides and pages you already published stay online.', 'fileora' ) . '"' : '' ) . '>' . esc_html( $label ) . '</button></form>';
	}

	private static function check_box( $n, $key, $label, $checked, $help = '' ) {
		$extra = '<input type="hidden" name="key" value="' . esc_attr( $key ) . '">';
		/* translators: %s: task name */
		$aria = ' aria-pressed="' . ( $checked ? 'true' : 'false' ) . '" aria-label="' . esc_attr( sprintf( __( 'Done: %s', 'fileora' ), $label ) ) . '"';
		return '<li class="fo-plan-manual' . ( $checked ? ' is-done' : '' ) . '">' . self::button( 'check', $n, $checked ? '✓' : '', 'fo-plan-tick', $extra, $aria ) . '<div><strong>' . esc_html( $label ) . '</strong>' . ( $help ? '<p>' . wp_kses( $help, array( 'a' => array( 'href' => true, 'target' => true, 'rel' => true ), 'code' => array(), 'strong' => array() ) ) . '</p>' : '' ) . '</div></li>';
	}

	public static function screen( $plan = 'seo' ) {
		self::use_plan( $plan );
		$sched = self::schedule();
		$state = self::state();
		$today = self::today();
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$open = isset( $_GET['day'] ) ? absint( $_GET['day'] ) : $today;
		$msg  = isset( $_GET['msg'] ) ? sanitize_key( $_GET['msg'] ) : '';
		// phpcs:enable
		$msgs = array(
			'applied'   => __( 'Done. Check the changes below; new guides and pages are drafts until you press “Publish the drafts”.', 'fileora' ),
			'undone'    => __( 'The day was undone.', 'fileora' ),
			'published' => __( 'The drafts are now live.', 'fileora' ),
			'waiting'   => __( 'Some items were not published yet; the note on the card says why (a size check to tick, or a tool that is switched off).', 'fileora' ),
			'nothing'   => __( 'There was nothing left to publish.', 'fileora' ),
			'locked'    => __( 'That day is not open yet.', 'fileora' ),
			'saved'     => __( 'Saved.', 'fileora' ),
			/* translators: %d: number of images */
			'images'    => sprintf( __( 'Cover images added: %d. Every enabled post now has its featured image.', 'fileora' ), isset( $_GET['n'] ) ? absint( $_GET['n'] ) : 0 ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		);
		if ( isset( $msgs[ $msg ] ) ) {
			echo '<div class="notice notice-' . ( in_array( $msg, array( 'waiting', 'locked' ), true ) ? 'warning' : 'success' ) . ' is-dismissible"><p>' . esc_html( $msgs[ $msg ] ) . '</p></div>';
		}
		$done = 0;
		foreach ( $sched as $n => $d ) {
			if ( 'done' === self::day_state( $n )['status'] ) {
				++$done;
			}
		}
		$pct = (int) round( $done / max( 1, count( $sched ) ) * 100 );
		echo '<div class="fo-plan-head"><div><p class="fo-lead">' . esc_html( 'blog' === self::$plan ? __( 'One blog post a day for 70 days, one for every tool. Press Enable to create the day’s post as a draft (or to refresh an older guide on the same subject), read it, then publish. Each post has 10 search keywords and 10 title ideas in its SEO box. Every change can be undone.', 'fileora' ) : __( 'One step a day for 60 days. Open today’s card, read what it changes, press Enable, then do the tasks marked “You”. Every change can be undone.', 'fileora' ) ) . '</p>';
		echo '<div class="fo-plan-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . (int) $pct . '" aria-label="' . esc_attr__( 'Plan progress', 'fileora' ) . '"><span style="width:' . (int) $pct . '%"></span></div>';
		/* translators: 1: days done, 2: total days, 3: today's day number */
		echo '<p class="fo-muted">' . esc_html( sprintf( __( '%1$d of %2$d days enabled · today is day %3$d', 'fileora' ), $done, count( $sched ), $today ) ) . '</p></div>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="fo-plan-ahead">' . wp_nonce_field( 'fileora_plan_settings', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="fileora_plan_settings"><input type="hidden" name="plan" value="' . esc_attr( self::$plan ) . '"><label class="fo-check"><input type="checkbox" name="ahead" value="1"' . checked( ! empty( $state['ahead'] ), true, false ) . ' onchange="this.form.submit()"> ' . esc_html__( 'Let me work ahead (open every day now)', 'fileora' ) . '</label><noscript><button class="button">' . esc_html__( 'Save', 'fileora' ) . '</button></noscript></form></div>';

		if ( 'blog' === self::$plan ) {
			$missing = 0;
			foreach ( $state['days'] as $dn => $dds ) {
				foreach ( (array) ( isset( $dds['items'] ) ? $dds['items'] : array() ) as $r ) {
					if ( ! empty( $r['post'] ) && get_post( (int) $r['post'] ) && ! has_post_thumbnail( (int) $r['post'] ) ) {
						++$missing;
					}
				}
			}
			echo '<div class="fo-plan-images"><p class="fo-muted">' . esc_html__( 'Each post gets its own cover image (1200 × 675, with alt text) in the Media Library, set as the featured image when its day is enabled, so it shows as soon as you publish.', 'fileora' ) . '</p>';
			if ( $missing ) {
				/* translators: %d: number of posts */
				echo self::button( 'images', 0, sprintf( _n( 'Add the missing cover image (%d post)', 'Add the missing cover images (%d posts)', $missing, 'fileora' ), $missing ), 'button button-secondary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</div>';
		}

		if ( Fileora_SEO_Fields::seo_plugin() ) {
			echo '<div class="notice notice-info inline"><p>' . esc_html__( 'An SEO plugin is active. The plan also fills in its title, description and focus keyword fields for Yoast SEO and Rank Math.', 'fileora' ) . '</p></div>';
		}

		$weeks = array();
		foreach ( $sched as $n => $d ) {
			$weeks[ (int) ceil( $n / 7 ) ][ $n ] = $d;
		}
		foreach ( $weeks as $w => $days ) {
			/* translators: %d: week number */
			echo '<h2 class="fo-plan-week">' . esc_html( sprintf( __( 'Week %d', 'fileora' ), $w ) ) . '</h2><div class="fo-plan-days">';
			foreach ( $days as $n => $d ) {
				self::card( $n, $d, $today, $open );
			}
			echo '</div>';
		}
	}

	private static function card( $n, array $d, $today, $open ) {
		$ds       = self::day_state( $n );
		$unlocked = self::unlocked( $n );
		$done     = 'done' === $ds['status'];
		$status   = $done ? array( 'good', __( 'Enabled', 'fileora' ) ) : ( $n === $today ? array( 'warn', __( 'Today', 'fileora' ) ) : ( $unlocked ? array( 'warn', __( 'Open', 'fileora' ) ) : array( 'none', __( 'Later', 'fileora' ) ) ) );
		$manual   = isset( $d['manual'] ) ? (array) $d['manual'] : array();
		$ticked   = 0;
		foreach ( $manual as $mi => $m ) {
			$ticked += empty( $ds['checks'][ 'm:' . $mi ] ) ? 0 : 1;
		}
		echo '<details class="fo-plan-day' . ( $done ? ' is-done' : '' ) . ( $n === $today ? ' is-today' : '' ) . '" id="day-' . (int) $n . '"' . ( $n === $open ? ' open' : '' ) . '><summary><span class="fo-plan-n">' . (int) $n . '</span><span class="fo-plan-t"><strong>' . esc_html( $d['title'] ) . '</strong><small>' . esc_html( $d['why'] ) . '</small></span><span class="fo-st fo-st-' . esc_attr( $status[0] ) . '"><i></i>' . esc_html( $status[1] ) . ( $manual ? ' · ' . esc_html( $ticked . '/' . count( $manual ) ) : '' ) . '</span></summary><div class="fo-plan-body">';

		if ( ! empty( $d['auto'] ) ) {
			echo '<h3>' . esc_html__( 'Done by the button', 'fileora' ) . '</h3><ul class="fo-plan-auto">';
			foreach ( $d['auto'] as $i => $item ) {
				$info = self::describe( $n, $item );
				$r    = isset( $ds['items'][ $i ] ) ? $ds['items'][ $i ] : array();
				$mark = $done ? ( ! empty( $r['ok'] ) ? '✓' : '–' ) : '•';
				echo '<li><span class="fo-plan-mark" aria-hidden="true">' . esc_html( $mark ) . '</span><div><strong>' . esc_html( $info['label'] ) . '</strong>';
				if ( '' !== (string) $info['detail'] ) {
					echo ' <span class="fo-muted">' . esc_html( $info['detail'] ) . '</span>';
				}
				if ( $done && ! empty( $r['skip'] ) ) {
					echo '<p class="fo-plan-warn">' . esc_html__( 'Skipped: it already existed or the tool is not on the site.', 'fileora' ) . '</p>';
				} elseif ( ! $done && $info['warn'] && 'skip' !== $info['warn'] ) {
					echo '<p class="fo-plan-warn">' . esc_html( $info['warn'] ) . '</p>';
				} elseif ( ! $done && 'skip' === $info['warn'] ) {
					echo '<p class="fo-plan-warn">' . esc_html( $info['detail'] ) . '</p>';
				}
				if ( $done && ! empty( $r['post'] ) ) {
					$post = get_post( (int) $r['post'] );
					if ( $post ) {
						echo '<p class="fo-plan-links"><a href="' . esc_url( get_permalink( $post ) ) . '" target="_blank" rel="noopener">' . esc_html( 'publish' === $post->post_status ? __( 'View', 'fileora' ) : __( 'Preview', 'fileora' ) ) . '</a> · <a href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">' . esc_html__( 'Edit', 'fileora' ) . '</a> · <span class="fo-muted">' . esc_html( 'publish' === $post->post_status ? __( 'live', 'fileora' ) : __( 'draft', 'fileora' ) ) . '</span></p>';
					}
				}
				echo '</div></li>';
				if ( $done && ! empty( $info['verify'] ) && ! empty( $r['created'] ) ) {
					$key = 'v:' . $item[1];
					echo '<li class="fo-plan-verify"><ul>' . self::check_box( $n, $key, __( 'I checked the sizes against the official notification', 'fileora' ), ! empty( $ds['checks'][ $key ] ), __( 'Open the page, compare every number with the latest official notification linked on it, and correct any that changed. Only then tick this.', 'fileora' ) ) . '</ul></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
			}
			echo '</ul>';
		}

		if ( $manual ) {
			echo '<h3>' . esc_html__( 'You', 'fileora' ) . '</h3><ul class="fo-plan-manuals">';
			foreach ( $manual as $mi => $m ) {
				echo self::check_box( $n, 'm:' . $mi, $m[0], ! empty( $ds['checks'][ 'm:' . $mi ] ), isset( $m[1] ) ? $m[1] : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</ul>';
		}

		echo '<div class="fo-plan-actions">';
		if ( ! $unlocked ) {
			/* translators: %d: day number */
			echo '<p class="fo-muted">' . esc_html( sprintf( __( 'Opens on day %d. Tick “Let me work ahead” above to open it now.', 'fileora' ), $n ) ) . '</p>';
		} elseif ( ! $done ) {
			if ( ! empty( $d['auto'] ) ) {
				/* translators: %d: day number */
				echo self::button( 'apply', $n, sprintf( __( 'Enable day %d', 'fileora' ), $n ), 'button button-primary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			} else {
				echo self::button( 'apply', $n, __( 'Mark this day as started', 'fileora' ), 'button button-primary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		} else {
			$drafts = 0;
			foreach ( $ds['items'] as $r ) {
				if ( ! empty( $r['created'] ) && ! empty( $r['post'] ) && 'draft' === get_post_status( (int) $r['post'] ) ) {
					++$drafts;
				}
			}
			if ( $drafts ) {
				/* translators: %d: number of drafts */
				echo self::button( 'publish', $n, sprintf( _n( 'Publish the draft', 'Publish the %d drafts', $drafts, 'fileora' ), $drafts ), 'button button-primary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			if ( ! empty( $d['auto'] ) ) {
				echo self::button( 'undo', $n, __( 'Undo this day', 'fileora' ), 'button-link fo-plan-undo' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			/* translators: %s: date */
			echo '<p class="fo-muted">' . esc_html( sprintf( __( 'Enabled %s', 'fileora' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $ds['at'] ) ) ) . '</p>';
		}
		echo '</div></div></details>';
	}
}
