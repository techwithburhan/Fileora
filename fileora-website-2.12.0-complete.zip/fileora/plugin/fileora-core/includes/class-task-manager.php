<?php
/**
 * Processing task records: one row per server task (table {prefix}fileora_tasks).
 *
 * Rows hold no file contents, only what is needed for status checks, daily
 * limits, the 30-day reports and the Processing Tasks screen. The processing
 * server stays the authority for a job's live status; WordPress stores the
 * final outcome once it has been reported.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Task_Manager {

	const DB_VERSION = '3';

	/** Failure codes that are the site's fault, not the visitor's: they don't count towards the daily limit. */
	const SYSTEM_CODES = array( 'unreachable', 'auth', 'not_configured', 'server_error' );

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'fileora_tasks';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$collate = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
			id char(32) NOT NULL,
			tool varchar(20) NOT NULL,
			token_hash char(64) NOT NULL DEFAULT '',
			status varchar(12) NOT NULL DEFAULT 'queued',
			error_code varchar(40) DEFAULT NULL,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			ip_hash char(64) NOT NULL DEFAULT '',
			sid char(32) NOT NULL DEFAULT '',
			ip varchar(45) NOT NULL DEFAULT '',
			country char(2) NOT NULL DEFAULT '',
			region varchar(80) NOT NULL DEFAULT '',
			city varchar(80) NOT NULL DEFAULT '',
			file_name varchar(160) NOT NULL DEFAULT '',
			files smallint(5) unsigned NOT NULL DEFAULT 0,
			bytes_in bigint(20) unsigned NOT NULL DEFAULT 0,
			result_name varchar(200) DEFAULT NULL,
			bytes_out bigint(20) unsigned DEFAULT NULL,
			error varchar(255) DEFAULT NULL,
			created_at datetime NOT NULL,
			finished_at datetime DEFAULT NULL,
			duration_ms int(10) unsigned DEFAULT NULL,
			downloaded_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY ip_created (ip_hash, created_at),
			KEY tool_created (tool, created_at),
			KEY status_created (status, created_at),
			KEY country_created (country, created_at)
			) {$collate};"
		);
		update_option( 'fileora_tasks_db_version', self::DB_VERSION, false );
		self::import_old();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'fileora_tasks_db_version' ) !== self::DB_VERSION ) {
			self::install();
		}
	}

	/** Copies the task history of the earlier single "Fileora" plugin, once. */
	private static function import_old() {
		global $wpdb;
		if ( get_option( 'fileora_tasks_imported' ) ) {
			return;
		}
		$old = $wpdb->prefix . 'fileora_jobs';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $old ) ) === $old ) {
			$table = self::table();
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "INSERT IGNORE INTO {$table} (id, tool, token_hash, status, user_id, ip_hash, files, bytes_in, result_name, bytes_out, error, created_at, finished_at, duration_ms, downloaded_at) SELECT id, tool, token_hash, status, user_id, ip_hash, files, bytes_in, result_name, bytes_out, error, created_at, finished_at, CASE WHEN finished_at IS NOT NULL THEN TIMESTAMPDIFF(SECOND, created_at, finished_at) * 1000 END, downloaded_at FROM {$old}" );
		}
		update_option( 'fileora_tasks_imported', 1, false );
	}

	public static function create( array $row ) {
		global $wpdb;
		$row['created_at'] = gmdate( 'Y-m-d H:i:s' );
		return false !== $wpdb->insert( self::table(), $row ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
	}

	/** Records a task that failed before the processing server accepted it. */
	public static function record_rejected( $tool, $code, $message, array $extra = array() ) {
		self::create(
			array_merge(
				array(
					'id'          => str_replace( '-', '', wp_generate_uuid4() ),
					'tool'        => $tool,
					'status'      => 'failed',
					'error_code'  => substr( sanitize_key( $code ), 0, 40 ),
					'error'       => substr( sanitize_text_field( $message ), 0, 255 ),
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
					'duration_ms' => 0,
				),
				$extra
			)
		);
	}

	public static function find( $id ) {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %s", $id ) );
	}

	public static function update( $id, array $data ) {
		global $wpdb;
		return $wpdb->update( self::table(), $data, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/** Stores the final outcome reported by the processing server, once. */
	public static function finish( $row, array $status ) {
		if ( in_array( $row->status, array( 'done', 'failed' ), true ) ) {
			return;
		}
		$done = isset( $status['status'] ) && 'done' === $status['status'];
		self::update(
			$row->id,
			array(
				'status'      => $done ? 'done' : 'failed',
				'error_code'  => $done ? null : ( isset( $status['error_code'] ) ? substr( sanitize_key( $status['error_code'] ), 0, 40 ) : 'processing' ),
				'result_name' => isset( $status['name'] ) ? substr( sanitize_file_name( $status['name'] ), 0, 200 ) : null,
				'bytes_out'   => isset( $status['size'] ) ? (int) $status['size'] : null,
				'error'       => isset( $status['error'] ) ? substr( sanitize_text_field( $status['error'] ), 0, 255 ) : null,
				'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				'duration_ms' => max( 0, (int) round( ( microtime( true ) - strtotime( $row->created_at . ' UTC' ) ) * 1000 ) ),
			)
		);
	}

	/** Visitor-caused tasks started by this visitor (or account) in the last 24 hours. */
	public static function count_recent( $ip_hash, $user_id ) {
		global $wpdb;
		$table  = self::table();
		$since  = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
		$codes  = "'" . implode( "','", array_map( 'esc_sql', self::SYSTEM_CODES ) ) . "'";
		$who    = $user_id ? $wpdb->prepare( 'user_id = %d', $user_id ) : $wpdb->prepare( 'ip_hash = %s', $ip_hash );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$who} AND created_at >= %s AND (error_code IS NULL OR error_code NOT IN ({$codes}))", $since ) );
	}

	/** Totals for a window: tasks, done, failed, success rate, average duration. */
	public static function totals( $days = 30 ) {
		global $wpdb;
		$table = self::table();
		$since = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$r = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS total, SUM(status = 'done') AS done, SUM(status = 'failed') AS failed, SUM(status IN ('queued','running')) AS open, AVG(CASE WHEN status = 'done' THEN duration_ms END) AS avg_ms, SUM(bytes_in) AS bytes_in FROM {$table} WHERE created_at >= %s", $since ) );
		$total  = (int) $r->total;
		$done   = (int) $r->done;
		$failed = (int) $r->failed;
		return array(
			'total'    => $total,
			'done'     => $done,
			'failed'   => $failed,
			'open'     => (int) $r->open,
			'rate'     => ( $done + $failed ) ? $done / ( $done + $failed ) : null,
			'avg_ms'   => null !== $r->avg_ms ? (int) round( (float) $r->avg_ms ) : null,
			'bytes_in' => (int) $r->bytes_in,
		);
	}

	/** Usage per tool for a window. */
	public static function by_tool( $days = 30 ) {
		global $wpdb;
		$table = self::table();
		$since = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_results( $wpdb->prepare( "SELECT tool, COUNT(*) AS total, SUM(status = 'done') AS done, SUM(status = 'failed') AS failed, ROUND(AVG(CASE WHEN status = 'done' THEN duration_ms END)) AS avg_ms, SUM(bytes_in) AS bytes_in FROM {$table} WHERE created_at >= %s GROUP BY tool ORDER BY total DESC", $since ) );
	}

	/** Tasks per day (UTC date => [done, failed]) for a window. */
	public static function per_day( $days = 30 ) {
		global $wpdb;
		$table = self::table();
		$since = gmdate( 'Y-m-d 00:00:00', time() - ( $days - 1 ) * DAY_IN_SECONDS );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT DATE(created_at) AS d, SUM(status = 'done') AS done, SUM(status = 'failed') AS failed FROM {$table} WHERE created_at >= %s GROUP BY DATE(created_at)", $since ) );
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ $r->d ] = array( (int) $r->done, (int) $r->failed );
		}
		return $out;
	}

	public static function recent_failures( $limit = 10 ) {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_results( $wpdb->prepare( "SELECT id, tool, error, error_code, created_at FROM {$table} WHERE status = 'failed' ORDER BY created_at DESC LIMIT %d", $limit ) );
	}

	/**
	 * Filtered, paginated task list for the Processing Tasks screen.
	 *
	 * @param array $f from, to (Y-m-d, site time), tool, status, q (job id prefix), page, per_page.
	 * @return array{rows:array, total:int}
	 */
	public static function query( array $f ) {
		global $wpdb;
		$table = self::table();
		$where = array( '1=1' );
		$args  = array();
		if ( ! empty( $f['from_utc'] ) ) {
			$where[] = 'created_at >= %s';
			$args[]  = $f['from_utc'];
		}
		if ( ! empty( $f['to_utc'] ) ) {
			$where[] = 'created_at < %s';
			$args[]  = $f['to_utc'];
		}
		if ( ! empty( $f['tool'] ) ) {
			$where[] = 'tool = %s';
			$args[]  = $f['tool'];
		}
		if ( ! empty( $f['status'] ) ) {
			if ( 'open' === $f['status'] ) {
				$where[] = "status IN ('queued','running')";
			} else {
				$where[] = 'status = %s';
				$args[]  = $f['status'];
			}
		}
		if ( ! empty( $f['q'] ) ) {
			$where[] = 'id LIKE %s';
			$args[]  = $wpdb->esc_like( $f['q'] ) . '%';
		}
		$sql_where = implode( ' AND ', $where );
		$per       = max( 1, (int) ( isset( $f['per_page'] ) ? $f['per_page'] : 50 ) );
		$page      = max( 1, (int) ( isset( $f['page'] ) ? $f['page'] : 1 ) );
		$limit     = isset( $f['all'] ) && $f['all'] ? '' : $wpdb->prepare( 'LIMIT %d OFFSET %d', $per, ( $page - 1 ) * $per );
		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$sql_where}";
		$rows_sql  = "SELECT id, tool, status, error_code, error, files, bytes_in, bytes_out, result_name, user_id, created_at, finished_at, duration_ms, downloaded_at FROM {$table} WHERE {$sql_where} ORDER BY created_at DESC {$limit}";
		if ( $args ) {
			$count_sql = $wpdb->prepare( $count_sql, $args ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$rows_sql  = $wpdb->prepare( $rows_sql, $args ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}
		return array(
			'total' => (int) $wpdb->get_var( $count_sql ), // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
			'rows'  => $wpdb->get_results( $rows_sql ), // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		);
	}

	/** Jobs that never reported back (server restarted, visitor left) are closed. */
	public static function fail_stale( $seconds ) {
		global $wpdb;
		$table = self::table();
		$since = gmdate( 'Y-m-d H:i:s', time() - $seconds );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = 'failed', error_code = 'abandoned', error = 'No result before the time limit (the visitor may have left)', finished_at = %s WHERE status IN ('queued','running') AND created_at < %s", gmdate( 'Y-m-d H:i:s' ), $since ) );
	}

	public static function purge( $days ) {
		global $wpdb;
		$table = self::table();
		$since = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", $since ) );
	}

	/** Erases stored IP addresses older than $days. */
	public static function erase_old_ips( $days ) {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET ip = '' WHERE ip <> '' AND created_at < %s", gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) );
	}
}
