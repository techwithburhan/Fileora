<?php
/**
 * Popup announcements: maintenance notices, new features, service updates.
 *
 * Each announcement is a post of the hidden type "fileora_notice" (Fileora →
 * Announcements), edited with the classic rich-text editor, plus settings:
 * on/off, start and end date, how often a visitor sees it (once per visit,
 * once per day, every page), position (centre, top bar, bottom bar, corner),
 * colours, an optional button, and the audience (everyone, new or returning
 * visitors, logged-in or logged-out, phones or computers, and which pages).
 *
 * Dates are checked on the server and again in the browser, so a cached page
 * never shows an expired announcement. Frequency is remembered in the
 * visitor's browser (sessionStorage / localStorage), never on the server.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Announcements {

	const POST_TYPE = 'fileora_notice';
	const META      = '_fileora_notice';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ), 30 );
		add_action( 'wp_footer', array( __CLASS__, 'footer' ), 20 );
		if ( is_admin() ) {
			add_action( 'add_meta_boxes_' . self::POST_TYPE, array( __CLASS__, 'meta_boxes' ) );
			add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
			add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', array( __CLASS__, 'columns' ) );
			add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
			add_filter( 'use_block_editor_for_post_type', array( __CLASS__, 'classic_editor' ), 10, 2 );
			add_filter( 'post_row_actions', array( __CLASS__, 'row_actions' ), 10, 2 );
		}
	}

	public static function register() {
		$cap = 'fileora_manage_announcements';
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'              => array(
					'name'          => __( 'Announcements', 'fileora' ),
					'singular_name' => __( 'Announcement', 'fileora' ),
					'add_new'       => __( 'Add announcement', 'fileora' ),
					'add_new_item'  => __( 'Add announcement', 'fileora' ),
					'edit_item'     => __( 'Edit announcement', 'fileora' ),
					'all_items'     => __( 'Announcements', 'fileora' ),
					'not_found'     => __( 'No announcements yet.', 'fileora' ),
				),
				'public'              => false,
				'show_ui'             => true,
				'show_in_menu'        => false, // added under Fileora by class-admin.php
				'show_in_rest'        => false,
				'exclude_from_search' => true,
				'supports'            => array( 'title', 'editor', 'revisions' ),
				'capabilities'        => array(
					'edit_post'              => $cap,
					'read_post'              => $cap,
					'delete_post'            => $cap,
					'edit_posts'             => $cap,
					'edit_others_posts'      => $cap,
					'publish_posts'          => $cap,
					'read_private_posts'     => $cap,
					'delete_posts'           => $cap,
					'delete_published_posts' => $cap,
					'delete_others_posts'    => $cap,
					'edit_published_posts'   => $cap,
					'create_posts'           => $cap,
				),
				'map_meta_cap'        => false,
			)
		);
	}

	public static function classic_editor( $use, $post_type ) {
		return self::POST_TYPE === $post_type ? false : $use;
	}

	public static function defaults() {
		return array(
			'enabled'   => 1,
			'start'     => '',
			'end'       => '',
			'frequency' => 'session', // session | day | always
			'position'  => 'center',  // center | top | bottom | corner
			'style'     => 'light',   // light | dark | accent
			'accent'    => '#FFD43B',
			'button'    => '',
			'url'       => '',
			'audience'  => 'all',     // all | new | returning | logged_in | logged_out
			'device'    => 'all',     // all | mobile | desktop
			'pages'     => 'all',     // all | home | tools | blog
			'delay'     => 1,         // seconds before it appears
		);
	}

	public static function settings( $post_id ) {
		$m = get_post_meta( $post_id, self::META, true );
		return wp_parse_args( is_array( $m ) ? $m : array(), self::defaults() );
	}

	/** Local "Y-m-d\TH:i" → Unix time (site time zone). */
	private static function to_ts( $local ) {
		if ( ! $local ) {
			return 0;
		}
		$dt = date_create_immutable( $local, wp_timezone() );
		return $dt ? $dt->getTimestamp() : 0;
	}

	/** Current state for the list: active, scheduled, expired or off. */
	public static function state( $post ) {
		$m = self::settings( $post->ID );
		if ( 'publish' !== $post->post_status || ! $m['enabled'] ) {
			return 'off';
		}
		$now = time();
		if ( $m['end'] && self::to_ts( $m['end'] ) < $now ) {
			return 'expired';
		}
		if ( $m['start'] && self::to_ts( $m['start'] ) > $now ) {
			return 'scheduled';
		}
		return 'active';
	}

	/* ------------------------------------------------------------------
	 * Admin.
	 * ---------------------------------------------------------------- */

	public static function meta_boxes() {
		add_meta_box( 'fileora-notice', __( 'Display settings', 'fileora' ), array( __CLASS__, 'box' ), self::POST_TYPE, 'normal', 'high' );
		add_meta_box( 'fileora-notice-preview', __( 'Preview', 'fileora' ), array( __CLASS__, 'preview_box' ), self::POST_TYPE, 'side', 'high' );
	}

	public static function preview_box( $post ) {
		if ( 'auto-draft' === $post->post_status ) {
			echo '<p>' . esc_html__( 'Save a draft first, then preview it on your homepage.', 'fileora' ) . '</p>';
			return;
		}
		$url = wp_nonce_url( add_query_arg( 'fileora_notice_preview', $post->ID, home_url( '/' ) ), 'fileora_notice_preview_' . $post->ID );
		echo '<p>' . esc_html__( 'Opens your homepage with this announcement, even if it is switched off or scheduled. Save your changes first. Only you see the preview.', 'fileora' ) . '</p>';
		echo '<p><a class="button" target="_blank" rel="noopener" href="' . esc_url( $url ) . '">' . esc_html__( 'Preview on the site', 'fileora' ) . '</a></p>';
	}

	public static function box( $post ) {
		$m = self::settings( $post->ID );
		wp_nonce_field( 'fileora_notice_save', 'fileora_notice_nonce' );
		$sel = function ( $name, $choices ) use ( $m ) {
			$h = '<select name="fileora_notice[' . esc_attr( $name ) . ']" id="fo-n-' . esc_attr( $name ) . '">';
			foreach ( $choices as $v => $l ) {
				$h .= '<option value="' . esc_attr( $v ) . '"' . selected( $m[ $name ], $v, false ) . '>' . esc_html( $l ) . '</option>';
			}
			return $h . '</select>';
		};
		?>
		<table class="form-table" role="presentation">
			<tr><th scope="row"><?php esc_html_e( 'Show it', 'fileora' ); ?></th><td><label><input type="checkbox" name="fileora_notice[enabled]" value="1" <?php checked( $m['enabled'] ); ?>> <?php esc_html_e( 'Announcement is switched on', 'fileora' ); ?></label><p class="description"><?php esc_html_e( 'It also has to be published. Switch it off to keep it for later without deleting it.', 'fileora' ); ?></p></td></tr>
			<tr><th scope="row"><label for="fo-n-start"><?php esc_html_e( 'Start', 'fileora' ); ?></label></th><td><input type="datetime-local" id="fo-n-start" name="fileora_notice[start]" value="<?php echo esc_attr( $m['start'] ); ?>"> <span class="description"><?php esc_html_e( 'Empty = right away', 'fileora' ); ?></span></td></tr>
			<tr><th scope="row"><label for="fo-n-end"><?php esc_html_e( 'Expires', 'fileora' ); ?></label></th><td><input type="datetime-local" id="fo-n-end" name="fileora_notice[end]" value="<?php echo esc_attr( $m['end'] ); ?>"> <span class="description"><?php echo esc_html( sprintf( /* translators: %s: timezone */ __( 'Empty = never. Times are in %s.', 'fileora' ), wp_timezone_string() ) ); ?></span></td></tr>
			<tr><th scope="row"><label for="fo-n-frequency"><?php esc_html_e( 'How often', 'fileora' ); ?></label></th><td><?php echo $sel( 'frequency', array( 'session' => __( 'Once per visit', 'fileora' ), 'day' => __( 'Once per day', 'fileora' ), 'always' => __( 'On every page', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><p class="description"><?php esc_html_e( 'After a visitor closes it, it stays closed for that visit or that day. Editing the announcement shows it again.', 'fileora' ); ?></p></td></tr>
			<tr><th scope="row"><label for="fo-n-position"><?php esc_html_e( 'Position', 'fileora' ); ?></label></th><td><?php echo $sel( 'position', array( 'center' => __( 'Centre of the screen (popup)', 'fileora' ), 'top' => __( 'Bar at the top', 'fileora' ), 'bottom' => __( 'Bar at the bottom', 'fileora' ), 'corner' => __( 'Small card, bottom right', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td></tr>
			<tr><th scope="row"><label for="fo-n-style"><?php esc_html_e( 'Look', 'fileora' ); ?></label></th><td><?php echo $sel( 'style', array( 'light' => __( 'Light', 'fileora' ), 'dark' => __( 'Dark', 'fileora' ), 'accent' => __( 'Highlight colour', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <label><?php esc_html_e( 'Highlight colour', 'fileora' ); ?> <input type="color" name="fileora_notice[accent]" value="<?php echo esc_attr( $m['accent'] ); ?>"></label><p class="description"><?php esc_html_e( 'The highlight colour is used for the button, and for the background with the “Highlight colour” look. Pick a light colour: the text on it is dark.', 'fileora' ); ?></p></td></tr>
			<tr><th scope="row"><label for="fo-n-button"><?php esc_html_e( 'Button (optional)', 'fileora' ); ?></label></th><td><input type="text" class="regular-text" id="fo-n-button" name="fileora_notice[button]" value="<?php echo esc_attr( $m['button'] ); ?>" placeholder="<?php esc_attr_e( 'e.g. Try it now', 'fileora' ); ?>"> <input type="url" class="regular-text" name="fileora_notice[url]" value="<?php echo esc_attr( $m['url'] ); ?>" placeholder="https://"></td></tr>
			<tr><th scope="row"><label for="fo-n-audience"><?php esc_html_e( 'Who sees it', 'fileora' ); ?></label></th><td>
				<?php
				echo $sel( 'audience', array( 'all' => __( 'Everyone', 'fileora' ), 'new' => __( 'First-time visitors', 'fileora' ), 'returning' => __( 'Returning visitors', 'fileora' ), 'logged_in' => __( 'Logged-in users', 'fileora' ), 'logged_out' => __( 'Visitors who are not logged in', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo ' ' . $sel( 'device', array( 'all' => __( 'on all devices', 'fileora' ), 'mobile' => __( 'on phones and tablets', 'fileora' ), 'desktop' => __( 'on computers', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo ' ' . $sel( 'pages', array( 'all' => __( 'on every page', 'fileora' ), 'home' => __( 'on the homepage', 'fileora' ), 'tools' => __( 'on tool pages', 'fileora' ), 'blog' => __( 'on blog posts', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
				<p class="description"><?php esc_html_e( '“First-time” and “returning” are recognised by the visitor’s browser. If a page cache serves the same page to everyone, logged-in and logged-out targeting depends on your cache keeping logged-in pages separate (LiteSpeed Cache does).', 'fileora' ); ?></p>
			</td></tr>
			<tr><th scope="row"><label for="fo-n-delay"><?php esc_html_e( 'Delay', 'fileora' ); ?></label></th><td><input type="number" min="0" max="60" id="fo-n-delay" name="fileora_notice[delay]" value="<?php echo esc_attr( $m['delay'] ); ?>" class="small-text"> <?php esc_html_e( 'seconds after the page opens', 'fileora' ); ?></td></tr>
		</table>
		<?php
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['fileora_notice_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['fileora_notice_nonce'] ), 'fileora_notice_save' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'fileora_manage_announcements' ) ) {
			return;
		}
		$in  = isset( $_POST['fileora_notice'] ) && is_array( $_POST['fileora_notice'] ) ? wp_unslash( $_POST['fileora_notice'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized below
		$d   = self::defaults();
		$one = function ( $k, $allowed ) use ( $in, $d ) {
			return isset( $in[ $k ] ) && in_array( $in[ $k ], $allowed, true ) ? $in[ $k ] : $d[ $k ];
		};
		$dt  = function ( $k ) use ( $in ) {
			$v = isset( $in[ $k ] ) ? sanitize_text_field( $in[ $k ] ) : '';
			return preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $v ) ? $v : '';
		};
		$out = array(
			'enabled'   => empty( $in['enabled'] ) ? 0 : 1,
			'start'     => $dt( 'start' ),
			'end'       => $dt( 'end' ),
			'frequency' => $one( 'frequency', array( 'session', 'day', 'always' ) ),
			'position'  => $one( 'position', array( 'center', 'top', 'bottom', 'corner' ) ),
			'style'     => $one( 'style', array( 'light', 'dark', 'accent' ) ),
			'accent'    => isset( $in['accent'] ) && sanitize_hex_color( $in['accent'] ) ? sanitize_hex_color( $in['accent'] ) : $d['accent'],
			'button'    => isset( $in['button'] ) ? mb_substr( sanitize_text_field( $in['button'] ), 0, 40 ) : '',
			'url'       => isset( $in['url'] ) ? esc_url_raw( $in['url'], array( 'http', 'https' ) ) : '',
			'audience'  => $one( 'audience', array( 'all', 'new', 'returning', 'logged_in', 'logged_out' ) ),
			'device'    => $one( 'device', array( 'all', 'mobile', 'desktop' ) ),
			'pages'     => $one( 'pages', array( 'all', 'home', 'tools', 'blog' ) ),
			'delay'     => isset( $in['delay'] ) ? min( 60, absint( $in['delay'] ) ) : 1,
		);
		update_post_meta( $post_id, self::META, $out );
	}

	public static function columns( $cols ) {
		$new = array();
		foreach ( $cols as $k => $v ) {
			$new[ $k ] = $v;
			if ( 'title' === $k ) {
				$new['fo_state']    = __( 'Status', 'fileora' );
				$new['fo_when']     = __( 'Shown', 'fileora' );
				$new['fo_how']      = __( 'How often / where', 'fileora' );
			}
		}
		unset( $new['date'] );
		return $new;
	}

	public static function column( $col, $post_id ) {
		$post = get_post( $post_id );
		$m    = self::settings( $post_id );
		if ( 'fo_state' === $col ) {
			$labels = array(
				'active'    => __( 'Showing now', 'fileora' ),
				'scheduled' => __( 'Scheduled', 'fileora' ),
				'expired'   => __( 'Expired', 'fileora' ),
				'off'       => __( 'Off', 'fileora' ),
			);
			$state  = self::state( $post );
			echo '<span class="fo-pill fo-pill-' . esc_attr( $state ) . '">' . esc_html( $labels[ $state ] ) . '</span>';
		} elseif ( 'fo_when' === $col ) {
			$fmt = function ( $v ) {
				return $v ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), self::to_ts( $v ) ) : '';
			};
			echo esc_html( ( $m['start'] ? $fmt( $m['start'] ) : __( 'Now', 'fileora' ) ) . ' → ' . ( $m['end'] ? $fmt( $m['end'] ) : __( 'no end', 'fileora' ) ) );
		} elseif ( 'fo_how' === $col ) {
			$f = array( 'session' => __( 'once per visit', 'fileora' ), 'day' => __( 'once per day', 'fileora' ), 'always' => __( 'every page', 'fileora' ) );
			$p = array( 'center' => __( 'popup', 'fileora' ), 'top' => __( 'top bar', 'fileora' ), 'bottom' => __( 'bottom bar', 'fileora' ), 'corner' => __( 'corner card', 'fileora' ) );
			echo esc_html( $p[ $m['position'] ] . ', ' . $f[ $m['frequency'] ] );
		}
	}

	public static function row_actions( $actions, $post ) {
		if ( self::POST_TYPE === $post->post_type && current_user_can( 'fileora_manage_announcements' ) ) {
			$url                        = wp_nonce_url( add_query_arg( 'fileora_notice_preview', $post->ID, home_url( '/' ) ), 'fileora_notice_preview_' . $post->ID );
			$actions['fileora_preview'] = '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Preview', 'fileora' ) . '</a>';
			unset( $actions['inline hide-if-no-js'] );
		}
		return $actions;
	}

	/* ------------------------------------------------------------------
	 * Front end.
	 * ---------------------------------------------------------------- */

	private static $items = null;

	/** The preview id, when a user who may manage announcements asked for one. */
	private static function preview_id() {
		if ( empty( $_GET['fileora_notice_preview'] ) || empty( $_GET['_wpnonce'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return 0;
		}
		$id = absint( $_GET['fileora_notice_preview'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! current_user_can( 'fileora_manage_announcements' ) || ! wp_verify_nonce( sanitize_key( $_GET['_wpnonce'] ), 'fileora_notice_preview_' . $id ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return 0;
		}
		return $id;
	}

	private static function page_kind() {
		if ( is_front_page() ) {
			return 'home';
		}
		if ( is_singular( Fileora_Tool_Registry::POST_TYPE ) ) {
			return 'tools';
		}
		if ( is_singular( 'post' ) ) {
			return 'blog';
		}
		return 'other';
	}

	/** Announcements for this page. */
	public static function items() {
		if ( null !== self::$items ) {
			return self::$items;
		}
		self::$items = array();
		if ( is_admin() || is_feed() || is_embed() ) {
			return self::$items;
		}
		$preview = self::preview_id();
		if ( $preview ) {
			$posts = array_filter( array( get_post( $preview ) ) );
		} else {
			$posts = get_posts(
				array(
					'post_type'        => self::POST_TYPE,
					'post_status'      => 'publish',
					'numberposts'      => 5,
					'orderby'          => 'date',
					'order'            => 'DESC',
					'suppress_filters' => false,
				)
			);
		}
		$kind = self::page_kind();
		$now  = time();
		foreach ( $posts as $p ) {
			if ( self::POST_TYPE !== $p->post_type ) {
				continue;
			}
			$m     = self::settings( $p->ID );
			$start = self::to_ts( $m['start'] );
			$end   = self::to_ts( $m['end'] );
			if ( ! $preview ) {
				if ( ! $m['enabled'] || ( $end && $end < $now ) ) {
					continue;
				}
				if ( 'all' !== $m['pages'] && $m['pages'] !== $kind ) {
					continue;
				}
				if ( ( 'logged_in' === $m['audience'] && ! is_user_logged_in() ) || ( 'logged_out' === $m['audience'] && is_user_logged_in() ) ) {
					continue;
				}
			}
			$content       = apply_filters( 'the_content', $p->post_content );
			self::$items[] = array(
				'id'        => $p->ID,
				'v'         => strtotime( $p->post_modified_gmt . ' UTC' ),
				'title'     => get_the_title( $p ),
				'html'      => wp_kses_post( $content ),
				'start'     => $preview ? 0 : $start * 1000,
				'end'       => $preview ? 0 : $end * 1000,
				'frequency' => $preview ? 'always' : $m['frequency'],
				'position'  => $m['position'],
				'style'     => $m['style'],
				'accent'    => $m['accent'],
				'button'    => $m['button'],
				'url'       => $m['url'],
				'audience'  => $preview ? 'all' : $m['audience'],
				'device'    => $preview ? 'all' : $m['device'],
				'delay'     => $preview ? 0 : (int) $m['delay'],
				'preview'   => (bool) $preview,
			);
		}
		return self::$items;
	}

	public static function assets() {
		if ( ! self::items() ) {
			return;
		}
		wp_enqueue_style( 'fileora-notice', FILEORA_CORE_URL . 'public/css/fileora-notice.css', array(), FILEORA_CORE_VERSION );
		wp_enqueue_script( 'fileora-notice', FILEORA_CORE_URL . 'public/js/fileora-notice.js', array(), FILEORA_CORE_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	}

	public static function footer() {
		$items = self::items();
		if ( ! $items ) {
			return;
		}
		wp_print_inline_script_tag(
			'window.FileoraNotices=' . wp_json_encode(
				array(
					'items' => $items,
					'close' => __( 'Close', 'fileora' ),
					'label' => __( 'Announcement', 'fileora' ),
				),
				JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP
			) . ';',
			array( 'id' => 'fileora-notices' )
		);
	}
}
