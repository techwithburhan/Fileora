<?php
/**
 * Server monitoring: real health checks of the processing server
 * (table {prefix}fileora_health).
 *
 * A scheduled check runs every few minutes (Settings → Monitoring interval).
 * Each check stores: time, up/down, HTTP status, response time, whether the
 * shared key is accepted, and how many tools the server can run; since 2.12
 * also a network probe (ICMP ping, or a labelled TCP/HTTP fallback: latency,
 * packet loss, reachability, see Fileora_Net_Probe) and the server's own
 * figures from GET /metrics (CPU, memory, disk, network, uptime). Values that
 * weren't measured are stored as NULL and shown as "Not Available".
 *
 * Availability is time-based, as documented in the README:
 *
 *   Availability = time covered by successful checks / total monitored time × 100
 *
 * Each check "covers" the time until the next check, but never more than two
 * intervals. Longer gaps (WP-Cron not running, site down) count as
 * unmonitored time: they are left out of availability and reported
 * separately as monitoring coverage, so missing checks are never counted as
 * uptime.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Server_Monitor {

	const DB_VERSION = '2';
	const HOOK       = 'fileora_core_health_check';
	const SCHEDULE   = 'fileora_monitor';
	const LAST       = 'fileora_last_health';

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval
		add_action( self::HOOK, array( __CLASS__, 'scheduled_check' ) );
		add_action( 'update_option_' . Fileora_Core_Settings::OPTION, array( __CLASS__, 'reschedule' ), 20, 2 );
	}

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'fileora_health';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$collate = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			checked_at datetime NOT NULL,
			ok tinyint(1) NOT NULL DEFAULT 0,
			http_code smallint(5) unsigned NOT NULL DEFAULT 0,
			latency_ms int(10) unsigned NOT NULL DEFAULT 0,
			auth_ok tinyint(1) DEFAULT NULL,
			tools_ok smallint(5) unsigned DEFAULT NULL,
			tools_total smallint(5) unsigned DEFAULT NULL,
			error varchar(255) DEFAULT NULL,
			source varchar(8) NOT NULL DEFAULT 'cron',
			probe varchar(8) DEFAULT NULL,
			probe_port smallint(5) unsigned DEFAULT NULL,
			icmp varchar(12) DEFAULT NULL,
			probe_ms decimal(9,2) DEFAULT NULL,
			probe_min decimal(9,2) DEFAULT NULL,
			probe_max decimal(9,2) DEFAULT NULL,
			probe_sent tinyint(3) unsigned DEFAULT NULL,
			probe_recv tinyint(3) unsigned DEFAULT NULL,
			probe_loss decimal(5,1) DEFAULT NULL,
			reachable tinyint(1) DEFAULT NULL,
			cpu_pct decimal(5,1) DEFAULT NULL,
			load1 decimal(7,2) DEFAULT NULL,
			mem_pct decimal(5,1) DEFAULT NULL,
			mem_used bigint(20) unsigned DEFAULT NULL,
			mem_total bigint(20) unsigned DEFAULT NULL,
			disk_pct decimal(5,1) DEFAULT NULL,
			disk_free bigint(20) unsigned DEFAULT NULL,
			disk_total bigint(20) unsigned DEFAULT NULL,
			net_rx_bps bigint(20) unsigned DEFAULT NULL,
			net_tx_bps bigint(20) unsigned DEFAULT NULL,
			uptime_s bigint(20) unsigned DEFAULT NULL,
			temp_tasks int(10) unsigned DEFAULT NULL,
			temp_bytes bigint(20) unsigned DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY checked_at (checked_at)
			) {$collate};"
		);
		update_option( 'fileora_health_db_version', self::DB_VERSION, false );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'fileora_health_db_version' ) !== self::DB_VERSION ) {
			self::install();
		}
	}

	public static function interval() {
		return max( 5, (int) Fileora_Core_Settings::value( 'monitor_interval' ) ) * MINUTE_IN_SECONDS;
	}

	public static function schedules( $s ) {
		$s[ self::SCHEDULE ] = array(
			'interval' => self::interval(),
			/* translators: %d: minutes */
			'display'  => sprintf( __( 'Fileora health check (every %d minutes)', 'fileora' ), (int) ( self::interval() / 60 ) ),
		);
		return $s;
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 60, self::SCHEDULE, self::HOOK );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOOK );
	}

	public static function reschedule( $old, $new ) {
		$o = is_array( $old ) && isset( $old['monitor_interval'] ) ? (int) $old['monitor_interval'] : 0;
		$n = is_array( $new ) && isset( $new['monitor_interval'] ) ? (int) $new['monitor_interval'] : 0;
		if ( $o !== $n ) {
			Fileora_Core_Settings::flush_cache();
			self::unschedule();
			self::schedule();
		}
	}

	public static function scheduled_check() {
		self::check( 'cron' );
	}

	/**
	 * Runs one health check now, stores it and returns the result.
	 *
	 * @param string $source 'cron' or 'manual'.
	 */
	public static function check( $source = 'manual' ) {
		$r       = Fileora_Backend_API::check();
		$tools   = isset( $r['body']['tools'] ) && is_array( $r['body']['tools'] ) ? $r['body']['tools'] : array();
		$probe   = Fileora_Net_Probe::run( $r );
		$metrics = null;
		$m_error = '';
		if ( $r['ok'] && true === $r['auth'] ) {
			$m = Fileora_Backend_API::metrics();
			if ( is_wp_error( $m ) ) {
				$m_error = $m->get_error_message();
			} elseif ( 200 === $m['status'] ) {
				$metrics = $m['body'];
			} else {
				$m_error = 404 === $m['status'] ? 'not-supported' : sprintf( 'HTTP %d', $m['status'] );
			}
		}
		$num = function ( $v ) {
			return is_numeric( $v ) ? $v + 0 : null;
		};
		$get = function ( $path ) use ( $metrics, $num ) {
			$v = $metrics;
			foreach ( explode( '.', $path ) as $k ) {
				if ( ! is_array( $v ) || ! array_key_exists( $k, $v ) ) {
					return null;
				}
				$v = $v[ $k ];
			}
			return $num( $v );
		};
		$cpu  = $get( 'cpu.pct_5m' );
		$load = is_array( $metrics ) && isset( $metrics['cpu']['load'][0] ) ? $num( $metrics['cpu']['load'][0] ) : null;
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			self::table(),
			array(
				'checked_at'  => gmdate( 'Y-m-d H:i:s' ),
				'ok'          => $r['ok'] ? 1 : 0,
				'http_code'   => (int) $r['http'],
				'latency_ms'  => (int) $r['latency_ms'],
				'auth_ok'     => null === $r['auth'] ? null : ( $r['auth'] ? 1 : 0 ),
				'tools_ok'    => $tools ? count( array_filter( $tools ) ) : null,
				'tools_total' => $tools ? count( $tools ) : null,
				'error'       => $r['error'] ? substr( $r['error'], 0, 255 ) : null,
				'source'      => 'manual' === $source ? 'manual' : 'cron',
				'probe'       => $probe['method'],
				'probe_port'  => 'icmp' === $probe['method'] ? null : $probe['port'],
				'icmp'        => $probe['icmp'],
				'probe_ms'    => $probe['avg_ms'],
				'probe_min'   => $probe['min_ms'],
				'probe_max'   => $probe['max_ms'],
				'probe_sent'  => $probe['sent'],
				'probe_recv'  => $probe['received'],
				'probe_loss'  => $probe['loss'],
				'reachable'   => null === $probe['reachable'] ? null : ( $probe['reachable'] ? 1 : 0 ),
				'cpu_pct'     => null !== $cpu ? $cpu : $get( 'cpu.pct' ),
				'load1'       => $load,
				'mem_pct'     => $get( 'memory.pct' ),
				'mem_used'    => $get( 'memory.used' ),
				'mem_total'   => $get( 'memory.total' ),
				'disk_pct'    => $get( 'disk.pct' ),
				'disk_free'   => $get( 'disk.free' ),
				'disk_total'  => $get( 'disk.total' ),
				'net_rx_bps'  => $get( 'network.rx_bps' ),
				'net_tx_bps'  => $get( 'network.tx_bps' ),
				'uptime_s'    => $get( 'uptime' ),
				'temp_tasks'  => $get( 'temp.tasks' ),
				'temp_bytes'  => $get( 'temp.bytes' ),
			)
		);
		update_option(
			self::LAST,
			array(
				'time'          => time(),
				'ok'            => $r['ok'],
				'auth'          => $r['auth'],
				'http'          => $r['http'],
				'latency_ms'    => $r['latency_ms'],
				'error'         => $r['error'],
				'body'          => $r['body'],
				'probe'         => $probe,
				'metrics'       => $metrics,
				'metrics_error' => $m_error,
			),
			false
		);
		return $r;
	}

	/** Unix time of the most recent successful check, or null. */
	public static function last_success() {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$t = $wpdb->get_var( "SELECT checked_at FROM {$table} WHERE ok = 1 ORDER BY checked_at DESC LIMIT 1" );
		return $t ? strtotime( $t . ' UTC' ) : null;
	}

	/** Is the schedule running? false when the last check is older than three intervals. */
	public static function schedule_ok() {
		$l = self::last();
		return $l && ( time() - (int) $l['time'] ) <= 3 * self::interval() + 120;
	}

	/** The most recent check result (or null when none has run yet). */
	public static function last() {
		$l = get_option( self::LAST, null );
		return is_array( $l ) ? $l : null;
	}

	/**
	 * Can the server run this tool? true / false, or null when unknown
	 * (no check yet, or the last one is older than three intervals).
	 */
	public static function tool_available( $tool_id ) {
		$l = self::last();
		if ( ! $l || ( time() - (int) $l['time'] ) > max( 3 * self::interval(), HOUR_IN_SECONDS ) ) {
			return null;
		}
		if ( ! $l['ok'] || false === $l['auth'] ) {
			return false;
		}
		$tools = isset( $l['body']['tools'] ) && is_array( $l['body']['tools'] ) ? $l['body']['tools'] : array();
		return isset( $tools[ $tool_id ] ) ? (bool) $tools[ $tool_id ] : null;
	}

	/** Checks inside a window, oldest first. */
	public static function checks( $seconds ) {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_results( $wpdb->prepare( "SELECT checked_at, ok, http_code, latency_ms, auth_ok, tools_ok, tools_total, error, source, probe, probe_port, icmp, probe_ms, probe_min, probe_max, probe_sent, probe_recv, probe_loss, reachable, cpu_pct, load1, mem_pct, mem_used, mem_total, disk_pct, disk_free, disk_total, net_rx_bps, net_tx_bps, uptime_s, temp_tasks, temp_bytes FROM {$table} WHERE checked_at >= %s ORDER BY checked_at ASC", gmdate( 'Y-m-d H:i:s', time() - $seconds ) ) );
	}

	/**
	 * Time-based availability for a window ending now.
	 *
	 * @param int        $seconds Window length.
	 * @param array|null $rows    Checks (oldest first); loaded when null.
	 * @param int|null   $end     Window end (Unix time); now when null.
	 * @return array{availability:float|null, coverage:float, up:int, down:int, monitored:int, checks:int, ok_checks:int, check_rate:float|null, window:int}
	 */
	public static function uptime( $seconds, $rows = null, $end = null ) {
		$end   = null === $end ? time() : (int) $end;
		$start = $end - $seconds;
		$rows  = null === $rows ? self::checks( $seconds ) : $rows;
		$cap   = 2 * self::interval();
		$up    = 0;
		$down  = 0;
		$ok_n  = 0;
		$n     = 0;
		$list  = array();
		foreach ( $rows as $r ) {
			$t = strtotime( $r->checked_at . ' UTC' );
			if ( $t >= $start && $t <= $end ) {
				$list[] = array( $t, (int) $r->ok );
			}
		}
		$count = count( $list );
		foreach ( $list as $i => $c ) {
			$next = $i + 1 < $count ? $list[ $i + 1 ][0] : $end;
			$span = max( 0, min( $next, $c[0] + $cap, $end ) - $c[0] );
			if ( $c[1] ) {
				$up += $span;
				++$ok_n;
			} else {
				$down += $span;
			}
			++$n;
		}
		$monitored = $up + $down;
		return array(
			'availability' => $monitored > 0 ? $up / $monitored * 100 : null,
			'coverage'     => $seconds > 0 ? min( 100, $monitored / $seconds * 100 ) : 0,
			'up'           => $up,
			'down'         => $down,
			'monitored'    => $monitored,
			'checks'       => $n,
			'ok_checks'    => $ok_n,
			'check_rate'   => $n ? $ok_n / $n * 100 : null,
			'window'       => $seconds,
		);
	}

	/** Availability per day (UTC date => availability or null) for the last $days. */
	public static function daily( $days = 30 ) {
		$rows = self::checks( $days * DAY_IN_SECONDS + DAY_IN_SECONDS );
		$out  = array();
		$today_end = time();
		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$day_start = strtotime( gmdate( 'Y-m-d 00:00:00', time() - $i * DAY_IN_SECONDS ) . ' UTC' );
			$day_end   = min( $today_end, $day_start + DAY_IN_SECONDS );
			$u         = self::uptime( $day_end - $day_start, $rows, $day_end );
			$out[ gmdate( 'Y-m-d', $day_start ) ] = $u;
		}
		return $out;
	}

	public static function purge( $days ) {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE checked_at < %s", gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) );
	}
}
