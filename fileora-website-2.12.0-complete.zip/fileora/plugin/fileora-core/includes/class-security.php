<?php
/**
 * Upload validation, visitor identity (hashed) and job tokens.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Core_Security {

	/** Cloudflare's published edge ranges (https://www.cloudflare.com/ips/). */
	const CLOUDFLARE = array(
		'173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22', '141.101.64.0/18', '108.162.192.0/18',
		'190.93.240.0/20', '188.114.96.0/20', '197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
		'104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
		'2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32', '2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32',
	);

	/** @var string|null */
	private static $ip = null;

	private static function server( $key ) {
		return isset( $_SERVER[ $key ] ) ? trim( sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) ) : '';
	}

	/** True for a public (not private, loopback or reserved) address. */
	public static function is_public_ip( $ip ) {
		return (bool) filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
	}

	public static function in_cidr( $ip, $cidr ) {
		list( $net, $bits ) = explode( '/', $cidr );
		$a = @inet_pton( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$b = @inet_pton( $net ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( false === $a || false === $b || strlen( $a ) !== strlen( $b ) ) {
			return false;
		}
		$bits  = (int) $bits;
		$bytes = intdiv( $bits, 8 );
		if ( $bytes && substr( $a, 0, $bytes ) !== substr( $b, 0, $bytes ) ) {
			return false;
		}
		$rest = $bits % 8;
		if ( ! $rest ) {
			return true;
		}
		$mask = chr( ( 0xff << ( 8 - $rest ) ) & 0xff );
		return ( $a[ $bytes ] & $mask ) === ( $b[ $bytes ] & $mask );
	}

	public static function from_cloudflare( $ip ) {
		foreach ( self::CLOUDFLARE as $cidr ) {
			if ( self::in_cidr( $ip, $cidr ) ) {
				return true;
			}
		}
		return false;
	}

	/** First public address in an X-Forwarded-For list ("client, proxy1, proxy2"). */
	private static function first_public( $list ) {
		foreach ( array_map( 'trim', explode( ',', (string) $list ) ) as $ip ) {
			$ip = preg_replace( '/:\d+$/', '', trim( $ip, '[] ' ) ); // strip "1.2.3.4:5678" ports
			if ( self::is_public_ip( $ip ) ) {
				return $ip;
			}
		}
		return '';
	}

	/**
	 * Every address the request reports, for the diagnostics in Settings.
	 *
	 * @return array<string,string>
	 */
	public static function ip_candidates() {
		return array(
			'REMOTE_ADDR'          => self::server( 'REMOTE_ADDR' ),
			'CF-Connecting-IP'     => self::server( 'HTTP_CF_CONNECTING_IP' ),
			'True-Client-IP'       => self::server( 'HTTP_TRUE_CLIENT_IP' ),
			'X-Forwarded-For'      => self::server( 'HTTP_X_FORWARDED_FOR' ),
			'X-Real-IP'            => self::server( 'HTTP_X_REAL_IP' ),
		);
	}

	/**
	 * The visitor's IP address.
	 *
	 * Settings → Visitor location → "Visitor IP address comes from":
	 *   auto        Cloudflare's CF-Connecting-IP when the request really comes
	 *               from Cloudflare; X-Forwarded-For / X-Real-IP when the server
	 *               itself is behind a local proxy (private REMOTE_ADDR);
	 *               otherwise REMOTE_ADDR.
	 *   remote      REMOTE_ADDR only.
	 *   cloudflare  CF-Connecting-IP (site always behind Cloudflare).
	 *   forwarded   first public address in X-Forwarded-For (a CDN or proxy you trust).
	 *   real        X-Real-IP.
	 * Headers can be faked by anyone, so they are only used in "auto" when the
	 * connection comes from where such a header is expected.
	 */
	public static function client_ip() {
		if ( null !== self::$ip ) {
			return (string) apply_filters( 'fileora_client_ip', self::$ip );
		}
		$remote = preg_replace( '/:\d+$/', '', self::server( 'REMOTE_ADDR' ) );
		$remote = filter_var( $remote, FILTER_VALIDATE_IP ) ? $remote : self::server( 'REMOTE_ADDR' );
		$cf     = self::server( 'HTTP_CF_CONNECTING_IP' );
		$xff    = self::first_public( self::server( 'HTTP_X_FORWARDED_FOR' ) );
		$real   = self::is_public_ip( self::server( 'HTTP_X_REAL_IP' ) ) ? self::server( 'HTTP_X_REAL_IP' ) : '';
		$mode   = class_exists( 'Fileora_Core_Settings' ) ? (string) Fileora_Core_Settings::value( 'ip_source' ) : 'auto';
		$ip     = $remote;
		switch ( $mode ) {
			case 'remote':
				break;
			case 'cloudflare':
				$ip = filter_var( $cf, FILTER_VALIDATE_IP ) ? $cf : $remote;
				break;
			case 'forwarded':
				$ip = $xff ? $xff : $remote;
				break;
			case 'real':
				$ip = $real ? $real : $remote;
				break;
			default:
				if ( filter_var( $cf, FILTER_VALIDATE_IP ) && self::from_cloudflare( $remote ) ) {
					$ip = $cf;
				} elseif ( ! self::is_public_ip( $remote ) && ( $xff || $real ) ) {
					$ip = $xff ? $xff : $real;
				}
		}
		self::$ip = (string) $ip;
		return (string) apply_filters( 'fileora_client_ip', self::$ip );
	}

	/** For tests and settings changes. */
	public static function reset_ip() {
		self::$ip = null;
	}

	/**
	 * The IP address as Settings → Visitor Analytics says it may be stored:
	 * full, anonymized (IPv4 last part / IPv6 last 80 bits set to zero) or not at all.
	 */
	public static function stored_ip( $ip = null ) {
		$ip   = null === $ip ? self::client_ip() : (string) $ip;
		$mode = (string) Fileora_Core_Settings::value( 'ip_mode' );
		if ( 'none' === $mode || ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return '';
		}
		if ( 'anon' === $mode ) {
			$bin = inet_pton( $ip );
			if ( 4 === strlen( $bin ) ) {
				$bin[3] = "\0";
			} else {
				$bin = substr( $bin, 0, 6 ) . str_repeat( "\0", 10 );
			}
			return inet_ntop( $bin );
		}
		return $ip;
	}

	/** Keyed hash of the IP address (used for the daily task limit). */
	public static function ip_hash() {
		return hash_hmac( 'sha256', self::client_ip(), wp_salt( 'auth' ) );
	}

	/**
	 * Anonymous visitor id for analytics: a keyed hash of IP, browser and the
	 * date. It changes every day, so visitors can't be followed across days.
	 */
	public static function session_id() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		return substr( hash_hmac( 'sha256', self::client_ip() . '|' . $ua . '|' . gmdate( 'Y-m-d' ), wp_salt( 'nonce' ) ), 0, 16 );
	}

	/** Random token the browser must show to read a job's status or result. */
	public static function new_token() {
		$token = bin2hex( random_bytes( 24 ) );
		return array( $token, hash( 'sha256', $token ) );
	}

	public static function token_matches( $token, $hash ) {
		return is_string( $token ) && '' !== $token && hash_equals( (string) $hash, hash( 'sha256', $token ) );
	}

	/**
	 * Turns $_FILES['files'] (single or multiple) into a flat list.
	 *
	 * @param array|null $files Raw entry from the request.
	 * @return array<int, array{name:string, tmp_name:string, size:int, error:int}>
	 */
	public static function normalize_files( $files ) {
		if ( empty( $files ) || ! isset( $files['name'] ) ) {
			return array();
		}
		$list = array();
		if ( is_array( $files['name'] ) ) {
			foreach ( array_keys( $files['name'] ) as $i ) {
				$list[] = array(
					'name'     => (string) $files['name'][ $i ],
					'tmp_name' => (string) $files['tmp_name'][ $i ],
					'size'     => (int) $files['size'][ $i ],
					'error'    => (int) $files['error'][ $i ],
				);
			}
		} else {
			$list[] = array(
				'name'     => (string) $files['name'],
				'tmp_name' => (string) $files['tmp_name'],
				'size'     => (int) $files['size'],
				'error'    => (int) $files['error'],
			);
		}
		return $list;
	}

	/**
	 * Checks one uploaded file: upload error, size, extension and real content.
	 *
	 * @return true|WP_Error
	 */
	public static function validate_file( array $file, $accept, $max_bytes ) {
		$name = sanitize_file_name( $file['name'] );
		if ( UPLOAD_ERR_OK !== $file['error'] ) {
			if ( in_array( $file['error'], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ) {
				return new WP_Error( 'fileora_too_big', sprintf( '%s is larger than this server allows.', $name ), array( 'status' => 413 ) );
			}
			return new WP_Error( 'fileora_upload', sprintf( '%s didn’t upload completely. Please try again.', $name ), array( 'status' => 400 ) );
		}
		if ( ! is_uploaded_file( $file['tmp_name'] ) && ! apply_filters( 'fileora_trust_upload', false, $file ) ) {
			return new WP_Error( 'fileora_upload', 'The upload could not be verified.', array( 'status' => 400 ) );
		}
		if ( $file['size'] > $max_bytes ) {
			return new WP_Error( 'fileora_too_big', sprintf( '%s is larger than %d MB.', $name, (int) ( $max_bytes / MB_IN_BYTES ) ), array( 'status' => 413 ) );
		}
		$ext     = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		$allowed = isset( Fileora_Tool_Registry::EXTENSIONS[ $accept ] ) ? Fileora_Tool_Registry::EXTENSIONS[ $accept ] : array();
		if ( ! in_array( $ext, $allowed, true ) ) {
			return new WP_Error( 'fileora_type', sprintf( '%s isn’t a supported file for this tool.', $name ), array( 'status' => 415 ) );
		}
		if ( ! self::content_matches( $file['tmp_name'], $ext ) ) {
			return new WP_Error( 'fileora_type', sprintf( '%s doesn’t look like a real .%s file.', $name, $ext ), array( 'status' => 415 ) );
		}
		return true;
	}

	/** Checks the file's first bytes, so a renamed .exe can't pass as a PDF. */
	public static function content_matches( $path, $ext ) {
		$fh = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		if ( ! $fh ) {
			return false;
		}
		$head = (string) fread( $fh, 1024 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		$zip = 0 === strpos( $head, "PK\x03\x04" );
		$ole = 0 === strpos( $head, "\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1" );
		switch ( $ext ) {
			case 'pdf':
				return false !== strpos( $head, '%PDF-' );
			case 'docx':
			case 'xlsx':
			case 'pptx':
			case 'ppsx':
			case 'odt':
			case 'ods':
			case 'odp':
				return $zip;
			case 'doc':
			case 'xls':
			case 'ppt':
			case 'pps':
				return $ole;
			case 'rtf':
				return 0 === strpos( ltrim( $head ), '{\rtf' );
			case 'txt':
			case 'csv':
			case 'html':
			case 'htm':
				return false === strpos( $head, "\0" );
		}
		return false;
	}

	/** True for common crawlers and monitoring bots (not counted as visitors). */
	public static function is_bot( $ua ) {
		return '' === $ua || (bool) preg_match( '/bot|crawl|spider|slurp|facebookexternalhit|preview|monitor|uptime|curl|wget|python-requests|headless|lighthouse|pingdom|semrush|ahrefs/i', $ua );
	}
}
