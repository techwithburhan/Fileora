<?php
/**
 * Visitor analytics.
 *
 * Two tables:
 *   {prefix}fileora_events    one row per event:
 *       page_view  a page was opened
 *       tool_view  a tool page was opened
 *       tool_run   a tool finished (exec browser|server, status done|failed,
 *                  duration, number of files, first file name)
 *       ping       "still here", at most one per visit per minute while the
 *                  tab is visible (for active visitors and minute-by-minute
 *                  traffic; kept as long as the other events)
 *   {prefix}fileora_sessions  one row per visit (session): visitor id, first
 *       and last activity, approximate location, IP address (as Settings
 *       allow), landing page, referrer, device, browser, operating system.
 *
 * Identifiers are pseudonymous: the browser keeps a random visitor id in
 * localStorage and a visit id in sessionStorage (a visit ends after 30
 * minutes without activity). No cookies are used. When storage is blocked,
 * a daily keyed hash of IP and browser is used instead.
 *
 * Words used on the reports:
 *   visits           sessions
 *   unique visitors  distinct visitor ids
 *   active visitors  visits with activity in the last 5 minutes
 *   page views       page_view events
 *   tool runs        browser tool runs + server tasks (server tasks come from
 *                    the task table, the record of what the server did)
 *
 * File contents are never recorded. File names are stored only when
 * Settings → "Record file names" is on.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Analytics {

	const DB_VERSION = '3';

	/** Option holding the latest database errors (count, last time, last 10 messages). */
	const DB_ERRORS = 'fileora_db_errors';
	const TYPES      = array( 'page_view', 'tool_view', 'tool_run', 'ping' );
	const PAGES      = array( 'home', 'tool', 'post', 'page', 'archive', 'search', 'other' );
	const ACTIVE_MIN = 5;

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'fileora_events';
	}

	public static function sessions_table() {
		global $wpdb;
		return $wpdb->prefix . 'fileora_sessions';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table    = self::table();
		$sessions = self::sessions_table();
		$collate  = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			type varchar(16) NOT NULL,
			tool varchar(20) NOT NULL DEFAULT '',
			exec varchar(8) NOT NULL DEFAULT '',
			status varchar(8) NOT NULL DEFAULT '',
			ms int(10) unsigned DEFAULT NULL,
			session char(16) NOT NULL,
			sid char(32) NOT NULL DEFAULT '',
			visitor char(32) NOT NULL DEFAULT '',
			device varchar(8) NOT NULL DEFAULT '',
			page varchar(10) NOT NULL DEFAULT '',
			country char(2) NOT NULL DEFAULT '',
			region varchar(80) NOT NULL DEFAULT '',
			city varchar(80) NOT NULL DEFAULT '',
			files smallint(5) unsigned NOT NULL DEFAULT 0,
			file_name varchar(160) NOT NULL DEFAULT '',
			eid char(16) DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY eid (eid),
			KEY created_at (created_at),
			KEY visitor_created (visitor, created_at),
			KEY run_status (type, status, created_at),
			KEY type_created (type, created_at),
			KEY session_created (session, created_at),
			KEY tool_created (tool, created_at),
			KEY sid_created (sid, created_at),
			KEY country_created (country, created_at)
			) {$collate};"
		);
		dbDelta(
			"CREATE TABLE {$sessions} (
			sid char(32) NOT NULL,
			visitor char(32) NOT NULL DEFAULT '',
			first_seen datetime NOT NULL,
			last_seen datetime NOT NULL,
			is_new tinyint(1) unsigned NOT NULL DEFAULT 0,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			ip varchar(45) NOT NULL DEFAULT '',
			country char(2) NOT NULL DEFAULT '',
			region varchar(80) NOT NULL DEFAULT '',
			city varchar(80) NOT NULL DEFAULT '',
			landing varchar(255) NOT NULL DEFAULT '',
			last_page varchar(255) NOT NULL DEFAULT '',
			last_tool varchar(20) NOT NULL DEFAULT '',
			referrer varchar(255) NOT NULL DEFAULT '',
			device varchar(8) NOT NULL DEFAULT '',
			browser varchar(24) NOT NULL DEFAULT '',
			os varchar(24) NOT NULL DEFAULT '',
			pages int(10) unsigned NOT NULL DEFAULT 0,
			tool_runs int(10) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (sid),
			KEY last_seen (last_seen),
			KEY first_seen (first_seen),
			KEY visitor (visitor),
			KEY country_last (country, last_seen)
			) {$collate};"
		);
		// Rows from version 1 had only the daily id: use it for both visitor and visit.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "UPDATE {$table} SET visitor = RPAD(session, 32, 'f'), sid = RPAD(session, 32, '0') WHERE visitor = ''" );
		Fileora_History::install();
		// Version 2.3: detailed records are kept at least 90 days.
		$s = Fileora_Core_Settings::get();
		$fix = array();
		foreach ( array( 'event_retention', 'task_retention' ) as $k ) {
			if ( (int) $s[ $k ] > 0 && (int) $s[ $k ] < Fileora_Core_Settings::MIN_RETENTION ) {
				$fix[ $k ] = Fileora_Core_Settings::MIN_RETENTION;
			}
		}
		if ( $fix ) {
			Fileora_Core_Settings::update( $fix );
		}
		update_option( 'fileora_events_db_version', self::DB_VERSION, false );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'fileora_events_db_version' ) !== self::DB_VERSION ) {
			self::install();
		}
	}

	/* ------------------------------------------------------------------
	 * User agent parsing (small and dependency-free).
	 * ---------------------------------------------------------------- */

	public static function device( $ua ) {
		if ( preg_match( '/iPad|Tablet|Nexus 7|Nexus 10|SM-T|Kindle|Silk/i', $ua ) || ( preg_match( '/Android/i', $ua ) && ! preg_match( '/Mobile/i', $ua ) ) ) {
			return 'tablet';
		}
		if ( preg_match( '/Mobi|iPhone|iPod|Android|Windows Phone/i', $ua ) ) {
			return 'mobile';
		}
		return 'desktop';
	}

	public static function browser( $ua ) {
		$map = array(
			'/Edg(e|A|iOS)?\//'   => 'Edge',
			'/OPR\/|Opera/'       => 'Opera',
			'/SamsungBrowser/'    => 'Samsung Internet',
			'/UCBrowser/'         => 'UC Browser',
			'/YaBrowser/'         => 'Yandex',
			'/Firefox\/|FxiOS/'   => 'Firefox',
			'/CriOS|Chrome\//'    => 'Chrome',
			'/Version\/.*Safari/' => 'Safari',
			'/Safari/'            => 'Safari',
		);
		foreach ( $map as $re => $name ) {
			if ( preg_match( $re, $ua ) ) {
				return $name;
			}
		}
		return 'Other';
	}

	public static function os( $ua ) {
		$map = array(
			'/Windows/'                => 'Windows',
			'/iPhone|iPad|iPod/'       => 'iOS',
			'/Android/'                => 'Android',
			'/CrOS/'                   => 'ChromeOS',
			'/Mac OS X|Macintosh/'     => 'macOS',
			'/Linux/'                  => 'Linux',
		);
		foreach ( $map as $re => $name ) {
			if ( preg_match( $re, $ua ) ) {
				return $name;
			}
		}
		return 'Other';
	}

	/** Path of a URL on this site, without query string (max 255). */
	private static function path_of( $url ) {
		$path = (string) wp_parse_url( (string) $url, PHP_URL_PATH );
		return substr( '/' . ltrim( sanitize_text_field( rawurldecode( $path ) ), '/' ), 0, 255 );
	}

	/** Referrer as host + path (no query string), external sites only. */
	private static function clean_referrer( $url ) {
		$url  = (string) $url;
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		if ( '' === $host || wp_parse_url( home_url(), PHP_URL_HOST ) === $host ) {
			return '';
		}
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		return substr( sanitize_text_field( $host . ( '/' === $path ? '' : $path ) ), 0, 255 );
	}

	/** A file name safe to show in reports: no folders, no control characters, max 160. */
	private static function clean_file_name( $name ) {
		$name = wp_basename( str_replace( '\\', '/', (string) $name ) );
		$name = preg_replace( '/[\x00-\x1F\x7F<>"]/u', '', $name );
		return mb_substr( sanitize_text_field( $name ), 0, 160 );
	}

	/* ------------------------------------------------------------------
	 * Recording.
	 * ---------------------------------------------------------------- */

	/**
	 * Stores one event from the browser after validating it.
	 *
	 * @return true|WP_Error
	 */
	public static function record( array $e ) {
		$s = Fileora_Core_Settings::get();
		if ( empty( $s['analytics'] ) ) {
			return new WP_Error( 'off', 'Analytics are switched off.', array( 'status' => 204 ) );
		}
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		if ( Fileora_Core_Security::is_bot( $ua ) ) {
			return new WP_Error( 'bot', 'Ignored.', array( 'status' => 204 ) );
		}
		if ( ! empty( $s['exclude_admins'] ) && current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'admin', 'Ignored.', array( 'status' => 204 ) );
		}
		$type = isset( $e['type'] ) ? (string) $e['type'] : '';
		if ( ! in_array( $type, self::TYPES, true ) ) {
			return new WP_Error( 'type', 'Unknown event.', array( 'status' => 400 ) );
		}
		$tool = isset( $e['tool'] ) ? sanitize_key( $e['tool'] ) : '';
		if ( in_array( $type, array( 'tool_view', 'tool_run' ), true ) && ! Fileora_Tool_Registry::definition( $tool ) ) {
			return new WP_Error( 'tool', 'Unknown tool.', array( 'status' => 400 ) );
		}
		if ( ! in_array( $type, array( 'tool_view', 'tool_run' ), true ) ) {
			$tool = $tool && Fileora_Tool_Registry::definition( $tool ) ? $tool : '';
		}
		$exec   = isset( $e['exec'] ) && in_array( $e['exec'], array( 'browser', 'server' ), true ) ? $e['exec'] : '';
		$status = isset( $e['status'] ) && in_array( $e['status'], array( 'done', 'failed' ), true ) ? $e['status'] : '';
		$page   = isset( $e['page'] ) && in_array( $e['page'], self::PAGES, true ) ? $e['page'] : ( 'page_view' === $type ? 'other' : '' );
		$ms     = isset( $e['ms'] ) ? min( 86400000, absint( $e['ms'] ) ) : null;
		if ( 'tool_run' === $type && ( '' === $exec || '' === $status ) ) {
			return new WP_Error( 'run', 'A tool run needs exec and status.', array( 'status' => 400 ) );
		}

		// A browser retry or a double send carries the same event id: store it once.
		$eid = isset( $e['eid'] ) && preg_match( '/^[a-f0-9]{16}$/', (string) $e['eid'] ) ? (string) $e['eid'] : null;
		if ( $eid ) {
			if ( get_transient( 'fo_ev_' . $eid ) ) {
				return true;
			}
			set_transient( 'fo_ev_' . $eid, 1, 10 * MINUTE_IN_SECONDS );
		}

		$daily   = Fileora_Core_Security::session_id();
		$sid     = isset( $e['sid'] ) && preg_match( '/^[a-f0-9]{32}$/', (string) $e['sid'] ) ? (string) $e['sid'] : str_pad( $daily, 32, '0' );
		$visitor = isset( $e['visitor'] ) && preg_match( '/^[a-f0-9]{32}$/', (string) $e['visitor'] ) ? (string) $e['visitor'] : str_pad( $daily, 32, 'f' );

		// At most 120 events per visit per minute.
		$rl_key = 'fo_rl_' . substr( $sid, 0, 20 );
		$count  = (int) get_transient( $rl_key );
		if ( $count >= 120 ) {
			return new WP_Error( 'rate', 'Too many events.', array( 'status' => 429 ) );
		}
		set_transient( $rl_key, $count + 1, MINUTE_IN_SECONDS );

		$now  = gmdate( 'Y-m-d H:i:s' );
		$path = isset( $e['url'] ) ? self::path_of( $e['url'] ) : '';
		$geo  = self::touch_session( $sid, $visitor, $type, $tool, $path, $e, $ua, $now );
		if ( 'ping' === $type ) {
			// One ping per visit per minute is enough.
			$pk = 'fo_pg_' . substr( $sid, 0, 20 );
			if ( get_transient( $pk ) || null === $geo ) {
				return true;
			}
			set_transient( $pk, 1, 50 );
		}
		if ( null === $geo ) {
			$geo = array( 'country' => '', 'region' => '', 'city' => '' );
		}

		$files     = 'tool_run' === $type && isset( $e['files'] ) ? min( 1000, absint( $e['files'] ) ) : 0;
		$file_name = 'tool_run' === $type && ! empty( $s['record_file_names'] ) && isset( $e['name'] ) ? self::clean_file_name( $e['name'] ) : '';

		global $wpdb;
		$table = self::table();
		// INSERT IGNORE: the unique event id stops duplicates.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ok = $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$table} (created_at, type, tool, exec, status, ms, session, sid, visitor, device, page, country, region, city, files, file_name, eid) VALUES (%s, %s, %s, %s, %s, " . ( null === $ms ? 'NULL' : '%d' ) . ', %s, %s, %s, %s, %s, %s, %s, %s, %d, %s, ' . ( null === $eid ? 'NULL' : '%s' ) . ')', // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				array_values(
					array_filter(
						array( $now, $type, $tool, $exec, $status, $ms, $daily, $sid, $visitor, self::device( $ua ), $page, $geo['country'], $geo['region'], $geo['city'], $files, $file_name, $eid ),
						function ( $v ) {
							return null !== $v;
						}
					)
				)
			)
		);
		if ( false === $ok ) {
			self::db_error( 'event', $wpdb->last_error );
			return new WP_Error( 'db', 'The event could not be saved.', array( 'status' => 503 ) );
		}
		return true;
	}

	/**
	 * Creates or updates the visit. Returns its location, or null for a ping
	 * that belongs to no known visit.
	 */
	private static function touch_session( $sid, $visitor, $type, $tool, $path, array $e, $ua, $now ) {
		global $wpdb;
		$table = self::sessions_table();
		$ck    = 'fo_ss_' . substr( $sid, 0, 20 );
		$geo   = get_transient( $ck );
		if ( false === $geo ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT country, region, city FROM {$table} WHERE sid = %s", $sid ), ARRAY_A );
			if ( $row ) {
				$geo = $row;
			} elseif ( 'ping' === $type ) {
				return null;
			} else {
				$ip  = Fileora_Core_Security::client_ip();
				$geo = Fileora_Geo::lookup( $ip );
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$ins = $wpdb->query(
					$wpdb->prepare(
						"INSERT IGNORE INTO {$table} (sid, visitor, first_seen, last_seen, is_new, user_id, ip, country, region, city, landing, last_page, last_tool, referrer, device, browser, os, pages, tool_runs) VALUES (%s, %s, %s, %s, %d, %d, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %d, %d)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						$sid,
						$visitor,
						$now,
						$now,
						empty( $e['new'] ) ? 0 : 1,
						get_current_user_id(),
						Fileora_Core_Security::stored_ip( $ip ),
						$geo['country'],
						$geo['region'],
						$geo['city'],
						$path,
						$path,
						$tool,
						isset( $e['ref'] ) ? self::clean_referrer( $e['ref'] ) : '',
						self::device( $ua ),
						self::browser( $ua ),
						self::os( $ua ),
						'page_view' === $type ? 1 : 0,
						'tool_run' === $type ? 1 : 0
					)
				);
				if ( false === $ins ) {
					self::db_error( 'visit', $wpdb->last_error );
					return $geo;
				}
				set_transient( $ck, $geo, 45 * MINUTE_IN_SECONDS );
				return $geo;
			}
			set_transient( $ck, $geo, 45 * MINUTE_IN_SECONDS );
		}
		$sets = array( 'last_seen = %s' );
		$args = array( $now );
		if ( 'page_view' === $type ) {
			$sets[] = 'pages = pages + 1';
			if ( $path ) {
				$sets[] = 'last_page = %s';
				$args[] = $path;
			}
		}
		if ( 'tool_run' === $type ) {
			$sets[] = 'tool_runs = tool_runs + 1';
		}
		if ( $tool && 'ping' !== $type ) {
			$sets[] = 'last_tool = %s';
			$args[] = $tool;
		}
		$args[] = $sid;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( false === $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET " . implode( ', ', $sets ) . ' WHERE sid = %s', $args ) ) ) {
			self::db_error( 'visit update', $wpdb->last_error );
		}
		return $geo;
	}

	/** Location of a visit (for tasks started during that visit). */
	public static function session_geo( $sid ) {
		if ( ! preg_match( '/^[a-f0-9]{32}$/', (string) $sid ) ) {
			return null;
		}
		$geo = get_transient( 'fo_ss_' . substr( $sid, 0, 20 ) );
		if ( is_array( $geo ) ) {
			return $geo;
		}
		global $wpdb;
		$table = self::sessions_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT country, region, city FROM {$table} WHERE sid = %s", $sid ), ARRAY_A );
		return $row ? $row : null;
	}

	/* ------------------------------------------------------------------
	 * Reports used by the Fileora dashboard (30-day overview).
	 * ---------------------------------------------------------------- */

	private static function since( $days ) {
		return gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
	}

	/** Visits with activity in the last $minutes. */
	public static function active( $minutes = self::ACTIVE_MIN ) {
		global $wpdb;
		$table = self::sessions_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE last_seen >= %s", gmdate( 'Y-m-d H:i:s', time() - $minutes * 60 ) ) );
	}

	public static function totals( $days = 30 ) {
		global $wpdb;
		$table = self::table();
		$since = self::since( $days );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$r = $wpdb->get_row( $wpdb->prepare( "SELECT SUM(type = 'page_view') AS views, SUM(type = 'tool_view') AS tool_views, SUM(type = 'tool_run') AS runs, SUM(type = 'tool_run' AND exec = 'browser') AS browser_runs, SUM(type = 'tool_run' AND exec = 'browser' AND status = 'done') AS browser_done, SUM(type = 'tool_run' AND exec = 'browser' AND status = 'failed') AS browser_failed, SUM(type = 'tool_run' AND exec = 'server') AS server_runs, COUNT(DISTINCT visitor) AS visitors FROM {$table} WHERE created_at >= %s", $since ) );
		return array(
			'visitors'       => (int) $r->visitors,
			'views'          => (int) $r->views,
			'tool_views'     => (int) $r->tool_views,
			'runs'           => (int) $r->runs,
			'browser_runs'   => (int) $r->browser_runs,
			'browser_done'   => (int) $r->browser_done,
			'browser_failed' => (int) $r->browser_failed,
			'server_runs'    => (int) $r->server_runs,
		);
	}

	/** Browser tool runs per tool: tool => [runs, failed]. */
	public static function browser_runs_by_tool( $days = 30 ) {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT tool, COUNT(*) AS runs, SUM(status = 'failed') AS failed FROM {$table} WHERE type = 'tool_run' AND exec = 'browser' AND created_at >= %s GROUP BY tool", self::since( $days ) ) );
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ $r->tool ] = array( (int) $r->runs, (int) $r->failed );
		}
		return $out;
	}

	/* ------------------------------------------------------------------
	 * Housekeeping.
	 * ---------------------------------------------------------------- */

	/**
	 * Deletes detailed records older than $days (0 = keep forever). Daily
	 * totals are saved first, so the history stays available as summaries.
	 */
	public static function purge( $days ) {
		$days = (int) $days;
		if ( $days <= 0 ) {
			return;
		}
		Fileora_History::rollup();
		global $wpdb;
		$table    = self::table();
		$sessions = self::sessions_table();
		$cut      = self::since( $days );
		// Small batches keep the tables usable while old rows are removed.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		for ( $i = 0; $i < 200; $i++ ) {
			$n = $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s LIMIT 5000", $cut ) );
			if ( false === $n ) {
				self::db_error( 'purge', $wpdb->last_error );
				break;
			}
			if ( $n < 5000 ) {
				break;
			}
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$sessions} WHERE last_seen < %s", $cut ) );
		// phpcs:enable
	}

	/* ------------------------------------------------------------------
	 * Database errors: written to the PHP error log and kept (without
	 * visitor data) for Settings → Analytics storage.
	 * ---------------------------------------------------------------- */

	public static function db_error( $context, $message ) {
		$message = substr( preg_replace( "/'[^']*'/", "'…'", (string) $message ), 0, 200 ); // no values from the query
		Fileora_Core_Log::error( 'Analytics database error (' . $context . ')', array( 'error' => $message ) );
		if ( get_transient( 'fo_dberr_' . md5( $context ) ) ) {
			$e = get_option( self::DB_ERRORS, array() );
			$e['count'] = isset( $e['count'] ) ? (int) $e['count'] + 1 : 1;
			update_option( self::DB_ERRORS, $e, false );
			return;
		}
		set_transient( 'fo_dberr_' . md5( $context ), 1, MINUTE_IN_SECONDS );
		$e = get_option( self::DB_ERRORS, array() );
		$e = is_array( $e ) ? $e : array();
		$e['count'] = isset( $e['count'] ) ? (int) $e['count'] + 1 : 1;
		$e['last']  = time();
		$items      = isset( $e['items'] ) ? (array) $e['items'] : array();
		array_unshift( $items, array( time(), (string) $context, $message ) );
		$e['items'] = array_slice( $items, 0, 10 );
		update_option( self::DB_ERRORS, $e, false );
	}

	/** Erases stored IP addresses older than Settings → "Keep IP addresses for". */
	public static function erase_old_ips( $days ) {
		global $wpdb;
		$sessions = self::sessions_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "UPDATE {$sessions} SET ip = '' WHERE ip <> '' AND first_seen < %s", self::since( $days ) ) );
	}
}
