<?php
/**
 * SEO controls for every post, page and tool page, and site-wide SEO
 * settings (Fileora → SEO).
 *
 * Per page (meta box "SEO" in the editor):
 *   _fileora_focus_keyword     the search phrase the page should rank for
 *   _fileora_seo_title         <title> (the site name is added after it)
 *   _fileora_meta_description  meta description and social description
 *   _fileora_social_image      attachment id of the image shown when shared
 *   _fileora_canonical         canonical URL (when the page copies another)
 *   _fileora_noindex           1 = keep the page out of search results and the sitemap
 * The box shows a Google preview and a checklist that updates while you type.
 * The same keys are used by the theme's starter content.
 *
 * Site (Fileora → SEO → Settings): search engine verification codes,
 * homepage title, default social image, X (Twitter) account and the
 * organisation shown to search engines (name, logo, social profiles).
 *
 * When Yoast SEO, Rank Math, All in One SEO, SEOPress or The SEO Framework
 * is active, that plugin writes the tags: Fileora then shows a note instead
 * of its own fields and outputs nothing that would duplicate it.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_SEO_Fields {

	const OPTION = 'fileora_seo';
	const KEYS   = array(
		'keyword'   => '_fileora_focus_keyword',
		'title'     => '_fileora_seo_title',
		'desc'      => '_fileora_meta_description',
		'image'     => '_fileora_social_image',
		'canonical' => '_fileora_canonical',
		'noindex'   => '_fileora_noindex',
		'keywords'  => '_fileora_keywords',
	);
	const IDEAS  = '_fileora_title_ideas';

	/** The search keywords saved for a page (up to 10, one per line). */
	public static function keyword_list( $post_id ) {
		return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $post_id, self::KEYS['keywords'], true ) ) ) ) );
	}

	public static function types() {
		return array( 'post', 'page', Fileora_Tool_Registry::POST_TYPE );
	}

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'meta_box' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_setting' ) );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 1 );
		add_filter( 'wp_robots', array( __CLASS__, 'robots' ) );
		add_filter( 'get_canonical_url', array( __CLASS__, 'canonical' ), 10, 2 );
		add_filter( 'document_title_parts', array( __CLASS__, 'title' ), 30 );
		add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'sitemap_exclude' ), 20 );
	}

	public static function seo_plugin() {
		if ( Fileora_SEO::seo_plugin_active() ) {
			foreach ( array( 'WPSEO_VERSION' => 'Yoast SEO', 'RANK_MATH_VERSION' => 'Rank Math', 'AIOSEO_VERSION' => 'All in One SEO', 'SEOPRESS_VERSION' => 'SEOPress', 'THE_SEO_FRAMEWORK_VERSION' => 'The SEO Framework' ) as $c => $name ) {
				if ( defined( $c ) ) {
					return $name;
				}
			}
			return __( 'an SEO plugin', 'fileora' );
		}
		return '';
	}

	public static function settings() {
		static $cache = null;
		if ( null !== $cache ) {
			return $cache;
		}
		$s     = get_option( self::OPTION, array() );
		$cache = self::sanitize( is_array( $s ) ? $s : array() ); // also cleans values saved without the settings form
		return $cache;
	}

	public static function get( $post_id, $key ) {
		return get_post_meta( $post_id, self::KEYS[ $key ], true );
	}

	/* ------------------------------------------------------------------
	 * Editor: the SEO box.
	 * ---------------------------------------------------------------- */

	public static function meta_box() {
		foreach ( self::types() as $t ) {
			add_meta_box( 'fileora-seo', __( 'SEO: how this page appears in Google', 'fileora' ), array( __CLASS__, 'box' ), $t, 'normal', 'high' );
		}
	}

	public static function box( $post ) {
		$plugin = self::seo_plugin();
		if ( $plugin ) {
			/* translators: %s: plugin name */
			echo '<p>' . esc_html( sprintf( __( '%s is active, so it controls this page’s title, description and search settings. Use its box on this screen.', 'fileora' ), $plugin ) ) . '</p>';
			return;
		}
		wp_nonce_field( 'fileora_seo_' . $post->ID, 'fileora_seo_nonce' );
		$v      = array();
		foreach ( self::KEYS as $k => $meta ) {
			$v[ $k ] = get_post_meta( $post->ID, $meta, true );
		}
		$img    = (int) $v['image'];
		$img_u  = $img ? wp_get_attachment_image_url( $img, 'medium' ) : '';
		$tool   = Fileora_Tool_Registry::POST_TYPE === $post->post_type ? Fileora_Tool_Registry::by_post( $post ) : null;
		$deft   = $tool ? Fileora_SEO::title_for( array_merge( $tool, array( 'post_id' => 0 ) ) ) : '';
		$defd   = $tool ? Fileora_SEO::description( array_merge( $tool, array( 'post_id' => 0 ) ) ) : '';
		$others = self::keywords_in_use( $post->ID );
		$config = array(
			'site'      => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'sep'       => ' – ',
			'home'      => home_url( '/' ),
			'defTitle'  => $deft,
			'defDesc'   => $defd,
			'others'    => $others,
			'isTool'    => (bool) $tool,
			'faq'       => $tool ? (string) get_post_meta( $post->ID, Fileora_Tool_Registry::META_FAQ, true ) : '',
			'extra'     => self::template_text( $post ),
		);
		?>
		<div class="fo-seo" data-config="<?php echo esc_attr( wp_json_encode( $config ) ); ?>">
			<div class="fo-seo-preview" aria-label="<?php esc_attr_e( 'Google preview', 'fileora' ); ?>">
				<span class="fo-seo-pv-label"><?php esc_html_e( 'Google preview', 'fileora' ); ?></span>
				<div class="fo-seo-pv-url"></div>
				<div class="fo-seo-pv-title"></div>
				<div class="fo-seo-pv-desc"></div>
			</div>
			<div class="fo-seo-grid">
				<div class="fo-seo-fields">
					<p>
						<label for="fo-seo-keyword"><strong><?php esc_html_e( 'Focus keyword', 'fileora' ); ?></strong></label>
						<input type="text" id="fo-seo-keyword" name="fileora_seo[keyword]" value="<?php echo esc_attr( $v['keyword'] ); ?>" class="widefat" placeholder="<?php esc_attr_e( 'e.g. compress pdf to 100kb', 'fileora' ); ?>">
						<span class="description"><?php esc_html_e( 'The phrase people type into Google that this page should answer. One per page.', 'fileora' ); ?></span>
					</p>
					<p>
						<label for="fo-seo-keywords"><strong><?php esc_html_e( 'Search keywords (up to 10)', 'fileora' ); ?></strong></label>
						<textarea id="fo-seo-keywords" name="fileora_seo[keywords]" rows="5" class="widefat" placeholder="<?php esc_attr_e( "how to merge pdf files\nmerge pdf online free\n…", 'fileora' ); ?>"><?php echo esc_textarea( $v['keywords'] ); ?></textarea>
						<span class="description"><?php esc_html_e( 'Other ways people search for this page, one per line. Use each one naturally in the text; the list below shows which are still missing.', 'fileora' ); ?></span>
						<span class="fo-seo-kwcov" aria-live="polite"></span>
					</p>
					<?php
					$ideas = array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $post->ID, self::IDEAS, true ) ) ) ) );
					if ( $ideas ) :
						?>
						<details class="fo-seo-ideas">
							<summary><?php echo esc_html( sprintf( /* translators: %d: number of titles */ __( '%d title ideas', 'fileora' ), count( $ideas ) ) ); ?></summary>
							<ul>
								<?php foreach ( $ideas as $idea ) : ?>
									<li><span><?php echo esc_html( $idea ); ?></span> <small>(<?php echo (int) mb_strlen( $idea ); ?>)</small> <button type="button" class="button-link fo-seo-use" data-title="<?php echo esc_attr( $idea ); ?>"><?php esc_html_e( 'Use as SEO title', 'fileora' ); ?></button></li>
								<?php endforeach; ?>
							</ul>
						</details>
					<?php endif; ?>
					<p>
						<label for="fo-seo-title"><strong><?php esc_html_e( 'SEO title', 'fileora' ); ?></strong></label>
						<input type="text" id="fo-seo-title" name="fileora_seo[title]" value="<?php echo esc_attr( $v['title'] ); ?>" class="widefat" maxlength="120" placeholder="<?php echo esc_attr( $deft ? $deft : get_the_title( $post ) ); ?>">
						<span class="fo-seo-meter" data-for="fo-seo-title" data-min="30" data-max="60"><i></i></span>
						<span class="description fo-seo-count" data-for="fo-seo-title"></span>
					</p>
					<p>
						<label for="fo-seo-desc"><strong><?php esc_html_e( 'Meta description', 'fileora' ); ?></strong></label>
						<textarea id="fo-seo-desc" name="fileora_seo[desc]" rows="3" class="widefat" maxlength="320" placeholder="<?php echo esc_attr( $defd ? $defd : __( 'One or two sentences that make people want to click: what the page does and why it is the right result.', 'fileora' ) ); ?>"><?php echo esc_textarea( $v['desc'] ); ?></textarea>
						<span class="fo-seo-meter" data-for="fo-seo-desc" data-min="120" data-max="160"><i></i></span>
						<span class="description fo-seo-count" data-for="fo-seo-desc"></span>
					</p>
					<div class="fo-seo-image">
						<strong><?php esc_html_e( 'Image when shared (WhatsApp, Facebook, X, LinkedIn)', 'fileora' ); ?></strong>
						<input type="hidden" name="fileora_seo[image]" value="<?php echo esc_attr( $img ? $img : '' ); ?>">
						<div class="fo-seo-img-pv"><?php echo $img_u ? '<img src="' . esc_url( $img_u ) . '" alt="">' : ''; ?></div>
						<button type="button" class="button fo-seo-pick"><?php esc_html_e( 'Choose image', 'fileora' ); ?></button>
						<button type="button" class="button-link fo-seo-clear"<?php echo $img ? '' : ' hidden'; ?>><?php esc_html_e( 'Remove', 'fileora' ); ?></button>
						<p class="description"><?php esc_html_e( 'Best at 1200 × 630 px. Without one, the featured image or the default image from Fileora → SEO is used.', 'fileora' ); ?></p>
					</div>
					<details class="fo-seo-adv"<?php echo ( $v['canonical'] || $v['noindex'] ) ? ' open' : ''; ?>>
						<summary><?php esc_html_e( 'Advanced', 'fileora' ); ?></summary>
						<p>
							<label><input type="checkbox" name="fileora_seo[noindex]" value="1" <?php checked( (bool) $v['noindex'] ); ?>> <?php esc_html_e( 'Hide this page from search engines (noindex) and from the sitemap', 'fileora' ); ?></label>
						</p>
						<p>
							<label for="fo-seo-canonical"><?php esc_html_e( 'Canonical URL', 'fileora' ); ?></label>
							<input type="url" id="fo-seo-canonical" name="fileora_seo[canonical]" value="<?php echo esc_attr( $v['canonical'] ); ?>" class="widefat" placeholder="<?php echo esc_attr( get_permalink( $post ) ); ?>">
							<span class="description"><?php esc_html_e( 'Only when this page copies another page: enter the original’s address. Leave empty otherwise.', 'fileora' ); ?></span>
						</p>
					</details>
				</div>
				<div class="fo-seo-checks">
					<div class="fo-seo-score"><span class="fo-seo-dot"></span><strong class="fo-seo-score-l"></strong></div>
					<ul class="fo-seo-list" aria-live="polite"></ul>
					<p class="description"><?php esc_html_e( 'The checklist updates while you edit. Write for people first: these checks only make sure Google understands the page.', 'fileora' ); ?></p>
				</div>
			</div>
		</div>
		<?php
	}

	/** Focus keywords used by other published pages (to warn about competing pages). */
	public static function keywords_in_use( $except = 0 ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT m.meta_value AS k, p.post_title AS t FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = %s AND m.meta_value <> '' AND p.post_status = 'publish' AND p.ID <> %d LIMIT 2000", self::KEYS['keyword'], (int) $except ) );
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ mb_strtolower( trim( $r->k ) ) ] = $r->t;
		}
		return $out;
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['fileora_seo_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['fileora_seo_nonce'] ) ), 'fileora_seo_' . $post_id ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$in = isset( $_POST['fileora_seo'] ) && is_array( $_POST['fileora_seo'] ) ? wp_unslash( $_POST['fileora_seo'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per field below
		$val = array(
			'keyword'   => isset( $in['keyword'] ) ? sanitize_text_field( $in['keyword'] ) : '',
			'title'     => isset( $in['title'] ) ? sanitize_text_field( $in['title'] ) : '',
			'desc'      => isset( $in['desc'] ) ? sanitize_textarea_field( $in['desc'] ) : '',
			'image'     => isset( $in['image'] ) ? absint( $in['image'] ) : 0,
			'canonical' => isset( $in['canonical'] ) ? esc_url_raw( trim( $in['canonical'] ), array( 'http', 'https' ) ) : '',
			'noindex'   => empty( $in['noindex'] ) ? 0 : 1,
			'keywords'  => isset( $in['keywords'] ) ? implode( "\n", array_slice( array_values( array_unique( array_filter( array_map( 'sanitize_text_field', preg_split( '/\R/', (string) $in['keywords'] ) ) ) ) ), 0, 10 ) ) : '',
		);
		foreach ( $val as $k => $v ) {
			if ( '' === $v || 0 === $v ) {
				delete_post_meta( $post_id, self::KEYS[ $k ] );
			} else {
				update_post_meta( $post_id, self::KEYS[ $k ], $v );
			}
		}
	}

	public static function assets( $hook ) {
		$screen = get_current_screen();
		$edit   = in_array( $hook, array( 'post.php', 'post-new.php' ), true ) && $screen && in_array( $screen->post_type, self::types(), true );
		$page   = false !== strpos( (string) $hook, 'fileora-seo' );
		if ( ! $edit && ! $page ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'fileora-seo', FILEORA_CORE_URL . 'admin/assets/seo.css', array(), FILEORA_CORE_VERSION );
		wp_enqueue_script( 'fileora-seo', FILEORA_CORE_URL . 'admin/assets/seo.js', array( 'jquery' ), FILEORA_CORE_VERSION, true );
	}

	/* ------------------------------------------------------------------
	 * Page analysis (also used by the overview table).
	 * ---------------------------------------------------------------- */

	/**
	 * The same checks as the editor checklist, from the saved page.
	 *
	 * @return array{score:int,passed:int,total:int,fails:string[]}
	 */
	public static function analyze( WP_Post $p ) {
		$kw    = mb_strtolower( trim( (string) self::get( $p->ID, 'keyword' ) ) );
		$tool  = Fileora_Tool_Registry::POST_TYPE === $p->post_type ? Fileora_Tool_Registry::by_post( $p ) : null;
		$title = (string) self::get( $p->ID, 'title' );
		if ( '' === $title ) {
			$title = $tool ? Fileora_SEO::title_for( $tool ) : get_the_title( $p );
		}
		$desc = (string) self::get( $p->ID, 'desc' );
		if ( '' === $desc && $tool ) {
			$desc = Fileora_SEO::description( $tool );
		}
		$extra = self::template_text( $p );
		$html  = ( '' !== $p->post_excerpt && '' !== $extra ? '<p>' . esc_html( $p->post_excerpt ) . '</p>' : '' ) . $p->post_content . $extra;
		$faq   = $tool ? (string) get_post_meta( $p->ID, Fileora_Tool_Registry::META_FAQ, true ) : '';
		$text  = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( strip_shortcodes( $html ) . ' ' . $faq ) ) );
		$words = $text ? count( preg_split( '/\s+/', $text ) ) : 0;
		$lc    = function ( $s ) {
			return mb_strtolower( (string) $s );
		};
		$has   = function ( $hay ) use ( $kw, $lc ) {
			return '' !== $kw && false !== mb_strpos( $lc( $hay ), $kw );
		};
		preg_match_all( '/<h[23][^>]*>(.*?)<\/h[23]>/is', $html, $hs );
		preg_match_all( '/<img\b[^>]*>/i', $html, $imgs );
		$no_alt = 0;
		foreach ( $imgs[0] as $tag ) {
			if ( ! preg_match( '/\balt\s*=\s*"[^"]+"/i', $tag ) ) {
				++$no_alt;
			}
		}
		$host     = wp_parse_url( home_url(), PHP_URL_HOST );
		$internal = preg_match( '/href\s*=\s*"(\/[^"\/]|https?:\/\/' . preg_quote( (string) $host, '/' ) . ')/i', $html ) || ( $tool && $faq ) || '' !== $extra;
		$first    = implode( ' ', array_slice( preg_split( '/\s+/', $text ), 0, 120 ) );
		$slug     = str_replace( '-', ' ', $p->post_name );
		$tlen     = mb_strlen( $title );
		$dlen     = mb_strlen( $desc );
		$checks   = array(
			__( 'Set a focus keyword', 'fileora' )                     => '' !== $kw,
			__( 'Focus keyword in the SEO title', 'fileora' )          => $has( $title ),
			__( 'Focus keyword in the meta description', 'fileora' )   => $has( $desc ),
			__( 'Focus keyword in the page address', 'fileora' )       => '' !== $kw && $has( $slug ) || ( '' !== $kw && $has( $p->post_name ) ),
			__( 'Focus keyword near the start of the text', 'fileora' ) => $has( $first ),
			__( 'Focus keyword in a subheading', 'fileora' )           => $has( implode( ' ', $hs[1] ) ),
			__( 'SEO title 30–60 characters', 'fileora' )              => $tlen >= 30 && $tlen <= 60,
			__( 'Meta description 120–160 characters', 'fileora' )     => $dlen >= 120 && $dlen <= 160,
			__( 'At least 300 words of text', 'fileora' )              => $words >= 300,
			__( 'All images have alt text', 'fileora' )                => 0 === $no_alt,
			__( 'Links to another page on this site', 'fileora' )      => (bool) $internal,
		);
		$kws = self::keyword_list( $p->ID );
		if ( $kws ) {
			$all   = $lc( $title . ' ' . $desc . ' ' . $text );
			$found = count(
				array_filter(
					$kws,
					function ( $k ) use ( $all, $lc ) {
						return false !== mb_strpos( $all, $lc( $k ) );
					}
				)
			);
			$need  = min( 8, count( $kws ) );
			/* translators: %d: number of keywords */
			$checks[ sprintf( __( 'Search keywords used in the text (at least %d)', 'fileora' ), $need ) ] = $found >= $need;
		}
		$fails  = array_keys( array_filter( $checks, function ( $ok ) { return ! $ok; } ) );
		$passed = count( $checks ) - count( $fails );
		return array(
			'score'  => (int) round( $passed / count( $checks ) * 100 ),
			'passed' => $passed,
			'total'  => count( $checks ),
			'fails'  => $fails,
			'title'  => $title,
			'desc'   => $desc,
			'words'  => $words,
		);
	}

	/**
	 * Text a page template shows besides the editor content, so the checks see
	 * what visitors and Google see: the "All tools" page lists every tool.
	 */
	public static function template_text( WP_Post $p ) {
		if ( 'page' !== $p->post_type || 'page-all-tools.php' !== get_post_meta( $p->ID, '_wp_page_template', true ) ) {
			return '';
		}
		$out = '';
		foreach ( Fileora_Tool_Registry::tools() as $t ) {
			$out .= ' <p><a href="' . esc_url( $t['url'] ) . '">' . esc_html( $t['name'] ) . '</a> ' . esc_html( $t['desc'] ) . '</p>';
		}
		return $out;
	}

	/* ------------------------------------------------------------------
	 * Fileora → SEO: overview and site settings.
	 * ---------------------------------------------------------------- */

	public static function register_setting() {
		register_setting( 'fileora_seo', self::OPTION, array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) ) );
	}

	/** A verification code, also when the whole <meta> tag was pasted. */
	private static function code( $v ) {
		$v = trim( (string) $v );
		if ( preg_match( '/content\s*=\s*["\']([^"\']+)["\']/i', $v, $m ) ) {
			$v = $m[1];
		}
		return preg_replace( '/[^A-Za-z0-9_\-=.]/', '', $v );
	}

	public static function sanitize( $in ) {
		$in = is_array( $in ) ? $in : array();
		$same = array();
		foreach ( explode( "\n", isset( $in['same_as'] ) ? (string) $in['same_as'] : '' ) as $u ) {
			$u = trim( $u );
			if ( preg_match( '#^https?://[^\s/$.?\#].[^\s]*$#i', $u ) ) {
				$same[] = esc_url_raw( $u );
			}
		}
		return array(
			'google'        => self::code( isset( $in['google'] ) ? $in['google'] : '' ),
			'bing'          => self::code( isset( $in['bing'] ) ? $in['bing'] : '' ),
			'yandex'        => self::code( isset( $in['yandex'] ) ? $in['yandex'] : '' ),
			'pinterest'     => self::code( isset( $in['pinterest'] ) ? $in['pinterest'] : '' ),
			'home_title'    => isset( $in['home_title'] ) ? sanitize_text_field( $in['home_title'] ) : '',
			'default_image' => isset( $in['default_image'] ) ? absint( $in['default_image'] ) : 0,
			'twitter'       => isset( $in['twitter'] ) ? ltrim( preg_replace( '/[^A-Za-z0-9_@]/', '', (string) $in['twitter'] ), '@' ) : '',
			'org_name'      => isset( $in['org_name'] ) ? sanitize_text_field( $in['org_name'] ) : '',
			'org_logo'      => isset( $in['org_logo'] ) ? absint( $in['org_logo'] ) : 0,
			'same_as'       => implode( "\n", $same ),
			'clean_archives' => empty( $in['clean_archives'] ) ? 0 : 1,
		);
	}

	public static function page() {
		if ( ! current_user_can( 'fileora_manage_settings' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'fileora' ), 403 );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$tab  = isset( $_GET['tab'] ) && in_array( $_GET['tab'], array( 'settings', 'plan', 'blog' ), true ) ? sanitize_key( $_GET['tab'] ) : 'overview';
		$type = isset( $_GET['type'] ) && in_array( $_GET['type'], self::types(), true ) ? sanitize_key( $_GET['type'] ) : '';
		$only = ! empty( $_GET['needs'] );
		// phpcs:enable
		$base = admin_url( 'admin.php?page=fileora-seo' );
		echo '<div class="wrap fo-wrap fo-seo-page"><h1>' . esc_html__( 'SEO', 'fileora' ) . '</h1>';
		$plugin = self::seo_plugin();
		if ( $plugin ) {
			/* translators: %s: plugin name */
			echo '<div class="notice notice-info inline"><p>' . esc_html( sprintf( __( '%s is active, so it writes titles, descriptions and search engine tags. Fileora’s SEO fields and settings are switched off to avoid duplicates; the overview below still helps you find pages that need work.', 'fileora' ), $plugin ) ) . '</p></div>';
		}
		echo '<nav class="nav-tab-wrapper"><a class="nav-tab' . ( 'overview' === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( $base ) . '">' . esc_html__( 'Pages overview', 'fileora' ) . '</a><a class="nav-tab' . ( 'settings' === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( add_query_arg( 'tab', 'settings', $base ) ) . '">' . esc_html__( 'Site settings', 'fileora' ) . '</a><a class="nav-tab' . ( 'plan' === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( add_query_arg( 'tab', 'plan', $base ) ) . '">' . esc_html__( '60-day plan', 'fileora' ) . '</a><a class="nav-tab' . ( 'blog' === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( add_query_arg( 'tab', 'blog', $base ) ) . '">' . esc_html__( '70-day blog plan', 'fileora' ) . '</a></nav>';
		if ( 'plan' === $tab || 'blog' === $tab ) {
			Fileora_SEO_Plan::screen( 'blog' === $tab ? 'blog' : 'seo' );
		} elseif ( 'settings' === $tab ) {
			self::settings_form();
		} else {
			self::overview( $type, $only );
		}
		echo '</div>';
	}

	private static function overview( $type, $only ) {
		$posts = get_posts(
			array(
				'post_type'      => $type ? $type : self::types(),
				'post_status'    => 'publish',
				'posts_per_page' => 500,
				'orderby'        => array( 'post_type' => 'ASC', 'menu_order' => 'ASC', 'title' => 'ASC' ),
				'no_found_rows'  => true,
			)
		);
		$labels = array( 'post' => __( 'Post', 'fileora' ), 'page' => __( 'Page', 'fileora' ), Fileora_Tool_Registry::POST_TYPE => __( 'Tool', 'fileora' ) );
		$rows   = array();
		$sum    = array( 'good' => 0, 'ok' => 0, 'bad' => 0 );
		foreach ( $posts as $p ) {
			$a     = self::analyze( $p );
			$level = $a['score'] >= 80 ? 'good' : ( $a['score'] >= 50 ? 'ok' : 'bad' );
			++$sum[ $level ];
			if ( $only && 'good' === $level ) {
				continue;
			}
			$rows[] = array( $p, $a, $level );
		}
		usort(
			$rows,
			function ( $x, $y ) {
				return $x[1]['score'] <=> $y[1]['score'];
			}
		);
		echo '<p class="fo-lead">' . esc_html__( 'Every published page, post and tool, weakest first. Open one to fix it: the SEO box under the editor shows what is missing while you type.', 'fileora' ) . '</p>';
		echo '<div class="fo-seo-sum"><span class="fo-st fo-st-good"><i></i>' . esc_html( sprintf( /* translators: %d: count */ __( '%d good', 'fileora' ), $sum['good'] ) ) . '</span><span class="fo-st fo-st-warn"><i></i>' . esc_html( sprintf( /* translators: %d: count */ __( '%d could be better', 'fileora' ), $sum['ok'] ) ) . '</span><span class="fo-st fo-st-bad"><i></i>' . esc_html( sprintf( /* translators: %d: count */ __( '%d need work', 'fileora' ), $sum['bad'] ) ) . '</span></div>';
		echo '<form method="get" class="fo-filters"><input type="hidden" name="page" value="fileora-seo"><label>' . esc_html__( 'Show', 'fileora' ) . ' <select name="type"><option value="">' . esc_html__( 'Pages, posts and tools', 'fileora' ) . '</option>';
		foreach ( $labels as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $type, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></label> <label class="fo-check"><input type="checkbox" name="needs" value="1"' . checked( $only, true, false ) . '> ' . esc_html__( 'Only pages that need work', 'fileora' ) . '</label> <button class="button">' . esc_html__( 'Filter', 'fileora' ) . '</button></form>';
		echo '<div class="fo-table-wrap"><table class="widefat striped fo-table"><thead><tr><th>' . esc_html__( 'Page', 'fileora' ) . '</th><th>' . esc_html__( 'Focus keyword', 'fileora' ) . '</th><th>' . esc_html__( 'Title / description length', 'fileora' ) . '</th><th class="num">' . esc_html__( 'Words', 'fileora' ) . '</th><th>' . esc_html__( 'Score', 'fileora' ) . '</th><th>' . esc_html__( 'To do', 'fileora' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			list( $p, $a, $level ) = $r;
			$kw  = (string) self::get( $p->ID, 'keyword' );
			$noi = (bool) self::get( $p->ID, 'noindex' );
			$tl  = mb_strlen( $a['title'] );
			$dl  = mb_strlen( $a['desc'] );
			echo '<tr><td><a href="' . esc_url( get_edit_post_link( $p->ID ) ) . '"><strong>' . esc_html( get_the_title( $p ) ) . '</strong></a><br><small class="fo-muted">' . esc_html( $labels[ $p->post_type ] ) . ' · <a href="' . esc_url( get_permalink( $p ) ) . '" target="_blank" rel="noopener">' . esc_html( wp_parse_url( get_permalink( $p ), PHP_URL_PATH ) ) . '</a>' . ( $noi ? ' · ' . esc_html__( 'hidden from search', 'fileora' ) : '' ) . '</small></td>';
			echo '<td>' . ( $kw ? esc_html( $kw ) : '<span class="fo-muted">—</span>' ) . '</td>';
			echo '<td>' . esc_html( sprintf( /* translators: 1: title length, 2: description length */ __( '%1$d / %2$d characters', 'fileora' ), $tl, $dl ) ) . '</td>';
			echo '<td class="num">' . esc_html( number_format_i18n( $a['words'] ) ) . '</td>';
			echo '<td><span class="fo-st fo-st-' . esc_attr( 'ok' === $level ? 'warn' : $level ) . '"><i></i>' . esc_html( $a['score'] . '%' ) . '</span></td>';
			echo '<td><small>' . esc_html( implode( ' · ', array_slice( $a['fails'], 0, 3 ) ) ) . ( count( $a['fails'] ) > 3 ? ' …' : '' ) . '</small></td></tr>';
		}
		if ( ! $rows ) {
			echo '<tr><td colspan="6">' . esc_html__( 'Nothing to show.', 'fileora' ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	private static function settings_form() {
		$s    = self::settings();
		$name = self::OPTION;
		$img  = function ( $key, $label, $help ) use ( $s, $name ) {
			$id  = (int) $s[ $key ];
			$url = $id ? wp_get_attachment_image_url( $id, 'medium' ) : '';
			echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td><div class="fo-seo-image"><input type="hidden" name="' . esc_attr( $name . '[' . $key . ']' ) . '" value="' . esc_attr( $id ? $id : '' ) . '"><div class="fo-seo-img-pv">' . ( $url ? '<img src="' . esc_url( $url ) . '" alt="">' : '' ) . '</div><button type="button" class="button fo-seo-pick">' . esc_html__( 'Choose image', 'fileora' ) . '</button> <button type="button" class="button-link fo-seo-clear"' . ( $id ? '' : ' hidden' ) . '>' . esc_html__( 'Remove', 'fileora' ) . '</button><p class="description">' . esc_html( $help ) . '</p></div></td></tr>';
		};
		$text = function ( $key, $label, $help, $ph = '' ) use ( $s, $name ) {
			echo '<tr><th scope="row"><label for="fo-seo-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><input type="text" class="regular-text" id="fo-seo-' . esc_attr( $key ) . '" name="' . esc_attr( $name . '[' . $key . ']' ) . '" value="' . esc_attr( $s[ $key ] ) . '" placeholder="' . esc_attr( $ph ) . '"><p class="description">' . esc_html( $help ) . '</p></td></tr>';
		};
		echo '<form method="post" action="options.php" class="fo-settings">';
		settings_fields( 'fileora_seo' );
		echo '<section class="fo-card"><h2>' . esc_html__( 'Search engine verification', 'fileora' ) . '</h2><p>' . esc_html__( 'Paste the code (or the whole <meta> tag) each service gives you when you add your site. Google Search Console: choose “HTML tag” as the verification method.', 'fileora' ) . '</p><table class="form-table" role="presentation">';
		$text( 'google', __( 'Google Search Console', 'fileora' ), __( 'google-site-verification', 'fileora' ) );
		$text( 'bing', __( 'Bing Webmaster Tools', 'fileora' ), __( 'msvalidate.01 (Bing also powers Yahoo and DuckDuckGo results)', 'fileora' ) );
		$text( 'yandex', __( 'Yandex Webmaster', 'fileora' ), __( 'yandex-verification', 'fileora' ) );
		$text( 'pinterest', __( 'Pinterest', 'fileora' ), __( 'p:domain_verify', 'fileora' ) );
		echo '</table><p class="description">' . esc_html( sprintf( /* translators: %s: sitemap URL */ __( 'Your sitemap for Search Console and Bing: %s', 'fileora' ), home_url( '/wp-sitemap.xml' ) ) ) . '</p></section>';
		echo '<section class="fo-card"><h2>' . esc_html__( 'Homepage and sharing', 'fileora' ) . '</h2><table class="form-table" role="presentation">';
		$text( 'home_title', __( 'Homepage title', 'fileora' ), __( 'The blue headline in Google for your homepage, 30–60 characters. Empty = site title and tagline. The homepage description is in Appearance → Customize → Fileora → Homepage.', 'fileora' ), get_bloginfo( 'name' ) . ' – ' . get_bloginfo( 'description' ) );
		$img( 'default_image', __( 'Default image when shared', 'fileora' ), __( 'Used for pages without their own image or featured image. 1200 × 630 px works everywhere.', 'fileora' ) );
		$text( 'twitter', __( 'X (Twitter) account', 'fileora' ), __( 'Without @. Shown as the site’s account on shared links.', 'fileora' ) );
		echo '</table></section>';
		echo '<section class="fo-card"><h2>' . esc_html__( 'Your organisation', 'fileora' ) . '</h2><p>' . esc_html__( 'Helps Google show the right name and logo for your site.', 'fileora' ) . '</p><table class="form-table" role="presentation">';
		$text( 'org_name', __( 'Name', 'fileora' ), __( 'Empty = the site title.', 'fileora' ), get_bloginfo( 'name' ) );
		$img( 'org_logo', __( 'Logo', 'fileora' ), __( 'Square or wide, at least 112 × 112 px. Empty = the logo from Appearance → Customize.', 'fileora' ) );
		echo '<tr><th scope="row"><label for="fo-seo-same_as">' . esc_html__( 'Social profiles', 'fileora' ) . '</label></th><td><textarea class="large-text" rows="4" id="fo-seo-same_as" name="' . esc_attr( $name . '[same_as]' ) . '" placeholder="https://www.instagram.com/…">' . esc_textarea( $s['same_as'] ) . '</textarea><p class="description">' . esc_html__( 'One address per line: Instagram, YouTube, LinkedIn, Facebook, X…', 'fileora' ) . '</p></td></tr>';
		echo '</table></section>';
		echo '<section class="fo-card"><h2>' . esc_html__( 'Sitemap and archives', 'fileora' ) . '</h2><label class="fo-check"><input type="checkbox" name="' . esc_attr( $name . '[clean_archives]' ) . '" value="1"' . checked( ! empty( $s['clean_archives'] ), true, false ) . '> ' . esc_html__( 'Leave users and tags out of the sitemap, and hide author, tag, date and search pages from Google', 'fileora' ) . '</label><p class="description">' . esc_html__( 'These archive pages repeat content found elsewhere. Recommended on.', 'fileora' ) . '</p></section>';
		submit_button();
		echo '</form>';
		echo '<section class="fo-card"><h2>' . esc_html__( 'What Fileora already does for SEO', 'fileora' ) . '</h2><ul class="fo-seo-done">';
		foreach ( array(
			__( 'XML sitemap of pages, posts and tools (WordPress’s own, at /wp-sitemap.xml); pages marked “hide from search” are left out.', 'fileora' ),
			__( 'Title, meta description, Open Graph and X tags on every page, post and tool.', 'fileora' ),
			__( 'Structured data: WebApplication and FAQ for tools, BlogPosting for posts, Breadcrumbs everywhere, Organization and WebSite on the homepage.', 'fileora' ),
			__( 'Canonical addresses, fast self-hosted fonts and libraries, mobile-friendly pages.', 'fileora' ),
		) as $li ) {
			echo '<li>' . esc_html( $li ) . '</li>';
		}
		echo '</ul></section>';
	}

	/* ------------------------------------------------------------------
	 * Front end.
	 * ---------------------------------------------------------------- */

	public static function title( $parts ) {
		if ( self::seo_plugin() ) {
			return $parts;
		}
		if ( is_front_page() ) {
			$t = trim( (string) self::settings()['home_title'] );
			if ( '' !== $t ) {
				return array( 'title' => $t );
			}
			return $parts;
		}
		if ( is_singular( self::types() ) ) {
			$t = (string) self::get( get_queried_object_id(), 'title' );
			if ( '' !== $t ) {
				$parts['title'] = $t;
			}
		}
		return $parts;
	}

	public static function robots( $robots ) {
		if ( is_singular( self::types() ) && self::get( get_queried_object_id(), 'noindex' ) && ! self::seo_plugin() ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
			unset( $robots['max-image-preview'] );
		}
		return $robots;
	}

	public static function canonical( $url, $post ) {
		if ( self::seo_plugin() ) {
			return $url;
		}
		$c = (string) self::get( $post->ID, 'canonical' );
		return '' !== $c ? $c : $url;
	}

	public static function sitemap_exclude( $args ) {
		$args['meta_query'] = isset( $args['meta_query'] ) ? $args['meta_query'] : array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		$args['meta_query'][] = array(
			'key'     => self::KEYS['noindex'],
			'compare' => 'NOT EXISTS',
		);
		return $args;
	}

	/** The share image for the current page: its own, the featured image, then the default. */
	public static function share_image( $post_id = 0 ) {
		$id = $post_id ? (int) self::get( $post_id, 'image' ) : 0;
		if ( ! $id && $post_id && has_post_thumbnail( $post_id ) ) {
			$id = (int) get_post_thumbnail_id( $post_id );
		}
		if ( ! $id ) {
			$id = (int) self::settings()['default_image'];
		}
		$src = $id ? wp_get_attachment_image_src( $id, 'full' ) : false;
		return $src ? array( 'url' => $src[0], 'w' => $src[1], 'h' => $src[2], 'alt' => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) : null;
	}

	public static function head() {
		if ( self::seo_plugin() ) {
			return;
		}
		$s = self::settings();
		foreach ( array( 'google' => 'google-site-verification', 'bing' => 'msvalidate.01', 'yandex' => 'yandex-verification', 'pinterest' => 'p:domain_verify' ) as $k => $meta ) {
			if ( '' !== $s[ $k ] ) {
				echo '<meta name="' . esc_attr( $meta ) . '" content="' . esc_attr( $s[ $k ] ) . '">' . "\n";
			}
		}
		if ( '' !== $s['twitter'] ) {
			echo '<meta name="twitter:site" content="@' . esc_attr( $s['twitter'] ) . '">' . "\n";
		}
		// Fallback tags for posts and pages when the active theme doesn't write them.
		if ( is_singular( array( 'post', 'page' ) ) && ! is_front_page() && ! current_theme_supports( 'fileora-seo' ) ) {
			$id   = get_queried_object_id();
			$desc = (string) self::get( $id, 'desc' );
			if ( '' === $desc ) {
				$desc = has_excerpt( $id ) ? get_the_excerpt( $id ) : wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_post_field( 'post_content', $id ) ) ), 28, '…' );
			}
			echo '<meta name="description" content="' . esc_attr( trim( wp_strip_all_tags( $desc ) ) ) . '">' . "\n";
			echo '<meta property="og:title" content="' . esc_attr( wp_get_document_title() ) . '">' . "\n";
			echo '<meta property="og:description" content="' . esc_attr( trim( wp_strip_all_tags( $desc ) ) ) . '">' . "\n";
			echo '<meta property="og:url" content="' . esc_url( get_permalink( $id ) ) . '">' . "\n";
		}
		// Share image for pages, posts and tools; the Fileora theme already prints featured images.
		if ( is_singular( self::types() ) && ! is_front_page() ) {
			$id   = get_queried_object_id();
			// The Fileora theme prints the image for posts and pages itself (using share_image()).
			$skip = current_theme_supports( 'fileora-seo' ) && ! is_singular( Fileora_Tool_Registry::POST_TYPE );
			$img  = $skip ? null : self::share_image( $id );
			if ( $img ) {
				self::image_tags( $img );
			}
		}
		if ( is_front_page() ) {
			$img = self::share_image( 0 );
			if ( $img ) {
				echo '<meta property="og:type" content="website">' . "\n";
				echo '<meta property="og:title" content="' . esc_attr( wp_get_document_title() ) . '">' . "\n";
				echo '<meta property="og:url" content="' . esc_url( home_url( '/' ) ) . '">' . "\n";
				self::image_tags( $img );
			}
			self::site_schema();
		}
	}

	private static function image_tags( array $img ) {
		echo '<meta property="og:image" content="' . esc_url( $img['url'] ) . '">' . "\n";
		echo '<meta property="og:image:width" content="' . (int) $img['w'] . '">' . "\n";
		echo '<meta property="og:image:height" content="' . (int) $img['h'] . '">' . "\n";
		if ( '' !== $img['alt'] ) {
			echo '<meta property="og:image:alt" content="' . esc_attr( $img['alt'] ) . '">' . "\n";
		}
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
		echo '<meta name="twitter:image" content="' . esc_url( $img['url'] ) . '">' . "\n";
	}

	/** Organization and WebSite (with site search) on the homepage. */
	private static function site_schema() {
		$s    = self::settings();
		$logo = (int) $s['org_logo'] ? (int) $s['org_logo'] : (int) get_theme_mod( 'custom_logo' );
		$org  = array_filter(
			array(
				'@type'  => 'Organization',
				'@id'    => home_url( '/#organization' ),
				'name'   => '' !== $s['org_name'] ? $s['org_name'] : wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
				'url'    => home_url( '/' ),
				'logo'   => $logo ? wp_get_attachment_image_url( $logo, 'full' ) : null,
				'sameAs' => '' !== $s['same_as'] ? array_values( array_filter( explode( "\n", $s['same_as'] ) ) ) : null,
			)
		);
		$site = array(
			'@type'           => 'WebSite',
			'@id'             => home_url( '/#website' ),
			'url'             => home_url( '/' ),
			'name'            => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'description'     => wp_specialchars_decode( get_bloginfo( 'description' ), ENT_QUOTES ),
			'publisher'       => array( '@id' => home_url( '/#organization' ) ),
			'inLanguage'      => get_bloginfo( 'language' ),
			'potentialAction' => array(
				'@type'       => 'SearchAction',
				'target'      => array( '@type' => 'EntryPoint', 'urlTemplate' => home_url( '/?s={search_term_string}' ) ),
				'query-input' => 'required name=search_term_string',
			),
		);
		echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => array( $org, $site ) ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . "</script>\n";
	}
}
