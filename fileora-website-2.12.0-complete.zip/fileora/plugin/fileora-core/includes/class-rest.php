<?php
/**
 * REST API: /wp-json/fileora/v1/...
 *
 *   POST /jobs/{tool}        upload files, start a server task -> 202 {job, token, status}
 *   GET  /jobs/{id}          task status (header X-Fileora-Token) -> {status, ahead, kind, name, size, text, error}
 *   GET  /jobs/{id}/file     download the result once (header X-Fileora-Token)
 *   POST /events             analytics event from the browser (page_view, tool_view, tool_run)
 *   GET  /health             live processing-server check (needs fileora_view_reports)
 *
 * The browser only ever talks to WordPress. WordPress talks to the
 * processing server with the shared key, which never reaches the browser.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Core_REST {

	const NS = 'fileora/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route(
			self::NS,
			'/jobs/(?P<tool>[a-z][a-z0-9]{1,19})',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'submit' ),
				'permission_callback' => '__return_true', // public tools; limits are enforced in submit()
			)
		);
		register_rest_route(
			self::NS,
			'/jobs/(?P<id>[a-f0-9]{32})',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'status' ),
				'permission_callback' => '__return_true', // access is checked with the job token
			)
		);
		register_rest_route(
			self::NS,
			'/jobs/(?P<id>[a-f0-9]{32})/file',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'file' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			self::NS,
			'/events',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'event' ),
				'permission_callback' => '__return_true', // anonymous; validated and rate-limited in Fileora_Analytics::record()
			)
		);
		register_rest_route(
			self::NS,
			'/health',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'health' ),
				'permission_callback' => function () {
					return current_user_can( 'fileora_view_reports' );
				},
			)
		);
	}

	/**
	 * Keeps page caches away from these responses. LiteSpeed Cache (installed
	 * by default on Hostinger) can cache REST GET requests, and a cached
	 * status would stay "queued" forever.
	 */
	private static function no_cache() {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		do_action( 'litespeed_control_set_nocache', 'fileora task' );
	}

	private static function response( $data, $status = 200 ) {
		$r = new WP_REST_Response( $data, $status );
		$r->header( 'Cache-Control', 'no-store' );
		return $r;
	}

	private static function error( $message, $status ) {
		return self::response( array( 'error' => $message ), $status );
	}

	/** POST /jobs/{tool} */
	public static function submit( WP_REST_Request $request ) {
		self::no_cache();
		$settings = Fileora_Core_Settings::get();
		$tool     = (string) $request['tool'];
		$def      = Fileora_Tool_Registry::get( $tool );

		if ( ! $def || 'browser' === $def['exec'] ) {
			return self::error( 'Unknown tool.', 404 );
		}
		if ( ! $def['enabled'] ) {
			return self::error( sprintf( '%s is switched off on this site.', $def['name'] ), 403 );
		}
		if ( 'ready' !== $def['status'] ) {
			return self::error( sprintf( '%s is coming soon.', $def['name'] ), 403 );
		}
		$user_id = get_current_user_id();
		$ip_hash = Fileora_Core_Security::ip_hash();
		$sid     = (string) $request->get_param( 'fo_sid' );
		$sid     = preg_match( '/^[a-f0-9]{32}$/', $sid ) ? $sid : '';
		$geo     = $sid ? Fileora_Analytics::session_geo( $sid ) : null;
		if ( ! $geo ) {
			$geo = Fileora_Geo::lookup( Fileora_Core_Security::client_ip() );
		}
		$who     = array(
			'user_id' => $user_id,
			'ip_hash' => $ip_hash,
			'sid'     => $sid,
			'ip'      => Fileora_Core_Security::stored_ip(),
			'country' => (string) $geo['country'],
			'region'  => (string) $geo['region'],
			'city'    => (string) $geo['city'],
		);
		if ( ! Fileora_Core_Settings::backend_configured() ) {
			Fileora_Task_Manager::record_rejected( $tool, 'not_configured', 'No processing server is set up.', $who );
			return self::error( 'The processing server isn’t connected yet.', 503 );
		}

		// Daily limit per visitor (or per account when logged in). Admins are never limited.
		$limit = (int) apply_filters( 'fileora_daily_limit', (int) $settings['daily_limit'], $user_id );
		if ( $limit > 0 && ! current_user_can( 'manage_options' ) && Fileora_Task_Manager::count_recent( $ip_hash, $user_id ) >= $limit ) {
			return self::error( sprintf( 'You’ve reached the limit of %d tasks in 24 hours. Please try again later.', $limit ), 429 );
		}

		/**
		 * Last check before a task is created, e.g. Cloudflare Turnstile or "members only".
		 * Return a WP_Error to refuse; its message is shown to the visitor.
		 */
		$allowed = apply_filters( 'fileora_pre_submit', true, $request, $tool );
		if ( is_wp_error( $allowed ) ) {
			$data = $allowed->get_error_data();
			return self::error( $allowed->get_error_message(), isset( $data['status'] ) ? (int) $data['status'] : 403 );
		}

		// Files.
		$raw       = $request->get_file_params();
		$files     = Fileora_Core_Security::normalize_files( isset( $raw['files'] ) ? $raw['files'] : null );
		$max_bytes = Fileora_Core_Settings::max_mb( $user_id ) * MB_IN_BYTES;
		$max_files = max( 1, min( (int) $settings['max_files'], (int) $def['max_files'] ) );
		if ( 'url' !== $def['accept'] ) {
			if ( ! $files ) {
				return self::error( 'Add a file first.', 400 );
			}
			if ( count( $files ) > $max_files ) {
				return self::error( sprintf( '%s accepts up to %d files at a time.', $def['name'], $max_files ), 400 );
			}
		} elseif ( $files ) {
			return self::error( 'This tool doesn’t take files.', 400 );
		}
		$bytes = 0;
		foreach ( $files as $file ) {
			$check = Fileora_Core_Security::validate_file( $file, $def['accept'], $max_bytes );
			if ( is_wp_error( $check ) ) {
				return self::error( $check->get_error_message(), $check->get_error_data()['status'] );
			}
			$bytes += $file['size'];
		}
		$who['files']    = count( $files );
		$who['bytes_in'] = $bytes;
		if ( Fileora_Core_Settings::value( 'record_file_names' ) ) {
			$first            = $files ? (string) $files[0]['name'] : (string) wp_parse_url( (string) $request->get_param( 'url' ), PHP_URL_HOST );
			$who['file_name'] = mb_substr( sanitize_text_field( wp_basename( str_replace( '\\', '/', $first ) ) ), 0, 160 );
		}

		// Options (JSON from the browser) and the web address for HTML to PDF.
		$options = (string) $request->get_param( 'options' );
		if ( strlen( $options ) > 20000 || ! is_array( json_decode( $options, true ) ) ) {
			$options = '{}';
		}
		$url = '';
		if ( 'url' === $def['accept'] ) {
			$url = esc_url_raw( trim( (string) $request->get_param( 'url' ) ), array( 'http', 'https' ) );
			if ( '' === $url ) {
				return self::error( 'Enter a web address, like https://example.com.', 400 );
			}
		}

		$result = Fileora_Backend_API::submit( $tool, $files, $options, $url );
		if ( is_wp_error( $result ) ) {
			Fileora_Task_Manager::record_rejected( $tool, 'unreachable', $result->get_error_message(), $who );
			return self::error( $result->get_error_message(), 502 );
		}
		if ( 202 !== $result['status'] || empty( $result['body']['job'] ) ) {
			$message = isset( $result['body']['error'] ) ? (string) $result['body']['error'] : 'The processing server couldn’t accept this file.';
			$status  = (int) $result['status'];
			if ( 401 === $status ) {
				Fileora_Core_Log::error( 'service rejected the shared key; check FILEORA_KEY' );
				Fileora_Task_Manager::record_rejected( $tool, 'auth', 'The processing server rejected the shared key.', $who );
				return self::error( 'The processing server isn’t set up correctly. Please try again later.', 502 );
			}
			$code = $status >= 400 && $status < 500 ? 'rejected' : 'server_error';
			Fileora_Task_Manager::record_rejected( $tool, $code, $message, $who );
			return self::error( $message, $status >= 400 && $status < 500 ? $status : 502 );
		}

		list( $token, $hash ) = Fileora_Core_Security::new_token();
		$job_id               = sanitize_key( $result['body']['job'] );
		Fileora_Task_Manager::create(
			array_merge(
				$who,
				array(
					'id'         => $job_id,
					'tool'       => $tool,
					'token_hash' => $hash,
					'status'     => 'queued',
				)
			)
		);
		do_action( 'fileora_job_created', $job_id, $tool, $user_id );

		return self::response(
			array(
				'job'    => $job_id,
				'token'  => $token,
				'status' => 'queued',
			),
			202
		);
	}

	/** Finds the task and checks the browser's token. */
	private static function authorized_job( WP_REST_Request $request ) {
		self::no_cache();
		$row = Fileora_Task_Manager::find( (string) $request['id'] );
		if ( ! $row || ! $row->token_hash || ! Fileora_Core_Security::token_matches( $request->get_header( 'x_fileora_token' ), $row->token_hash ) ) {
			return self::error( 'This task wasn’t found. Please run it again.', 404 );
		}
		return $row;
	}

	/** GET /jobs/{id} */
	public static function status( WP_REST_Request $request ) {
		$row = self::authorized_job( $request );
		if ( $row instanceof WP_REST_Response ) {
			return $row;
		}
		if ( 'failed' === $row->status ) {
			return self::response(
				array(
					'status' => 'failed',
					'error'  => $row->error ? $row->error : 'The task failed.',
				)
			);
		}

		$result = Fileora_Backend_API::status( $row->id );
		if ( is_wp_error( $result ) ) {
			return self::error( 'Lost contact with the processing server. Please try again.', 502 );
		}
		if ( 404 === $result['status'] ) {
			Fileora_Task_Manager::finish(
				$row,
				array(
					'status'     => 'failed',
					'error'      => 'Expired on the processing server',
					'error_code' => 'expired',
				)
			);
			return self::error( 'This task has expired. Please run it again.', 410 );
		}
		if ( 200 !== $result['status'] ) {
			return self::error( 'The processing server couldn’t report on this task. Please try again.', 502 );
		}
		$body = $result['body'];
		$out  = array_intersect_key( $body, array_flip( array( 'status', 'ahead', 'kind', 'name', 'size', 'error', 'text' ) ) );

		if ( isset( $body['status'] ) && in_array( $body['status'], array( 'done', 'failed' ), true ) ) {
			Fileora_Task_Manager::finish( $row, $body );
			if ( 'done' === $body['status'] && isset( $body['kind'] ) && 'text' === $body['kind'] ) {
				Fileora_Backend_API::delete( $row->id ); // the text is in this response; nothing left to download
			}
			do_action( 'fileora_job_finished', $row->id, $row->tool, $body['status'] );
		} elseif ( isset( $body['status'] ) && 'running' === $body['status'] && 'queued' === $row->status ) {
			Fileora_Task_Manager::update( $row->id, array( 'status' => 'running' ) );
		}
		return self::response( $out );
	}

	/** GET /jobs/{id}/file: streams the file, then deletes it on the server. */
	public static function file( WP_REST_Request $request ) {
		$row = self::authorized_job( $request );
		if ( $row instanceof WP_REST_Response ) {
			return $row;
		}
		if ( 'done' !== $row->status ) {
			return self::error( 'This task isn’t finished yet.', 409 );
		}
		if ( $row->downloaded_at ) {
			return self::error( 'This file was already downloaded and has been deleted from the server. Please run the task again.', 410 );
		}
		$sent = Fileora_Backend_API::stream( $row->id, $row->result_name ? $row->result_name : 'fileora-result' );
		if ( is_wp_error( $sent ) ) {
			return self::error( $sent->get_error_message(), 502 );
		}
		Fileora_Task_Manager::update( $row->id, array( 'downloaded_at' => gmdate( 'Y-m-d H:i:s' ) ) );
		Fileora_Backend_API::delete( $row->id );
		exit;
	}

	/** POST /events */
	public static function event( WP_REST_Request $request ) {
		self::no_cache();
		$data = $request->get_json_params();
		if ( ! is_array( $data ) ) {
			$data = $request->get_body_params();
		}
		$r = Fileora_Analytics::record( is_array( $data ) ? $data : array() );
		if ( is_wp_error( $r ) ) {
			$code = isset( $r->get_error_data()['status'] ) ? (int) $r->get_error_data()['status'] : 400;
			return 204 === $code ? new WP_REST_Response( null, 204 ) : self::error( $r->get_error_message(), $code );
		}
		return new WP_REST_Response( null, 204 );
	}

	/** GET /health */
	public static function health() {
		self::no_cache();
		$r = Fileora_Server_Monitor::check( 'manual' );
		return self::response(
			array(
				'ok'         => $r['ok'],
				'auth'       => $r['auth'],
				'http'       => $r['http'],
				'latency_ms' => $r['latency_ms'],
				'error'      => $r['error'],
				'server'     => $r['body'],
			)
		);
	}
}
