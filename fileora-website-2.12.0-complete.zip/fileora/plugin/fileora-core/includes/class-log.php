<?php
/**
 * Minimal logger. Writes to the PHP error log (wp-content/debug.log when
 * WP_DEBUG_LOG is on). File contents and passwords are never logged.
 *
 * Audit log (2.12): administrative actions on the processing server's
 * temporary files and cleanup are always written to the error log and kept
 * as the last 200 entries in the option fileora_audit_log (shown on
 * Processing Tasks → Temporary files & cleanup).
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Core_Log {

	const AUDIT_OPTION = 'fileora_audit_log';
	const AUDIT_KEEP   = 200;

	public static function error( $message, array $context = array() ) {
		self::write( 'ERROR', $message, $context );
	}

	public static function info( $message, array $context = array() ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			self::write( 'INFO', $message, $context );
		}
	}

	/**
	 * Records an administrative action: who, when, from where, what, on which target and the outcome.
	 *
	 * @param string $action  e.g. "cleanup.run", "temp.delete".
	 * @param string $target  e.g. a task id; never a file path.
	 * @param string $result  "ok", "refused" or "failed".
	 * @param array  $details Scalar facts (counts, old/new values, error text).
	 */
	public static function audit( $action, $target = '', $result = 'ok', array $details = array() ) {
		$user  = wp_get_current_user();
		$clean = array();
		foreach ( $details as $k => $v ) {
			if ( is_scalar( $v ) || null === $v ) {
				$clean[ sanitize_key( $k ) ] = is_string( $v ) ? substr( sanitize_text_field( $v ), 0, 300 ) : $v;
			}
		}
		$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? filter_var( wp_unslash( $_SERVER['REMOTE_ADDR'] ), FILTER_VALIDATE_IP ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$entry = array(
			'time'    => time(),
			'user_id' => (int) $user->ID,
			'user'    => $user->ID ? $user->user_login : ( wp_doing_cron() ? 'wp-cron' : '' ),
			'ip'      => $ip ? $ip : '',
			'action'  => preg_replace( '/[^a-z0-9._-]/', '', strtolower( (string) $action ) ),
			'target'  => substr( preg_replace( '/[^a-z0-9_-]/i', '', (string) $target ), 0, 64 ),
			'result'  => in_array( $result, array( 'ok', 'refused', 'failed' ), true ) ? $result : 'failed',
			'details' => $clean,
		);
		$log = get_option( self::AUDIT_OPTION, array() );
		$log = is_array( $log ) ? $log : array();
		array_unshift( $log, $entry );
		update_option( self::AUDIT_OPTION, array_slice( $log, 0, self::AUDIT_KEEP ), false );
		self::write( 'AUDIT', $entry['action'], array( 'user' => $entry['user'] . '#' . $entry['user_id'], 'ip' => $entry['ip'], 'target' => $entry['target'], 'result' => $entry['result'] ) + $clean );
	}

	/** Newest audit entries first. */
	public static function audit_entries( $limit = 50 ) {
		$log = get_option( self::AUDIT_OPTION, array() );
		return array_slice( is_array( $log ) ? $log : array(), 0, max( 1, (int) $limit ) );
	}

	private static function write( $level, $message, array $context ) {
		unset( $context['password'], $context['options'], $context['key'] );
		$line = sprintf( '[Fileora] %s %s', $level, $message );
		if ( $context ) {
			$line .= ' ' . wp_json_encode( $context );
		}
		error_log( $line ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	}
}
