<?php
/**
 * HTTP client for the Fileora processing service (the "existing backend").
 *
 * API contract (all requests carry the shared key in X-Fileora-Key):
 *   POST   /jobs/{tool}       multipart files[], options (JSON), url -> 202 {job, status}
 *   GET    /jobs/{id}         -> {status: queued|running|done|failed, ahead, kind, name, size, text, error}
 *   GET    /jobs/{id}/file    -> the result file (deleted after download by WordPress)
 *   DELETE /jobs/{id}         -> {deleted: true}
 *   GET    /health            (no key) -> {ok, key_set, tools: {id: bool}, workers, queue?}
 *
 * Administration (server 2.4+, key needed, plus X-Fileora-Actor for the audit log):
 *   GET    /metrics                 CPU, memory, disk, network, uptime
 *   GET    /admin/cleanup           cleanup settings, schedule, counts, failures
 *   PUT    /admin/cleanup/settings  {enabled, ttl_min, interval_min}
 *   POST   /admin/cleanup/run       run the cleanup now
 *   GET    /admin/cleanup/history   recent runs and admin actions
 *   GET    /admin/temp              temporary task folders with cleanup status
 *   GET    /admin/temp/{id}         one task folder
 *   DELETE /admin/temp/{id}         delete one finished task folder
 *   POST   /admin/temp/{id}/retry   retry a failed deletion
 *
 * Uploads and downloads use cURL directly: the WordPress HTTP API can't send
 * files as multipart uploads or stream large downloads. Small JSON calls use
 * wp_remote_*().
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Backend_API {

	private static function url( $path ) {
		return untrailingslashit( (string) Fileora_Core_Settings::value( 'service_url' ) ) . $path;
	}

	private static function key() {
		return (string) Fileora_Core_Settings::value( 'service_key' );
	}

	/**
	 * Sends the files to the service and creates a job.
	 *
	 * @return array{status:int, body:array}|WP_Error
	 */
	public static function submit( $tool, array $files, $options, $url = '' ) {
		if ( ! function_exists( 'curl_init' ) ) {
			return new WP_Error( 'fileora_curl', 'The PHP cURL extension is required.' );
		}
		$fields = array( 'options' => $options );
		foreach ( array_values( $files ) as $i => $file ) {
			$fields[ "files[{$i}]" ] = new CURLFile( $file['tmp_name'], 'application/octet-stream', sanitize_file_name( $file['name'] ) );
		}
		if ( '' !== $url ) {
			$fields['url'] = $url;
		}
		$ch = curl_init( self::url( '/jobs/' . rawurlencode( $tool ) ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init
		curl_setopt_array( // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt_array
			$ch,
			array(
				CURLOPT_POST           => true,
				CURLOPT_POSTFIELDS     => $fields,
				CURLOPT_HTTPHEADER     => array( 'X-Fileora-Key: ' . self::key(), 'Expect:' ),
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_CONNECTTIMEOUT => 10,
				CURLOPT_TIMEOUT        => 300,
			)
		);
		$body   = curl_exec( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec
		$status = (int) curl_getinfo( $ch, CURLINFO_RESPONSE_CODE ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_getinfo
		$error  = curl_error( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_error
		curl_close( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close
		if ( false === $body ) {
			Fileora_Core_Log::error( 'submit failed', array( 'tool' => $tool, 'curl' => $error ) );
			return new WP_Error( 'fileora_unreachable', 'The processing server isn’t responding. Please try again in a minute.', array( 'detail' => $error ) );
		}
		$json = json_decode( $body, true );
		return array(
			'status' => $status,
			'body'   => is_array( $json ) ? $json : array(),
		);
	}

	/** @return array{status:int, body:array}|WP_Error */
	public static function status( $job_id ) {
		$response = wp_remote_get(
			self::url( '/jobs/' . $job_id ),
			array(
				'timeout' => 15,
				'headers' => array( 'X-Fileora-Key' => self::key() ),
			)
		);
		if ( is_wp_error( $response ) ) {
			Fileora_Core_Log::error( 'status failed', array( 'job' => $job_id, 'error' => $response->get_error_message() ) );
			return $response;
		}
		$json = json_decode( wp_remote_retrieve_body( $response ), true );
		return array(
			'status' => (int) wp_remote_retrieve_response_code( $response ),
			'body'   => is_array( $json ) ? $json : array(),
		);
	}

	/** Deletes the job folder on the service right away. */
	public static function delete( $job_id ) {
		wp_remote_request(
			self::url( '/jobs/' . $job_id ),
			array(
				'method'   => 'DELETE',
				'timeout'  => 5,
				'blocking' => false,
				'headers'  => array( 'X-Fileora-Key' => self::key() ),
			)
		);
	}

	/**
	 * Streams the result file straight to the browser without loading it
	 * into memory. Returns WP_Error only if nothing was sent yet.
	 *
	 * @return true|WP_Error
	 */
	public static function stream( $job_id, $fallback_name ) {
		$headers = array();
		$started = false;
		$status  = 0;
		$ch      = curl_init( self::url( '/jobs/' . $job_id . '/file' ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init
		curl_setopt_array( // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt_array
			$ch,
			array(
				CURLOPT_HTTPHEADER     => array( 'X-Fileora-Key: ' . self::key() ),
				CURLOPT_CONNECTTIMEOUT => 10,
				CURLOPT_TIMEOUT        => 600,
				CURLOPT_HEADERFUNCTION => function ( $ch, $line ) use ( &$headers, &$status ) {
					if ( preg_match( '#^HTTP/\S+\s+(\d{3})#', $line, $m ) ) {
						$status = (int) $m[1];
					}
					$parts = explode( ':', $line, 2 );
					if ( 2 === count( $parts ) ) {
						$headers[ strtolower( trim( $parts[0] ) ) ] = trim( $parts[1] );
					}
					return strlen( $line );
				},
				CURLOPT_WRITEFUNCTION  => function ( $ch, $chunk ) use ( &$headers, &$started, &$status, $fallback_name ) {
					if ( 200 !== $status ) {
						return strlen( $chunk ); // swallow error bodies; handled below
					}
					if ( ! $started ) {
						$started = true;
						while ( ob_get_level() ) {
							ob_end_clean();
						}
						nocache_headers();
						header( 'Content-Type: ' . ( isset( $headers['content-type'] ) ? $headers['content-type'] : 'application/octet-stream' ) );
						header( 'Content-Disposition: ' . ( isset( $headers['content-disposition'] ) ? $headers['content-disposition'] : 'attachment; filename="' . sanitize_file_name( $fallback_name ) . '"' ) );
						if ( isset( $headers['content-length'] ) ) {
							header( 'Content-Length: ' . (int) $headers['content-length'] );
						}
						header( 'X-Content-Type-Options: nosniff' );
					}
					echo $chunk; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- binary file data
					flush();
					return strlen( $chunk );
				},
			)
		);
		$ok = curl_exec( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec
		curl_close( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close
		if ( $started ) {
			return true;
		}
		Fileora_Core_Log::error( 'download failed', array( 'job' => $job_id, 'status' => $status, 'ok' => (bool) $ok ) );
		return new WP_Error( 'fileora_download', 'The result couldn’t be downloaded. Please run the task again.' );
	}

	/**
	 * Authenticated JSON call to the server's monitoring and cleanup endpoints.
	 *
	 * @param string     $method  GET, PUT, POST or DELETE.
	 * @param string     $path    Path starting with "/".
	 * @param array|null $body    JSON body.
	 * @param int        $timeout Seconds.
	 * @return array{status:int, body:array}|WP_Error
	 */
	public static function admin( $method, $path, $body = null, $timeout = 20 ) {
		if ( '' === trim( (string) Fileora_Core_Settings::value( 'service_url' ) ) ) {
			return new WP_Error( 'fileora_not_configured', 'No server address set (Fileora → Settings).' );
		}
		$args = array(
			'method'  => $method,
			'timeout' => $timeout,
			'headers' => array(
				'X-Fileora-Key'   => self::key(),
				'X-Fileora-Actor' => self::actor(),
				'Accept'          => 'application/json',
			),
		);
		if ( null !== $body ) {
			$args['headers']['Content-Type'] = 'application/json';
			$args['body']                    = wp_json_encode( $body );
		}
		$response = wp_remote_request( self::url( $path ), $args );
		if ( is_wp_error( $response ) ) {
			Fileora_Core_Log::error( 'admin request failed', array( 'path' => strtok( $path, '?' ), 'error' => $response->get_error_message() ) );
			return $response;
		}
		$json = json_decode( wp_remote_retrieve_body( $response ), true );
		return array(
			'status' => (int) wp_remote_retrieve_response_code( $response ),
			'body'   => is_array( $json ) ? $json : array(),
		);
	}

	/** GET /metrics (server 2.4+). */
	public static function metrics() {
		return self::admin( 'GET', '/metrics', null, 10 );
	}

	/** Who is acting, for the server's audit log: "wp-user:<id>:<login>" or "wp-cron". */
	private static function actor() {
		$user = function_exists( 'wp_get_current_user' ) ? wp_get_current_user() : null;
		if ( $user && $user->ID ) {
			return 'wp-user:' . $user->ID . ':' . preg_replace( '/[^\w@.-]/', '', $user->user_login );
		}
		return wp_doing_cron() ? 'wp-cron' : 'wordpress';
	}

	/**
	 * Health check: is the service up, how fast, and is the shared key accepted?
	 *
	 * @return array{ok:bool, http:int, latency_ms:int, error:string, body:array, auth:bool|null}
	 */
	public static function check() {
		$out = array(
			'ok'         => false,
			'http'       => 0,
			'latency_ms' => 0,
			'error'      => '',
			'body'       => array(),
			'auth'       => null,
		);
		if ( '' === trim( (string) Fileora_Core_Settings::value( 'service_url' ) ) ) {
			$out['error'] = 'No server address set.';
			return $out;
		}
		$t0       = microtime( true );
		$response = wp_remote_get( self::url( '/health' ), array( 'timeout' => 10 ) );
		$out['latency_ms'] = (int) round( ( microtime( true ) - $t0 ) * 1000 );
		if ( is_wp_error( $response ) ) {
			$out['error'] = $response->get_error_message();
			return $out;
		}
		$out['http'] = (int) wp_remote_retrieve_response_code( $response );
		$json        = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $out['http'] || ! is_array( $json ) ) {
			$out['error'] = sprintf( 'Unexpected answer (HTTP %d).', $out['http'] );
			return $out;
		}
		$out['body'] = $json;
		$out['ok']   = ! empty( $json['ok'] );
		if ( ! $out['ok'] ) {
			$out['error'] = empty( $json['key_set'] ) ? 'The server is running without a shared key (FILEORA_KEY).' : 'The server reports a problem.';
		}
		// The key is right if an authenticated request for a job that can't exist returns 404 (wrong key: 401).
		$probe = wp_remote_get(
			self::url( '/jobs/' . str_repeat( '0', 32 ) ),
			array(
				'timeout' => 10,
				'headers' => array( 'X-Fileora-Key' => self::key() ),
			)
		);
		if ( ! is_wp_error( $probe ) ) {
			$code = (int) wp_remote_retrieve_response_code( $probe );
			if ( 401 === $code ) {
				$out['auth'] = false;
				if ( $out['ok'] ) {
					$out['error'] = 'The server rejected the shared key. It must equal FILEORA_KEY in /etc/fileora/fileora.env.';
				}
			} elseif ( 404 === $code ) {
				$out['auth'] = true;
			}
		}
		return $out;
	}
}
