<?php
/**
 * Visitor Analytics reports and their REST endpoints (admin only).
 *
 *   GET /fileora/v1/admin/analytics   summary, locations, real-time traffic, visitors vs tool runs, tool usage, devices
 *   GET /fileora/v1/admin/series      traffic per minute, hour or day for the selected period
 *   GET /fileora/v1/admin/activity    latest file processing (server tasks + browser tool runs)
 *   GET /fileora/v1/admin/visitors    visits with location, device and pages
 *
 * The period is range=1m|30m|24h|7d|30d|90d, or range=custom with from and
 * to (dates in the site's time zone, both included). Every number comes from
 * the stored records (see class-history.php for the definitions).
 *
 * All endpoints need the fileora_view_reports capability and the REST nonce.
 * IP addresses are only included for users with fileora_view_ip.
 * The summary is cached for 30 seconds, so several open dashboards don't
 * repeat the same queries.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Reports {

	const RANGES = array(
		'1m'  => MINUTE_IN_SECONDS,
		'30m' => 30 * MINUTE_IN_SECONDS,
		'24h' => DAY_IN_SECONDS,
		'7d'  => 7 * DAY_IN_SECONDS,
		'30d' => 30 * DAY_IN_SECONDS,
		'90d' => 90 * DAY_IN_SECONDS,
	);

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/**
	 * The period for a request: start and end timestamps (end excluded).
	 *
	 * @return array|WP_Error
	 */
	public static function window( $range, $from = '', $to = '' ) {
		$now = time();
		if ( 'custom' === $range ) {
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $from ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $to ) || ! strtotime( $from . ' UTC' ) || ! strtotime( $to . ' UTC' ) ) {
				return new WP_Error( 'range', __( 'Choose a start and an end date.', 'fileora' ), array( 'status' => 400 ) );
			}
			if ( $from > $to ) {
				list( $from, $to ) = array( $to, $from );
			}
			$start = Fileora_History::day_start( $from );
			$end   = min( $now, Fileora_History::day_start( $to ) + DAY_IN_SECONDS );
			if ( $start >= $now ) {
				return new WP_Error( 'range', __( 'The start date is in the future.', 'fileora' ), array( 'status' => 400 ) );
			}
			if ( $end - $start > 3660 * DAY_IN_SECONDS ) {
				return new WP_Error( 'range', __( 'Choose a period of 10 years or less.', 'fileora' ), array( 'status' => 400 ) );
			}
			return array( 'range' => 'custom', 'start' => $start, 'end' => $end, 'from' => $from, 'to' => $to );
		}
		if ( ! isset( self::RANGES[ $range ] ) ) {
			$range = '24h';
		}
		return array( 'range' => $range, 'start' => $now - self::RANGES[ $range ], 'end' => $now, 'from' => '', 'to' => '' );
	}

	/** The period from REST parameters, or a WP_Error. */
	private static function req_window( WP_REST_Request $req ) {
		return self::window( (string) $req['range'], (string) $req['from'], (string) $req['to'] );
	}

	/** Cache time for a period: short while it includes the present, longer for the past. */
	private static function ttl( array $w ) {
		return $w['end'] < time() - HOUR_IN_SECONDS ? 10 * MINUTE_IN_SECONDS : 30;
	}

	public static function routes() {
		$perm = function () {
			return current_user_can( 'fileora_view_reports' );
		};
		$win  = array(
			'range' => array( 'default' => '24h', 'enum' => array_merge( array_keys( self::RANGES ), array( 'custom' ) ) ),
			'from'  => array( 'default' => '' ),
			'to'    => array( 'default' => '' ),
		);
		register_rest_route(
			Fileora_Core_REST::NS,
			'/admin/analytics',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'rest_analytics' ),
				'permission_callback' => $perm,
				'args'                => array_merge(
					$win,
					array(
						'level' => array( 'default' => 'country', 'enum' => array( 'country', 'region', 'city' ) ),
						'days'  => array( 'default' => '30' ),
						'group' => array( 'default' => 'day', 'enum' => array( 'day', 'week', 'month' ) ),
					)
				),
			)
		);
		register_rest_route(
			Fileora_Core_REST::NS,
			'/admin/series',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'rest_series' ),
				'permission_callback' => $perm,
				'args'                => array_merge( $win, array( 'interval' => array( 'default' => '' ) ) ),
			)
		);
		register_rest_route(
			Fileora_Core_REST::NS,
			'/admin/activity',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'rest_activity' ),
				'permission_callback' => $perm,
			)
		);
		register_rest_route(
			Fileora_Core_REST::NS,
			'/admin/visitors',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'rest_visitors' ),
				'permission_callback' => $perm,
			)
		);
	}

	private static function no_cache( WP_REST_Response $r ) {
		$r->header( 'Cache-Control', 'no-store, private' );
		do_action( 'litespeed_control_set_nocache', 'fileora reports' );
		return $r;
	}

	private static function utc( $ts ) {
		return gmdate( 'Y-m-d H:i:s', $ts );
	}

	/** Site timezone offset in seconds (for daily buckets). */
	private static function offset() {
		return (int) round( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
	}

	/** Local date "Y-m-d" → UTC datetime string of its start (or end). */
	private static function local_day_utc( $date, $end = false ) {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) ) {
			return '';
		}
		$ts = strtotime( $date . ' 00:00:00 UTC' ) - self::offset() + ( $end ? DAY_IN_SECONDS - 1 : 0 );
		return self::utc( $ts );
	}

	/* ------------------------------------------------------------------
	 * Summary endpoint.
	 * ---------------------------------------------------------------- */

	public static function rest_analytics( WP_REST_Request $req ) {
		$w = self::req_window( $req );
		if ( is_wp_error( $w ) ) {
			return $w;
		}
		$level = (string) $req['level'];
		$days  = 'range' === $req['days'] ? 'range' : ( in_array( (int) $req['days'], array( 7, 30, 90, 180, 365 ), true ) ? (int) $req['days'] : 30 );
		$group = (string) $req['group'];
		$key   = 'fo_rep_' . md5( implode( '|', array( $w['range'], $w['from'], $w['to'], $level, $days, $group, get_locale(), 'custom' === $w['range'] ? '' : floor( time() / 30 ) ) ) );
		$data  = get_transient( $key );
		if ( false === $data ) {
			$tools = Fileora_History::tools( $w['start'], $w['end'] );
			$data  = array(
				'range'     => $w['range'],
				'window'    => array( 'start' => $w['start'], 'end' => $w['end'], 'from' => $w['from'], 'to' => $w['to'] ),
				'coverage'  => array( 'detail_from' => Fileora_History::detail_from(), 'retention' => (int) Fileora_Core_Settings::value( 'event_retention' ) ),
				'summary'   => self::summary( $w['start'], $w['end'] ),
				'locations' => self::locations( $w['start'], $w['end'], $level ),
				'realtime'  => self::realtime( 30 ),
				'compare'   => self::compare( 'range' === $days ? $w : $days, $group ),
				'tools'     => $tools,
				'top_tools' => array_slice(
					array_values(
						array_filter(
							$tools,
							function ( $t ) {
								return $t['runs'] > 0;
							}
						)
					),
					0,
					8
				),
				'devices'   => self::breakdown( $w['start'], $w['end'] ),
			);
			set_transient( $key, $data, self::ttl( $w ) );
		}
		$data['generated'] = time();
		return self::no_cache( new WP_REST_Response( $data ) );
	}

	public static function rest_series( WP_REST_Request $req ) {
		$w = self::req_window( $req );
		if ( is_wp_error( $w ) ) {
			return $w;
		}
		$iv   = sanitize_key( (string) $req['interval'] );
		$key  = 'fo_ser_' . md5( implode( '|', array( $w['range'], $w['from'], $w['to'], $iv, get_locale(), 'custom' === $w['range'] ? '' : floor( time() / 30 ) ) ) );
		$data = get_transient( $key );
		if ( false === $data ) {
			$data           = Fileora_History::series( $w['start'], $w['end'], $iv );
			$data['window'] = array( 'start' => $w['start'], 'end' => $w['end'] );
			set_transient( $key, $data, self::ttl( $w ) );
		}
		$data['generated'] = time();
		return self::no_cache( new WP_REST_Response( $data ) );
	}

	/** Totals for the period [$start, $end). Visits = visits with activity in the period. */
	public static function summary( $start_ts, $end_ts = null ) {
		global $wpdb;
		$e     = Fileora_Analytics::table();
		$s     = Fileora_Analytics::sessions_table();
		$t     = Fileora_Task_Manager::table();
		$start = self::utc( $start_ts );
		$end   = self::utc( null === $end_ts ? time() + 1 : $end_ts );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sess = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS visits, COUNT(DISTINCT visitor) AS visitors, SUM(first_seen >= %s AND is_new = 1) AS new_visitors FROM {$s} WHERE last_seen >= %s AND first_seen < %s", $start, $start, $end ) );
		$ev   = $wpdb->get_row( $wpdb->prepare( "SELECT SUM(type = 'page_view') AS views, SUM(type = 'tool_run' AND exec = 'browser') AS runs, SUM(type = 'tool_run' AND exec = 'browser' AND status = 'failed') AS failed, SUM(IF(type = 'tool_run' AND exec = 'browser' AND status = 'done', files, 0)) AS files FROM {$e} WHERE created_at >= %s AND created_at < %s", $start, $end ) );
		$tk   = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS runs, SUM(status = 'failed') AS failed, SUM(status IN ('queued', 'running')) AS running, SUM(IF(status = 'done', files, 0)) AS files FROM {$t} WHERE created_at >= %s AND created_at < %s", $start, $end ) );
		// phpcs:enable
		return array(
			'visits'         => (int) $sess->visits,
			'visitors'       => (int) $sess->visitors,
			'new_visitors'   => (int) $sess->new_visitors,
			'active'         => Fileora_Analytics::active(),
			'page_views'     => (int) $ev->views,
			'tool_runs'      => (int) $ev->runs + (int) $tk->runs,
			'browser_runs'   => (int) $ev->runs,
			'server_runs'    => (int) $tk->runs,
			'failed'         => (int) $ev->failed + (int) $tk->failed,
			'running'        => (int) $tk->running,
			'files'          => (int) $ev->files + (int) $tk->files,
		);
	}

	/** Unique visitors per location, top 8 and "Other". */
	public static function locations( $start_ts, $end_ts, $level = 'country' ) {
		global $wpdb;
		$s     = Fileora_Analytics::sessions_table();
		$start = self::utc( $start_ts );
		$end   = self::utc( $end_ts );
		$cols  = array(
			'country' => 'country',
			'region'  => 'country, region',
			'city'    => 'country, region, city',
		);
		$by    = $cols[ $level ];
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT {$by}, COUNT(DISTINCT visitor) AS n FROM {$s} WHERE last_seen >= %s AND first_seen < %s GROUP BY {$by} ORDER BY n DESC LIMIT 200", $start, $end ) );
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT visitor) FROM {$s} WHERE last_seen >= %s AND first_seen < %s", $start, $end ) );
		// phpcs:enable
		$items = array();
		$other = 0;
		$known = 0;
		foreach ( $rows as $i => $r ) {
			$n = (int) $r->n;
			if ( $i < 8 ) {
				$items[] = array(
					'label'   => Fileora_Geo::label( $r->country, 'country' === $level ? '' : (string) $r->region, 'city' === $level ? (string) $r->city : '' ),
					'country' => (string) $r->country,
					'n'       => $n,
				);
			} else {
				$other += $n;
			}
			if ( $r->country ) {
				$known += $n;
			}
		}
		if ( $other ) {
			$items[] = array( 'label' => __( 'Other locations', 'fileora' ), 'country' => '', 'n' => $other, 'other' => true );
		}
		return array(
			'level' => $level,
			'total' => $total,
			'known' => $known,
			'items' => $items,
			'note'  => self::geo_note(),
		);
	}

	private static function geo_note() {
		$src = (string) Fileora_Core_Settings::value( 'geo_source' );
		if ( 'off' === $src ) {
			return __( 'Location lookup is switched off in Settings.', 'fileora' );
		}
		$db = Fileora_Geo::db_info();
		if ( $db ) {
			return $db['dbip'] ? __( 'Approximate location from the DB-IP City Lite database (IP Geolocation by DB-IP, CC BY 4.0).', 'fileora' ) : sprintf( /* translators: %s: file name */ __( 'Approximate location from %s.', 'fileora' ), $db['file'] );
		}
		return __( 'No location database installed: only visitors arriving through Cloudflare get a country. Install the free database in Settings → Visitor location.', 'fileora' );
	}

	/**
	 * Visitors per minute for the last $minutes, split by the 4 busiest countries.
	 */
	public static function realtime( $minutes = 30 ) {
		global $wpdb;
		$e     = Fileora_Analytics::table();
		$now   = time();
		$end   = $now - ( $now % 60 ) + 60; // end of the current minute
		$start = $end - $minutes * 60;
		$s     = self::utc( $start );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT TIMESTAMPDIFF(MINUTE, %s, created_at) AS m, country, COUNT(DISTINCT sid) AS n, SUM(type = 'page_view') AS views FROM {$e} WHERE created_at >= %s GROUP BY m, country", $s, $s ) );
		$tops = $wpdb->get_col( $wpdb->prepare( "SELECT country FROM {$e} WHERE created_at >= %s AND country <> '' GROUP BY country ORDER BY COUNT(DISTINCT sid) DESC LIMIT 4", $s ) );
		$tot  = $wpdb->get_results( $wpdb->prepare( "SELECT TIMESTAMPDIFF(MINUTE, %s, created_at) AS m, COUNT(DISTINCT sid) AS n FROM {$e} WHERE created_at >= %s GROUP BY m", $s, $s ) );
		// phpcs:enable
		$labels = array();
		for ( $i = 0; $i < $minutes; $i++ ) {
			$labels[] = ( $start + $i * 60 ) * 1000;
		}
		$series = array();
		foreach ( $tops as $c ) {
			$series[ $c ] = array( 'label' => Fileora_Geo::country_name( $c ), 'data' => array_fill( 0, $minutes, 0 ) );
		}
		$series['_other'] = array( 'label' => $tops ? __( 'Other or unknown', 'fileora' ) : __( 'Visitors', 'fileora' ), 'data' => array_fill( 0, $minutes, 0 ), 'other' => (bool) $tops );
		$views            = array_fill( 0, $minutes, 0 );
		foreach ( $rows as $r ) {
			$m = (int) $r->m;
			if ( $m < 0 || $m >= $minutes ) {
				continue;
			}
			$k = isset( $series[ $r->country ] ) && '' !== $r->country ? $r->country : '_other';
			$series[ $k ]['data'][ $m ] += (int) $r->n;
			$views[ $m ]                += (int) $r->views;
		}
		$total = array_fill( 0, $minutes, 0 );
		foreach ( $tot as $r ) {
			$m = (int) $r->m;
			if ( $m >= 0 && $m < $minutes ) {
				$total[ $m ] = (int) $r->n;
			}
		}
		if ( ! array_sum( $series['_other']['data'] ) && count( $series ) > 1 ) {
			unset( $series['_other'] );
		}
		return array(
			'labels' => $labels,
			'series' => array_values( $series ),
			'total'  => $total,
			'views'  => $views,
		);
	}

	/**
	 * Unique visitors and tool runs per day, week or month (site time zone),
	 * for the last $days days or for a period from window().
	 * Days come from the saved daily totals (see class-history.php), so they
	 * stay available after the detailed records are removed. Weeks and
	 * months are counted from the detailed records.
	 */
	public static function compare( $days = 30, $group = 'day' ) {
		$today = Fileora_History::local_date( time() );
		if ( is_array( $days ) ) {
			$first = Fileora_History::local_date( $days['start'] );
			$last  = Fileora_History::local_date( $days['end'] - 1 );
			$days  = (int) round( ( strtotime( $last . ' UTC' ) - strtotime( $first . ' UTC' ) ) / DAY_IN_SECONDS ) + 1;
		} else {
			$last  = $today;
			$first = gmdate( 'Y-m-d', strtotime( $today . ' UTC' ) - ( $days - 1 ) * DAY_IN_SECONDS );
		}
		$out = array( 'group' => $group, 'days' => $days, 'first' => $first, 'last' => $last, 'labels' => array(), 'visitors' => array(), 'runs' => array(), 'views' => array(), 'visits' => array(), 'files' => array(), 'failed' => array(), 'source' => array() );
		if ( 'day' === $group ) {
			foreach ( Fileora_History::days( $first, $last ) as $d ) {
				$out['labels'][]   = $d['day'];
				$out['visitors'][] = $d['visitors'];
				$out['visits'][]   = $d['visits'];
				$out['views'][]    = $d['page_views'];
				$out['runs'][]     = $d['tool_runs'];
				$out['files'][]    = $d['files'];
				$out['failed'][]   = $d['failed'];
				$out['source'][]   = $d['source'];
			}
			return $out;
		}
		global $wpdb;
		$e   = Fileora_Analytics::table();
		$s   = Fileora_Analytics::sessions_table();
		$t   = Fileora_Task_Manager::table();
		$off = self::offset();
		if ( 'week' === $group ) {
			$first = gmdate( 'Y-m-d', strtotime( $first . ' UTC' ) - ( (int) gmdate( 'N', strtotime( $first . ' UTC' ) ) - 1 ) * DAY_IN_SECONDS );
		} else {
			$first = substr( $first, 0, 7 ) . '-01';
		}
		$start = self::local_day_utc( $first );
		$end   = self::local_day_utc( $last, true );
		$expr  = function ( $col ) use ( $off, $group ) {
			$local = 'DATE_ADD(' . $col . ', INTERVAL ' . $off . ' SECOND)';
			return 'week' === $group ? "DATE(DATE_SUB({$local}, INTERVAL WEEKDAY({$local}) DAY))" : "DATE_FORMAT({$local}, '%%Y-%%m-01')";
		};
		$be = $expr( 'created_at' );
		$bs = $expr( 'first_seen' );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$v  = $wpdb->get_results( $wpdb->prepare( "SELECT {$be} AS k, COUNT(DISTINCT visitor) AS visitors, SUM(type = 'page_view') AS views, SUM(type = 'tool_run' AND exec = 'browser') AS runs, SUM(type = 'tool_run' AND exec = 'browser' AND status = 'failed') AS failed, SUM(IF(type = 'tool_run' AND exec = 'browser' AND status = 'done', files, 0)) AS files FROM {$e} WHERE created_at >= %s AND created_at <= %s GROUP BY k", $start, $end ), OBJECT_K );
		$vs = $wpdb->get_results( $wpdb->prepare( "SELECT {$bs} AS k, COUNT(*) AS visits FROM {$s} WHERE first_seen >= %s AND first_seen <= %s GROUP BY k", $start, $end ), OBJECT_K );
		$tk = $wpdb->get_results( $wpdb->prepare( "SELECT {$be} AS k, COUNT(*) AS runs, SUM(status = 'failed') AS failed, SUM(IF(status = 'done', files, 0)) AS files FROM {$t} WHERE created_at >= %s AND created_at <= %s GROUP BY k", $start, $end ), OBJECT_K );
		// phpcs:enable
		$from = Fileora_History::local_date( Fileora_History::detail_from() );
		$d    = strtotime( $first . ' UTC' );
		while ( $d <= strtotime( $last . ' UTC' ) ) {
			$k                 = gmdate( 'Y-m-d', $d );
			$out['labels'][]   = $k;
			$out['visitors'][] = isset( $v[ $k ] ) ? (int) $v[ $k ]->visitors : 0;
			$out['visits'][]   = isset( $vs[ $k ] ) ? (int) $vs[ $k ]->visits : 0;
			$out['views'][]    = isset( $v[ $k ] ) ? (int) $v[ $k ]->views : 0;
			$out['runs'][]     = ( isset( $v[ $k ] ) ? (int) $v[ $k ]->runs : 0 ) + ( isset( $tk[ $k ] ) ? (int) $tk[ $k ]->runs : 0 );
			$out['files'][]    = ( isset( $v[ $k ] ) ? (int) $v[ $k ]->files : 0 ) + ( isset( $tk[ $k ] ) ? (int) $tk[ $k ]->files : 0 );
			$out['failed'][]   = ( isset( $v[ $k ] ) ? (int) $v[ $k ]->failed : 0 ) + ( isset( $tk[ $k ] ) ? (int) $tk[ $k ]->failed : 0 );
			$next              = 'week' === $group ? $d + 7 * DAY_IN_SECONDS : strtotime( gmdate( 'Y-m-01', $d ) . ' +1 month UTC' );
			$out['source'][]   = gmdate( 'Y-m-d', $next - DAY_IN_SECONDS ) < $from ? 'partial' : 'detail';
			$d                 = $next;
		}
		return $out;
	}

	/** Most-used tools in the window: browser runs + server tasks. */
	public static function top_tools( $seconds, $limit = 8 ) {
		global $wpdb;
		$e     = Fileora_Analytics::table();
		$t     = Fileora_Task_Manager::table();
		$start = self::utc( time() - $seconds );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT tool, SUM(runs) AS runs, SUM(failed) AS failed FROM ( SELECT tool, COUNT(*) AS runs, SUM(status = 'failed') AS failed FROM {$e} WHERE type = 'tool_run' AND exec = 'browser' AND created_at >= %s GROUP BY tool UNION ALL SELECT tool, COUNT(*) AS runs, SUM(status = 'failed') AS failed FROM {$t} WHERE created_at >= %s GROUP BY tool ) x GROUP BY tool ORDER BY runs DESC LIMIT %d", $start, $start, $limit ) );
		// phpcs:enable
		$out = array();
		foreach ( $rows as $r ) {
			$tool  = Fileora_Tool_Registry::get( $r->tool );
			$out[] = array( 'tool' => $r->tool, 'name' => $tool ? $tool['name'] : $r->tool, 'runs' => (int) $r->runs, 'failed' => (int) $r->failed );
		}
		return $out;
	}

	/** Visits per device, browser and operating system. */
	public static function breakdown( $start_ts, $end_ts ) {
		global $wpdb;
		$s     = Fileora_Analytics::sessions_table();
		$start = self::utc( $start_ts );
		$end   = self::utc( $end_ts );
		$out   = array();
		foreach ( array( 'device', 'browser', 'os' ) as $col ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows        = $wpdb->get_results( $wpdb->prepare( "SELECT {$col} AS k, COUNT(*) AS n FROM {$s} WHERE last_seen >= %s AND first_seen < %s GROUP BY k ORDER BY n DESC LIMIT 6", $start, $end ) );
			$out[ $col ] = array_map(
				function ( $r ) {
					return array( 'label' => '' === $r->k ? __( 'Unknown', 'fileora' ) : ucfirst( $r->k ), 'n' => (int) $r->n );
				},
				$rows
			);
		}
		return $out;
	}

	/**
	 * Tables follow the period chosen at the top (period=range, wfrom, wto)
	 * unless their own From/To dates are set.
	 */
	private static function table_window( WP_REST_Request $req, $from, $to ) {
		if ( '' !== $from || '' !== $to || '' === (string) $req['period'] ) {
			return array( $from, $to );
		}
		$w = self::window( (string) $req['period'], (string) $req['wfrom'], (string) $req['wto'] );
		if ( is_wp_error( $w ) ) {
			return array( $from, $to );
		}
		return array( self::utc( $w['start'] ), self::utc( $w['end'] - 1 ) );
	}

	/* ------------------------------------------------------------------
	 * Latest file processing.
	 * ---------------------------------------------------------------- */

	public static function rest_activity( WP_REST_Request $req ) {
		global $wpdb;
		$e      = Fileora_Analytics::table();
		$s      = Fileora_Analytics::sessions_table();
		$t      = Fileora_Task_Manager::table();
		$per    = max( 5, min( 100, (int) ( $req['per_page'] ? $req['per_page'] : 15 ) ) );
		$page   = max( 1, (int) $req['page'] );
		$tool   = sanitize_key( (string) $req['tool'] );
		$status = in_array( $req['status'], array( 'done', 'failed', 'progress' ), true ) ? $req['status'] : '';
		$cc     = preg_match( '/^[A-Z]{2}$/', strtoupper( (string) $req['country'] ) ) ? strtoupper( (string) $req['country'] ) : '';
		$from   = self::local_day_utc( (string) $req['from'] );
		$to     = self::local_day_utc( (string) $req['to'], true );
		list( $from, $to ) = self::table_window( $req, $from, $to );
		$q      = trim( sanitize_text_field( (string) $req['search'] ) );
		$ip_ok  = current_user_can( 'fileora_view_ip' );

		$wt = array( '1=1' );
		$at = array();
		$we = array( "e.type = 'tool_run'", "e.exec = 'browser'" );
		$ae = array();
		if ( $tool ) {
			$wt[] = 't.tool = %s';
			$at[] = $tool;
			$we[] = 'e.tool = %s';
			$ae[] = $tool;
		}
		if ( 'progress' === $status ) {
			$wt[] = "t.status IN ('queued', 'running')";
			$we[] = '1=0';
		} elseif ( $status ) {
			$wt[] = 't.status = %s';
			$at[] = $status;
			$we[] = 'e.status = %s';
			$ae[] = $status;
		}
		if ( $cc ) {
			$wt[] = 't.country = %s';
			$at[] = $cc;
			$we[] = 'e.country = %s';
			$ae[] = $cc;
		}
		if ( $from ) {
			$wt[] = 't.created_at >= %s';
			$at[] = $from;
			$we[] = 'e.created_at >= %s';
			$ae[] = $from;
		}
		if ( $to ) {
			$wt[] = 't.created_at <= %s';
			$at[] = $to;
			$we[] = 'e.created_at <= %s';
			$ae[] = $to;
		}
		if ( '' !== $q ) {
			$like = '%' . $wpdb->esc_like( $q ) . '%';
			$wt[] = $ip_ok ? '(t.file_name LIKE %s OR t.city LIKE %s OR t.ip LIKE %s)' : '(t.file_name LIKE %s OR t.city LIKE %s)';
			$we[] = '(e.file_name LIKE %s OR e.city LIKE %s)';
			array_push( $at, $like, $like );
			if ( $ip_ok ) {
				$at[] = $like;
			}
			array_push( $ae, $like, $like );
		}
		$sql_t = "SELECT 'server' AS exec, t.created_at AS at, t.tool, t.file_name, t.files, t.country, t.region, t.city, t.ip, t.status, t.duration_ms AS ms, t.error FROM {$t} t WHERE " . implode( ' AND ', $wt );
		$sql_e = "SELECT 'browser' AS exec, e.created_at AS at, e.tool, e.file_name, e.files, e.country, e.region, e.city, COALESCE(s.ip, '') AS ip, e.status, e.ms, '' AS error FROM {$e} e LEFT JOIN {$s} s ON s.sid = e.sid WHERE " . implode( ' AND ', $we );
		$args  = array_merge( $at, $ae );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( $args ? $wpdb->prepare( "SELECT COUNT(*) FROM ( {$sql_t} UNION ALL {$sql_e} ) x", $args ) : "SELECT COUNT(*) FROM ( {$sql_t} UNION ALL {$sql_e} ) x" );
		$rows  = $wpdb->get_results( $wpdb->prepare( "{$sql_t} UNION ALL {$sql_e} ORDER BY at DESC LIMIT %d OFFSET %d", array_merge( $args, array( $per, ( $page - 1 ) * $per ) ) ) );
		// phpcs:enable
		$items = array();
		foreach ( $rows as $r ) {
			$def     = Fileora_Tool_Registry::get( $r->tool );
			$items[] = array(
				'at'       => strtotime( $r->at . ' UTC' ),
				'tool'     => $r->tool,
				'toolName' => $def ? $def['name'] : $r->tool,
				'exec'     => $r->exec,
				'file'     => (string) $r->file_name,
				'files'    => (int) $r->files,
				'location' => '' === $r->country && '' === $r->city ? '' : Fileora_Geo::label( $r->country, $r->region, $r->city ),
				'country'  => (string) $r->country,
				'ip'       => $ip_ok ? (string) $r->ip : null,
				'status'   => in_array( $r->status, array( 'queued', 'running' ), true ) ? 'progress' : (string) $r->status,
				'ms'       => null === $r->ms ? null : (int) $r->ms,
				'error'    => (string) $r->error,
			);
		}
		return self::no_cache(
			new WP_REST_Response(
				array(
					'items'     => $items,
					'total'     => $total,
					'page'      => $page,
					'pages'     => max( 1, (int) ceil( $total / $per ) ),
					'canSeeIp'  => $ip_ok,
					'generated' => time(),
				)
			)
		);
	}

	/* ------------------------------------------------------------------
	 * Visits.
	 * ---------------------------------------------------------------- */

	public static function rest_visitors( WP_REST_Request $req ) {
		global $wpdb;
		$s     = Fileora_Analytics::sessions_table();
		$per   = max( 5, min( 100, (int) ( $req['per_page'] ? $req['per_page'] : 20 ) ) );
		$page  = max( 1, (int) $req['page'] );
		$ip_ok = current_user_can( 'fileora_view_ip' );
		$cc    = preg_match( '/^[A-Z]{2}$/', strtoupper( (string) $req['country'] ) ) ? strtoupper( (string) $req['country'] ) : '';
		$from  = self::local_day_utc( (string) $req['from'] );
		$to    = self::local_day_utc( (string) $req['to'], true );
		list( $from, $to ) = self::table_window( $req, $from, $to );
		$q     = trim( sanitize_text_field( (string) $req['search'] ) );
		$sorts = array( 'last_seen', 'first_seen', 'pages', 'tool_runs', 'country', 'device', 'browser' );
		$sort  = in_array( $req['orderby'], $sorts, true ) ? $req['orderby'] : 'last_seen';
		$order = 'asc' === strtolower( (string) $req['order'] ) ? 'ASC' : 'DESC';
		$w     = array( '1=1' );
		$a     = array();
		if ( $cc ) {
			$w[] = 'country = %s';
			$a[] = $cc;
		}
		if ( $from ) {
			$w[] = 'last_seen >= %s';
			$a[] = $from;
		}
		if ( $to ) {
			$w[] = 'first_seen <= %s';
			$a[] = $to;
		}
		if ( 'active' === $req['status'] ) {
			$w[] = 'last_seen >= %s';
			$a[] = self::utc( time() - Fileora_Analytics::ACTIVE_MIN * 60 );
		}
		if ( '' !== $q ) {
			$like = '%' . $wpdb->esc_like( $q ) . '%';
			$f    = array( 'visitor LIKE %s', 'city LIKE %s', 'region LIKE %s', 'landing LIKE %s', 'last_page LIKE %s', 'referrer LIKE %s', 'browser LIKE %s' );
			if ( $ip_ok ) {
				$f[] = 'ip LIKE %s';
			}
			$w[] = '(' . implode( ' OR ', $f ) . ')';
			$a   = array_merge( $a, array_fill( 0, count( $f ), $like ) );
		}
		$where = implode( ' AND ', $w );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( $a ? $wpdb->prepare( "SELECT COUNT(*) FROM {$s} WHERE {$where}", $a ) : "SELECT COUNT(*) FROM {$s} WHERE {$where}" );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$s} WHERE {$where} ORDER BY {$sort} {$order} LIMIT %d OFFSET %d", array_merge( $a, array( $per, ( $page - 1 ) * $per ) ) ) );
		// phpcs:enable
		$active = time() - Fileora_Analytics::ACTIVE_MIN * 60;
		$items  = array();
		foreach ( $rows as $r ) {
			$last    = strtotime( $r->last_seen . ' UTC' );
			$tool    = $r->last_tool ? Fileora_Tool_Registry::get( $r->last_tool ) : null;
			$items[] = array(
				'visitor'  => substr( $r->visitor, 0, 8 ),
				'first'    => strtotime( $r->first_seen . ' UTC' ),
				'last'     => $last,
				'location' => Fileora_Geo::label( $r->country, $r->region, $r->city ),
				'country'  => (string) $r->country,
				'ip'       => $ip_ok ? (string) $r->ip : null,
				'landing'  => (string) $r->landing,
				'page'     => (string) $r->last_page,
				'tool'     => $tool ? $tool['name'] : '',
				'referrer' => (string) $r->referrer,
				'device'   => (string) $r->device,
				'browser'  => (string) $r->browser,
				'os'       => (string) $r->os,
				'pages'    => (int) $r->pages,
				'runs'     => (int) $r->tool_runs,
				'new'      => (bool) $r->is_new,
				'status'   => $last >= $active ? 'active' : 'ended',
			);
		}
		return self::no_cache(
			new WP_REST_Response(
				array(
					'items'     => $items,
					'total'     => $total,
					'page'      => $page,
					'pages'     => max( 1, (int) ceil( $total / $per ) ),
					'canSeeIp'  => $ip_ok,
					'generated' => time(),
				)
			)
		);
	}

	/** Countries seen in the last 90 days (for the filter menus). */
	public static function countries() {
		global $wpdb;
		$s = Fileora_Analytics::sessions_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$codes = $wpdb->get_col( "SELECT DISTINCT country FROM {$s} WHERE country <> ''" );
		$out   = array();
		foreach ( $codes as $c ) {
			$out[ $c ] = Fileora_Geo::country_name( $c );
		}
		asort( $out );
		return $out;
	}
}
