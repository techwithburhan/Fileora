<?php
/**
 * The Support account.
 *
 * An administrator creates it in Fileora → Settings → Support account (or with
 * WP-CLI: `wp fileora support-user --password=<initial password>`), typing
 * the initial password there. The password is handed straight to WordPress,
 * which stores only its hash; it is never saved in options, logs or code.
 *
 * When "Require a new password at first login" is ticked, the user is sent to
 * their profile after logging in and can't open other admin pages until they
 * have chosen a new password.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Support {

	const MUST_CHANGE = 'fileora_must_change_password';

	public static function init() {
		add_action( 'admin_post_fileora_create_support', array( __CLASS__, 'handle_create' ) );
		add_action( 'admin_init', array( __CLASS__, 'enforce_change' ), 1 );
		add_action( 'profile_update', array( __CLASS__, 'password_changed' ), 10, 2 );
		add_action( 'after_password_reset', array( __CLASS__, 'after_reset' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_filter( 'login_redirect', array( __CLASS__, 'login_redirect' ), 20, 3 );
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			WP_CLI::add_command( 'fileora support-user', array( __CLASS__, 'cli' ) );
		}
	}

	/**
	 * Creates the Support user or updates its role. Returns the user id or WP_Error.
	 */
	public static function create( $login, $display, $email, $password, $must_change ) {
		$login = sanitize_user( $login, true );
		if ( '' === $login ) {
			return new WP_Error( 'login', __( 'Enter a username.', 'fileora' ) );
		}
		if ( username_exists( $login ) ) {
			return new WP_Error( 'exists', __( 'A user with this username already exists. Edit that user in Users instead.', 'fileora' ) );
		}
		if ( strlen( $password ) < 8 ) {
			return new WP_Error( 'weak', __( 'Use an initial password of at least 8 characters.', 'fileora' ) );
		}
		if ( ! $email || ! is_email( $email ) ) {
			// WordPress needs an email address to save the profile (and so to change the password).
			return new WP_Error( 'email', __( 'Enter a valid email address for the Support user. WordPress needs it to save a new password and for password resets.', 'fileora' ) );
		}
		if ( email_exists( $email ) ) {
			return new WP_Error( 'email_exists', __( 'This email address already belongs to another user.', 'fileora' ) );
		}
		Fileora_Permissions::sync_role();
		$id = wp_insert_user(
			array(
				'user_login'   => $login,
				'user_pass'    => $password,
				'user_email'   => $email,
				'display_name' => $display ? $display : $login,
				'nickname'     => $display ? $display : $login,
				'role'         => Fileora_Permissions::SUPPORT_ROLE,
			)
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		if ( $must_change ) {
			update_user_meta( $id, self::MUST_CHANGE, 1 );
		}
		update_user_meta( $id, 'show_welcome_panel', 0 );
		return $id;
	}

	public static function handle_create() {
		if ( ! current_user_can( 'create_users' ) || ! current_user_can( 'fileora_manage_settings' ) ) {
			wp_die( esc_html__( 'You are not allowed to create users.', 'fileora' ), 403 );
		}
		check_admin_referer( 'fileora_create_support' );
		// The password is used once, passed to WordPress and not stored anywhere else.
		$pass = isset( $_POST['support_pass'] ) ? (string) wp_unslash( $_POST['support_pass'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- passwords are not sanitized
		$r    = self::create(
			isset( $_POST['support_login'] ) ? sanitize_user( wp_unslash( $_POST['support_login'] ), true ) : 'Support',
			isset( $_POST['support_name'] ) ? sanitize_text_field( wp_unslash( $_POST['support_name'] ) ) : 'Support',
			isset( $_POST['support_email'] ) ? sanitize_email( wp_unslash( $_POST['support_email'] ) ) : '',
			$pass,
			! empty( $_POST['support_must_change'] )
		);
		$args = is_wp_error( $r ) ? array( 'fo_support_error' => rawurlencode( $r->get_error_message() ) ) : array( 'fo_support_created' => (int) $r );
		wp_safe_redirect( add_query_arg( array_merge( array( 'page' => 'fileora-settings' ), $args ), admin_url( 'admin.php' ) ) . '#support' );
		exit;
	}

	/** Users that have the Support role. */
	public static function users() {
		return get_users( array( 'role' => Fileora_Permissions::SUPPORT_ROLE, 'fields' => array( 'ID', 'user_login', 'display_name' ) ) );
	}

	/** Keeps a user who must change the password on their profile page. */
	public static function enforce_change() {
		$uid = get_current_user_id();
		if ( ! $uid || ! get_user_meta( $uid, self::MUST_CHANGE, true ) || wp_doing_ajax() ) {
			return;
		}
		global $pagenow;
		if ( 'profile.php' === $pagenow || 'admin-post.php' === $pagenow ) {
			return;
		}
		wp_safe_redirect( admin_url( 'profile.php?fileora_new_password=1#password' ) );
		exit;
	}

	/** Clears the flag once a different password was saved. */
	public static function password_changed( $user_id, $old ) {
		if ( ! get_user_meta( $user_id, self::MUST_CHANGE, true ) ) {
			return;
		}
		$new = get_userdata( $user_id );
		if ( $new && $old && $new->user_pass !== $old->user_pass ) {
			delete_user_meta( $user_id, self::MUST_CHANGE );
		}
	}

	public static function after_reset( $user ) {
		delete_user_meta( $user->ID, self::MUST_CHANGE );
	}

	public static function notice() {
		$uid = get_current_user_id();
		if ( $uid && get_user_meta( $uid, self::MUST_CHANGE, true ) ) {
			echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'Please choose a new password.', 'fileora' ) . '</strong> ' . esc_html__( 'Your account was created with an initial password. Set a new one under “Account Management” below and press “Update Profile”. Other pages open once that is done.', 'fileora' ) . '</p></div>';
		}
	}

	/** After logging in, users who can see the reports land on Visitor Analytics (Settings). */
	public static function login_redirect( $to, $requested, $user ) {
		if ( ! $user instanceof WP_User ) {
			return $to;
		}
		if ( get_user_meta( $user->ID, self::MUST_CHANGE, true ) ) {
			return admin_url( 'profile.php?fileora_new_password=1#password' );
		}
		$default = in_array( untrailingslashit( (string) $requested ), array( '', untrailingslashit( admin_url() ) ), true ) || untrailingslashit( $to ) === untrailingslashit( admin_url() );
		if ( $default && user_can( $user, 'fileora_view_reports' ) && Fileora_Core_Settings::value( 'login_to_analytics' ) ) {
			return admin_url( 'admin.php?page=fileora-analytics' );
		}
		return $to;
	}

	/**
	 * Creates the Support user.
	 *
	 * ## OPTIONS
	 *
	 * --password=<password>
	 * : Initial password (the user is asked to change it at first login).
	 *
	 * [--login=<login>]
	 * : Username. Default: Support
	 *
	 * [--display-name=<name>]
	 * : Display name. Default: Support
	 *
	 * --email=<email>
	 * : Email address (WordPress needs it to save a new password).
	 *
	 * [--no-force-change]
	 * : Don't require a new password at first login.
	 */
	public static function cli( $args, $assoc ) {
		$r = self::create(
			isset( $assoc['login'] ) ? $assoc['login'] : 'Support',
			isset( $assoc['display-name'] ) ? $assoc['display-name'] : 'Support',
			isset( $assoc['email'] ) ? $assoc['email'] : '',
			isset( $assoc['password'] ) ? (string) $assoc['password'] : '',
			(bool) \WP_CLI\Utils\get_flag_value( $assoc, 'force-change', true )
		);
		if ( is_wp_error( $r ) ) {
			WP_CLI::error( $r->get_error_message() );
		}
		WP_CLI::success( sprintf( 'Support user created (ID %d).', $r ) );
	}
}
