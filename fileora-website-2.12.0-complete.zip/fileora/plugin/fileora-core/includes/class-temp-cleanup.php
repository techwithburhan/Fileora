<?php
/**
 * Processing Tasks → Temporary files & cleanup.
 *
 * The temporary files live on the processing server (FILEORA_WORKDIR, by
 * default /var/lib/fileora/jobs). The server owns the cleanup job, its
 * settings (kept in /var/lib/fileora/cleanup-settings.json, so they survive
 * restarts) and every safety check (see server/temp_store.py). WordPress only
 * shows the state and sends authorised admin actions:
 *
 *   view   capability fileora_view_reports (Administrator, Support)
 *   change capability fileora_manage_settings (Administrator) + a nonce per action
 *
 * Every action is written to the audit log here (Fileora_Core_Log::audit)
 * and on the server (journalctl -u fileora). Nothing here touches WordPress
 * posts, pages, media, users or the task records in the database.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Temp_Cleanup {

	const CAP_VIEW   = 'fileora_view_reports';
	const CAP_MANAGE = 'fileora_manage_settings';
	const CACHE      = 'fileora_temp_lookup';
	const PAGE       = 'fileora-tasks';
	const TTL_CHOICES      = array( 15, 30, 60, 120, 180, 360, 720, 1440 );
	const INTERVAL_CHOICES = array( 1, 2, 5, 10, 15, 30, 60 );
	const FILTERS          = array( 'active', 'scheduled', 'due', 'kept', 'failed', 'done' );

	public static function init() {
		if ( ! is_admin() ) {
			return;
		}
		foreach ( array( 'settings', 'toggle', 'run', 'delete', 'retry' ) as $a ) {
			add_action( 'admin_post_fileora_cleanup_' . $a, array( __CLASS__, 'handle_' . $a ) );
		}
	}

	/** Readable message for a failed server call. */
	public static function error_text( $res ) {
		if ( is_wp_error( $res ) ) {
			return 'fileora_not_configured' === $res->get_error_code()
				? $res->get_error_message()
				: sprintf( /* translators: %s: error */ __( 'The processing server isn’t reachable (%s).', 'fileora' ), $res->get_error_message() );
		}
		$status = (int) $res['status'];
		if ( 401 === $status ) {
			return __( 'The processing server rejected the shared key (Fileora → Settings → Shared key must equal FILEORA_KEY).', 'fileora' );
		}
		if ( 404 === $status && isset( $res['body']['detail'] ) ) {
			return __( 'This processing server doesn’t support temporary-file management yet. Update it to version 2.4 (README section 8.13).', 'fileora' );
		}
		if ( ! empty( $res['body']['error'] ) ) {
			return (string) $res['body']['error'];
		}
		return sprintf( __( 'Unexpected answer from the processing server (HTTP %d).', 'fileora' ), $status );
	}

	private static function ok( $res ) {
		return ! is_wp_error( $res ) && 200 === (int) $res['status'];
	}

	/**
	 * Everything the Temporary files view needs, in three server calls.
	 *
	 * @return array{ok:bool, error:string, status:array, temp:array, history:array}
	 */
	public static function overview() {
		$out    = array(
			'ok'      => false,
			'error'   => '',
			'status'  => array(),
			'temp'    => array(),
			'history' => array(),
		);
		$status = Fileora_Backend_API::admin( 'GET', '/admin/cleanup' );
		if ( ! self::ok( $status ) ) {
			$out['error'] = self::error_text( $status );
			return $out;
		}
		$temp = Fileora_Backend_API::admin( 'GET', '/admin/temp' );
		if ( ! self::ok( $temp ) ) {
			$out['error'] = self::error_text( $temp );
			return $out;
		}
		$hist           = Fileora_Backend_API::admin( 'GET', '/admin/cleanup/history?limit=50' );
		$out['ok']      = true;
		$out['status']  = $status['body'];
		$out['temp']    = $temp['body'];
		$out['history'] = self::ok( $hist ) && isset( $hist['body']['history'] ) ? (array) $hist['body']['history'] : array();
		return $out;
	}

	/** One task folder on the server, or the error. */
	public static function task( $id ) {
		if ( ! preg_match( '/^[a-f0-9]{32}$/', (string) $id ) ) {
			return array( 'ok' => false, 'error' => __( 'Not a task id.', 'fileora' ) );
		}
		$r = Fileora_Backend_API::admin( 'GET', '/admin/temp/' . $id );
		if ( self::ok( $r ) ) {
			return array( 'ok' => true, 'task' => $r['body'] );
		}
		if ( ! is_wp_error( $r ) && 404 === (int) $r['status'] && ! isset( $r['body']['detail'] ) ) {
			return array( 'ok' => false, 'gone' => true, 'removed' => isset( $r['body']['removed'] ) ? $r['body']['removed'] : null, 'error' => __( 'No temporary files for this task on the server.', 'fileora' ) );
		}
		return array( 'ok' => false, 'error' => self::error_text( $r ) );
	}

	/**
	 * Temp-file status per task for the Task history list (cached for 30 seconds).
	 *
	 * @return array{ok:bool, error?:string, tasks?:array, removed?:array}
	 */
	public static function lookup() {
		$c = get_transient( self::CACHE );
		if ( is_array( $c ) ) {
			return $c;
		}
		$r = Fileora_Backend_API::admin( 'GET', '/admin/temp', null, 8 );
		if ( ! self::ok( $r ) ) {
			$c = array(
				'ok'    => false,
				'error' => self::error_text( $r ),
			);
		} else {
			$tasks = array();
			foreach ( isset( $r['body']['tasks'] ) ? (array) $r['body']['tasks'] : array() as $t ) {
				if ( isset( $t['id'] ) ) {
					$tasks[ $t['id'] ] = array(
						'cleanup'   => isset( $t['cleanup'] ) ? $t['cleanup'] : '',
						'expires'   => isset( $t['expires'] ) ? (int) $t['expires'] : 0,
						'remaining' => isset( $t['remaining'] ) ? (int) $t['remaining'] : 0,
						'size'      => isset( $t['size'] ) ? (int) $t['size'] : 0,
					);
				}
			}
			$c = array(
				'ok'       => true,
				'verified' => ! empty( $r['body']['summary']['verified'] ),
				'tasks'    => $tasks,
				'removed'  => isset( $r['body']['removed'] ) ? (array) $r['body']['removed'] : array(),
			);
		}
		set_transient( self::CACHE, $c, 30 );
		return $c;
	}

	public static function flush() {
		delete_transient( self::CACHE );
	}

	/** Label and state (good|warning|critical|unknown) for a cleanup status from the server. */
	public static function cleanup_label( $cleanup, array $t = array() ) {
		switch ( $cleanup ) {
			case 'active':
				return array( __( 'Protected: in use', 'fileora' ), 'unknown' );
			case 'scheduled':
				/* translators: %s: time until expiry */
				return array( isset( $t['remaining'] ) ? sprintf( __( 'Deleted in %s', 'fileora' ), fo_admin_duration( $t['remaining'] ) ) : __( 'Scheduled', 'fileora' ), 'good' );
			case 'due':
				return array( __( 'Expired: deleted at the next run', 'fileora' ), 'warning' );
			case 'kept':
				return array( __( 'Expired: kept (cleanup is off)', 'fileora' ), 'warning' );
			case 'failed':
				return array( __( 'Deletion failed: will retry', 'fileora' ), 'critical' );
		}
		return array( fo_admin_na(), 'unknown' );
	}

	/** Labels for history triggers. */
	public static function trigger_label( $trigger ) {
		$labels = array(
			'schedule'     => __( 'Schedule', 'fileora' ),
			'manual'       => __( 'Run now', 'fileora' ),
			'admin-delete' => __( 'Manual delete', 'fileora' ),
			'retry'        => __( 'Retry', 'fileora' ),
			'settings'     => __( 'Settings changed', 'fileora' ),
			'download'     => __( 'After download', 'fileora' ),
		);
		return isset( $labels[ $trigger ] ) ? $labels[ $trigger ] : (string) $trigger;
	}

	/**
	 * What switching cleanup off would keep, measured from the task records:
	 * results that were never downloaded (downloaded ones are deleted at once)
	 * over the last 7 days. Text results are delivered in the reply and deleted,
	 * so Summarize and Translate are left out.
	 *
	 * @return array{days:int, results:int, bytes:int, per_day:float|null}
	 */
	public static function impact() {
		global $wpdb;
		$table = Fileora_Task_Manager::table();
		$since = gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS n, COALESCE(SUM(bytes_out), 0) AS b FROM {$table} WHERE status = 'done' AND downloaded_at IS NULL AND tool NOT IN ('summarize', 'translate') AND created_at >= %s", $since ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$first = $wpdb->get_var( $wpdb->prepare( "SELECT MIN(created_at) FROM {$table} WHERE created_at >= %s", $since ) );
		$days  = $first ? max( 1, (int) ceil( ( time() - strtotime( $first . ' UTC' ) ) / DAY_IN_SECONDS ) ) : 0;
		return array(
			'days'    => min( 7, $days ),
			'results' => $row ? (int) $row->n : 0,
			'bytes'   => $row ? (int) $row->b : 0,
			'per_day' => $days ? ( $row ? (int) $row->b : 0 ) / min( 7, $days ) : null,
		);
	}

	// ------------------------------------------------------------ actions

	private static function guard( $nonce ) {
		if ( ! current_user_can( self::CAP_MANAGE ) ) {
			Fileora_Core_Log::audit( 'cleanup.denied', '', 'refused', array( 'nonce' => $nonce ) );
			wp_die( esc_html__( 'You are not allowed to change the cleanup.', 'fileora' ), 403 );
		}
		check_admin_referer( $nonce );
	}

	private static function done( $type, $text, array $args = array() ) {
		self::flush();
		set_transient( 'fileora_cleanup_notice_' . get_current_user_id(), array( $type, $text ), 120 );
		wp_safe_redirect( add_query_arg( array_merge( array( 'view' => 'temp' ), $args ), admin_url( 'admin.php?page=' . self::PAGE ) ) );
		exit;
	}

	/** The notice left by the last action of this user, once. */
	public static function take_notice() {
		$key = 'fileora_cleanup_notice_' . get_current_user_id();
		$n   = get_transient( $key );
		if ( $n ) {
			delete_transient( $key );
		}
		return is_array( $n ) ? $n : null;
	}

	/** Save settings: on/off, expiry, interval. */
	public static function handle_settings() {
		self::guard( 'fileora_cleanup_settings' );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked in guard()
		$ttl      = isset( $_POST['ttl_min'] ) ? absint( $_POST['ttl_min'] ) : 60;
		$interval = isset( $_POST['interval_min'] ) ? absint( $_POST['interval_min'] ) : 5;
		$enabled  = ! empty( $_POST['enabled'] );
		// phpcs:enable
		if ( ! in_array( $ttl, self::TTL_CHOICES, true ) || ! in_array( $interval, self::INTERVAL_CHOICES, true ) ) {
			Fileora_Core_Log::audit( 'cleanup.settings', '', 'refused', array( 'ttl_min' => $ttl, 'interval_min' => $interval ) );
			self::done( 'error', __( 'Choose an expiry and an interval from the lists.', 'fileora' ) );
		}
		$res = Fileora_Backend_API::admin(
			'PUT',
			'/admin/cleanup/settings',
			array(
				'enabled'      => $enabled,
				'ttl_min'      => $ttl,
				'interval_min' => $interval,
			)
		);
		if ( ! self::ok( $res ) ) {
			Fileora_Core_Log::audit( 'cleanup.settings', '', 'failed', array( 'error' => self::error_text( $res ) ) );
			self::done( 'error', self::error_text( $res ) );
		}
		Fileora_Core_Log::audit( 'cleanup.settings', '', 'ok', array( 'enabled' => $enabled ? 1 : 0, 'ttl_min' => $ttl, 'interval_min' => $interval ) );
		self::done( 'success', $enabled ? __( 'Cleanup settings saved on the processing server.', 'fileora' ) : __( 'Settings saved. Automatic cleanup is off: expired files are kept until you start it again or delete them.', 'fileora' ) );
	}

	/** Start or stop the schedule (the same switch as "Delete expired files automatically"). */
	public static function handle_toggle() {
		self::guard( 'fileora_cleanup_toggle' );
		$start = isset( $_POST['state'] ) && 'start' === $_POST['state']; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$res   = Fileora_Backend_API::admin( 'PUT', '/admin/cleanup/settings', array( 'enabled' => $start ) );
		if ( ! self::ok( $res ) ) {
			Fileora_Core_Log::audit( $start ? 'cleanup.start' : 'cleanup.stop', '', 'failed', array( 'error' => self::error_text( $res ) ) );
			self::done( 'error', self::error_text( $res ) );
		}
		Fileora_Core_Log::audit( $start ? 'cleanup.start' : 'cleanup.stop', '', 'ok' );
		self::done(
			'success',
			$start
				? __( 'Automatic cleanup started. The first run is one interval from now.', 'fileora' )
				: __( 'Automatic cleanup stopped. Nothing was deleted; running tasks and the rest of the service carry on.', 'fileora' )
		);
	}

	/** Run the cleanup once now (after the confirmation step). */
	public static function handle_run() {
		self::guard( 'fileora_cleanup_run' );
		$res = Fileora_Backend_API::admin( 'POST', '/admin/cleanup/run', null, 120 );
		if ( ! self::ok( $res ) ) {
			Fileora_Core_Log::audit( 'cleanup.run', '', 'failed', array( 'error' => self::error_text( $res ) ) );
			self::done( 'error', self::error_text( $res ) );
		}
		$b = $res['body'];
		if ( isset( $b['mode'] ) && 'blocked' === $b['mode'] ) {
			Fileora_Core_Log::audit( 'cleanup.run', '', 'refused', array( 'reason' => isset( $b['reason'] ) ? $b['reason'] : '' ) );
			self::done( 'error', sprintf( __( 'Nothing was deleted: %s', 'fileora' ), isset( $b['reason'] ) ? $b['reason'] : '' ) );
		}
		$deleted = isset( $b['deleted'] ) ? (int) $b['deleted'] : 0;
		$failed  = isset( $b['failed'] ) ? (int) $b['failed'] : 0;
		Fileora_Core_Log::audit(
			'cleanup.run',
			'',
			$failed ? 'failed' : 'ok',
			array(
				'deleted'        => $deleted,
				'failed'         => $failed,
				'freed'          => isset( $b['freed'] ) ? (int) $b['freed'] : 0,
				'skipped_active' => isset( $b['skipped_active'] ) ? (int) $b['skipped_active'] : 0,
			)
		);
		self::done(
			$failed ? 'warning' : 'success',
			sprintf(
				/* translators: 1: deleted, 2: size, 3: failed, 4: active */
				__( 'Cleanup done: %1$d expired task folders deleted (%2$s freed), %3$d failed, %4$d active tasks left alone.', 'fileora' ),
				$deleted,
				size_format( isset( $b['freed'] ) ? (int) $b['freed'] : 0 ),
				$failed,
				isset( $b['skipped_active'] ) ? (int) $b['skipped_active'] : 0
			)
		);
	}

	private static function posted_task() {
		$id = isset( $_POST['task'] ) ? sanitize_key( wp_unslash( $_POST['task'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		return preg_match( '/^[a-f0-9]{32}$/', $id ) ? $id : '';
	}

	/** Delete one finished task's temporary files (after the confirmation step). */
	public static function handle_delete() {
		$id = self::posted_task();
		self::guard( 'fileora_cleanup_delete_' . $id );
		if ( '' === $id || empty( $_POST['confirm'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			Fileora_Core_Log::audit( 'temp.delete', $id, 'refused', array( 'reason' => 'not confirmed' ) );
			self::done( 'error', __( 'Deletion needs a confirmation.', 'fileora' ) );
		}
		$res = Fileora_Backend_API::admin( 'DELETE', '/admin/temp/' . $id );
		if ( ! self::ok( $res ) ) {
			Fileora_Core_Log::audit( 'temp.delete', $id, ! is_wp_error( $res ) && 409 === (int) $res['status'] ? 'refused' : 'failed', array( 'error' => self::error_text( $res ) ) );
			self::done( 'error', self::error_text( $res ), array( 'task' => $id ) );
		}
		Fileora_Core_Log::audit( 'temp.delete', $id, 'ok', array( 'freed' => isset( $res['body']['freed'] ) ? (int) $res['body']['freed'] : 0 ) );
		self::done(
			'success',
			! empty( $res['body']['deleted'] )
				? sprintf( __( 'Temporary files of task %1$s deleted (%2$s). The task record stays in Task history.', 'fileora' ), substr( $id, 0, 8 ), size_format( isset( $res['body']['freed'] ) ? (int) $res['body']['freed'] : 0 ) )
				: __( 'There were no temporary files left for this task.', 'fileora' )
		);
	}

	/** Retry a failed deletion. */
	public static function handle_retry() {
		$id = self::posted_task();
		self::guard( 'fileora_cleanup_retry_' . $id );
		if ( '' === $id ) {
			self::done( 'error', __( 'Not a task id.', 'fileora' ) );
		}
		$res = Fileora_Backend_API::admin( 'POST', '/admin/temp/' . $id . '/retry' );
		if ( ! self::ok( $res ) ) {
			Fileora_Core_Log::audit( 'temp.retry', $id, 'failed', array( 'error' => self::error_text( $res ) ) );
			self::done( 'error', self::error_text( $res ) );
		}
		Fileora_Core_Log::audit( 'temp.retry', $id, 'ok', array( 'freed' => isset( $res['body']['freed'] ) ? (int) $res['body']['freed'] : 0 ) );
		self::done( 'success', sprintf( __( 'Retry done: the temporary files of task %s are gone.', 'fileora' ), substr( $id, 0, 8 ) ) );
	}
}
