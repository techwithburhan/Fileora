<?php
/**
 * Public functions for themes and other plugins.
 *
 * The Fileora theme checks function_exists( 'fileora_get_tools' ) and works
 * without them, so the theme never breaks when this plugin is off.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

/** True when Fileora Core is active. */
function fileora_core_active() {
	return true;
}

/**
 * Enabled tools in display order.
 *
 * @param array $args Optional: 'category' => term id, 'module' => module id, 'runs' => 'browser'|'server'.
 * @return array[]
 */
function fileora_get_tools( array $args = array() ) {
	$tools = Fileora_Tool_Registry::visible();
	if ( ! empty( $args['category'] ) ) {
		$tools = array_filter(
			$tools,
			function ( $t ) use ( $args ) {
				return $t['category'] && (int) $t['category']['id'] === (int) $args['category'];
			}
		);
	}
	if ( ! empty( $args['module'] ) ) {
		$tools = array_filter(
			$tools,
			function ( $t ) use ( $args ) {
				return $t['module'] === $args['module'];
			}
		);
	}
	if ( ! empty( $args['runs'] ) ) {
		$tools = array_filter(
			$tools,
			function ( $t ) use ( $args ) {
				return Fileora_Tool_Registry::runs_on( $t ) === $args['runs'];
			}
		);
	}
	return array_values( $tools );
}

/** Enabled tools grouped by category (each group: id, name, slug, desc, color, order, tools[]). */
function fileora_get_tool_groups() {
	return Fileora_Tool_Registry::grouped();
}

/**
 * One tool by id, slug, post or post id. Returns null when unknown.
 *
 * @param mixed $which Tool id ("merge"), slug ("merge-pdf"), WP_Post or post id.
 */
function fileora_get_tool( $which ) {
	if ( $which instanceof WP_Post || is_int( $which ) || ctype_digit( (string) $which ) ) {
		return Fileora_Tool_Registry::by_post( $which );
	}
	$which = (string) $which;
	$tool  = Fileora_Tool_Registry::get( $which );
	return $tool ? $tool : Fileora_Tool_Registry::by_slug( $which );
}

/** Where a tool runs right now: 'browser' or 'server'. */
function fileora_runs_on( array $tool ) {
	return Fileora_Tool_Registry::runs_on( $tool );
}

/** The interactive workspace for a tool (HTML). */
function fileora_render_workspace( $tool ) {
	return Fileora_Core_Frontend::render_workspace( $tool );
}

/** FAQ of a tool page as [ ['q' => ..., 'a' => ...], ... ]. */
function fileora_tool_faq( $post = null ) {
	$post = get_post( $post );
	return $post ? Fileora_Tool_Registry::parse_faq( get_post_meta( $post->ID, Fileora_Tool_Registry::META_FAQ, true ) ) : array();
}

/** Icon markup: <svg class="ic"><use href="#i-NAME"/></svg>. */
function fileora_icon( $name, $class = 'ic' ) {
	return Fileora_Icons::icon( $name, $class );
}

/** Light tool list for search boxes and menus (JSON-safe). */
function fileora_catalog_data() {
	return Fileora_Core_Frontend::catalog_data();
}

/** How soon server files are deleted, as shown to visitors (e.g. "within 1 hour"). */
function fileora_deletion_text() {
	return (string) Fileora_Core_Settings::value( 'deletion_text' );
}
