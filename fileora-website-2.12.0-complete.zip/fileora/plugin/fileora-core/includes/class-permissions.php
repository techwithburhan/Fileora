<?php
/**
 * Capabilities and the Blog Editor role.
 *
 * The code checks capabilities, never role names:
 *   fileora_manage_tools     Tool Management, tool pages and tool categories
 *   fileora_manage_settings  Processing server, limits, retention, roles
 *   fileora_view_reports     Dashboard, Visitor Analytics, Server Monitoring, Processing Tasks
 *   fileora_view_ip          see visitors' IP addresses in Visitor Analytics and activity logs
 *   fileora_manage_announcements  create and edit popup announcements
 *
 * The "Support" role (fileora_support) can open the reports and activity logs
 * and edit its own profile, nothing else. Whether it sees IP addresses is a
 * setting.
 *
 * Administrators get all three. The "Blog Editor" role can write blog posts
 * (and, if allowed in Settings, publish, delete and read reports) but cannot
 * touch tools, settings, plugins, themes or users.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Permissions {

	const ROLE = 'fileora_blog_editor';

	const SUPPORT_ROLE = 'fileora_support';

	const CAPS = array( 'fileora_manage_tools', 'fileora_manage_settings', 'fileora_view_reports', 'fileora_view_ip', 'fileora_manage_announcements', 'fileora_export_data' );

	public static function init() {
		add_action( 'update_option_' . Fileora_Core_Settings::OPTION, array( __CLASS__, 'sync_role' ) );
		add_filter( 'editable_roles', array( __CLASS__, 'editable_roles' ) );
	}

	/** Gives administrators the Fileora capabilities and creates or updates the Blog Editor role. */
	public static function install() {
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( self::CAPS as $cap ) {
				$admin->add_cap( $cap );
			}
		}
		self::sync_role();
	}

	/** The Blog Editor role's capabilities, based on the settings. */
	public static function editor_caps() {
		$s    = Fileora_Core_Settings::get();
		$caps = array(
			'read'                 => true,
			'upload_files'         => true,
			'edit_posts'           => true,
			'manage_categories'    => true,
			'edit_published_posts' => (bool) $s['editor_publish'],
			'publish_posts'        => (bool) $s['editor_publish'],
			'edit_others_posts'    => (bool) $s['editor_others'],
			'delete_posts'         => (bool) $s['editor_delete'],
			'delete_published_posts' => $s['editor_delete'] && $s['editor_publish'],
			'delete_others_posts'  => $s['editor_delete'] && $s['editor_others'],
			'edit_private_posts'   => (bool) $s['editor_others'],
			'read_private_posts'   => (bool) $s['editor_others'],
			'fileora_view_reports' => (bool) $s['editor_reports'],
		);
		return array_filter( $caps );
	}

	public static function sync_role() {
		Fileora_Core_Settings::flush_cache();
		remove_role( self::ROLE );
		add_role( self::ROLE, __( 'Blog Editor', 'fileora' ), self::editor_caps() );
		remove_role( self::SUPPORT_ROLE );
		add_role( self::SUPPORT_ROLE, __( 'Support', 'fileora' ), self::support_caps() );
	}

	/** Support: reports and activity logs, own profile; IP addresses only when allowed in Settings. */
	public static function support_caps() {
		$s = Fileora_Core_Settings::get();
		return array_filter(
			array(
				'read'                 => true,
				'fileora_view_reports' => true,
				'fileora_view_ip'      => (bool) $s['support_ip'],
			)
		);
	}

	/** Only administrators may hand out the Blog Editor role. */
	public static function editable_roles( $roles ) {
		foreach ( array( self::ROLE, self::SUPPORT_ROLE ) as $r ) {
			if ( isset( $roles[ $r ] ) && ! current_user_can( 'promote_users' ) ) {
				unset( $roles[ $r ] );
			}
		}
		return $roles;
	}

	public static function uninstall() {
		remove_role( self::ROLE );
		remove_role( self::SUPPORT_ROLE );
		foreach ( wp_roles()->role_objects as $role ) {
			foreach ( self::CAPS as $cap ) {
				$role->remove_cap( $cap );
			}
		}
	}
}
