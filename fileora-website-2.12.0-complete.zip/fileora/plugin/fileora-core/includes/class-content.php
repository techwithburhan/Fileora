<?php
/**
 * Shortcodes that keep the Privacy Policy, Security, FAQ and Sitemap pages
 * true to how the site actually works, plus a review reminder.
 *
 *   [fileora_data_flow]            table: every tool, where files are processed, whether they leave the device, what is kept
 *   [fileora_data_flow view="counts"]  one sentence with the numbers
 *   [fileora_privacy_facts]        what Visitor Analytics records with the current settings
 *   [fileora_privacy field="…"]    one value: email, host_web, host_server, deletion, event_days, task_days, ip_days, ip_mode, geo
 *   [fileora_sitemap]              HTML sitemap: pages, tools by category, blog posts
 *   [fileora_last_updated]         the page's last-modified date
 *
 * The text around the shortcodes is normal page content, editable in the
 * editor. When the facts behind these shortcodes change (a tool moves to the
 * server, analytics settings change…), administrators see a reminder to
 * review the pages, and can mark them as reviewed.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Content {

	const REVIEW = 'fileora_policy_review';

	public static function init() {
		add_shortcode( 'fileora_data_flow', array( __CLASS__, 'data_flow' ) );
		add_shortcode( 'fileora_privacy_facts', array( __CLASS__, 'privacy_facts' ) );
		add_shortcode( 'fileora_privacy', array( __CLASS__, 'privacy_field' ) );
		add_shortcode( 'fileora_sitemap', array( __CLASS__, 'sitemap' ) );
		add_shortcode( 'fileora_last_updated', array( __CLASS__, 'last_updated' ) );
		add_action( 'admin_notices', array( __CLASS__, 'review_notice' ) );
		add_action( 'admin_post_fileora_policy_reviewed', array( __CLASS__, 'mark_reviewed' ) );
	}

	/** Where a tool processes files right now: device | server | server_ai. */
	public static function flow( array $t ) {
		$runs = Fileora_Tool_Registry::runs_on( $t );
		if ( 'browser' === $runs ) {
			return 'device';
		}
		return 'ai' === $t['module'] ? 'server_ai' : 'server';
	}

	/** The tools a visitor can use, with their data flow. */
	private static function rows() {
		$rows = array();
		foreach ( Fileora_Tool_Registry::visible() as $t ) {
			if ( 'ready' !== $t['status'] ) {
				continue;
			}
			$rows[] = array( 'tool' => $t, 'flow' => self::flow( $t ) );
		}
		return $rows;
	}

	public static function data_flow( $atts ) {
		$atts = shortcode_atts( array( 'view' => 'table' ), $atts, 'fileora_data_flow' );
		$rows = self::rows();
		$n    = array( 'device' => 0, 'server' => 0, 'server_ai' => 0 );
		foreach ( $rows as $r ) {
			++$n[ $r['flow'] ];
		}
		$del = esc_html( (string) Fileora_Core_Settings::value( 'deletion_text' ) );
		if ( 'counts' === $atts['view'] ) {
			/* translators: 1: total tools, 2: tools on device, 3: tools on server */
			$s = sprintf( esc_html__( 'Of the %1$d tools on this site, %2$d process files only on your device and %3$d use our processing server.', 'fileora' ), count( $rows ), $n['device'], $n['server'] + $n['server_ai'] );
			if ( $n['server_ai'] ) {
				/* translators: %d: number of AI tools */
				$s .= ' ' . sprintf( esc_html__( '%d of the server tools also send the document text to an AI provider (see below).', 'fileora' ), $n['server_ai'] );
			}
			return '<span class="fo-flow-counts">' . $s . '</span>';
		}
		$label = array(
			'device'    => array( __( 'On your device', 'fileora' ), __( 'No', 'fileora' ), __( 'Nothing: the file never reaches us.', 'fileora' ) ),
			'server'    => array( __( 'Our processing server', 'fileora' ), __( 'Yes, encrypted (HTTPS), to our server only', 'fileora' ), sprintf( /* translators: %s: e.g. "within 1 hour" */ __( 'Upload and result deleted after download, or automatically %s.', 'fileora' ), $del ) ),
			'server_ai' => array( __( 'Our processing server + Anthropic (Claude API)', 'fileora' ), __( 'Yes, to our server, which sends the document text to Anthropic', 'fileora' ), sprintf( /* translators: %s: e.g. "within 1 hour" */ __( 'Deleted from our server %s; Anthropic handles the text under its API terms.', 'fileora' ), $del ) ),
		);
		$groups = array();
		foreach ( $rows as $r ) {
			$cat                          = $r['tool']['category'] ? $r['tool']['category']['name'] : __( 'Other', 'fileora' );
			$groups[ $r['flow'] ][ $cat ][] = $r['tool'];
		}
		$html = '<div class="fo-flow"><figure class="wp-block-table"><table><thead><tr><th>' . esc_html__( 'Tools', 'fileora' ) . '</th><th>' . esc_html__( 'Where the file is processed', 'fileora' ) . '</th><th>' . esc_html__( 'Does the file leave your device?', 'fileora' ) . '</th><th>' . esc_html__( 'What we keep', 'fileora' ) . '</th></tr></thead><tbody>';
		foreach ( array( 'device', 'server', 'server_ai' ) as $flow ) {
			if ( empty( $groups[ $flow ] ) ) {
				continue;
			}
			$list = array();
			foreach ( $groups[ $flow ] as $cat => $tools ) {
				$names  = array_map(
					function ( $t ) {
						return '<a href="' . esc_url( $t['url'] ) . '">' . esc_html( $t['name'] ) . '</a>';
					},
					$tools
				);
				$list[] = '<strong>' . esc_html( $cat ) . ':</strong> ' . implode( ', ', $names );
			}
			$html .= '<tr><td>' . implode( '<br>', $list ) . '</td><td>' . esc_html( $label[ $flow ][0] ) . '</td><td>' . esc_html( $label[ $flow ][1] ) . '</td><td>' . esc_html( $label[ $flow ][2] ) . '</td></tr>';
		}
		$html .= '</tbody></table></figure>';
		/* translators: %s: date */
		$html .= '<p class="fo-flow-note"><small>' . esc_html( sprintf( __( 'This table is generated from the site’s current tool settings (%s).', 'fileora' ), wp_date( get_option( 'date_format' ) ) ) ) . '</small></p></div>';
		return $html;
	}

	public static function privacy_facts() {
		$s     = Fileora_Core_Settings::get();
		$items = array();
		if ( empty( $s['analytics'] ) ) {
			return '<p>' . esc_html__( 'Visitor analytics are currently switched off: we do not record visits or tool use.', 'fileora' ) . '</p>';
		}
		$items[] = __( 'A random visitor ID stored in your browser’s local storage, and a visit ID in session storage (a visit ends after 30 minutes without activity). We do not use analytics cookies.', 'fileora' );
		$items[] = __( 'The date and time of each page view and tool use, which page or tool, and a short “still here” signal once a minute while the page is open, to count active visitors.', 'fileora' );
		$items[] = __( 'The first page of a visit and the website that sent you there (address without its query string).', 'fileora' );
		$items[] = __( 'Device type (phone, tablet, computer), browser and operating system, read from your browser’s user agent.', 'fileora' );
		$geo     = 'off' === $s['geo_source'] ? '' : __( 'Your approximate location (country, region, city), worked out on our own server from your IP address with an IP location database, or the country reported by our content delivery network where one is used. No third-party location service is contacted.', 'fileora' );
		if ( $geo ) {
			$items[] = $geo;
		}
		if ( 'full' === $s['ip_mode'] ) {
			/* translators: %d: days */
			$items[] = sprintf( __( 'Your IP address, visible only to authorised staff and erased after %d days.', 'fileora' ), (int) $s['ip_retention'] );
		} elseif ( 'anon' === $s['ip_mode'] ) {
			/* translators: %d: days */
			$items[] = sprintf( __( 'A shortened IP address (the last part removed, so it no longer identifies a single connection), erased after %d days.', 'fileora' ), (int) $s['ip_retention'] );
		}
		$items[] = ! empty( $s['record_file_names'] ) ? __( 'For each tool use: the tool, the number of files, the name of the first file, how long it took and whether it worked. Never the contents of your files.', 'fileora' ) : __( 'For each tool use: the tool, the number of files, how long it took and whether it worked. Never file names or file contents.', 'fileora' );
		$extra = array();
		if ( ! empty( $s['respect_dnt'] ) ) {
			$extra[] = __( 'If your browser sends “Do Not Track” or “Global Privacy Control”, nothing is recorded.', 'fileora' );
		}
		$extra[] = __( 'Search engine crawlers and other bots are not recorded.', 'fileora' );
		/* translators: 1: "180 days" or "no automatic deletion", 2: same for task records */
		$extra[] = sprintf( __( 'Detailed visit and tool-use records are kept: %1$s. Processing task records: %2$s.', 'fileora' ), self::keep_text( $s['event_retention'] ), self::keep_text( $s['task_retention'] ) );
		$extra[] = __( 'After that only daily totals remain (counts per day and per tool, with no visitor IDs, locations or IP addresses).', 'fileora' );
		$html    = '<ul class="fo-facts">';
		foreach ( $items as $i ) {
			$html .= '<li>' . esc_html( $i ) . '</li>';
		}
		$html .= '</ul><p>' . esc_html( implode( ' ', $extra ) ) . '</p>';
		$db    = 'off' === $s['geo_source'] ? null : Fileora_Geo::db_info();
		if ( $db && $db['dbip'] ) {
			$html .= '<p><small><a href="https://db-ip.com" target="_blank" rel="noopener">' . esc_html__( 'IP Geolocation by DB-IP', 'fileora' ) . '</a> (CC BY 4.0).</small></p>';
		}
		return $html;
	}

	/** "180 days", or a note that nothing is deleted automatically. */
	public static function keep_text( $days ) {
		$days = (int) $days;
		/* translators: %d: number of days */
		return $days > 0 ? sprintf( _n( '%d day', '%d days', $days, 'fileora' ), $days ) : __( 'until the site owner deletes them (no automatic deletion)', 'fileora' );
	}

	public static function privacy_field( $atts ) {
		$atts = shortcode_atts( array( 'field' => '' ), $atts, 'fileora_privacy' );
		$s    = Fileora_Core_Settings::get();
		switch ( $atts['field'] ) {
			case 'email':
				$m = $s['privacy_email'] ? $s['privacy_email'] : get_option( 'admin_email' );
				return '<a href="mailto:' . esc_attr( antispambot( $m ) ) . '">' . esc_html( antispambot( $m ) ) . '</a>';
			case 'host_web':
				return esc_html( $s['host_web'] ? $s['host_web'] : __( 'our web hosting provider', 'fileora' ) );
			case 'host_server':
				return esc_html( $s['host_server'] ? $s['host_server'] : __( 'a cloud server provider', 'fileora' ) );
			case 'deletion':
				return esc_html( (string) $s['deletion_text'] );
			case 'event_days':
				return esc_html( (int) $s['event_retention'] ? (string) (int) $s['event_retention'] : __( 'an unlimited number of', 'fileora' ) );
			case 'task_days':
				return esc_html( (int) $s['task_retention'] ? (string) (int) $s['task_retention'] : __( 'an unlimited number of', 'fileora' ) );
			case 'event_keep':
				return esc_html( self::keep_text( $s['event_retention'] ) );
			case 'task_keep':
				return esc_html( self::keep_text( $s['task_retention'] ) );
			case 'message_keep':
				return esc_html( self::keep_text( $s['message_retention'] ) );
			case 'ip_days':
				return esc_html( (string) (int) $s['ip_retention'] );
			case 'max_mb':
				return esc_html( (string) Fileora_Core_Settings::max_mb() );
			case 'site':
				return esc_html( get_bloginfo( 'name' ) );
		}
		return '';
	}

	public static function last_updated() {
		$post = get_post();
		return $post ? esc_html( wp_date( get_option( 'date_format' ), strtotime( $post->post_modified_gmt . ' UTC' ) ) ) : '';
	}

	/** HTML sitemap. */
	public static function sitemap() {
		$html  = '<div class="fo-sitemap">';
		$front = (int) get_option( 'page_on_front' );
		$pages = get_pages( array( 'sort_column' => 'menu_order,post_title', 'post_status' => 'publish' ) );
		$html .= '<section><h2>' . esc_html__( 'Pages', 'fileora' ) . '</h2><ul><li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'fileora' ) . '</a></li>';
		foreach ( $pages as $p ) {
			if ( $p->ID === $front || post_password_required( $p ) || get_post_meta( $p->ID, '_fileora_noindex', true ) ) {
				continue;
			}
			$html .= '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></li>';
		}
		$html .= '</ul></section>';
		foreach ( Fileora_Tool_Registry::grouped() as $g ) {
			$html .= '<section><h2>' . esc_html( $g['name'] ) . '</h2><ul>';
			foreach ( $g['tools'] as $t ) {
				if ( 'ready' !== $t['status'] ) {
					continue;
				}
				$html .= '<li><a href="' . esc_url( $t['url'] ) . '">' . esc_html( $t['name'] ) . '</a></li>';
			}
			$html .= '</ul></section>';
		}
		$posts = get_posts( array( 'numberposts' => 100, 'post_status' => 'publish' ) );
		if ( $posts ) {
			$html .= '<section><h2>' . esc_html__( 'Blog', 'fileora' ) . '</h2><ul>';
			foreach ( $posts as $p ) {
				$html .= '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></li>';
			}
			$html .= '</ul></section>';
		}
		$html .= '</div>';
		if ( function_exists( 'wp_sitemaps_get_server' ) && wp_sitemaps_get_server()->sitemaps_enabled() ) {
			/* translators: %s: link */
			$html .= '<p class="fo-sitemap-xml"><small>' . sprintf( esc_html__( 'For search engines: %s', 'fileora' ), '<a href="' . esc_url( home_url( '/wp-sitemap.xml' ) ) . '">' . esc_html__( 'XML sitemap', 'fileora' ) . '</a>' ) . '</small></p>';
		}
		return $html;
	}

	/* ------------------------------------------------------------------
	 * Review reminder.
	 * ---------------------------------------------------------------- */

	/** A fingerprint of the facts the policy pages describe. */
	public static function signature() {
		$s     = Fileora_Core_Settings::get();
		$facts = array(
			'flows' => array_map(
				function ( $r ) {
					return $r['tool']['id'] . ':' . $r['flow'];
				},
				self::rows()
			),
			'settings' => array_intersect_key( $s, array_flip( array( 'analytics', 'respect_dnt', 'ip_mode', 'ip_retention', 'record_file_names', 'geo_source', 'event_retention', 'task_retention', 'deletion_text', 'host_web', 'host_server', 'privacy_email', 'message_retention' ) ) ),
		);
		return md5( wp_json_encode( $facts ) );
	}

	/** Pages that use the policy shortcodes. */
	public static function policy_pages() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' AND (post_content LIKE '%[fileora_data_flow%' OR post_content LIKE '%[fileora_privacy%')" );
	}

	public static function review_notice() {
		if ( ! current_user_can( 'fileora_manage_settings' ) ) {
			return;
		}
		$pages = self::policy_pages();
		if ( ! $pages ) {
			return;
		}
		$r = get_option( self::REVIEW );
		if ( ! is_array( $r ) ) {
			update_option( self::REVIEW, array( 'sig' => self::signature(), 'time' => time(), 'user' => get_current_user_id() ), false );
			return;
		}
		if ( $r['sig'] === self::signature() ) {
			return;
		}
		$links = array();
		foreach ( $pages as $id ) {
			$links[] = '<a href="' . esc_url( get_edit_post_link( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a>';
		}
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=fileora_policy_reviewed' ), 'fileora_policy_reviewed' );
		echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'Please review your Privacy and Security pages.', 'fileora' ) . '</strong> ';
		/* translators: %s: date */
		echo esc_html( sprintf( __( 'Since they were last reviewed (%s), how tools process files or what analytics record has changed. The tables on those pages update themselves; check that the text around them is still right:', 'fileora' ), wp_date( get_option( 'date_format' ), (int) $r['time'] ) ) ) . ' ' . implode( ', ', $links ) . '. '; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<a class="button button-small" href="' . esc_url( $url ) . '">' . esc_html__( 'Mark as reviewed', 'fileora' ) . '</a></p></div>';
	}

	public static function mark_reviewed() {
		if ( ! current_user_can( 'fileora_manage_settings' ) ) {
			wp_die( '', 403 );
		}
		check_admin_referer( 'fileora_policy_reviewed' );
		update_option( self::REVIEW, array( 'sig' => self::signature(), 'time' => time(), 'user' => get_current_user_id() ), false );
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url() );
		exit;
	}
}
