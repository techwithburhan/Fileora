<?php
/**
 * Analytics history: daily summaries, time series and CSV export.
 *
 * Detailed records (one row per event, visit and server task) stay in their
 * own tables for as long as Settings → Data retention allows (at least 90
 * days, or forever). Daily totals are saved in two small tables so that
 * long ranges load quickly and the history survives the removal of old
 * detailed records:
 *
 *   {prefix}fileora_daily        one row per day (site time zone)
 *   {prefix}fileora_daily_tools  one row per day and tool
 *
 * Totals for a day are (re)calculated from the detailed records every hour
 * for today and the two days before, and once for every older day that has
 * detailed records but no totals yet. A day whose detailed records were
 * removed is never recalculated, so its totals are never overwritten with
 * zeros. Summaries hold counts only: no visitor ids, IP addresses or
 * locations.
 *
 * Definitions (the same everywhere on the dashboard):
 *   visits           visits (sessions) with activity in the period
 *   unique visitors  distinct visitor ids among those visits
 *   page views       page_view events
 *   tool runs        browser tool runs + server tasks started in the period
 *   files processed  files in successful runs
 *   failed           failed browser runs + failed server tasks
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_History {

	const DB_VERSION = '1';
	const THROUGH    = 'fileora_rollup_through';
	const EXPORT_LOG = 'fileora_export_log';

	/** Maximum number of buckets in one time series. */
	const MAX_BUCKETS = 2200;

	const STEPS = array(
		'minute' => 60,
		'hour'   => 3600,
		'day'    => 86400,
	);

	public static function init() {
		add_action( 'admin_post_fileora_export_analytics', array( __CLASS__, 'export' ) );
	}

	public static function daily_table() {
		global $wpdb;
		return $wpdb->prefix . 'fileora_daily';
	}

	public static function tools_table() {
		global $wpdb;
		return $wpdb->prefix . 'fileora_daily_tools';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$d       = self::daily_table();
		$t       = self::tools_table();
		$collate = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$d} (
			day date NOT NULL,
			visits int(10) unsigned NOT NULL DEFAULT 0,
			visitors int(10) unsigned NOT NULL DEFAULT 0,
			new_visitors int(10) unsigned NOT NULL DEFAULT 0,
			page_views int(10) unsigned NOT NULL DEFAULT 0,
			tool_views int(10) unsigned NOT NULL DEFAULT 0,
			browser_runs int(10) unsigned NOT NULL DEFAULT 0,
			server_runs int(10) unsigned NOT NULL DEFAULT 0,
			failed int(10) unsigned NOT NULL DEFAULT 0,
			files int(10) unsigned NOT NULL DEFAULT 0,
			countries smallint(5) unsigned NOT NULL DEFAULT 0,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (day)
			) {$collate};"
		);
		dbDelta(
			"CREATE TABLE {$t} (
			day date NOT NULL,
			tool varchar(20) NOT NULL,
			views int(10) unsigned NOT NULL DEFAULT 0,
			browser_runs int(10) unsigned NOT NULL DEFAULT 0,
			server_runs int(10) unsigned NOT NULL DEFAULT 0,
			failed int(10) unsigned NOT NULL DEFAULT 0,
			files int(10) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (day, tool),
			KEY tool_day (tool, day)
			) {$collate};"
		);
		update_option( 'fileora_history_db_version', self::DB_VERSION, false );
	}

	/* ------------------------------------------------------------------
	 * Time helpers (site time zone).
	 * ---------------------------------------------------------------- */

	public static function offset() {
		return (int) round( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
	}

	public static function utc( $ts ) {
		return gmdate( 'Y-m-d H:i:s', (int) $ts );
	}

	/** Local "Y-m-d" of a timestamp. */
	public static function local_date( $ts ) {
		return gmdate( 'Y-m-d', (int) $ts + self::offset() );
	}

	/** Timestamp of the start of a local day. */
	public static function day_start( $date ) {
		return strtotime( $date . ' 00:00:00 UTC' ) - self::offset();
	}

	/** Oldest detailed record still stored (timestamp), or 0. */
	public static function oldest() {
		$o = null;
		if ( null === $o ) {
			global $wpdb;
			$e = Fileora_Analytics::table();
			$t = Fileora_Task_Manager::table();
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$a = $wpdb->get_var( "SELECT MIN(created_at) FROM {$e}" );
			$b = $wpdb->get_var( "SELECT MIN(created_at) FROM {$t}" );
			// phpcs:enable
			$x = array_filter( array( $a ? strtotime( $a . ' UTC' ) : 0, $b ? strtotime( $b . ' UTC' ) : 0 ) );
			$o = $x ? min( $x ) : 0;
		}
		return $o;
	}

	/** Start of the oldest local day whose detailed records are complete. */
	public static function detail_from() {
		$days = (int) Fileora_Core_Settings::value( 'event_retention' );
		$old  = self::oldest();
		if ( ! $old ) {
			return self::day_start( self::local_date( time() ) );
		}
		$from = self::day_start( self::local_date( $old ) ); // the day recording started is complete
		if ( $days > 0 ) {
			// The daily purge removes records older than $days, so that day is only partly kept.
			$cut  = time() - $days * DAY_IN_SECONDS;
			$cday = self::day_start( self::local_date( $cut ) );
			if ( $cday >= $from ) {
				$from = $cday + DAY_IN_SECONDS;
			}
		}
		return $from;
	}

	/* ------------------------------------------------------------------
	 * Daily totals.
	 * ---------------------------------------------------------------- */

	/** Totals for one local day, calculated from the detailed records. */
	public static function compute_day( $date ) {
		global $wpdb;
		$e     = Fileora_Analytics::table();
		$s     = Fileora_Analytics::sessions_table();
		$t     = Fileora_Task_Manager::table();
		$start = self::utc( self::day_start( $date ) );
		$end   = self::utc( self::day_start( $date ) + DAY_IN_SECONDS );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ss = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS visits, COUNT(DISTINCT visitor) AS visitors, SUM(is_new = 1 AND first_seen >= %s) AS new_visitors, COUNT(DISTINCT NULLIF(country, '')) AS countries FROM {$s} WHERE last_seen >= %s AND first_seen < %s", $start, $start, $end ) );
		$ev = $wpdb->get_row( $wpdb->prepare( "SELECT SUM(type = 'page_view') AS views, SUM(type = 'tool_view') AS tool_views, SUM(type = 'tool_run' AND exec = 'browser') AS runs, SUM(type = 'tool_run' AND exec = 'browser' AND status = 'failed') AS failed, SUM(IF(type = 'tool_run' AND exec = 'browser' AND status = 'done', files, 0)) AS files FROM {$e} WHERE created_at >= %s AND created_at < %s", $start, $end ) );
		$tk = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS runs, SUM(status = 'failed') AS failed, SUM(IF(status = 'done', files, 0)) AS files FROM {$t} WHERE created_at >= %s AND created_at < %s", $start, $end ) );
		$te = $wpdb->get_results( $wpdb->prepare( "SELECT tool, SUM(type = 'tool_view') AS views, SUM(type = 'tool_run' AND exec = 'browser') AS runs, SUM(type = 'tool_run' AND exec = 'browser' AND status = 'failed') AS failed, SUM(IF(type = 'tool_run' AND exec = 'browser' AND status = 'done', files, 0)) AS files FROM {$e} WHERE created_at >= %s AND created_at < %s AND tool <> '' AND type IN ('tool_view', 'tool_run') GROUP BY tool", $start, $end ) );
		$tt = $wpdb->get_results( $wpdb->prepare( "SELECT tool, COUNT(*) AS runs, SUM(status = 'failed') AS failed, SUM(IF(status = 'done', files, 0)) AS files FROM {$t} WHERE created_at >= %s AND created_at < %s GROUP BY tool", $start, $end ) );
		// phpcs:enable
		$tools = array();
		foreach ( $te as $r ) {
			$tools[ $r->tool ] = array( 'views' => (int) $r->views, 'browser_runs' => (int) $r->runs, 'server_runs' => 0, 'failed' => (int) $r->failed, 'files' => (int) $r->files );
		}
		foreach ( $tt as $r ) {
			if ( ! isset( $tools[ $r->tool ] ) ) {
				$tools[ $r->tool ] = array( 'views' => 0, 'browser_runs' => 0, 'server_runs' => 0, 'failed' => 0, 'files' => 0 );
			}
			$tools[ $r->tool ]['server_runs'] = (int) $r->runs;
			$tools[ $r->tool ]['failed']     += (int) $r->failed;
			$tools[ $r->tool ]['files']      += (int) $r->files;
		}
		return array(
			'day'          => $date,
			'visits'       => (int) $ss->visits,
			'visitors'     => (int) $ss->visitors,
			'new_visitors' => (int) $ss->new_visitors,
			'page_views'   => (int) $ev->views,
			'tool_views'   => (int) $ev->tool_views,
			'browser_runs' => (int) $ev->runs,
			'server_runs'  => (int) $tk->runs,
			'failed'       => (int) $ev->failed + (int) $tk->failed,
			'files'        => (int) $ev->files + (int) $tk->files,
			'countries'    => (int) $ss->countries,
			'tools'        => $tools,
		);
	}

	private static function store_day( array $row ) {
		global $wpdb;
		$d     = self::daily_table();
		$t     = self::tools_table();
		$tools = $row['tools'];
		unset( $row['tools'] );
		$row['updated_at'] = self::utc( time() );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( false === $wpdb->replace( $d, $row ) ) {
			Fileora_Analytics::db_error( 'daily totals', $wpdb->last_error );
			return false;
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE day = %s", $row['day'] ) );
		foreach ( $tools as $tool => $v ) {
			$wpdb->insert( $t, array_merge( array( 'day' => $row['day'], 'tool' => substr( (string) $tool, 0, 20 ) ), $v ) );
		}
		// phpcs:enable
		return true;
	}

	/**
	 * Saves daily totals: today and the 2 days before always, older days
	 * once. Runs every hour and before old records are removed.
	 */
	public static function rollup( $max_days = 120 ) {
		global $wpdb;
		$today = self::local_date( time() );
		$from  = self::local_date( self::detail_from() );
		$d     = self::daily_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$have  = array_flip( (array) $wpdb->get_col( $wpdb->prepare( "SELECT day FROM {$d} WHERE day >= %s", $from ) ) );
		$fresh = gmdate( 'Y-m-d', strtotime( $today . ' UTC' ) - 2 * DAY_IN_SECONDS );
		$done  = 0;
		for ( $ts = strtotime( $from . ' UTC' ); $ts <= strtotime( $today . ' UTC' ) && $done < $max_days; $ts += DAY_IN_SECONDS ) {
			$day = gmdate( 'Y-m-d', $ts );
			if ( $day < $fresh && isset( $have[ $day ] ) ) {
				continue;
			}
			self::store_day( self::compute_day( $day ) );
			++$done;
		}
		update_option( self::THROUGH, $today, false );
		return $done;
	}

	/**
	 * One row per local day from $first to $last (inclusive): saved totals
	 * where they exist, otherwise calculated from the detailed records.
	 * 'source' is "summary", "detail" or "none" (no records left).
	 */
	public static function days( $first, $last ) {
		global $wpdb;
		$d     = self::daily_table();
		$today = self::local_date( time() );
		$from  = self::local_date( self::detail_from() );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$saved = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$d} WHERE day BETWEEN %s AND %s", $first, $last ), OBJECT_K );
		$out   = array();
		$live  = 0;
		for ( $ts = strtotime( $first . ' UTC' ); $ts <= strtotime( min( $last, $today ) . ' UTC' ); $ts += DAY_IN_SECONDS ) {
			$day = gmdate( 'Y-m-d', $ts );
			if ( $day !== $today && isset( $saved[ $day ] ) ) {
				$r          = (array) $saved[ $day ];
				$row        = array_map( 'intval', array_intersect_key( $r, array_flip( array( 'visits', 'visitors', 'new_visitors', 'page_views', 'tool_views', 'browser_runs', 'server_runs', 'failed', 'files', 'countries' ) ) ) );
				$row['day'] = $day;
				$row['source'] = 'summary';
			} elseif ( $day >= $from && $live < 400 ) {
				$row = self::compute_day( $day );
				unset( $row['tools'] );
				$row['source'] = 'detail';
				++$live;
			} else {
				$row = array( 'day' => $day, 'visits' => 0, 'visitors' => 0, 'new_visitors' => 0, 'page_views' => 0, 'tool_views' => 0, 'browser_runs' => 0, 'server_runs' => 0, 'failed' => 0, 'files' => 0, 'countries' => 0, 'source' => 'none' );
			}
			$row['tool_runs'] = $row['browser_runs'] + $row['server_runs'];
			$out[]            = $row;
		}
		return $out;
	}

	/* ------------------------------------------------------------------
	 * Time series: per minute, hour or day.
	 * ---------------------------------------------------------------- */

	/** Which intervals make sense for a window, and the default. */
	public static function intervals( $start, $end ) {
		$span = $end - $start;
		$ok   = array();
		foreach ( self::STEPS as $k => $step ) {
			if ( $span / $step <= self::MAX_BUCKETS && ( 'day' !== $k || $span >= DAY_IN_SECONDS ) ) {
				$ok[] = $k;
			}
		}
		if ( ! $ok ) {
			$ok = array( 'day' );
		}
		if ( $span <= 3 * HOUR_IN_SECONDS ) {
			$def = 'minute';
		} elseif ( $span <= 8 * DAY_IN_SECONDS ) {
			$def = 'hour';
		} else {
			$def = 'day';
		}
		return array( 'allowed' => $ok, 'default' => in_array( $def, $ok, true ) ? $def : $ok[0] );
	}

	/**
	 * Visits, unique visitors, page views, tool runs, files and the busiest
	 * locations per bucket, for the window [$start, $end).
	 */
	public static function series( $start, $end, $interval ) {
		$iv = self::intervals( $start, $end );
		if ( ! in_array( $interval, $iv['allowed'], true ) ) {
			$interval = $iv['default'];
		}
		if ( 'day' === $interval ) {
			return self::series_days( $start, $end, $iv );
		}
		global $wpdb;
		$e    = Fileora_Analytics::table();
		$t    = Fileora_Task_Manager::table();
		$step = self::STEPS[ $interval ];
		$off  = self::offset();
		$a    = (int) ( floor( ( $start + $off ) / $step ) * $step - $off ); // bucket boundaries in local time
		$n    = (int) ceil( ( $end - $a ) / $step );
		$s0   = self::utc( $a );
		$s1   = self::utc( $end );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ev  = $wpdb->get_results( $wpdb->prepare( "SELECT TIMESTAMPDIFF(SECOND, %s, created_at) DIV %d AS b, COUNT(DISTINCT sid) AS visits, COUNT(DISTINCT visitor) AS visitors, SUM(type = 'page_view') AS views, SUM(type = 'tool_run' AND exec = 'browser') AS runs, SUM(type = 'tool_run' AND exec = 'browser' AND status = 'failed') AS failed, SUM(IF(type = 'tool_run' AND exec = 'browser' AND status = 'done', files, 0)) AS files FROM {$e} WHERE created_at >= %s AND created_at < %s GROUP BY b", $s0, $step, $s0, $s1 ), OBJECT_K );
		$tk  = $wpdb->get_results( $wpdb->prepare( "SELECT TIMESTAMPDIFF(SECOND, %s, created_at) DIV %d AS b, COUNT(*) AS runs, SUM(status = 'failed') AS failed, SUM(IF(status = 'done', files, 0)) AS files FROM {$t} WHERE created_at >= %s AND created_at < %s GROUP BY b", $s0, $step, $s0, $s1 ), OBJECT_K );
		$loc = $wpdb->get_results( $wpdb->prepare( "SELECT TIMESTAMPDIFF(SECOND, %s, created_at) DIV %d AS b, country, region, city, COUNT(DISTINCT sid) AS n FROM {$e} WHERE created_at >= %s AND created_at < %s GROUP BY b, country, region, city ORDER BY b, n DESC LIMIT 60000", $s0, $step, $s0, $s1 ) );
		// phpcs:enable
		$top = array();
		foreach ( $loc as $r ) {
			$b = (int) $r->b;
			if ( ! isset( $top[ $b ] ) ) {
				$top[ $b ] = array();
			}
			if ( count( $top[ $b ] ) < 3 ) {
				$top[ $b ][] = array( '' === $r->country ? __( 'Unknown', 'fileora' ) : Fileora_Geo::label( $r->country, $r->region, $r->city ), (int) $r->n );
			}
		}
		$rows = array();
		for ( $i = 0; $i < $n; $i++ ) {
			$x      = isset( $ev[ $i ] ) ? $ev[ $i ] : null;
			$y      = isset( $tk[ $i ] ) ? $tk[ $i ] : null;
			$rows[] = array(
				't'         => $a + $i * $step,
				'visits'    => $x ? (int) $x->visits : 0,
				'visitors'  => $x ? (int) $x->visitors : 0,
				'views'     => $x ? (int) $x->views : 0,
				'runs'      => ( $x ? (int) $x->runs : 0 ) + ( $y ? (int) $y->runs : 0 ),
				'failed'    => ( $x ? (int) $x->failed : 0 ) + ( $y ? (int) $y->failed : 0 ),
				'files'     => ( $x ? (int) $x->files : 0 ) + ( $y ? (int) $y->files : 0 ),
				'locations' => isset( $top[ $i ] ) ? $top[ $i ] : array(),
			);
		}
		return array( 'interval' => $interval, 'step' => $step, 'allowed' => $iv['allowed'], 'rows' => $rows );
	}

	private static function series_days( $start, $end, $iv ) {
		$first = self::local_date( $start );
		$last  = self::local_date( $end - 1 );
		$rows  = array();
		foreach ( self::days( $first, $last ) as $d ) {
			$rows[] = array(
				't'         => self::day_start( $d['day'] ),
				'visits'    => $d['visits'],
				'visitors'  => $d['visitors'],
				'views'     => $d['page_views'],
				'runs'      => $d['tool_runs'],
				'failed'    => $d['failed'],
				'files'     => $d['files'],
				'locations' => array(),
				'source'    => $d['source'],
			);
		}
		// Busiest locations per day, from the detailed records still stored.
		global $wpdb;
		$s    = Fileora_Analytics::sessions_table();
		$off  = (int) self::offset();
		$s0   = self::utc( max( $start, self::detail_from() ) );
		$s1   = self::utc( $end );
		$expr = "DATE(DATE_ADD(first_seen, INTERVAL {$off} SECOND))";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$loc = $wpdb->get_results( $wpdb->prepare( "SELECT {$expr} AS d, country, region, city, COUNT(*) AS n FROM {$s} WHERE first_seen >= %s AND first_seen < %s GROUP BY d, country, region, city ORDER BY d, n DESC LIMIT 60000", $s0, $s1 ) );
		$top = array();
		foreach ( $loc as $r ) {
			if ( ! isset( $top[ $r->d ] ) ) {
				$top[ $r->d ] = array();
			}
			if ( count( $top[ $r->d ] ) < 3 ) {
				$top[ $r->d ][] = array( '' === $r->country ? __( 'Unknown', 'fileora' ) : Fileora_Geo::label( $r->country, $r->region, $r->city ), (int) $r->n );
			}
		}
		foreach ( $rows as &$row ) {
			$k = self::local_date( $row['t'] );
			if ( isset( $top[ $k ] ) ) {
				$row['locations'] = $top[ $k ];
			}
		}
		unset( $row );
		return array( 'interval' => 'day', 'step' => DAY_IN_SECONDS, 'allowed' => $iv['allowed'], 'rows' => $rows );
	}

	/* ------------------------------------------------------------------
	 * Tool usage.
	 * ---------------------------------------------------------------- */

	/** Per tool: views, browser runs, server runs, failed, files, average time. */
	public static function tools( $start, $end ) {
		global $wpdb;
		$e  = Fileora_Analytics::table();
		$t  = Fileora_Task_Manager::table();
		$s0 = self::utc( $start );
		$s1 = self::utc( $end );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ev = $wpdb->get_results( $wpdb->prepare( "SELECT tool, SUM(type = 'tool_view') AS views, SUM(type = 'tool_run' AND exec = 'browser') AS runs, SUM(type = 'tool_run' AND exec = 'browser' AND status = 'failed') AS failed, SUM(IF(type = 'tool_run' AND exec = 'browser' AND status = 'done', files, 0)) AS files, SUM(IF(type = 'tool_run' AND exec = 'browser', ms, 0)) AS ms, SUM(type = 'tool_run' AND exec = 'browser' AND ms IS NOT NULL) AS timed, COUNT(DISTINCT IF(type = 'tool_run', visitor, NULL)) AS users FROM {$e} WHERE created_at >= %s AND created_at < %s AND tool <> '' AND type IN ('tool_view', 'tool_run') GROUP BY tool", $s0, $s1 ) );
		$tk = $wpdb->get_results( $wpdb->prepare( "SELECT tool, COUNT(*) AS runs, SUM(status = 'failed') AS failed, SUM(IF(status = 'done', files, 0)) AS files, SUM(IFNULL(duration_ms, 0)) AS ms, SUM(duration_ms IS NOT NULL) AS timed FROM {$t} WHERE created_at >= %s AND created_at < %s GROUP BY tool", $s0, $s1 ) );
		// phpcs:enable
		$out = array();
		$add = function ( $tool ) use ( &$out ) {
			if ( ! isset( $out[ $tool ] ) ) {
				$def            = Fileora_Tool_Registry::get( $tool );
				$out[ $tool ] = array( 'tool' => $tool, 'name' => $def ? $def['name'] : $tool, 'views' => 0, 'browser_runs' => 0, 'server_runs' => 0, 'failed' => 0, 'files' => 0, 'ms' => 0, 'timed' => 0, 'users' => 0 );
			}
		};
		foreach ( $ev as $r ) {
			$add( $r->tool );
			$o                  = &$out[ $r->tool ];
			$o['views']         = (int) $r->views;
			$o['browser_runs']  = (int) $r->runs;
			$o['failed']       += (int) $r->failed;
			$o['files']        += (int) $r->files;
			$o['ms']           += (int) $r->ms;
			$o['timed']        += (int) $r->timed;
			$o['users']         = (int) $r->users;
			unset( $o );
		}
		foreach ( $tk as $r ) {
			$add( $r->tool );
			$o                 = &$out[ $r->tool ];
			$o['server_runs']  = (int) $r->runs;
			$o['failed']      += (int) $r->failed;
			$o['files']       += (int) $r->files;
			$o['ms']          += (int) $r->ms;
			$o['timed']       += (int) $r->timed;
			unset( $o );
		}
		foreach ( $out as &$o ) {
			$o['runs']   = $o['browser_runs'] + $o['server_runs'];
			$o['avg_ms'] = $o['timed'] ? (int) round( $o['ms'] / $o['timed'] ) : null;
			$o['ok_pct'] = $o['runs'] ? round( ( $o['runs'] - $o['failed'] ) / $o['runs'] * 100, 1 ) : null;
			unset( $o['ms'], $o['timed'] );
		}
		unset( $o );
		$out = array_values( $out );
		usort(
			$out,
			function ( $a, $b ) {
				return $b['runs'] <=> $a['runs'] ?: $b['views'] <=> $a['views'];
			}
		);
		return $out;
	}

	/* ------------------------------------------------------------------
	 * Storage information for Settings.
	 * ---------------------------------------------------------------- */

	public static function storage() {
		global $wpdb;
		$tables = array(
			'events'   => Fileora_Analytics::table(),
			'sessions' => Fileora_Analytics::sessions_table(),
			'tasks'    => Fileora_Task_Manager::table(),
			'daily'    => self::daily_table(),
			'tools'    => self::tools_table(),
		);
		$out = array();
		foreach ( $tables as $k => $name ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$st        = $wpdb->get_row( $wpdb->prepare( 'SELECT TABLE_ROWS AS n, DATA_LENGTH + INDEX_LENGTH AS bytes FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s', $name ) );
			$out[ $k ] = array( 'table' => $name, 'rows' => $st ? (int) $st->n : 0, 'bytes' => $st ? (int) $st->bytes : 0 );
		}
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out['events']['rows']   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tables['events']}" );
		$out['sessions']['rows'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tables['sessions']}" );
		$out['tasks']['rows']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tables['tasks']}" );
		$out['daily']['rows']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tables['daily']}" );
		$first                   = $wpdb->get_var( "SELECT MIN(day) FROM {$tables['daily']}" );
		// phpcs:enable
		return array(
			'tables'      => $out,
			'oldest'      => self::oldest(),
			'first_day'   => $first ? (string) $first : '',
			'through'     => (string) get_option( self::THROUGH, '' ),
			'errors'      => get_option( Fileora_Analytics::DB_ERRORS, array() ),
			'exports'     => get_option( self::EXPORT_LOG, array() ),
		);
	}

	/* ------------------------------------------------------------------
	 * CSV export (admin-post.php?action=fileora_export_analytics).
	 * ---------------------------------------------------------------- */

	const DATASETS = array( 'visits', 'events', 'processing', 'series', 'daily', 'tools' );

	/** Keeps spreadsheet programs from running a cell as a formula. */
	private static function cell( $v ) {
		if ( null === $v ) {
			return '';
		}
		if ( is_string( $v ) && '' !== $v && ! is_numeric( $v ) && false !== strpos( "=+-@\t\r", $v[0] ) ) {
			return "'" . $v;
		}
		return $v;
	}

	private static function put( $out, array $row ) {
		fputcsv( $out, array_map( array( __CLASS__, 'cell' ), $row ) );
	}

	/** Local time "Y-m-d H:i:s" of a UTC datetime string. */
	private static function lt( $utc ) {
		return $utc ? gmdate( 'Y-m-d H:i:s', strtotime( $utc . ' UTC' ) + self::offset() ) : '';
	}

	public static function export() {
		if ( ! current_user_can( 'fileora_export_data' ) ) {
			wp_die( esc_html__( 'You are not allowed to export analytics data.', 'fileora' ), 403 );
		}
		check_admin_referer( 'fileora_export_analytics' );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$set   = isset( $_GET['dataset'] ) && in_array( $_GET['dataset'], self::DATASETS, true ) ? sanitize_key( $_GET['dataset'] ) : 'visits';
		$range = isset( $_GET['range'] ) ? sanitize_key( wp_unslash( $_GET['range'] ) ) : '30d';
		$from  = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$to    = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
		$ip    = ! empty( $_GET['ip'] ) && current_user_can( 'fileora_view_ip' );
		$pings = ! empty( $_GET['pings'] );
		$iv    = isset( $_GET['interval'] ) ? sanitize_key( $_GET['interval'] ) : '';
		// phpcs:enable
		$w = Fileora_Reports::window( $range, $from, $to );
		if ( is_wp_error( $w ) ) {
			wp_die( esc_html( $w->get_error_message() ), 400 );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		$name = 'fileora-' . $set . '-' . self::local_date( $w['start'] ) . '-to-' . self::local_date( $w['end'] - 1 ) . '.csv';
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		header( 'X-Content-Type-Options: nosniff' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- BOM so Excel reads UTF-8
		$n = call_user_func( array( __CLASS__, 'export_' . $set ), $out, $w, $ip, $pings, $iv );
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		self::log_export( $set, $w, $n, $ip );
		exit;
	}

	private static function log_export( $set, array $w, $rows, $ip ) {
		$log = get_option( self::EXPORT_LOG, array() );
		$log = is_array( $log ) ? $log : array();
		array_unshift(
			$log,
			array(
				'at'      => time(),
				'user'    => get_current_user_id(),
				'dataset' => $set,
				'from'    => $w['start'],
				'to'      => $w['end'],
				'rows'    => (int) $rows,
				'ip'      => (bool) $ip,
			)
		);
		update_option( self::EXPORT_LOG, array_slice( $log, 0, 20 ), false );
		Fileora_Core_Log::info( 'Analytics export', array( 'user' => get_current_user_id(), 'dataset' => $set, 'rows' => (int) $rows ) );
	}

	private static function export_visits( $out, array $w, $ip ) {
		global $wpdb;
		$s    = Fileora_Analytics::sessions_table();
		$head = array( 'visit_start_local', 'last_activity_local', 'visit_start_utc', 'last_activity_utc', 'visitor_id', 'visit_id', 'first_visit', 'country', 'region', 'city' );
		if ( $ip ) {
			$head[] = 'ip_address';
		}
		self::put( $out, array_merge( $head, array( 'landing_page', 'last_page', 'last_tool', 'referrer', 'device', 'browser', 'os', 'page_views', 'tool_runs' ) ) );
		$n    = 0;
		$last = array( '0000-00-00 00:00:00', '' );
		do {
			// Keyset paging: (first_seen, sid) after the last row written.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$s} WHERE last_seen >= %s AND first_seen < %s AND (first_seen > %s OR (first_seen = %s AND sid > %s)) ORDER BY first_seen, sid LIMIT 2000", self::utc( $w['start'] ), self::utc( $w['end'] ), $last[0], $last[0], $last[1] ) );
			foreach ( $rows as $r ) {
				$row = array( self::lt( $r->first_seen ), self::lt( $r->last_seen ), $r->first_seen, $r->last_seen, $r->visitor, $r->sid, (int) $r->is_new, $r->country, $r->region, $r->city );
				if ( $ip ) {
					$row[] = $r->ip;
				}
				self::put( $out, array_merge( $row, array( $r->landing, $r->last_page, $r->last_tool, $r->referrer, $r->device, $r->browser, $r->os, (int) $r->pages, (int) $r->tool_runs ) ) );
				$last = array( $r->first_seen, $r->sid );
				++$n;
			}
			flush();
		} while ( count( $rows ) === 2000 );
		return $n;
	}

	private static function export_events( $out, array $w, $ip, $pings ) {
		global $wpdb;
		$e    = Fileora_Analytics::table();
		$s    = Fileora_Analytics::sessions_table();
		$head = array( 'time_local', 'time_utc', 'event', 'tool', 'runs_on', 'status', 'duration_ms', 'files', 'file_name', 'page_type', 'visitor_id', 'visit_id', 'device', 'country', 'region', 'city' );
		if ( $ip ) {
			$head[] = 'ip_address';
		}
		self::put( $out, $head );
		$n    = 0;
		$id   = 0;
		$type = $pings ? '' : " AND e.type <> 'ping'";
		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT e.*' . ( $ip ? ', s.ip' : '' ) . " FROM {$e} e" . ( $ip ? " LEFT JOIN {$s} s ON s.sid = e.sid" : '' ) . " WHERE e.created_at >= %s AND e.created_at < %s AND e.id > %d{$type} ORDER BY e.id LIMIT 5000", self::utc( $w['start'] ), self::utc( $w['end'] ), $id ) );
			foreach ( $rows as $r ) {
				$row = array( self::lt( $r->created_at ), $r->created_at, $r->type, $r->tool, $r->exec, $r->status, $r->ms, (int) $r->files, $r->file_name, $r->page, $r->visitor, $r->sid, $r->device, $r->country, $r->region, $r->city );
				if ( $ip ) {
					$row[] = (string) $r->ip;
				}
				self::put( $out, $row );
				$id = (int) $r->id;
				++$n;
			}
			flush();
		} while ( count( $rows ) === 5000 );
		return $n;
	}

	private static function export_processing( $out, array $w, $ip ) {
		global $wpdb;
		$t    = Fileora_Task_Manager::table();
		$e    = Fileora_Analytics::table();
		$head = array( 'time_local', 'time_utc', 'runs_on', 'tool', 'status', 'failure_code', 'error', 'duration_ms', 'files', 'bytes_in', 'bytes_out', 'file_name', 'finished_utc', 'downloaded_utc', 'visit_id', 'country', 'region', 'city' );
		if ( $ip ) {
			$head[] = 'ip_address';
		}
		self::put( $out, array_merge( $head, array( 'task_id' ) ) );
		$n    = 0;
		$last = array( '0000-00-00 00:00:00', '' );
		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE created_at >= %s AND created_at < %s AND (created_at > %s OR (created_at = %s AND id > %s)) ORDER BY created_at, id LIMIT 2000", self::utc( $w['start'] ), self::utc( $w['end'] ), $last[0], $last[0], $last[1] ) );
			foreach ( $rows as $r ) {
				$row = array( self::lt( $r->created_at ), $r->created_at, 'server', $r->tool, $r->status, $r->error_code, $r->error, $r->duration_ms, (int) $r->files, $r->bytes_in, $r->bytes_out, $r->file_name, $r->finished_at, $r->downloaded_at, $r->sid, $r->country, $r->region, $r->city );
				if ( $ip ) {
					$row[] = $r->ip;
				}
				$row[] = $r->id;
				self::put( $out, $row );
				$last = array( $r->created_at, $r->id );
				++$n;
			}
			flush();
		} while ( count( $rows ) === 2000 );
		$id = 0;
		$s  = Fileora_Analytics::sessions_table();
		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT e.*' . ( $ip ? ', s.ip' : '' ) . " FROM {$e} e" . ( $ip ? " LEFT JOIN {$s} s ON s.sid = e.sid" : '' ) . " WHERE e.type = 'tool_run' AND e.exec = 'browser' AND e.created_at >= %s AND e.created_at < %s AND e.id > %d ORDER BY e.id LIMIT 5000", self::utc( $w['start'] ), self::utc( $w['end'] ), $id ) );
			foreach ( $rows as $r ) {
				$row = array( self::lt( $r->created_at ), $r->created_at, 'browser', $r->tool, $r->status, '', '', $r->ms, (int) $r->files, '', '', $r->file_name, '', '', $r->sid, $r->country, $r->region, $r->city );
				if ( $ip ) {
					$row[] = (string) $r->ip;
				}
				$row[] = '';
				self::put( $out, $row );
				$id = (int) $r->id;
				++$n;
			}
			flush();
		} while ( count( $rows ) === 5000 );
		return $n;
	}

	private static function export_series( $out, array $w, $ip, $pings, $iv ) {
		$data = self::series( $w['start'], $w['end'], $iv ? $iv : self::intervals( $w['start'], $w['end'] )['default'] );
		self::put( $out, array( $data['interval'] . '_start_local', 'visits', 'unique_visitors', 'page_views', 'tool_runs', 'failed_runs', 'files_processed', 'top_locations' ) );
		foreach ( $data['rows'] as $r ) {
			$loc = implode(
				'; ',
				array_map(
					function ( $l ) {
						return $l[0] . ' (' . $l[1] . ')';
					},
					$r['locations']
				)
			);
			self::put( $out, array( gmdate( 'Y-m-d H:i', $r['t'] + self::offset() ), $r['visits'], $r['visitors'], $r['views'], $r['runs'], $r['failed'], $r['files'], $loc ) );
		}
		return count( $data['rows'] );
	}

	private static function export_daily( $out, array $w ) {
		self::put( $out, array( 'date', 'visits', 'unique_visitors', 'first_time_visitors', 'page_views', 'tool_page_views', 'browser_tool_runs', 'server_tool_runs', 'tool_runs', 'failed_runs', 'files_processed', 'countries', 'source' ) );
		$rows = self::days( self::local_date( $w['start'] ), self::local_date( $w['end'] - 1 ) );
		foreach ( $rows as $r ) {
			self::put( $out, array( $r['day'], $r['visits'], $r['visitors'], $r['new_visitors'], $r['page_views'], $r['tool_views'], $r['browser_runs'], $r['server_runs'], $r['tool_runs'], $r['failed'], $r['files'], $r['countries'], $r['source'] ) );
		}
		return count( $rows );
	}

	private static function export_tools( $out, array $w ) {
		self::put( $out, array( 'tool_id', 'tool', 'page_views', 'browser_runs', 'server_runs', 'tool_runs', 'failed_runs', 'success_percent', 'files_processed', 'average_ms', 'visitors_who_ran_it_in_browser' ) );
		$rows = self::tools( $w['start'], $w['end'] );
		foreach ( $rows as $r ) {
			self::put( $out, array( $r['tool'], $r['name'], $r['views'], $r['browser_runs'], $r['server_runs'], $r['runs'], $r['failed'], $r['ok_pct'], $r['files'], $r['avg_ms'], $r['users'] ) );
		}
		return count( $rows );
	}
}
