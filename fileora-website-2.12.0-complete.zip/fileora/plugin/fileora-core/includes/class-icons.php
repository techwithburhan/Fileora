<?php
/**
 * SVG icon sprite (interface and tool icons), printed once per page.
 * Use with: <svg class="ic"><use href="#i-merge"/></svg>
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Icons {

	/** @var bool */
	private static $printed = false;

	/** Icon id => inner SVG markup (24×24 viewBox, stroke icons). */
	public static function symbols() {
		return array(
			// Interface.
			'search'      => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
			'x'           => '<path d="M6 6l12 12M18 6 6 18"/>',
			'star'        => '<path d="m12 3.5 2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
			'check'       => '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
			'chev-down'   => '<path d="m6 9 6 6 6-6"/>',
			'chev-right'  => '<path d="m9 6 6 6-6 6"/>',
			'chev-left'   => '<path d="m15 6-6 6 6 6"/>',
			'arrow-left'  => '<path d="M19 12H5m6-6-6 6 6 6"/>',
			'arrow-right' => '<path d="M5 12h14m-6-6 6 6-6 6"/>',
			'upload'      => '<path d="M12 15V4M7.5 8.5 12 4l4.5 4.5"/><path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
			'download'    => '<path d="M12 4v11m-4.5-4.5L12 15l4.5-4.5"/><path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
			'trash'       => '<path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 12.5h9l1-12.5"/>',
			'plus'        => '<path d="M12 5v14M5 12h14"/>',
			'device'      => '<rect x="4" y="5" width="16" height="11" rx="1.5"/><path d="M2 19h20"/>',
			'server'      => '<rect x="4" y="4" width="16" height="7" rx="2"/><rect x="4" y="13" width="16" height="7" rx="2"/><path d="M8 7.5h.01M8 16.5h.01"/>',
			'sun'         => '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.6 4.6 6 6M18 18l1.4 1.4M2.5 12h2M19.5 12h2M4.6 19.4 6 18M18 6l1.4-1.4"/>',
			'moon'        => '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
			'menu'        => '<path d="M4 7h16M4 12h16M4 17h10"/>',
			'globe'       => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 3.7 5.7 3.7 9s-1.2 6.3-3.7 9c-2.5-2.7-3.7-5.7-3.7-9S9.5 5.7 12 3z"/>',
			'file'        => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
			'zip'         => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M10 5.5h2M10 8.5h2M10 11.5h2M9.5 14.5h3v3h-3z"/>',
			'eye'         => '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
			'copy'        => '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
			'rotate-cw'   => '<path d="M20 12a8 8 0 1 1-2.3-5.7"/><path d="M20 4v4.5h-4.5"/>',
			'rotate-ccw'  => '<path d="M4 12a8 8 0 1 0 2.3-5.7"/><path d="M4 4v4.5h4.5"/>',
			'sort'        => '<path d="M7 4v16m-3-3 3 3 3-3M14 6h6M14 11h4.5M14 16h3"/>',
			'shield'      => '<path d="M12 3 4.5 6v5.5c0 4.6 3.2 8.2 7.5 9.5 4.3-1.3 7.5-4.9 7.5-9.5V6z"/><path d="m9 12 2 2 4-4"/>',
			'clock'       => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
			'user'        => '<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5c1-3.6 4-5.5 7.5-5.5s6.5 1.9 7.5 5.5"/>',
			'phone'       => '<rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M11 18.5h2"/>',
			'monitor'     => '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M9 20h6M12 16v4"/>',
			'info'        => '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.5h.01"/>',
			'alert'       => '<path d="M12 3.5 2.5 20h19z"/><path d="M12 10v4.5M12 17.5h.01"/>',
			'external'    => '<path d="M14 4h6v6M20 4l-9 9M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/>',
			'hourglass'   => '<path d="M7 3.5h10M7 20.5h10M8 3.5c0 4 8 5 8 8.5s-8 4.5-8 8.5M16 3.5c0 4-8 5-8 8.5s8 4.5 8 8.5"/>',
			// Tools.
			'merge'       => '<path d="M6 3.5V8a4 4 0 0 0 4 4h4a4 4 0 0 0 4-4V3.5"/><path d="M12 12v8.5M8.5 17l3.5 3.5 3.5-3.5"/>',
			'split'       => '<path d="M12 3.5V9c0 3-6 3-6 7v4.5M12 9c0 3 6 3 6 7v4.5"/><path d="M3.5 18 6 20.5 8.5 18M15.5 18l2.5 2.5 2.5-2.5"/>',
			'compress'    => '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
			'organize'    => '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><path d="M13.5 16.5h6M16.5 13.5v6"/>',
			'rotate'      => '<path d="M20 12a8 8 0 1 1-2.3-5.7"/><path d="M20 4v4.5h-4.5"/><rect x="9.5" y="9" width="5" height="6.5" rx="1"/>',
			'repair'      => '<path d="M15 4.5a4.5 4.5 0 0 0-4.3 5.9l-6.2 6.2a2 2 0 0 0 2.9 2.9l6.2-6.2a4.5 4.5 0 0 0 5.9-4.3l-2.8 2.8-2.6-.8-.8-2.6z"/>',
			'ocr'         => '<path d="M4 8V5.5A1.5 1.5 0 0 1 5.5 4H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16"/><path d="M8.5 9.5h7M8.5 12.5h7M8.5 15.5h4"/>',
			'archive'     => '<rect x="3.5" y="4" width="17" height="4.5" rx="1"/><path d="M5 8.5V18a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8.5M10 12.5h4"/>',
			'doc'         => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="m8.5 12 1.3 5 2.2-3.5 2.2 3.5 1.3-5"/>',
			'slides'      => '<rect x="3" y="4" width="18" height="12.5" rx="2"/><path d="M12 16.5V20M8.5 20h7"/><path d="m7.5 12.5 3-3 2.5 2 3.5-3.5"/>',
			'sheet'       => '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 9.5h16M4 14.5h16M10 4v16"/>',
			'image'       => '<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="m20.5 15.5-4.5-4.5-9 8.5"/>',
			'html'        => '<path d="m8 8-4 4 4 4M16 8l4 4-4 4M13.5 5.5l-3 13"/>',
			'camera'      => '<path d="M4 8h3l1.8-2.5h6.4L17 8h3a1 1 0 0 1 1 1v9.5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>',
			'markdown'    => '<rect x="2.5" y="5.5" width="19" height="13" rx="2"/><path d="M6 15V9l2.5 3L11 9v6M17 9v6m-2.2-2.2L17 15l2.2-2.2"/>',
			'edit'        => '<path d="M4.5 19.5h4l10.3-10.3a2.1 2.1 0 0 0-3-3L5.5 16.5z"/><path d="m14.3 7.7 3 3M13 19.5h6.5"/>',
			'sign'        => '<path d="M3.5 16.5c2.2-3.4 3.6-7.5 5.4-7.5 2 0-1.4 7.4.8 7.4 1.6 0 2.4-3.4 3.6-3.4 1.1 0 .9 2.4 2.1 2.4 1 0 1.7-1.2 2.6-1.2"/><path d="M3.5 20.5h17"/>',
			'drop'        => '<path d="M12 3.5s6 6.4 6 10.7a6 6 0 0 1-12 0C6 9.9 12 3.5 12 3.5z"/><path d="M9.2 14.5a2.9 2.9 0 0 0 2.6 2.6"/>',
			'num'         => '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9.5 16.5h5M12 8v5.5M10.3 9.5 12 8"/>',
			'resize'      => '<path d="M14 4h6v6M20 4l-7 7M10 20H4v-6M4 20l7-7"/>',
			'crop'        => '<path d="M6.5 2.5v13a2 2 0 0 0 2 2h13"/><path d="M2.5 6.5h13a2 2 0 0 1 2 2v13"/>',
			'form'        => '<rect x="4" y="3" width="16" height="18" rx="2"/><rect x="7.5" y="7" width="3" height="3" rx=".6"/><path d="M13.5 8.5h3"/><rect x="7.5" y="13" width="3" height="3" rx=".6"/><path d="M13.5 14.5h3"/>',
			'lock'        => '<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5M12 14.5V17"/>',
			'unlock'      => '<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 7.7-1.5M12 14.5V17"/>',
			'redact'      => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M8.5 12.5h7M8.5 16.5h4.5" stroke-width="3"/>',
			'compare'     => '<rect x="3" y="4" width="7.5" height="16" rx="1.5"/><rect x="13.5" y="4" width="7.5" height="16" rx="1.5"/><path d="M5.5 8.5H8M5.5 12H8M16 8.5h2.5M16 12h2.5M16 15.5h2.5"/>',
			'summary'     => '<path d="M4 6.5h9M4 11h7M4 15.5h5"/><path d="m17.5 9.5 1.1 2.5 2.4 1.1-2.4 1.1-1.1 2.4-1.1-2.4-2.4-1.1 2.4-1.1z"/>',
			'translate'   => '<path d="M3.5 5.5h9M8 3.5v2M10.5 5.5c-.8 4-3.3 7-6.5 8.5M6 8.8c1.3 2.3 3.4 4.1 6 5.2"/><path d="m12.5 20.5 4-9 4 9M14 17.5h5"/>',
			'idcard'      => '<rect x="2.5" y="5" width="19" height="14" rx="2"/><circle cx="8.5" cy="11" r="2.2"/><path d="M5.2 16c.6-1.6 1.8-2.4 3.3-2.4s2.7.8 3.3 2.4M14.5 9.5h4M14.5 12.5h4M14.5 15.5h2.5"/>',
			'interleave'  => '<rect x="3" y="3.5" width="7" height="9" rx="1.2"/><rect x="14" y="11.5" width="7" height="9" rx="1.2"/><path d="M10 8h4.5l-2-2M14 16H9.5l2 2"/>',
			'splithalf'   => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M12 3v18" stroke-dasharray="2 2"/><path d="M6.5 9h3M6.5 12h3M14.5 9h3M14.5 12h3"/>',
			'blank'       => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9.5 12.5l5 5M14.5 12.5l-5 5"/>',
			'grid4'       => '<rect x="3.5" y="3.5" width="17" height="17" rx="2"/><path d="M12 3.5v17M3.5 12h17"/>',
			'book'        => '<path d="M12 6.5C10 5 7 4.5 3.5 5v13c3.5-.5 6.5 0 8.5 1.5 2-1.5 5-2 8.5-1.5V5C17 4.5 14 5 12 6.5zM12 6.5v13"/>',
			'hash'        => '<path d="M9.5 3.5 7.5 20.5M16.5 3.5l-2 17M4.5 9h16M3.5 15h16"/>',
			'header'      => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M8 7h4M8 18h8M8 11.5h8M8 14.5h6"/>',
			'tag'         => '<path d="M3.5 12.2V4.5a1 1 0 0 1 1-1h7.7l8.3 8.3a1.5 1.5 0 0 1 0 2.1l-6.4 6.4a1.5 1.5 0 0 1-2.1 0z"/><circle cx="8" cy="8" r="1.5"/>',
			'layers'      => '<path d="m12 3.5 9 4.8-9 4.8-9-4.8z"/><path d="m3 12.2 9 4.8 9-4.8M3 16.2 12 21l9-4.8"/>',
			'images'      => '<rect x="6.5" y="3.5" width="14" height="12" rx="2"/><path d="M3.5 7.5v11a2 2 0 0 0 2 2h11"/><circle cx="11" cy="8" r="1.4"/><path d="m20.5 12.5-3.5-3.5-7 6.5"/>',
			'text'        => '<path d="M5 6V4.5h14V6M12 4.5v15M9 19.5h6"/>',
			'contrast'    => '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17a8.5 8.5 0 0 0 0-17z" fill="currentColor"/>',
			'stamp'       => '<path d="M9.5 13V9.8a2.5 2.5 0 1 1 5 0V13M5 13h14a1 1 0 0 1 1 1v3H4v-3a1 1 0 0 1 1-1zM6 20.5h12"/>',
			'target'      => '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/>',
			'exam'        => '<rect x="4" y="3" width="16" height="18" rx="2"/><rect x="7" y="6.5" width="4.5" height="5.5" rx="1"/><path d="M14 7.5h3M14 10.5h3M7 15.5h10M7 18h6"/>',
			'passport'    => '<rect x="5" y="2.5" width="14" height="19" rx="2"/><circle cx="12" cy="10" r="3"/><path d="M8 17.5h8M9 6.5h6" stroke-width="1.4"/>',
			'pinoff'      => '<path d="M18.5 10.5c0 4.6-6.5 10-6.5 10s-2-1.7-3.7-4M6.4 7.4A6.5 6.5 0 0 1 18 7.9"/><path d="M3.5 3.5l17 17"/>',
			'blur'        => '<path d="M4.5 7h.01M4.5 12h.01M4.5 17h.01M9 4.5h.01M9 19.5h.01M15 4.5h.01M15 19.5h.01M19.5 7h.01M19.5 12h.01M19.5 17h.01" stroke-width="2.4"/><circle cx="9.5" cy="9.5" r="1.6"/><circle cx="14.5" cy="9.5" r="1.6"/><circle cx="9.5" cy="14.5" r="1.6"/><circle cx="14.5" cy="14.5" r="1.6"/>',
			'collage'     => '<rect x="3.5" y="3.5" width="17" height="17" rx="2"/><path d="M11 3.5v17M11 11.5h9.5"/>',
			'favicon'     => '<rect x="3" y="3" width="18" height="18" rx="5"/><path d="m12 7.5 1.5 3 3.3.5-2.4 2.3.6 3.2-3-1.6-3 1.6.6-3.2-2.4-2.3 3.3-.5z"/>',
			'vector'      => '<rect x="3" y="3" width="4" height="4" rx=".6"/><rect x="17" y="17" width="4" height="4" rx=".6"/><path d="M7 5h6a6 6 0 0 1 6 6v6M5 7v6a6 6 0 0 0 6 6h6"/>',
			'palette'     => '<path d="M12 3.5a8.5 8.5 0 0 0 0 17c1.2 0 1.8-.8 1.8-1.7 0-1.1-.9-1.5-.9-2.4 0-.8.7-1.4 1.6-1.4h2.1a3.9 3.9 0 0 0 3.9-3.9c0-4.3-3.8-7.6-8.5-7.6z"/><circle cx="7.5" cy="11" r="1.2"/><circle cx="10" cy="7.5" r="1.2"/><circle cx="14.5" cy="7.5" r="1.2"/>',
			'code'        => '<path d="m8.5 7-5 5 5 5M15.5 7l5 5-5 5"/>',
			'frame'       => '<rect x="3" y="3" width="18" height="18" rx="5"/><rect x="7" y="7" width="10" height="10" rx="2"/>',
		);
	}

	public static function sprite() {
		$out = '<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute;width:0;height:0;overflow:hidden" aria-hidden="true" focusable="false"><defs>';
		foreach ( self::symbols() as $id => $inner ) {
			$out .= '<symbol id="i-' . esc_attr( $id ) . '" viewBox="0 0 24 24">' . $inner . '</symbol>';
		}
		return $out . '</defs></svg>';
	}

	/** Prints the sprite once. */
	public static function print_sprite() {
		if ( self::$printed ) {
			return;
		}
		self::$printed = true;
		echo self::sprite(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG markup
	}

	public static function printed() {
		return self::$printed;
	}

	/** Markup for one icon. */
	public static function icon( $name, $class = 'ic' ) {
		return '<svg class="' . esc_attr( $class ) . '" aria-hidden="true" focusable="false"><use href="#i-' . esc_attr( $name ) . '"/></svg>';
	}
}
