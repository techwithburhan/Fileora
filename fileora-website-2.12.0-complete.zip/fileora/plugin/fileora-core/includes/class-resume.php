<?php
/**
 * ATS Resume Builder: [fileora_resume_builder].
 *
 * A separate section of the site. The builder runs entirely in the visitor's
 * browser (public/js/fileora-resume.js): the resume is typeset as a real-text
 * PDF with pdf-lib, shown with pdf.js, and never sent to this site or the
 * processing server. What a visitor types is kept in their own browser only
 * (this tab, or this device when they tick "Remember").
 *
 * On update, the plugin creates the "ATS Resume Builder" page once (role
 * "resume") and adds an "ATS Resume" link to the header menu once. If you
 * delete the page or the link, they are not added back.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Resume {

	const SHORTCODE = 'fileora_resume_builder';
	const ROLE      = 'resume';
	const SLUG      = 'ats-resume-builder';
	const OPTION    = 'fileora_resume';

	public static function init() {
		add_shortcode( self::SHORTCODE, array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ), 6 );
		add_action( 'admin_init', array( __CLASS__, 'maybe_install' ) );
	}

	/* ------------------------------------------------------------------
	 * The page and the menu link.
	 * ---------------------------------------------------------------- */

	/** The published builder page, or 0. */
	public static function page_id() {
		static $id = null;
		if ( null === $id ) {
			$ids = get_posts(
				array(
					'post_type'      => 'page',
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'meta_key'       => '_fileora_page_role', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
					'meta_value'     => self::ROLE, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
					'no_found_rows'  => true,
				)
			);
			$id = $ids ? (int) $ids[0] : 0;
		}
		return $id;
	}

	public static function url() {
		$id = self::page_id();
		return $id ? get_permalink( $id ) : '';
	}

	/** Once: create the page, then add the header link. Never again after the owner removes either. */
	public static function maybe_install() {
		$o = self::state();
		if ( ! empty( $o['done'] ) || wp_doing_ajax() || ! current_user_can( 'publish_pages' ) || ! current_user_can( 'edit_theme_options' ) ) {
			return;
		}
		$o['page'] = self::create_page();
		$o['menu'] = $o['page'] ? self::add_menu_link( $o['page'] ) : 0;
		$o['done'] = FILEORA_CORE_VERSION;
		update_option( self::OPTION, $o, false );
	}

	private static function state() {
		$o = get_option( self::OPTION, array() );
		return is_array( $o ) ? $o : array();
	}

	/** Creates the page (or adopts an existing page at the same address). Returns its ID. */
	public static function create_page() {
		$existing = get_page_by_path( self::SLUG );
		if ( $existing && 'trash' !== $existing->post_status ) {
			if ( ! has_shortcode( $existing->post_content, self::SHORTCODE ) ) {
				return 0; // someone else's page lives here: leave it alone
			}
			update_post_meta( $existing->ID, '_fileora_page_role', self::ROLE );
			return (int) $existing->ID;
		}
		$id = wp_insert_post(
			wp_slash(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => __( 'ATS Resume Builder', 'fileora' ),
					'post_name'    => self::SLUG,
					'post_excerpt' => __( 'Make an ATS-friendly resume in minutes: pick a template, fill in your details, check what applicant tracking systems will read, and download a PDF. Free, no sign-up, and your details stay in your browser.', 'fileora' ),
					'post_content' => self::page_content(),
					'meta_input'   => array(
						'_fileora_page_role'        => self::ROLE,
						'_fileora_seo_title'        => 'Free ATS Resume Builder – ATS-Friendly Resume in PDF',
						'_fileora_meta_description' => 'Free ATS resume builder: choose an ATS-friendly template, fill in your details, check what ATS software reads and download a text-based PDF. No sign-up.',
						'_fileora_focus_keyword'    => 'ats resume builder',
						'_fileora_keywords'         => implode( "\n", array( 'ats resume builder', 'free resume builder', 'ats friendly resume', 'resume maker online', 'ats resume format', 'resume pdf download', 'resume for freshers', 'ats resume template', 'resume builder without sign up', 'how to make an ats friendly resume' ) ),
					),
				)
			),
			true
		);
		return is_wp_error( $id ) ? 0 : (int) $id;
	}

	/** The builder, then a short guide and FAQ (what search engines and readers see under it). */
	private static function page_content() {
		$p   = function ( $t ) {
			return '<!-- wp:paragraph --><p>' . $t . '</p><!-- /wp:paragraph -->';
		};
		$h   = function ( $t ) {
			return '<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html( $t ) . '</h2><!-- /wp:heading -->';
		};
		$ul  = function ( array $items ) {
			$li = '';
			foreach ( $items as $i ) {
				$li .= '<!-- wp:list-item --><li>' . $i . '</li><!-- /wp:list-item -->';
			}
			return '<!-- wp:list --><ul class="wp-block-list">' . $li . '</ul><!-- /wp:list -->';
		};
		$faq = function ( $q, $a ) {
			return '<!-- wp:details --><details class="wp-block-details"><summary>' . esc_html( $q ) . '</summary><!-- wp:paragraph --><p>' . esc_html( $a ) . '</p><!-- /wp:paragraph --></details><!-- /wp:details -->';
		};
		$tool = function ( $slug, $label ) {
			$t = class_exists( 'Fileora_Tool_Registry' ) ? Fileora_Tool_Registry::by_slug( $slug ) : null;
			return $t && ! empty( $t['post_id'] ) && 'publish' === get_post_status( (int) $t['post_id'] ) ? '<a href="' . esc_url( get_permalink( (int) $t['post_id'] ) ) . '">' . esc_html( $label ) . '</a>' : esc_html( $label );
		};
		$guide = array(
			$h( 'How to use the ATS resume builder' ),
			$p( 'This ATS resume builder is free and works in your browser. Most large employers and job portals pass your resume through an applicant tracking system (ATS) before a recruiter sees it: the software reads the text of your file and files it under headings like Experience, Education and Skills. The builder keeps everything an ATS needs – one column, real selectable text, standard fonts and standard section names. Here is how to make an ATS friendly resume in five steps.' ),
			$ul(
				array(
					'<strong>Pick an ATS resume template.</strong> All four templates use a single column, no tables, text boxes or photos, so the reading order is always top to bottom.',
					'<strong>Fill in your details.</strong> Start every bullet with an action word and add numbers where you can: "Cut report time by 30%".',
					'<strong>Run the ATS check.</strong> It shows the exact text ATS software reads from your PDF, and checks contact details, dates, length and bullet points.',
					'<strong>Compare with the job ad.</strong> Paste the job description to see which of its words your resume already uses. Add the missing ones only where they are true for you.',
					'<strong>Download the PDF.</strong> The resume PDF download is ready in a second, made in your browser.',
				)
			),
			$h( 'The ATS resume format, in short' ),
			$ul(
				array(
					'Standard headings: Summary, Experience, Education, Skills, Projects, Certifications.',
					'Dates in one style, like "Jun 2023 – Present".',
					'Plain fonts (Helvetica or Times), black or dark text, no images of text.',
					'One page for freshers and early careers; two pages are fine with long experience.',
					'Save as a text-based PDF, unless the job ad asks for a Word file.',
				)
			),
			$h( 'A resume maker online, without sign-up' ),
			$p( 'This resume builder without sign up keeps your details in your own browser – in this tab, or on this device if you tick "Remember". Nothing is sent to our server. Save a copy as a file to keep working on another device. It suits a resume for freshers as well as one with ten years of experience.' ),
			$h( 'After you download' ),
			$p( 'Applying with certificates too? Join them with your resume using ' . $tool( 'merge-pdf', 'Merge PDF' ) . '. If a portal has a size limit, use ' . $tool( 'compress-pdf', 'Compress PDF' ) . '. Need a photo for the form? Try the ' . $tool( 'passport-size-photo-maker', 'Passport Photo Maker' ) . '.' ),
			$h( 'Questions' ),
			$faq( 'Is the ATS resume builder free?', 'Yes. No account, no watermark, no limit on downloads.' ),
			$faq( 'Can any tool guarantee a 100% ATS score?', 'No. Every company uses a different system and there is no single score. What you can control is that your resume is easy for software to read and matches the job. That is what the templates and the ATS check help with.' ),
			$faq( 'Is my information uploaded?', 'No. The resume is built and turned into a PDF in your browser. It stays in this tab, or on this device if you tick "Remember", until you delete it.' ),
			$faq( 'Which template should I choose?', 'Any of them reads well for ATS software. Classic suits government, banking and academic jobs, Modern suits most private-sector jobs, Compact helps fit a fresher resume on one page, and Minimal keeps things airy.' ),
			$faq( 'Can I write my resume in Hindi?', 'The templates use standard PDF fonts that cover English and other Latin-alphabet languages. Most Indian employers and ATS software expect an English resume.' ),
		);
		return '<!-- wp:shortcode -->[' . self::SHORTCODE . ']<!-- /wp:shortcode -->' . "\n\n"
			. '<!-- wp:group {"className":"prose fo-resume-guide"} --><div class="wp-block-group prose fo-resume-guide">' . implode( "\n\n", $guide ) . '</div><!-- /wp:group -->';
	}

	/** Adds "ATS Resume" to the menu in the header location, before a Contact link if there is one. Returns the item ID or 0. */
	public static function add_menu_link( $page_id ) {
		$locations = get_nav_menu_locations();
		$menu_id   = isset( $locations['primary'] ) ? (int) $locations['primary'] : 0;
		if ( ! $menu_id || ! wp_get_nav_menu_object( $menu_id ) ) {
			return 0; // no assigned menu: the theme's own fallback menu shows the link
		}
		$items = wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) );
		$items = is_array( $items ) ? $items : array();
		$pos   = count( $items ) + 1;
		$page_url = untrailingslashit( (string) get_permalink( $page_id ) );
		foreach ( $items as $it ) {
			if ( ( 'post_type' === $it->type && (int) $it->object_id === (int) $page_id ) || untrailingslashit( (string) $it->url ) === $page_url ) {
				return (int) $it->ID; // already there
			}
		}
		$contact     = function_exists( 'fileora_theme_page_by_role' ) ? (int) fileora_theme_page_by_role( 'contact' ) : 0;
		$contact_url = $contact ? untrailingslashit( (string) get_permalink( $contact ) ) : '';
		foreach ( $items as $it ) {
			$is_contact = in_array( 'menu-contact', (array) $it->classes, true )
				|| ( $contact && 'post_type' === $it->type && (int) $it->object_id === $contact )
				|| ( $contact_url && untrailingslashit( (string) $it->url ) === $contact_url );
			if ( $is_contact ) {
				$pos = (int) $it->menu_order;
				break;
			}
		}
		foreach ( $items as $it ) {
			if ( (int) $it->menu_order >= $pos ) {
				wp_update_post( array( 'ID' => $it->ID, 'menu_order' => (int) $it->menu_order + 1 ) );
			}
		}
		$id = wp_update_nav_menu_item(
			$menu_id,
			0,
			array(
				'menu-item-title'     => __( 'ATS Resume', 'fileora' ),
				'menu-item-object'    => 'page',
				'menu-item-object-id' => (int) $page_id,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
				'menu-item-position'  => $pos,
				'menu-item-classes'   => 'menu-resume',
			)
		);
		return is_wp_error( $id ) ? 0 : (int) $id;
	}

	/* ------------------------------------------------------------------
	 * The builder.
	 * ---------------------------------------------------------------- */

	/** Styles in the head on the builder page (no flash of unstyled content); scripts in the footer. */
	public static function assets() {
		$v = FILEORA_CORE_VERSION;
		wp_register_style( 'fileora-resume', FILEORA_CORE_URL . 'public/css/fileora-resume.css', array( 'fileora-tools' ), $v );
		wp_register_script( 'fileora-resume', FILEORA_CORE_URL . 'public/js/fileora-resume.js', array(), $v, true );
		$post = get_queried_object();
		if ( $post instanceof WP_Post && has_shortcode( $post->post_content, self::SHORTCODE ) ) {
			wp_enqueue_style( 'fileora-tools' );
			wp_enqueue_style( 'fileora-resume' );
		}
	}

	public static function shortcode() {
		if ( ! wp_style_is( 'fileora-resume', 'registered' ) ) {
			self::assets();
		}
		wp_enqueue_style( 'fileora-tools' );
		wp_enqueue_style( 'fileora-resume' );
		wp_enqueue_script( 'fileora-resume' );
		$vendor = FILEORA_CORE_URL . 'public/vendor/';
		wp_localize_script(
			'fileora-resume',
			'FileoraResume',
			array(
				'pdflib' => $vendor . 'pdf-lib.min.js',
				'pdfjs'  => $vendor . 'pdf.min.js',
				'worker' => $vendor . 'pdf.worker.min.js',
				'thumbs' => FILEORA_CORE_URL . 'public/img/resume/',
				'v'      => FILEORA_CORE_VERSION,
			)
		);
		static $n = 0;
		++$n;
		ob_start();
		?>
		<div class="fo-app fo-resume" id="fo-resume-<?php echo (int) $n; ?>" data-fo-resume>
			<div class="fo-rs-boot" role="status"><span class="fo-pbar indet"><i></i></span><span><?php esc_html_e( 'Loading the resume builder…', 'fileora' ); ?></span></div>
			<noscript><p class="fo-note"><?php esc_html_e( 'The resume builder needs JavaScript. Please turn it on in your browser.', 'fileora' ); ?></p></noscript>
		</div>
		<?php
		return ob_get_clean();
	}
}
