<?php
/**
 * Tool registry.
 *
 * The code (modules/<module>/module.php) defines what each tool is: its id,
 * execution type (browser, server or hybrid), accepted files, and whether it
 * is implemented ("ready") or still "pending".
 *
 * WordPress stores what each tool looks like: one "fileora_tool" post per
 * tool holds the name (title), short description (excerpt), page content,
 * address (slug), order (menu order), category (fileora_category term) and
 * on/off state (published or draft). Editors change these in WordPress
 * without touching code. Tool pages live at the site root, e.g. /merge-pdf/.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Tool_Registry {

	const POST_TYPE = 'fileora_tool';
	const TAXONOMY  = 'fileora_category';
	const META_ID   = '_fileora_tool_id';
	const META_FAQ  = '_fileora_faq';

	/** Accepted input groups and their extensions (server-side validation). */
	const EXTENSIONS = array(
		'pdf'   => array( 'pdf' ),
		'word'  => array( 'doc', 'docx', 'odt', 'rtf', 'txt' ),
		'ppt'   => array( 'ppt', 'pptx', 'pps', 'ppsx', 'odp' ),
		'excel' => array( 'xls', 'xlsx', 'ods', 'csv' ),
		'html'  => array( 'html', 'htm' ),
	);

	/** @var array|null Modules from code. */
	private static $modules = null;

	/** @var array|null Tool definitions from code, by id. */
	private static $defs = null;

	/** @var array|null Merged tools for this request, by id. */
	private static $tools = null;

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ), 5 );
		add_action( 'init', array( __CLASS__, 'rewrite_rules' ), 20 );
		add_filter( 'post_type_link', array( __CLASS__, 'permalink' ), 10, 2 );
		add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'flush_cache' ) );
		add_action( 'edited_' . self::TAXONOMY, array( __CLASS__, 'flush_cache' ) );
		add_action( 'created_' . self::TAXONOMY, array( __CLASS__, 'flush_cache' ) );
		add_action( 'delete_' . self::TAXONOMY, array( __CLASS__, 'flush_cache' ) );
		add_filter( 'redirect_canonical', array( __CLASS__, 'no_canonical_redirect' ), 10, 2 );
	}

	/* ------------------------------------------------------------------
	 * Code definitions
	 * ------------------------------------------------------------------ */

	/** All modules, keyed by id, each with its tools. */
	public static function modules() {
		if ( null === self::$modules ) {
			$modules = array();
			foreach ( array( 'pdf', 'image', 'converter', 'optimizer', 'security', 'editor', 'ai' ) as $id ) {
				$file = FILEORA_CORE_DIR . 'modules/' . $id . '/module.php';
				if ( file_exists( $file ) ) {
					$m = include $file;
					if ( is_array( $m ) ) {
						$m['dir']       = FILEORA_CORE_DIR . 'modules/' . $id . '/';
						$m['url']       = FILEORA_CORE_URL . 'modules/' . $id . '/';
						$modules[ $id ] = $m;
					}
				}
			}
			/**
			 * Add or change modules. A module is an array with id, name, desc,
			 * color, order, script (URL or file name in its folder) and tools.
			 */
			self::$modules = apply_filters( 'fileora_modules', $modules );
		}
		return self::$modules;
	}

	/** Tool definitions from code, by id, with defaults filled in. */
	public static function definitions() {
		if ( null === self::$defs ) {
			$defs = array();
			foreach ( self::modules() as $mid => $m ) {
				foreach ( (array) $m['tools'] as $i => $t ) {
					$t = wp_parse_args(
						$t,
						array(
							'exec'        => 'browser',
							'status'      => 'ready',
							'new'         => false,
							'paid'        => false,
							'default_off' => false,
							'max_files'   => 20,
							'needs'       => '',
							'keys'        => '',
							'icon'        => 'file',
							'accept'      => 'pdf',
						)
					);
					$t['module']      = $mid;
					$t['code_order']  = (int) $m['order'] * 100 + $i;
					$defs[ $t['id'] ] = $t;
				}
			}
			self::$defs = $defs;
		}
		return self::$defs;
	}

	public static function definition( $id ) {
		$d = self::definitions();
		return isset( $d[ $id ] ) ? $d[ $id ] : null;
	}

	/* ------------------------------------------------------------------
	 * WordPress objects
	 * ------------------------------------------------------------------ */

	public static function register() {
		$manage = 'fileora_manage_tools';
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'              => array(
					'name'          => __( 'Tools', 'fileora' ),
					'singular_name' => __( 'Tool', 'fileora' ),
					'edit_item'     => __( 'Edit tool page', 'fileora' ),
					'view_item'     => __( 'View tool page', 'fileora' ),
					'search_items'  => __( 'Search tools', 'fileora' ),
					'not_found'     => __( 'No tools found.', 'fileora' ),
					'all_items'     => __( 'All tool pages', 'fileora' ),
				),
				'public'              => true,
				'publicly_queryable'  => true,
				'exclude_from_search' => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_rest'        => true,
				'show_in_nav_menus'   => true,
				'rest_base'           => 'fileora-tools',
				'hierarchical'        => false,
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => self::POST_TYPE,
				'supports'            => array( 'title', 'editor', 'excerpt', 'page-attributes', 'revisions' ),
				'map_meta_cap'        => true,
				'capabilities'        => array(
					'edit_posts'             => $manage,
					'edit_others_posts'      => $manage,
					'edit_published_posts'   => $manage,
					'edit_private_posts'     => $manage,
					'publish_posts'          => $manage,
					'read_private_posts'     => $manage,
					'delete_posts'           => 'do_not_allow',
					'delete_private_posts'   => 'do_not_allow',
					'delete_published_posts' => 'do_not_allow',
					'delete_others_posts'    => 'do_not_allow',
					'create_posts'           => 'do_not_allow',
				),
				'menu_icon'           => 'dashicons-media-document',
			)
		);
		register_taxonomy(
			self::TAXONOMY,
			self::POST_TYPE,
			array(
				'labels'            => array(
					'name'          => __( 'Tool categories', 'fileora' ),
					'singular_name' => __( 'Tool category', 'fileora' ),
					'edit_item'     => __( 'Edit tool category', 'fileora' ),
					'add_new_item'  => __( 'Add tool category', 'fileora' ),
				),
				'public'            => false,
				'show_ui'           => true,
				'show_in_menu'      => false,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'hierarchical'      => true,
				'rewrite'           => false,
				'capabilities'      => array(
					'manage_terms' => $manage,
					'edit_terms'   => $manage,
					'delete_terms' => $manage,
					'assign_terms' => $manage,
				),
			)
		);
		register_post_meta(
			self::POST_TYPE,
			self::META_FAQ,
			array(
				'type'          => 'string',
				'single'        => true,
				'show_in_rest'  => false,
				'auth_callback' => function () {
					return current_user_can( 'fileora_manage_tools' );
				},
			)
		);
	}

	/** One rewrite rule for every enabled tool slug: /merge-pdf/ -> the tool post. */
	public static function rewrite_rules() {
		$slugs = array();
		foreach ( self::tools() as $t ) {
			if ( $t['enabled'] && $t['post_id'] ) {
				$slugs[] = preg_quote( $t['slug'], '#' );
			}
		}
		sort( $slugs );
		if ( $slugs ) {
			add_rewrite_rule( '^(' . implode( '|', $slugs ) . ')/?$', 'index.php?' . self::POST_TYPE . '=$matches[1]', 'top' );
		}
		$sig = md5( implode( ',', $slugs ) );
		if ( get_option( 'fileora_rewrite_sig' ) !== $sig ) {
			// Flush once every plugin has added its rules for this request.
			add_action(
				'wp_loaded',
				function () use ( $sig ) {
					update_option( 'fileora_rewrite_sig', $sig, true );
					flush_rewrite_rules( false );
				}
			);
		}
	}

	public static function permalink( $url, $post ) {
		if ( self::POST_TYPE === $post->post_type && $post->post_name ) {
			return home_url( user_trailingslashit( $post->post_name ) );
		}
		return $url;
	}

	/** Stops WordPress from "correcting" /merge-pdf/ to ?fileora_tool=merge-pdf. */
	public static function no_canonical_redirect( $redirect, $requested ) {
		if ( is_singular( self::POST_TYPE ) ) {
			return false;
		}
		return $redirect;
	}

	/* ------------------------------------------------------------------
	 * Sync: code -> WordPress
	 * ------------------------------------------------------------------ */

	/**
	 * Creates the category terms and tool posts that are missing. Existing
	 * posts and terms are never overwritten, so edits made in WordPress stay.
	 *
	 * @return int Number of tool pages created.
	 */
	public static function sync() {
		if ( ! post_type_exists( self::POST_TYPE ) ) {
			self::register();
		}
		$imported_off = (array) get_option( 'fileora_core_imported_disabled', array() );
		$terms        = array();
		foreach ( self::modules() as $mid => $m ) {
			$terms[ $mid ] = self::ensure_term( $mid, $m );
		}

		$existing = array();
		$posts    = get_posts(
			array(
				'post_type'        => self::POST_TYPE,
				'post_status'      => 'any',
				'numberposts'      => -1,
				'suppress_filters' => true,
			)
		);
		foreach ( $posts as $p ) {
			$id = get_post_meta( $p->ID, self::META_ID, true );
			if ( $id ) {
				$existing[ $id ] = $p->ID;
			}
		}

		$author = get_current_user_id();
		if ( ! $author ) {
			$admins = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID' ) );
			$author = $admins ? (int) $admins[0] : 0;
		}
		$created = 0;
		foreach ( self::definitions() as $id => $t ) {
			if ( isset( $existing[ $id ] ) ) {
				continue;
			}
			$off     = 'pending' === $t['status'] || $t['default_off'] || in_array( $id, $imported_off, true );
			$post_id = wp_insert_post(
				array(
					'post_type'    => self::POST_TYPE,
					'post_author'  => $author,
					'post_status'  => $off ? 'draft' : 'publish',
					'post_title'   => $t['name'],
					'post_name'    => $t['slug'],
					'post_excerpt' => $t['desc'],
					'post_content' => self::default_content( $t ),
					'menu_order'   => $t['code_order'],
					'meta_input'   => array_merge(
						array(
							self::META_ID  => $id,
							self::META_FAQ => self::default_faq( $t ),
						),
						// Title and description for Yoast / Rank Math, when the tool has its own.
						empty( $t['seo_title'] ) ? array() : array(
							'_yoast_wpseo_title'    => $t['seo_title'],
							'_yoast_wpseo_metadesc' => isset( $t['seo_desc'] ) ? $t['seo_desc'] : '',
							'rank_math_title'       => $t['seo_title'],
							'rank_math_description' => isset( $t['seo_desc'] ) ? $t['seo_desc'] : '',
						)
					),
				),
				true
			);
			if ( ! is_wp_error( $post_id ) ) {
				if ( ! empty( $terms[ $t['module'] ] ) ) {
					wp_set_object_terms( $post_id, (int) $terms[ $t['module'] ], self::TAXONOMY );
				}
				++$created;
			}
		}
		delete_option( 'fileora_core_imported_disabled' );
		self::flush_cache();
		/**
		 * Fires after the tool pages were checked (the Fileora theme creates its “All tools” page here).
		 */
		do_action( 'fileora_core_tools_synced', $created );
		return $created;
	}

	private static function ensure_term( $mid, array $m ) {
		$found = get_terms(
			array(
				'taxonomy'   => self::TAXONOMY,
				'hide_empty' => false,
				'meta_key'   => 'fo_module', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_query_meta_key
				'meta_value' => $mid, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_query_meta_value
			)
		);
		if ( ! is_wp_error( $found ) && $found ) {
			return $found[0]->term_id;
		}
		$res = wp_insert_term( $m['name'], self::TAXONOMY, array( 'slug' => sanitize_title( $m['name'] ), 'description' => $m['desc'] ) );
		if ( is_wp_error( $res ) ) {
			$term = get_term_by( 'slug', sanitize_title( $m['name'] ), self::TAXONOMY );
			if ( ! $term ) {
				return 0;
			}
			$term_id = $term->term_id;
		} else {
			$term_id = $res['term_id'];
		}
		update_term_meta( $term_id, 'fo_module', $mid );
		update_term_meta( $term_id, 'fo_color', $m['color'] );
		update_term_meta( $term_id, 'fo_order', (int) $m['order'] );
		update_term_meta( $term_id, 'fo_target', count( (array) $m['tools'] ) );
		return $term_id;
	}

	/**
	 * Hand-written starter page for a tool: modules/<module>/pages/<page>.php
	 * returning array( 'content' => block HTML, 'faq' => array( array( q, a ), … ) ).
	 */
	public static function page_data( array $t ) {
		if ( empty( $t['page'] ) ) {
			return array();
		}
		$file = FILEORA_CORE_DIR . 'modules/' . $t['module'] . '/pages/' . sanitize_file_name( $t['page'] ) . '.php';
		$data = file_exists( $file ) ? include $file : array();
		return is_array( $data ) ? $data : array();
	}

	/** Starter page content for a tool (editable in WordPress). */
	public static function default_content( array $t ) {
		$page = self::page_data( $t );
		if ( ! empty( $page['content'] ) ) {
			return $page['content'];
		}
		$name    = $t['name'];
		$browser = 'browser' === $t['exec'];
		$what    = self::accept_noun( $t['accept'], true );
		$steps   = array();
		if ( 'url' === $t['accept'] ) {
			$steps[] = 'Paste the address of the web page, for example https://example.com/article.';
		} elseif ( 'html' === $t['accept'] ) {
			$steps[] = 'Paste or type your HTML code in the editor, or open an .html file. The preview updates as you type.';
		} else {
			$steps[] = sprintf( 'Choose or drop your %s into the box above.', $what );
		}
		$steps[] = 'Check the options on the right. The defaults work for most files.';
		$steps[] = sprintf( 'Press the button to run %s and download the result.', $name );

		$privacy = $browser
			? 'Your files are processed right here in your browser, so they are never uploaded to a server.'
			: 'Your files travel over an encrypted connection to our processing server and are deleted automatically.';

		$html  = "<!-- wp:paragraph -->\n<p>" . esc_html( $t['desc'] . ' ' . $privacy ) . "</p>\n<!-- /wp:paragraph -->\n\n";
		$html .= "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html( sprintf( 'How to use %s', $name ) ) . "</h2>\n<!-- /wp:heading -->\n\n";
		$html .= "<!-- wp:list {\"ordered\":true} -->\n<ol class=\"wp-block-list\">";
		foreach ( $steps as $s ) {
			$html .= "<!-- wp:list-item -->\n<li>" . esc_html( $s ) . "</li>\n<!-- /wp:list-item -->";
		}
		$html .= "</ol>\n<!-- /wp:list -->";
		return $html;
	}

	/** Starter FAQ: "Question" on one line, the answer below, a blank line between entries. */
	public static function default_faq( array $t ) {
		$page = self::page_data( $t );
		if ( ! empty( $page['faq'] ) ) {
			return implode(
				"\n\n",
				array_map(
					function ( $qa ) {
						return $qa[0] . "\n" . $qa[1];
					},
					$page['faq']
				)
			);
		}
		$name    = $t['name'];
		$browser = 'browser' === $t['exec'];
		$faq     = array();
		$faq[]   = array( sprintf( 'Is %s free?', $name ), sprintf( 'Yes. %s is free to use and you don’t need an account.', $name ) );
		if ( $browser ) {
			$faq[] = array( 'Are my files uploaded?', 'No. This tool runs entirely in your browser, so your files never leave your device.' );
			$faq[] = array( 'Does it work on my phone?', 'Yes. It works in any modern browser on Android, iPhone, tablets and computers. Very large files are faster on a computer.' );
		} else {
			$faq[] = array( 'Are my files safe?', 'Files are sent over an encrypted connection, processed automatically and deleted from the server soon after. Nobody looks at them.' );
			$faq[] = array( 'How big can my files be?', 'Each file can be as large as the limit shown in the upload box. Larger files take longer to process.' );
		}
		return implode(
			"\n\n",
			array_map(
				function ( $qa ) {
					return $qa[0] . "\n" . $qa[1];
				},
				$faq
			)
		);
	}

	public static function accept_noun( $accept, $plural = false ) {
		$n = array(
			'pdf'      => array( 'PDF', 'PDF files' ),
			'image'    => array( 'image', 'images' ),
			'pdfimage' => array( 'PDF or image', 'PDF or images' ),
			'heic'     => array( 'HEIC photo', 'HEIC photos' ),
			'svg'      => array( 'SVG file', 'SVG files' ),
			'word'     => array( 'Word document', 'Word documents' ),
			'ppt'      => array( 'PowerPoint file', 'PowerPoint files' ),
			'excel'    => array( 'spreadsheet', 'spreadsheets' ),
			'url'      => array( 'web address', 'web addresses' ),
			'html'     => array( 'HTML code', 'HTML files' ),
		);
		$pair = isset( $n[ $accept ] ) ? $n[ $accept ] : array( 'file', 'files' );
		return $plural ? $pair[1] : $pair[0];
	}

	/** Parses the FAQ text into question/answer pairs. */
	public static function parse_faq( $text ) {
		$out = array();
		foreach ( preg_split( "/\R\s*\R/", trim( (string) $text ) ) as $block ) {
			$lines = preg_split( '/\R/', trim( $block ), 2 );
			if ( count( $lines ) === 2 && '' !== trim( $lines[0] ) && '' !== trim( $lines[1] ) ) {
				$out[] = array(
					'q' => trim( $lines[0] ),
					'a' => trim( $lines[1] ),
				);
			}
		}
		return $out;
	}

	/* ------------------------------------------------------------------
	 * Reading the registry
	 * ------------------------------------------------------------------ */

	public static function flush_cache() {
		self::$tools = null;
		wp_cache_delete( 'tools', 'fileora' );
	}

	/** Category terms ordered for display, each with id, name, slug, desc, color, order, target, module. */
	public static function categories() {
		$terms = get_terms(
			array(
				'taxonomy'   => self::TAXONOMY,
				'hide_empty' => false,
			)
		);
		if ( is_wp_error( $terms ) ) {
			return array();
		}
		$out = array();
		foreach ( $terms as $term ) {
			$out[ $term->term_id ] = array(
				'id'     => $term->term_id,
				'name'   => $term->name,
				'slug'   => $term->slug,
				'desc'   => $term->description,
				'color'  => (string) get_term_meta( $term->term_id, 'fo_color', true ),
				'order'  => (int) get_term_meta( $term->term_id, 'fo_order', true ),
				'target' => (int) get_term_meta( $term->term_id, 'fo_target', true ),
				'module' => (string) get_term_meta( $term->term_id, 'fo_module', true ),
			);
			if ( '' === $out[ $term->term_id ]['color'] ) {
				$out[ $term->term_id ]['color'] = 'organize';
			}
		}
		uasort(
			$out,
			function ( $a, $b ) {
				return $a['order'] <=> $b['order'] ?: strcmp( $a['name'], $b['name'] );
			}
		);
		return $out;
	}

	/**
	 * All tools: the code definition merged with its WordPress post.
	 *
	 * @return array<string, array> Keyed by tool id, in display order.
	 */
	public static function tools() {
		if ( null !== self::$tools ) {
			return self::$tools;
		}
		$defs  = self::definitions();
		$cats  = self::categories();
		$bymod = array();
		foreach ( $cats as $c ) {
			if ( $c['module'] && ! isset( $bymod[ $c['module'] ] ) ) {
				$bymod[ $c['module'] ] = $c;
			}
		}
		$posts = array();
		if ( post_type_exists( self::POST_TYPE ) ) {
			$q = get_posts(
				array(
					'post_type'        => self::POST_TYPE,
					'post_status'      => array( 'publish', 'draft', 'pending', 'private' ),
					'numberposts'      => -1,
					'suppress_filters' => true,
					'orderby'          => 'menu_order',
					'order'            => 'ASC',
				)
			);
			foreach ( $q as $p ) {
				$id = get_post_meta( $p->ID, self::META_ID, true );
				if ( $id && isset( $defs[ $id ] ) && ! isset( $posts[ $id ] ) ) {
					$posts[ $id ] = $p;
				}
			}
		}
		$tools = array();
		foreach ( $defs as $id => $d ) {
			$p   = isset( $posts[ $id ] ) ? $posts[ $id ] : null;
			$cat = null;
			if ( $p ) {
				$terms = get_the_terms( $p, self::TAXONOMY );
				if ( is_array( $terms ) ) {
					foreach ( $terms as $term ) {
						if ( isset( $cats[ $term->term_id ] ) ) {
							$cat = $cats[ $term->term_id ];
							break;
						}
					}
				}
			}
			if ( ! $cat && isset( $bymod[ $d['module'] ] ) ) {
				$cat = $bymod[ $d['module'] ];
			}
			$tools[ $id ] = array(
				'id'        => $id,
				'post_id'   => $p ? $p->ID : 0,
				'slug'      => $p ? $p->post_name : $d['slug'],
				'name'      => $p ? $p->post_title : $d['name'],
				'desc'      => $p && '' !== $p->post_excerpt ? $p->post_excerpt : $d['desc'],
				'keys'      => $d['keys'],
				'icon'      => $d['icon'],
				'exec'      => $d['exec'],
				'accept'    => $d['accept'],
				'max_files' => (int) $d['max_files'],
				'needs'     => $d['needs'],
				'status'    => $d['status'],
				'new'       => (bool) $d['new'],
				'paid'      => (bool) $d['paid'],
				'module'    => $d['module'],
				'category'  => $cat,
				'order'     => $p ? (int) $p->menu_order : $d['code_order'],
				'enabled'   => $p ? 'publish' === $p->post_status : false,
				'url'       => $p ? get_permalink( $p ) : '',
			);
		}
		uasort(
			$tools,
			function ( $a, $b ) {
				$ca = $a['category'] ? $a['category']['order'] : 999;
				$cb = $b['category'] ? $b['category']['order'] : 999;
				return $ca <=> $cb ?: $a['order'] <=> $b['order'];
			}
		);
		self::$tools = $tools;
		return $tools;
	}

	public static function get( $id ) {
		$t = self::tools();
		return isset( $t[ $id ] ) ? $t[ $id ] : null;
	}

	public static function by_slug( $slug ) {
		foreach ( self::tools() as $t ) {
			if ( $t['slug'] === $slug ) {
				return $t;
			}
		}
		return null;
	}

	public static function by_post( $post ) {
		$post = get_post( $post );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return null;
		}
		$id = get_post_meta( $post->ID, self::META_ID, true );
		return $id ? self::get( $id ) : null;
	}

	/** Tools visitors can see: enabled, with a page. */
	public static function visible() {
		return array_filter(
			self::tools(),
			function ( $t ) {
				return $t['enabled'] && $t['post_id'];
			}
		);
	}

	/**
	 * Where a tool runs right now: 'browser' or 'server'.
	 * Hybrid tools use the server only when it is connected and reports the tool as available.
	 */
	public static function runs_on( array $t ) {
		if ( 'hybrid' !== $t['exec'] ) {
			return $t['exec'];
		}
		return Fileora_Core_Settings::backend_configured() && true === Fileora_Server_Monitor::tool_available( $t['id'] ) ? 'server' : 'browser';
	}

	/** Visible tools grouped by category, for catalogs and menus. */
	public static function grouped() {
		$groups = array();
		foreach ( self::categories() as $cid => $c ) {
			$groups[ $cid ] = $c + array( 'tools' => array() );
		}
		foreach ( self::visible() as $t ) {
			if ( $t['category'] && isset( $groups[ $t['category']['id'] ] ) ) {
				$groups[ $t['category']['id'] ]['tools'][] = $t;
			}
		}
		return array_filter(
			$groups,
			function ( $g ) {
				return ! empty( $g['tools'] );
			}
		);
	}
}
