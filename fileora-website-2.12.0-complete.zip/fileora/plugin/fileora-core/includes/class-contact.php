<?php
/**
 * Contact form: [fileora_contact].
 *
 * A message is saved as a private "fileora_message" post (Fileora → Messages)
 * and emailed to the contact address, so nothing is lost when the host's
 * email doesn't work. Spam protection without third parties or cookies: a
 * hidden honeypot field, a minimum time to fill the form and at most 5
 * messages per hour from one connection. The form posts to
 * /wp-json/fileora/v1/contact, so cached pages keep working (no nonce that
 * could expire inside a cached page).
 *
 * Messages are deleted after Settings → "Contact form messages" days.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Contact {

	const POST_TYPE = 'fileora_message';
	const MAX_LEN   = 5000;

	public static function topics() {
		return array(
			'general'       => __( 'General question', 'fileora' ),
			'tool'          => __( 'A tool isn’t working', 'fileora' ),
			'privacy'       => __( 'Privacy or data request', 'fileora' ),
			'accessibility' => __( 'Accessibility', 'fileora' ),
			'business'      => __( 'Business or partnership', 'fileora' ),
			'other'         => __( 'Something else', 'fileora' ),
		);
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_shortcode( 'fileora_contact', array( __CLASS__, 'shortcode' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'add_meta_boxes_' . self::POST_TYPE, array( __CLASS__, 'meta_boxes' ) );
		add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		add_filter( 'post_row_actions', array( __CLASS__, 'row_actions' ), 10, 2 );
	}

	public static function register() {
		$cap = 'fileora_manage_settings';
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'          => array(
					'name'          => __( 'Messages', 'fileora' ),
					'singular_name' => __( 'Message', 'fileora' ),
					'all_items'     => __( 'Messages', 'fileora' ),
					'edit_item'     => __( 'Message', 'fileora' ),
					'search_items'  => __( 'Search messages', 'fileora' ),
					'not_found'     => __( 'No messages yet.', 'fileora' ),
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => false, // added under Fileora by Fileora_Core_Admin
				'show_in_rest'    => false,
				'supports'        => array( 'title' ),
				'map_meta_cap'    => false,
				'capabilities'    => array(
					'edit_post'              => $cap,
					'read_post'              => $cap,
					'delete_post'            => $cap,
					'edit_posts'             => $cap,
					'edit_others_posts'      => $cap,
					'edit_private_posts'     => $cap,
					'edit_published_posts'   => $cap,
					'publish_posts'          => $cap,
					'read_private_posts'     => $cap,
					'delete_posts'           => $cap,
					'delete_private_posts'   => $cap,
					'delete_others_posts'    => $cap,
					'delete_published_posts' => $cap,
					'create_posts'           => 'do_not_allow',
				),
			)
		);
	}

	/** Where messages are emailed: Settings → contact email, else the privacy email, else the admin email. */
	public static function recipient() {
		$s = Fileora_Core_Settings::get();
		foreach ( array( $s['contact_email'], $s['privacy_email'], get_option( 'admin_email' ) ) as $m ) {
			if ( is_email( $m ) ) {
				return $m;
			}
		}
		return '';
	}

	/* ------------------------------------------------------------------
	 * The form.
	 * ---------------------------------------------------------------- */

	public static function shortcode() {
		wp_enqueue_style( 'fileora-contact', FILEORA_CORE_URL . 'public/css/fileora-contact.css', array(), FILEORA_CORE_VERSION );
		wp_enqueue_script( 'fileora-contact', FILEORA_CORE_URL . 'public/js/fileora-contact.js', array(), FILEORA_CORE_VERSION, true );
		wp_localize_script(
			'fileora-contact',
			'FileoraContact',
			array(
				'url'  => esc_url_raw( rest_url( Fileora_Core_REST::NS . '/contact' ) ),
				'i18n' => array(
					'sending' => __( 'Sending…', 'fileora' ),
					'failed'  => __( 'Your message couldn’t be sent. Please try again, or write to us by email.', 'fileora' ),
					'fix'     => __( 'Please check the highlighted fields.', 'fileora' ),
				),
			)
		);
		static $n = 0;
		++$n;
		$id     = 'fo-contact-' . $n;
		$topics = self::topics();
		ob_start();
		?>
		<form class="fo-contact" id="<?php echo esc_attr( $id ); ?>" novalidate aria-describedby="<?php echo esc_attr( $id ); ?>-note">
			<p class="fo-c-note" id="<?php echo esc_attr( $id ); ?>-note"><?php esc_html_e( 'All fields are required.', 'fileora' ); ?></p>
			<div class="fo-c-row">
				<div class="fo-c-field">
					<label for="<?php echo esc_attr( $id ); ?>-name"><?php esc_html_e( 'Your name', 'fileora' ); ?></label>
					<input type="text" id="<?php echo esc_attr( $id ); ?>-name" name="name" autocomplete="name" required maxlength="100" aria-describedby="<?php echo esc_attr( $id ); ?>-name-err">
					<p class="fo-c-err" id="<?php echo esc_attr( $id ); ?>-name-err" hidden></p>
				</div>
				<div class="fo-c-field">
					<label for="<?php echo esc_attr( $id ); ?>-email"><?php esc_html_e( 'Email address', 'fileora' ); ?></label>
					<input type="email" id="<?php echo esc_attr( $id ); ?>-email" name="email" autocomplete="email" required maxlength="150" inputmode="email" aria-describedby="<?php echo esc_attr( $id ); ?>-email-err">
					<p class="fo-c-err" id="<?php echo esc_attr( $id ); ?>-email-err" hidden></p>
				</div>
			</div>
			<div class="fo-c-field">
				<label for="<?php echo esc_attr( $id ); ?>-topic"><?php esc_html_e( 'Topic', 'fileora' ); ?></label>
				<select id="<?php echo esc_attr( $id ); ?>-topic" name="topic" required>
					<?php foreach ( $topics as $k => $label ) : ?>
						<option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="fo-c-field">
				<label for="<?php echo esc_attr( $id ); ?>-message"><?php esc_html_e( 'Message', 'fileora' ); ?></label>
				<textarea id="<?php echo esc_attr( $id ); ?>-message" name="message" rows="7" required minlength="10" maxlength="<?php echo esc_attr( self::MAX_LEN ); ?>" aria-describedby="<?php echo esc_attr( $id ); ?>-message-hint <?php echo esc_attr( $id ); ?>-message-err"></textarea>
				<p class="fo-c-hint" id="<?php echo esc_attr( $id ); ?>-message-hint"><?php esc_html_e( 'Please don’t include passwords, ID numbers or bank details.', 'fileora' ); ?></p>
				<p class="fo-c-err" id="<?php echo esc_attr( $id ); ?>-message-err" hidden></p>
			</div>
			<div class="fo-c-hp" aria-hidden="true">
				<label for="<?php echo esc_attr( $id ); ?>-website">Website</label>
				<input type="text" id="<?php echo esc_attr( $id ); ?>-website" name="website" tabindex="-1" autocomplete="off">
			</div>
			<div class="fo-c-actions">
				<button type="submit" class="fo-c-btn"><?php esc_html_e( 'Send message', 'fileora' ); ?></button>
				<p class="fo-c-status" role="status" aria-live="polite"></p>
			</div>
			<p class="fo-c-privacy">
				<?php
				$pp = get_privacy_policy_url();
				/* translators: %s: how long messages are kept */
				echo esc_html( sprintf( __( 'We use your name, email address and message only to reply to you, and delete the message after %s.', 'fileora' ), Fileora_Content::keep_text( Fileora_Core_Settings::value( 'message_retention' ) ) ) );
				if ( $pp ) {
					echo ' <a href="' . esc_url( $pp ) . '">' . esc_html__( 'Privacy Policy', 'fileora' ) . '</a>';
				}
				?>
			</p>
		</form>
		<?php
		return ob_get_clean();
	}

	/* ------------------------------------------------------------------
	 * Receiving a message.
	 * ---------------------------------------------------------------- */

	public static function routes() {
		register_rest_route(
			Fileora_Core_REST::NS,
			'/contact',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'receive' ),
				'permission_callback' => '__return_true', // public form; protected by honeypot, timing and rate limit
			)
		);
	}

	public static function receive( WP_REST_Request $req ) {
		nocache_headers();
		$d = $req->get_json_params();
		$d = is_array( $d ) ? $d : $req->get_body_params();
		$name    = isset( $d['name'] ) ? trim( sanitize_text_field( wp_unslash( $d['name'] ) ) ) : '';
		$email   = isset( $d['email'] ) ? trim( sanitize_email( wp_unslash( $d['email'] ) ) ) : '';
		$topic   = isset( $d['topic'] ) && isset( self::topics()[ $d['topic'] ] ) ? (string) $d['topic'] : 'general';
		$message = isset( $d['message'] ) ? trim( sanitize_textarea_field( wp_unslash( $d['message'] ) ) ) : '';
		$page    = isset( $d['page'] ) ? esc_url_raw( wp_unslash( $d['page'] ) ) : '';
		$elapsed = isset( $d['t'] ) ? absint( $d['t'] ) : 0;

		// Bots: a filled hidden field gets a normal-looking answer, and nothing is saved.
		if ( ! empty( $d['website'] ) ) {
			return new WP_REST_Response( array( 'ok' => true, 'message' => self::thanks() ), 200 );
		}
		$errors = array();
		if ( '' === $name ) {
			$errors['name'] = __( 'Please enter your name.', 'fileora' );
		}
		if ( ! is_email( $email ) ) {
			$errors['email'] = __( 'Please enter a valid email address, for example name@example.com.', 'fileora' );
		}
		if ( mb_strlen( $message ) < 10 ) {
			$errors['message'] = __( 'Please write a little more (at least 10 characters).', 'fileora' );
		} elseif ( mb_strlen( $message ) > self::MAX_LEN ) {
			/* translators: %d: characters */
			$errors['message'] = sprintf( __( 'Please keep your message under %d characters.', 'fileora' ), self::MAX_LEN );
		}
		if ( $errors ) {
			return new WP_REST_Response( array( 'ok' => false, 'errors' => $errors ), 400 );
		}
		if ( $elapsed < 3000 ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => __( 'That was very quick. Please check your message and press Send again.', 'fileora' ) ), 429 );
		}
		$ip  = Fileora_Core_Security::client_ip();
		$key = 'fo_ct_' . substr( md5( $ip . wp_salt( 'nonce' ) ), 0, 20 );
		$n   = (int) get_transient( $key );
		if ( $n >= 5 ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => __( 'You have sent several messages in the last hour. Please try again later, or write to us by email.', 'fileora' ) ), 429 );
		}
		set_transient( $key, $n + 1, HOUR_IN_SECONDS );

		$topics = self::topics();
		$id     = wp_insert_post(
			array(
				'post_type'    => self::POST_TYPE,
				'post_status'  => 'private',
				'post_title'   => wp_trim_words( $topics[ $topic ] . ': ' . $name, 12, '…' ),
				'post_content' => '',
				'meta_input'   => array(
					'_fo_name'    => $name,
					'_fo_email'   => $email,
					'_fo_topic'   => $topic,
					'_fo_message' => $message,
					'_fo_page'    => $page,
					'_fo_ip'      => Fileora_Core_Security::stored_ip( $ip ),
				),
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			Fileora_Core_Log::error( 'Contact message could not be saved', array( 'error' => $id->get_error_message() ) );
			return new WP_REST_Response( array( 'ok' => false, 'message' => __( 'Your message couldn’t be saved. Please write to us by email.', 'fileora' ) ), 500 );
		}

		$to = self::recipient();
		if ( $to ) {
			/* translators: 1: site name, 2: topic */
			$subject = sprintf( __( '[%1$s] %2$s', 'fileora' ), wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), $topics[ $topic ] );
			$body    = sprintf( "%s: %s\n%s: %s\n%s: %s\n%s: %s\n\n%s\n\n—\n%s", __( 'From', 'fileora' ), $name, __( 'Email', 'fileora' ), $email, __( 'Topic', 'fileora' ), $topics[ $topic ], __( 'Page', 'fileora' ), $page, $message, admin_url( 'post.php?post=' . $id . '&action=edit' ) );
			$headers = array( 'Reply-To: ' . str_replace( array( "\r", "\n" ), '', $name ) . ' <' . $email . '>' );
			$sent    = wp_mail( $to, $subject, $body, $headers );
			update_post_meta( $id, '_fo_mailed', $sent ? 1 : 0 );
			if ( ! $sent ) {
				Fileora_Core_Log::error( 'Contact message saved but the email could not be sent', array( 'message_id' => $id ) );
			}
		}
		return new WP_REST_Response( array( 'ok' => true, 'message' => self::thanks() ), 200 );
	}

	private static function thanks() {
		return __( 'Thank you. Your message has been sent, and we will reply by email.', 'fileora' );
	}

	/** Deletes messages older than Settings → "Contact form messages" (daily). */
	public static function purge( $days ) {
		$days = (int) $days;
		if ( $days <= 0 ) {
			return;
		}
		$old = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => 200,
				'fields'         => 'ids',
				'date_query'     => array( array( 'before' => gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ), 'column' => 'post_date_gmt' ) ),
			)
		);
		foreach ( $old as $id ) {
			wp_delete_post( $id, true );
		}
	}

	/* ------------------------------------------------------------------
	 * Admin.
	 * ---------------------------------------------------------------- */

	public static function meta_boxes( $post ) {
		remove_meta_box( 'submitdiv', self::POST_TYPE, 'side' );
		add_meta_box( 'fileora-message', __( 'Message', 'fileora' ), array( __CLASS__, 'box' ), self::POST_TYPE, 'normal', 'high' );
	}

	public static function box( $post ) {
		$m      = function ( $k ) use ( $post ) {
			return (string) get_post_meta( $post->ID, '_fo_' . $k, true );
		};
		$topics = self::topics();
		$email  = $m( 'email' );
		echo '<table class="form-table" role="presentation">';
		echo '<tr><th>' . esc_html__( 'From', 'fileora' ) . '</th><td>' . esc_html( $m( 'name' ) ) . ' &lt;<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>&gt;</td></tr>';
		echo '<tr><th>' . esc_html__( 'Topic', 'fileora' ) . '</th><td>' . esc_html( isset( $topics[ $m( 'topic' ) ] ) ? $topics[ $m( 'topic' ) ] : $m( 'topic' ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Received', 'fileora' ) . '</th><td>' . esc_html( get_the_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $post ) ) . '</td></tr>';
		if ( $m( 'page' ) ) {
			echo '<tr><th>' . esc_html__( 'Sent from', 'fileora' ) . '</th><td><a href="' . esc_url( $m( 'page' ) ) . '">' . esc_html( $m( 'page' ) ) . '</a></td></tr>';
		}
		if ( current_user_can( 'fileora_view_ip' ) && $m( 'ip' ) ) {
			echo '<tr><th>' . esc_html__( 'IP address', 'fileora' ) . '</th><td><code>' . esc_html( $m( 'ip' ) ) . '</code></td></tr>';
		}
		echo '<tr><th>' . esc_html__( 'Email notification', 'fileora' ) . '</th><td>' . ( '' === $m( 'mailed' ) ? '—' : ( $m( 'mailed' ) ? esc_html__( 'Sent', 'fileora' ) : esc_html__( 'Not sent: check that your site can send email (for example with an SMTP plugin).', 'fileora' ) ) ) . '</td></tr>';
		echo '</table>';
		echo '<div style="white-space:pre-wrap;background:#f6f7f7;border:1px solid #dcdcde;border-radius:6px;padding:14px;font-size:14px;line-height:1.6">' . esc_html( $m( 'message' ) ) . '</div>';
		/* translators: %s: subject */
		$reply = 'mailto:' . rawurlencode( $email ) . '?subject=' . rawurlencode( sprintf( __( 'Re: %s', 'fileora' ), isset( $topics[ $m( 'topic' ) ] ) ? $topics[ $m( 'topic' ) ] : '' ) );
		echo '<p><a class="button button-primary" href="' . esc_attr( $reply ) . '">' . esc_html__( 'Reply by email', 'fileora' ) . '</a> ';
		echo '<a class="button-link-delete" style="margin-left:12px" href="' . esc_url( get_delete_post_link( $post->ID, '', true ) ) . '">' . esc_html__( 'Delete permanently', 'fileora' ) . '</a></p>';
	}

	public static function columns( $cols ) {
		return array(
			'cb'       => isset( $cols['cb'] ) ? $cols['cb'] : '',
			'title'    => __( 'Message', 'fileora' ),
			'fo_from'  => __( 'From', 'fileora' ),
			'fo_topic' => __( 'Topic', 'fileora' ),
			'date'     => __( 'Received', 'fileora' ),
		);
	}

	public static function column( $col, $id ) {
		if ( 'fo_from' === $col ) {
			$e = (string) get_post_meta( $id, '_fo_email', true );
			echo esc_html( (string) get_post_meta( $id, '_fo_name', true ) ) . '<br><a href="mailto:' . esc_attr( $e ) . '">' . esc_html( $e ) . '</a>';
		} elseif ( 'fo_topic' === $col ) {
			$t = (string) get_post_meta( $id, '_fo_topic', true );
			echo esc_html( isset( self::topics()[ $t ] ) ? self::topics()[ $t ] : $t );
		}
	}

	public static function row_actions( $actions, $post ) {
		if ( self::POST_TYPE !== $post->post_type ) {
			return $actions;
		}
		return array(
			'view'   => '<a href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">' . esc_html__( 'Read', 'fileora' ) . '</a>',
			'delete' => '<a href="' . esc_url( get_delete_post_link( $post->ID, '', true ) ) . '" class="submitdelete">' . esc_html__( 'Delete permanently', 'fileora' ) . '</a>',
		);
	}
}
