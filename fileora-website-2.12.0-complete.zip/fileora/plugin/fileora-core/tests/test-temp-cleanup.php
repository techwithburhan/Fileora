<?php
/**
 * Integration test: the temporary-file cleanup never touches WordPress content.
 *
 * Run on a test or staging site that is connected to a processing server 2.4+
 * (Fileora → Settings → Server address + Shared key):
 *
 *   wp eval-file wp-content/plugins/fileora-core/tests/test-temp-cleanup.php
 *
 * Optional, when the test can write to the server's temp directory (same
 * machine): FILEORA_TEST_WORKDIR=/var/lib/fileora/jobs  also creates expired
 * task folders and checks that the cleanup removes exactly those.
 *
 * What it does:
 *   1. Adds a canary post, page and upload, then fingerprints posts, postmeta,
 *      users, comments, terms, the Fileora task records and every file in
 *      wp-content/uploads.
 *   2. Checks that only administrators with a valid nonce can use the cleanup
 *      actions (others are refused and audited).
 *   3. Runs a real job, changes the cleanup settings, runs the cleanup, deletes
 *      a task's temporary files, stops and starts the schedule.
 *   4. Fingerprints again: everything must be identical. The canaries are then removed.
 *
 * It restores the cleanup settings it found. Exit code 1 on any failure.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;
if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
	exit;
}

$fo_fail = 0;
$fo_ok   = function ( $cond, $label ) use ( &$fo_fail ) {
	WP_CLI::log( ( $cond ? 'PASS ' : 'FAIL ' ) . $label );
	if ( ! $cond ) {
		++$fo_fail;
	}
};

/** Fingerprint of everything the cleanup must never change. */
$fo_fingerprint = function () {
	global $wpdb;
	$out = array();
	foreach ( array( 'posts', 'postmeta', 'users', 'usermeta', 'comments', 'commentmeta', 'terms', 'term_taxonomy', 'term_relationships', 'fileora_tasks' ) as $t ) {
		$table = $wpdb->prefix . $t;
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			continue;
		}
		$row         = $wpdb->get_row( "CHECKSUM TABLE {$table}", ARRAY_N ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$count       = $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out[ $t ]   = $count . ':' . ( $row ? $row[1] : '' );
	}
	$up   = wp_upload_dir();
	$base = $up['basedir'];
	$hash = array();
	if ( is_dir( $base ) ) {
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $base, FilesystemIterator::SKIP_DOTS ) );
		foreach ( $it as $f ) {
			if ( $f->isFile() ) {
				$hash[ substr( $f->getPathname(), strlen( $base ) ) ] = sha1_file( $f->getPathname() );
			}
		}
	}
	ksort( $hash );
	$out['uploads'] = count( $hash ) . ':' . sha1( wp_json_encode( $hash ) );
	return $out;
};

// Stop admin-post handlers before they redirect and exit, and turn wp_die() into an exception.
class Fileora_Test_Stop extends Exception {}
remove_all_filters( 'wp_redirect' );
add_filter(
	'wp_redirect',
	function ( $location ) {
		throw new Fileora_Test_Stop( 'redirect:' . $location );
	}
);
add_filter(
	'wp_die_handler',
	function () {
		return function ( $message, $title = '', $args = array() ) {
			$code = is_int( $title ) ? $title : ( is_int( $args ) ? $args : ( is_array( $args ) && isset( $args['response'] ) ? $args['response'] : '' ) );
			throw new Fileora_Test_Stop( 'die:' . $code );
		};
	}
);
$fo_call = function ( $handler, array $post, $nonce_action = '' ) {
	$_POST    = $post;
	$_REQUEST = $post;
	if ( $nonce_action ) {
		$_POST['_wpnonce']    = wp_create_nonce( $nonce_action );
		$_REQUEST['_wpnonce'] = $_POST['_wpnonce'];
	}
	try {
		call_user_func( array( 'Fileora_Temp_Cleanup', $handler ) );
	} catch ( Fileora_Test_Stop $e ) {
		return $e->getMessage();
	}
	return 'returned';
};

// ------------------------------------------------------------------ 0. server
$fo_status = Fileora_Backend_API::admin( 'GET', '/admin/cleanup' );
if ( is_wp_error( $fo_status ) || 200 !== $fo_status['status'] ) {
	WP_CLI::error( 'The processing server 2.4 isn’t reachable with the shared key: ' . Fileora_Temp_Cleanup::error_text( $fo_status ) );
}
$fo_saved = $fo_status['body']['settings'];
$fo_ok( ! empty( $fo_status['body']['verified'] ), 'server temp directory is verified' );

// ------------------------------------------------------------------ 1. canaries + fingerprint
$fo_admins = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID' ) );
if ( ! $fo_admins ) {
	WP_CLI::error( 'Needs an administrator account.' );
}
$fo_post = wp_insert_post( array( 'post_title' => 'Cleanup canary post', 'post_content' => 'Published content that must survive.', 'post_status' => 'publish', 'post_type' => 'post' ) );
$fo_page = wp_insert_post( array( 'post_title' => 'Cleanup canary page', 'post_content' => 'Page content.', 'post_status' => 'publish', 'post_type' => 'page' ) );
$fo_up   = wp_upload_dir();
wp_mkdir_p( $fo_up['path'] );
$fo_file = trailingslashit( $fo_up['path'] ) . 'fileora-cleanup-canary.txt';
file_put_contents( $fo_file, 'canary ' . wp_generate_password( 20, false ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
$fo_sub    = wp_insert_user( array( 'user_login' => 'fo_test_sub_' . wp_generate_password( 6, false ), 'user_pass' => wp_generate_password(), 'role' => 'subscriber' ) );
$fo_before = $fo_fingerprint();

// ------------------------------------------------------------------ 2. authorization
wp_set_current_user( $fo_sub );
$fo_r = $fo_call( 'handle_run', array(), 'fileora_cleanup_run' );
$fo_ok( 'die:403' === $fo_r, 'a subscriber is refused (' . $fo_r . ')' );
$fo_audit = Fileora_Core_Log::audit_entries( 1 );
$fo_ok( $fo_audit && 'cleanup.denied' === $fo_audit[0]['action'] && 'refused' === $fo_audit[0]['result'], 'the refusal is in the audit log' );
wp_set_current_user( (int) $fo_admins[0] );
$fo_r = $fo_call( 'handle_run', array() );
$fo_ok( 0 === strpos( $fo_r, 'die:' ), 'an administrator without a valid nonce is refused (' . $fo_r . ')' );
$fo_r = $fo_call( 'handle_delete', array( 'task' => str_repeat( 'a', 32 ) ), 'fileora_cleanup_delete_' . str_repeat( 'a', 32 ) );
$fo_ok( 0 === strpos( $fo_r, 'redirect:' ) && 'refused' === Fileora_Core_Log::audit_entries( 1 )[0]['result'], 'manual delete without the confirmation step is refused' );
$fo_r = $fo_call( 'handle_settings', array( 'enabled' => 1, 'ttl_min' => 7, 'interval_min' => 5 ), 'fileora_cleanup_settings' );
$fo_ok( 'refused' === Fileora_Core_Log::audit_entries( 1 )[0]['result'], 'an expiry outside the allowed list is refused' );

// ------------------------------------------------------------------ 3. real work
$fo_expired = array();
$fo_work    = getenv( 'FILEORA_TEST_WORKDIR' );
if ( $fo_work && is_dir( $fo_work ) && is_writable( $fo_work ) ) {
	for ( $i = 0; $i < 2; $i++ ) {
		$fo_id = bin2hex( random_bytes( 16 ) );
		wp_mkdir_p( "$fo_work/$fo_id/result" );
		file_put_contents( "$fo_work/$fo_id/result/old.pdf", str_repeat( 'x', 5000 ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		file_put_contents( "$fo_work/$fo_id/status.json", wp_json_encode( array( 'status' => 'done', 'tool' => 'compress', 'name' => 'old.pdf', 'kind' => 'file', 'created' => time() - 3 * HOUR_IN_SECONDS ) ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		$fo_expired[] = $fo_id;
	}
}
$fo_tmp = wp_tempnam( 'fileora-test.pdf' );
file_put_contents( $fo_tmp, "%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj 2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj 3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 200 200]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
$fo_job = Fileora_Backend_API::submit( 'protect', array( array( 'tmp_name' => $fo_tmp, 'name' => 'test.pdf' ) ), wp_json_encode( array( 'pw' => 'secret123' ) ) );
$fo_jid = ! is_wp_error( $fo_job ) && isset( $fo_job['body']['job'] ) ? $fo_job['body']['job'] : '';
$fo_ok( (bool) $fo_jid, 'a real job was accepted by the server' );
for ( $i = 0; $fo_jid && $i < 60; $i++ ) {
	$fo_s = Fileora_Backend_API::status( $fo_jid );
	if ( ! is_wp_error( $fo_s ) && isset( $fo_s['body']['status'] ) && in_array( $fo_s['body']['status'], array( 'done', 'failed' ), true ) ) {
		break;
	}
	usleep( 250000 );
}
@unlink( $fo_tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink

$fo_r = $fo_call( 'handle_settings', array( 'enabled' => 1, 'ttl_min' => 60, 'interval_min' => 5 ), 'fileora_cleanup_settings' );
$fo_ok( 0 === strpos( $fo_r, 'redirect:' ) && 'ok' === Fileora_Core_Log::audit_entries( 1 )[0]['result'], 'settings saved by an administrator (audited)' );
$fo_r = $fo_call( 'handle_run', array(), 'fileora_cleanup_run' );
$fo_ok( 0 === strpos( $fo_r, 'redirect:' ) && 'cleanup.run' === Fileora_Core_Log::audit_entries( 1 )[0]['action'], 'cleanup run now (audited)' );
$fo_list = Fileora_Backend_API::admin( 'GET', '/admin/temp' );
$fo_ids  = array();
foreach ( isset( $fo_list['body']['tasks'] ) ? $fo_list['body']['tasks'] : array() as $fo_t ) {
	$fo_ids[] = $fo_t['id'];
}
foreach ( $fo_expired as $fo_id ) {
	$fo_ok( ! in_array( $fo_id, $fo_ids, true ) && ! file_exists( "$fo_work/$fo_id" ), "expired task folder $fo_id was deleted" );
}
$fo_ok( $fo_jid && in_array( $fo_jid, $fo_ids, true ), 'the new (not expired) job is still there' );
if ( $fo_jid ) {
	$fo_r = $fo_call( 'handle_delete', array( 'task' => $fo_jid, 'confirm' => '1' ), 'fileora_cleanup_delete_' . $fo_jid );
	$fo_d = Fileora_Backend_API::admin( 'GET', '/admin/temp/' . $fo_jid );
	$fo_ok( ! is_wp_error( $fo_d ) && 404 === $fo_d['status'], 'manual delete removed the job’s temporary files' );
}
$fo_r = $fo_call( 'handle_toggle', array( 'state' => 'stop' ), 'fileora_cleanup_toggle' );
$fo_s = Fileora_Backend_API::admin( 'GET', '/admin/cleanup' );
$fo_ok( empty( $fo_s['body']['settings']['enabled'] ) && null === $fo_s['body']['next_run'], 'schedule stopped: no next run' );
$fo_r = $fo_call( 'handle_toggle', array( 'state' => 'start' ), 'fileora_cleanup_toggle' );

// ------------------------------------------------------------------ 4. nothing else changed
$fo_after = $fo_fingerprint();
foreach ( $fo_before as $fo_k => $fo_v ) {
	$fo_ok( $fo_after[ $fo_k ] === $fo_v, "unchanged: $fo_k" );
}
$fo_ok( 'publish' === get_post_status( $fo_post ) && 'publish' === get_post_status( $fo_page ) && file_exists( $fo_file ), 'canary post, page and upload are still there' );

// ------------------------------------------------------------------ clean up the test itself
Fileora_Backend_API::admin( 'PUT', '/admin/cleanup/settings', array_intersect_key( $fo_saved, array_flip( array( 'enabled', 'ttl_min', 'interval_min' ) ) ) );
wp_delete_post( $fo_post, true );
wp_delete_post( $fo_page, true );
@unlink( $fo_file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink
require_once ABSPATH . 'wp-admin/includes/user.php';
wp_delete_user( $fo_sub );
Fileora_Temp_Cleanup::flush();

if ( $fo_fail ) {
	WP_CLI::error( "$fo_fail checks failed." );
}
WP_CLI::success( 'The cleanup left posts, pages, media, users and task records untouched.' );
