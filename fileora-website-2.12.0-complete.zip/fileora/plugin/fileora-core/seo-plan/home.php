<?php
/**
 * Homepage title and description set on day 1 of the plan.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

return array(
	'title'       => 'Fileora | Free Online PDF Tools for Everyone',
	'description' => 'Free online PDF and image tools: merge, split, compress, convert and sign PDFs, and resize photos to KB. No sign-up; most tools run in your browser.',
);
