---
title: How to Rotate PDF Pages and Save Them the Right Way Up
slug: how-to-rotate-pdf-pages
seo_title: How to Rotate PDF Pages and Save Permanently
description: How to rotate PDF pages and save them permanently: turn all, odd or even pages 90° or 180°, fix sideways scans and batch-rotate files, free with no upload.
focus_keyword: how to rotate pdf pages
category: PDF Tools
tools: rotate-pdf, organize-pdf, scan-to-pdf
keywords: how to rotate pdf pages | rotate pdf online free | rotate pdf and save | rotate pdf permanently | rotate one page in pdf | rotate pdf 90 degrees | fix upside down pdf | rotate pdf on mobile | rotate pdf without acrobat | how to rotate pdf pages for free
titles: How to Rotate PDF Pages and Save Permanently | Rotate PDF Online Free, All Pages or Some | Rotate PDF and Save So It Stays Fixed | Rotate One Page in PDF Without Touching the Rest | Rotate PDF 90 Degrees Left or Right | Fix Upside Down PDF Scans in One Click | Rotate PDF on Mobile, No App Needed | Rotate PDF Without Acrobat | Odd and Even Pages Upside Down? Here's the Fix | Sideways Scans, Straightened in Seconds
---
Your PDF viewer has a rotate button, but it only turns the view. Send the file to someone and it's sideways again. Here's how to rotate PDF pages so the change is saved in the file itself – on every device, in every reader, when printed.

## Rotate PDF and save: the difference

Turning the page in Chrome or Adobe Reader is temporary. To rotate PDF permanently, the rotation has to be written into the file. That's what [Rotate PDF]({home}/rotate-pdf/) does: it changes the page itself, without redrawing it, so nothing gets blurry.

## How to rotate PDF pages

1. Open [Rotate PDF]({home}/rotate-pdf/) and add one or more PDFs.
2. Choose the turn: 90° right, 180°, or 90° left. (To rotate PDF 90 degrees clockwise, pick "90° right".)
3. Choose which pages: all, odd or even.
4. Rotate and download.

[[cta:rotate-pdf|Rotate PDF|Turn pages the right way up, saved permanently.]]

## Fix upside down PDF scans from a feeder

Double-sided documents scanned in a feeder often have every second page upside down. Choose **Even** and **180°** to fix upside down PDF pages in one pass. It's oddly satisfying.

## Rotate one page in PDF

Only one page is wrong? To rotate one page in PDF, use [Organize PDF]({home}/organize-pdf/): each page has its own rotate button, and you can reorder or delete pages at the same time. Our guide on [organizing PDF pages]({home}/how-to-organize-pdf-pages/) walks through it.

## Rotate PDF online free, and privately

This is a rotate PDF online free tool that works in your browser. The file isn't uploaded, there's no watermark, and you can rotate several PDFs together.

## Rotate PDF without Acrobat

You don't need Acrobat Pro or any desktop program. To rotate PDF without Acrobat on a work laptop where you can't install software, the browser is enough.

## Rotate PDF on mobile

Open fileora.in/rotate-pdf on your phone, pick the file, choose the angle and download. It's the easiest way to rotate PDF on mobile before forwarding a document on WhatsApp.

## Why PDFs end up sideways in the first place

Phones save a photo's orientation as a small tag rather than turning the picture itself. Some apps read the tag, some ignore it, so a page that looked upright in your gallery can come out sideways in a PDF. Scanners do something similar with landscape pages such as spreadsheets and certificates. Rotating the page in the PDF fixes it for good, whichever app opens it next.

## Prevent sideways pages next time

- When scanning with a phone, hold it in the same orientation as the paper.
- Use [Scan to PDF]({home}/scan-to-pdf/) and check the thumbnails before creating the file.
- For mixed portrait and landscape pages, rotate only the odd ones out.

## How to rotate PDF pages for free: summary

| Problem | Fix |
|---|---|
| Whole document sideways | Rotate PDF, all pages, 90° |
| Every second page upside down | Even pages, 180° |
| One page wrong | Organize PDF |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Will the rotation stay when I send the file?
Yes. The new orientation is saved in the PDF.

??? Does rotating reduce quality?
No. Pages are turned, not redrawn.

??? Can I rotate several PDFs at once?
Yes. Add several files and they're all rotated the same way.

??? Are my files uploaded?
No. Everything happens in your browser.
