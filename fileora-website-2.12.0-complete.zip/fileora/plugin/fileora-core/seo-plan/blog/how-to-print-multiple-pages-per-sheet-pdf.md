---
title: How to Print Multiple PDF Pages on One Sheet (2, 4, 6 or 9 Up)
slug: how-to-print-multiple-pages-per-sheet-pdf
seo_title: How to Print Multiple Pages per Sheet of a PDF
description: How to print multiple pages per sheet from a PDF: put 2, 4, 6 or 9 pages on one A4 page, with borders and reading order, to save paper on notes and slides.
focus_keyword: how to print multiple pages per sheet
category: PDF Tools
tools: n-up-pdf, pdf-booklet-maker, resize-pdf-pages
keywords: how to print multiple pages per sheet | multiple pages per sheet pdf | n-up pdf | 2 pages per sheet | 4 pages per sheet pdf | print slides as handouts | save paper printing pdf | combine pdf pages onto one page | print pdf 2 pages on 1 | how to print multiple pages per sheet for free
titles: How to Print Multiple Pages per Sheet of a PDF | Multiple Pages per Sheet PDF, Ready to Print | N-up PDF: 2, 4, 6 or 9 Pages on One Sheet | 2 Pages per Sheet for Notes and Readers | 4 Pages per Sheet PDF for Slides | Print Slides as Handouts Without PowerPoint | Save Paper Printing PDF Notes | Combine PDF Pages Onto One Page | Print PDF 2 Pages on 1, Properly Ordered | Study Notes on Fewer Pages
---
Printing a 120-slide lecture on 120 sheets is how printer budgets disappear. Most slides and many notes are perfectly readable at half or quarter size. Here's how to print multiple pages per sheet by making a new PDF where each sheet holds 2, 4, 6 or 9 pages.

## Multiple pages per sheet PDF vs the print dialog

Some printers and print shops support "pages per sheet", many don't, and settings differ on every computer. An n-up PDF works the same everywhere – send it to any shop or phone and it prints right.

## How to print multiple pages per sheet

1. Open [Pages per Sheet (N-up)]({home}/n-up-pdf/) and add your PDF.
2. Choose **Pages per sheet**: 2, 4, 6 or 9.
3. Choose the **Sheet**: A4, US Letter or A3.
4. Turn on **Thin border around each page** if you want them separated.
5. Choose **Order**: across, then down; or down, then across.
6. Download and print the new PDF normally.

[[cta:n-up-pdf|Pages per Sheet (N-up)|Put several pages on each sheet.]]

## 2 pages per sheet

Two pages side by side on landscape A4 is like an open book. For readers, novels and notes with normal-sized text, 2 pages per sheet halves the paper and stays comfortable to read. It's the classic way to print PDF 2 pages on 1.

## 4 pages per sheet PDF for slides

Presentation slides have big text, so 4 pages per sheet PDF output is very readable. It's how most people print slides as handouts without opening PowerPoint – and there's room for notes in the margins.

## 6 and 9 per sheet

Use 6 for slides with large text, 9 for quick reference overviews or contact sheets of a long document. Smaller than that and text becomes hard to read.

## Save paper printing PDF notes

| Content | Pages per sheet |
|---|---|
| Lecture slides | 4 or 6 |
| Novels and readers | 2 |
| Typed notes, normal font | 2 |
| Thumbnails / overview | 9 |

To save paper printing PDF files further, print double-sided too.

## A note on readability

Shrinking pages shrinks text. A normal 11-point document at 2 per sheet prints at roughly 8-point – fine for most eyes. At 4 per sheet it's around 5.5-point, which is only comfortable for slides and large text. If your source has tiny fonts or dense tables, stay at 2 or crop the margins first with our [PDF cropping guide]({home}/how-to-crop-pdf/) so the content fills more of each cell.

## Combine PDF pages onto one page vs a booklet

To combine PDF pages onto one page for reading flat, use N-up. If you want to fold the printout into a small book, use the [Booklet Maker]({home}/pdf-booklet-maker/), which arranges the pages in folding order.

## Private and free

The new PDF is built in your browser. Nothing is uploaded, and there's no watermark – this is how to print multiple pages per sheet for free.

## Before you print

Remove blank pages and fix sideways ones first: our guides to [removing blank pages]({home}/how-to-remove-blank-pages-from-pdf/) and [rotating PDF pages]({home}/how-to-rotate-pdf-pages/) take a minute each.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Can I put 4 slides on one page?
Yes. Choose 4 pages per sheet.

??? Will the text be readable?
At 2 or 4 per sheet, yes for most documents. 9 per sheet is for overviews.

??? Can I choose the reading order?
Yes. Across then down, or down then across.

??? Are my files uploaded?
No. The PDF is built in your browser.
