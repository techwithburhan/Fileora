---
title: How to Resize an Image Online (Pixels, Percent, Many at Once)
slug: how-to-resize-image-online
seo_title: How to Resize Image Online Free – Pixels or Percent
description: How to resize image files online for free: change width and height in pixels or by percent, keep the shape, and resize many photos at once with no upload.
focus_keyword: how to resize image
category: Image Tools
tools: resize-image, crop-image, compress-image
keywords: how to resize image | resize image online free | change image size in pixels | resize photo without losing quality | bulk image resizer | resize image for instagram | how to resize image for free | resize image by percentage | resize image to 1080x1080 | resize picture on phone
titles: How to Resize Image Online Free – Pixels or Percent | Resize Image Online Free Without Uploading | Change Image Size in Pixels in Seconds | Resize Photo Without Losing Quality | Bulk Image Resizer for Many Photos at Once | Resize Image for Instagram: 1080x1080 and More | Resize Image by Percentage, Keep the Shape | Resize Image to 1080x1080 for Posts | Resize Picture on Phone, No App Needed | Pixels, KB and cm: Image Sizes Made Simple
---
A shop listing wants 1000 × 1000. Your banner needs 1920 × 600. Instagram prefers 1080 × 1080. Every platform has its favourite size, and your camera ignores all of them. Here's how to resize image files to exactly what's needed, one at a time or in a batch.

## How to resize image files

1. Open [Resize Image]({home}/resize-image/) and add one or more pictures.
2. Choose **Resize by**: **Pixels** for exact dimensions, or **Percentage** to scale.
3. Type the width and height (or the percent).
4. Resize and download.

[[cta:resize-image|Resize Image|Resize photos in pixels or percent, in your browser.]]

## Change image size in pixels without stretching

If the new size has a different shape from the original – a tall phone photo into a square – something has to give. Either the picture gets squashed, or you crop. The clean way: crop to the right shape first with [Crop Image]({home}/crop-image/), then resize. Your faces will thank you.

## Resize image by percentage

Need everything half as big? Choose Percentage and type 50. To resize image by percentage is the quickest way to shrink a batch of very large photos while keeping each one's proportions.

## Resize image for Instagram and other platforms

| Use | Size in pixels |
|---|---|
| Square post | 1080 × 1080 |
| Portrait post | 1080 × 1350 |
| Story or Reel | 1080 × 1920 |
| YouTube thumbnail | 1280 × 720 |
| Website banner | 1920 × 1080 |

To resize image to 1080x1080, crop to Square first, then resize.

## Resize photo without losing quality

Going smaller keeps things sharp. Going much bigger can't invent detail and looks soft. So resize photo without losing quality by always starting from the largest original you have, and only scaling down.

## Bulk image resizer

Drop in a whole folder – product photos, event pictures – and every image is resized the same way. It's a bulk image resizer that runs on your own computer or phone, so a hundred photos don't need a hundred uploads.

## Resize picture on phone

Open fileora.in/resize-image in your mobile browser, select photos from the gallery and resize. That's how to resize image for free on the go, without installing an editor.

## Common resizing mistakes

- **Typing both width and height for a different shape** – the picture gets stretched. Crop first.
- **Enlarging a tiny image** – a 300-pixel logo blown up to 2000 pixels will look blurry. Find a bigger original or, for logos, convert it to a vector.
- **Resizing the same file again and again** – each JPG save adds a little loss. Keep the original and resize from it each time.
- **Forgetting retina screens** – images that look sharp on a laptop may need twice the pixels on a phone with a high-density display.

## Pixels vs KB

Resizing changes pixels; the file usually gets smaller too, but not to an exact KB. If a form asks for "under 50 KB", use our [guide to reducing image size in KB]({home}/how-to-reduce-image-size-in-kb/). For lighter website images, see [how to compress images]({home}/how-to-compress-image-without-losing-quality/).

More in [Image Tools]({home}/category/image-tools/).

??? How do I resize an image without stretching it?
Crop to the right shape first, then resize to the exact pixels.

??? Can I resize many images at once?
Yes. Add them all and they're resized together.

??? Will resizing reduce the file size?
Making a picture smaller in pixels usually makes the file smaller too.

??? Are my photos uploaded?
No. Resizing happens in your browser.
