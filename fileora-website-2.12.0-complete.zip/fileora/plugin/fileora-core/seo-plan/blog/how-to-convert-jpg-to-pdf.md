---
title: How to Convert JPG to PDF (Photos, Scans and Screenshots)
slug: how-to-convert-jpg-to-pdf
seo_title: How to Convert JPG to PDF Free – Photos to One PDF
description: How to convert JPG to PDF for free: turn photos, scans and screenshots into one PDF with the page size and margins you want, on phone or PC, with no upload.
focus_keyword: how to convert jpg to pdf
category: PDF Tools
tools: jpg-to-pdf, scan-to-pdf, merge-pdf
keywords: how to convert jpg to pdf | jpg to pdf converter free | convert image to pdf online | how to convert jpg to pdf for free | multiple jpg to one pdf | photo to pdf | png to pdf | convert jpg to pdf on mobile | jpg to pdf without losing quality | combine images into one pdf
titles: How to Convert JPG to PDF Free – Photos to One PDF | JPG to PDF Converter Free: No Upload, No Watermark | Photo to PDF in Seconds on Phone or PC | Multiple JPG to One PDF, in Any Order | Convert Image to PDF Online With A4 Pages | PNG to PDF and JPG to PDF in One Tool | Combine Images Into One PDF for Applications | JPG to PDF Without Losing Quality | Turn Phone Photos of Documents Into a PDF | Convert JPG to PDF on Mobile, Step by Step
---
You photographed your documents on your phone because the scanner at home stopped working years ago. Now the form wants a PDF. Here's how to convert JPG to PDF so the photos become clean, properly sized pages, in the order you choose.

## How to convert JPG to PDF in four steps

1. Open [JPG to PDF]({home}/jpg-to-pdf/).
2. Add your pictures. JPG, PNG and WebP all work, so it's also a PNG to PDF tool.
3. Drag them into order. Each picture becomes one page.
4. Choose page size (A4 is standard in India), orientation and margins, then convert and download.

[[cta:jpg-to-pdf|JPG to PDF|Turn photos into a PDF, right on your device.]]

## How to convert JPG to PDF for free, privately

Most "JPG to PDF converter free" sites upload your photos to their servers. If those photos are your Aadhaar, PAN or a medical report, that's a lot of trust. Fileora converts the pictures inside your browser, so they never leave your phone or computer. No sign-up, no watermark, no limit.

## Multiple JPG to one PDF

Applications often want everything in a single file. Add all your photos at once and you get multiple JPG to one PDF in one go. Put the most important document first. If you already have some PDFs too, convert the photos first and then join everything with [Merge PDF]({home}/merge-pdf/) – our [merging guide]({home}/how-to-merge-pdf-files/) shows the order most portals like.

## Convert JPG to PDF on mobile

Open fileora.in/jpg-to-pdf in Chrome or Safari, tap the box and pick from your gallery. On Android you can select several photos at once; on iPhone, tap each one. Convert, and the PDF is saved to Downloads or the Files app. Converting a photo to PDF this way is quicker than any app, and you don't need to install anything.

## JPG to PDF without losing quality

The tool places your pictures as they are, without squashing them into lower quality. A sharp photo makes a sharp page. If the result is too big for an upload limit, compress it afterwards; our [guide to compressing PDFs]({home}/how-to-compress-pdf/) explains which level to choose.

## Getting good pages from phone photos

- Shoot in daylight, straight from above, with the whole page in view.
- Put the paper on a dark surface so the edges are clear.
- Crop away fingers and table edges with [Crop Image]({home}/crop-image/).
- For a "scanned" look with white paper and dark text, use [Scan to PDF]({home}/scan-to-pdf/) instead: it cleans up the background.

## Convert image to PDF online: which page size?

| Use | Page size | Margin |
|---|---|---|
| Indian forms and printing | A4, portrait | Small |
| US forms | Letter | Small |
| Photo album or portfolio | Fit to image | None |

When you combine images into one PDF for printing, A4 with a small margin stops the printer from cutting edges off.

## Mistakes that get applications rejected

- **Sideways pages.** Rotate photos before converting, or fix the PDF afterwards with [Rotate PDF]({home}/rotate-pdf/).
- **Blurry text.** If you can't read it on your phone screen, the officer can't either. Retake the photo.
- **Wrong order.** Reviewers rarely search through a jumbled file; put the document they asked for first.
- **One giant file.** Ten 4 MB photos make a 40 MB PDF. Compress it before uploading.

More guides live in [PDF Tools]({home}/category/pdf-tools/).

??? Can I convert PNG or WebP images to PDF?
Yes. JPG, PNG and WebP are all accepted, and you can mix them.

??? How do I put several photos in one PDF?
Add all the photos, arrange them, and convert. Each becomes a page of the same PDF.

??? Are my photos uploaded?
No. The PDF is made in your browser.

??? Why is my PDF so large?
Phone photos are big. Compress the PDF after converting, or crop the photos first.
