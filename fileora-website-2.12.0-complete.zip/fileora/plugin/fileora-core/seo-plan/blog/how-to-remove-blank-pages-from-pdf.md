---
title: How to Remove Blank Pages From a PDF Automatically
slug: how-to-remove-blank-pages-from-pdf
seo_title: How to Remove Blank Pages From PDF Automatically
description: How to remove blank pages from PDF scans automatically: find empty and almost-empty pages, delete them in one go and keep the rest in order. Free, no upload.
focus_keyword: how to remove blank pages from pdf
category: PDF Tools
tools: remove-blank-pages-from-pdf, organize-pdf, add-page-numbers-to-pdf
keywords: how to remove blank pages from pdf | delete blank pages from pdf | remove empty pages from pdf | remove blank pages from scanned pdf | blank page remover online | delete white pages from pdf | remove blank pages automatically | duplex scan blank pages | remove blank pages from pdf free | clean up scanned pdf
titles: How to Remove Blank Pages From PDF Automatically | Delete Blank Pages PDF Scans Leave Behind | Remove Empty Pages From PDF in One Click | Remove Blank Pages From Scanned PDF Files | Blank Page Remover Online, No Upload | Delete White Pages From PDF Before Printing | Duplex Scan Blank Pages? Here's the Fix | Clean Up Scanned PDF Files in Seconds | Remove Blank Pages From PDF Free | Strict, Normal or Loose: Pick the Right Setting
---
Scan a stack of single-sided letters on a duplex scanner and you get a PDF where every second page is empty. Or you export a report and a blank page appears between chapters. Deleting them one by one is tedious. Here's how to remove blank pages from PDF files automatically – or rather, how to remove blank pages automatically and delete blank pages from PDF scans without hunting for them.

## How to remove blank pages from PDF files

1. Open [Remove Blank Pages]({home}/remove-blank-pages-from-pdf/) and add your PDF.
2. Choose how strict to be under **Count a page as blank when it is**:
    - **Completely empty** – only truly white pages.
    - **Almost empty** – the default; ignores tiny specks and scanner noise.
    - **Mostly empty** – also catches pages with a stray mark or a faint page number.
3. Run it, check the result and download.

[[cta:remove-blank-pages-from-pdf|Remove Blank Pages|Find and delete empty pages automatically.]]

## Duplex scan blank pages

This is the classic case. Duplex scanners scan both sides of every sheet, so single-sided documents produce a blank back for each page. "Almost empty" removes them while keeping pages that have even a short line of text. If your scanner shows faint show-through from the other side, try "Mostly empty" – and check the result.

## Remove blank pages from scanned PDF files safely

Scanned "blank" pages are rarely pure white; they have dust, shadows and grey noise. That's why a blank page remover online needs a tolerance setting. Start with the default, and only go looser if blank pages remain. Always scroll through the result before you delete the original.

## Delete white pages from PDF before printing

Printing a 200-page scan with 100 empty sheets wastes paper and toner. Delete white pages from PDF first; your printer (and your budget) will thank you.

## Removing a single page by hand

If there's just one empty page, or a page that isn't blank but should go, open the file in [Organize PDF]({home}/organize-pdf/) and delete it – our [guide to organizing PDF pages]({home}/how-to-organize-pdf-pages/) covers that.

## Why not just skip blank pages when printing?

You could, but the PDF stays twice as long, takes twice as long to upload, and anyone reading it on a screen still has to scroll past the empty pages. Fixing the file once means every future copy, email and upload is clean.

## After cleaning up

Once you remove empty pages from PDF documents, the page count changes. Add page numbers afterwards so they run correctly – see [adding page numbers to a PDF]({home}/how-to-add-page-numbers-to-pdf/).

## Remove blank pages from PDF free and privately

The checking happens in your browser, page by page. Nothing is uploaded, which matters for scanned contracts and records. It's free, with no watermark.

## How to remove blank pages from PDF: quick answers

| Situation | Setting |
|---|---|
| Exported document with true white pages | Completely empty |
| Normal scans | Almost empty |
| Scans with show-through or specks | Mostly empty (check result) |

More in [PDF Tools]({home}/category/pdf-tools/). To clean up scanned PDF files further, crop dark borders with our [PDF cropping guide]({home}/how-to-crop-pdf/).

??? Will it delete pages that only have a page number?
"Mostly empty" might. Use "Almost empty" to keep them.

??? Can I see which pages were removed?
Yes. The result lists the page numbers that were removed, so you can double-check them.

??? Does it change the other pages?
No. The remaining pages are copied as they are.

??? Are my files uploaded?
No. Everything happens in your browser.
