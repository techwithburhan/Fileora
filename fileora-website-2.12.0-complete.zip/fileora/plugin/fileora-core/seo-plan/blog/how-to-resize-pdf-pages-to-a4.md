---
title: How to Resize PDF Pages to A4 (or Letter, A3, A5, Legal)
slug: how-to-resize-pdf-pages-to-a4
seo_title: How to Resize PDF Pages to A4 – Free Online
description: How to resize PDF pages to A4, Letter, A3, A5 or Legal for free: make every page the same size for printing and portals, with margins you choose.
focus_keyword: how to resize pdf pages
category: PDF Tools
tools: resize-pdf-pages, crop-pdf, n-up-pdf
keywords: how to resize pdf pages | resize pdf to a4 | change pdf page size | convert letter size pdf to a4 | make all pdf pages same size | scale pdf for printing | resize pdf pages online free | a4 to a5 pdf | fix pdf page size for upload | how to resize pdf pages for free
titles: How to Resize PDF Pages to A4 – Free Online | Resize PDF to A4 for Printing in India | Change PDF Page Size in One Step | Convert Letter Size PDF to A4 | Make All PDF Pages Same Size | Scale PDF for Printing Without Cut-Off Edges | Resize PDF Pages Online Free | A4 to A5 PDF for Booklets and Notes | Fix PDF Page Size for Upload Portals | Mixed Page Sizes? Here's the Fix
---
Merge a few PDFs and you often get a mess: one page A4, another US Letter, a scanned receipt the size of a postcard. Printers crop the edges, and some portals reject mixed sizes. Here's how to resize PDF pages so every page is the size you want.

## How to resize PDF pages

1. Open [Resize PDF Pages]({home}/resize-pdf-pages/) and add your PDF.
2. Choose the **New page size**: A4, Letter, A3, A5 or Legal.
3. Choose the **Orientation**: same as each page, portrait or landscape.
4. Choose the **Margin**: none, small or large.
5. Download.

Each page's content is scaled to fit the new size without stretching – the simplest way to change PDF page size for a whole document at once.

[[cta:resize-pdf-pages|Resize PDF Pages|Make every page A4, Letter or another size.]]

## Resize PDF to A4

A4 (210 × 297 mm) is the standard in India and most of the world. To resize PDF to A4 is the most common fix before printing or uploading a document that came from the US or from a phone app.

## Convert Letter size PDF to A4

US Letter is slightly wider and shorter than A4. Printing a Letter PDF on A4 paper can cut off the top or bottom. Convert Letter size PDF to A4 with a small margin and everything fits.

## Make all PDF pages same size

After [merging documents]({home}/how-to-merge-pdf-files/), make all PDF pages same size so the file looks consistent and prints predictably. Choose A4, "same as each page" for orientation, and a small margin.

## Scale PDF for printing

Printers can't print to the very edge. If your pages have content right up to the border, scale PDF for printing with a small margin, and nothing gets lost.

## A4 to A5 PDF

For notes and small booklets, A4 to A5 PDF resizing halves the page. Text gets smaller, so it's best for large fonts. To print two A5 pages on one A4 sheet, see our [multiple pages per sheet guide]({home}/how-to-print-multiple-pages-per-sheet-pdf/).

## Fix PDF page size for upload portals

Some government and university portals check page size and reject anything that isn't A4. Fix PDF page size for upload by resizing to A4 first, then compress if needed using our [compression guide]({home}/how-to-compress-pdf/).

## Resize vs crop

Resizing changes the page size and scales content to fit. Cropping cuts off the edges without changing the content size. If your problem is wide white margins, read [how to crop a PDF]({home}/how-to-crop-pdf/) instead.

## Resize PDF pages online free, privately

Pages are resized in your browser – the file isn't uploaded. No account, no watermark: how to resize PDF pages for free on any device.

## Orientation tips

"Same as each page" keeps landscape pages landscape, which is right for mixed documents with spreadsheets or certificates. Choose Portrait if the file will be bound or uploaded to a portal that expects upright pages – wide pages are then scaled down to fit. Choose Landscape for slide decks and wide tables.

## Paper sizes at a glance

| Size | mm |
|---|---|
| A4 | 210 × 297 |
| A5 | 148 × 210 |
| A3 | 297 × 420 |
| Letter | 216 × 279 |
| Legal | 216 × 356 |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Will resizing stretch my pages?
No. Content is scaled to fit while keeping its shape.

??? Can I make every page A4?
Yes. Choose A4 as the new page size.

??? Does resizing reduce quality?
Text and vector content stay sharp; scanned images are scaled.

??? Are my files uploaded?
No. Resizing happens in your browser.
