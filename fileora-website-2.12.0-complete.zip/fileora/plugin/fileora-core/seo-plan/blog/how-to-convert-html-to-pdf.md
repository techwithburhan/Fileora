---
title: How to Convert HTML to PDF: Paste Your Code, Download a PDF
slug: how-to-convert-html-to-pdf
seo_title: How to Convert HTML to PDF Free – Code and CSS
description: How to convert HTML to PDF for free: paste HTML and CSS, check a live preview, set page size and margins, and download a PDF with real, selectable text.
focus_keyword: how to convert html to pdf
category: PDF Tools
tools: html-code-to-pdf, html-to-pdf, compress-pdf
keywords: how to convert html to pdf | html code to pdf | convert html and css to pdf | how to convert html to pdf for free | html invoice to pdf | html template to pdf | save html file as pdf | html to pdf with page breaks | html to pdf with css styles | html string to pdf
titles: How to Convert HTML to PDF Free – Code and CSS | HTML Code to PDF With a Live Preview | Convert HTML and CSS to PDF, Selectable Text | HTML Invoice to PDF for Your Business | HTML Template to PDF: Resumes, Certificates, Reports | Save HTML File as PDF Without the Print Dialog | HTML to PDF With Page Breaks That Behave | HTML to PDF With CSS Styles Intact | HTML String to PDF for Developers | Why Your HTML Looks Different in the PDF, and the Fix
---
You've built an invoice, a certificate or a resume in HTML and CSS. It looks right in the browser, but the client, the college or the office wants a PDF. The browser's print dialog adds dates and web addresses in the corners and breaks tables in odd places. Here's how to convert HTML to PDF cleanly, straight from your code.

## How to convert HTML to PDF in five steps

1. Open [HTML Code to PDF]({home}/html-code-to-pdf/).
2. Paste your code in the editor, or press **Open .html file**. CSS goes in a `<style>` block.
3. Watch the **Live preview** update as you type.
4. Choose **Page size**, **Orientation**, **Margins** and **CSS media**.
5. Press **Convert to PDF** and download.

[[cta:html-code-to-pdf|HTML Code to PDF|Paste HTML and CSS, preview it, download a PDF.]]

## HTML code to PDF: what you get

The PDF is printed by a real browser engine, so modern CSS works – flexbox, grid, custom fonts from a public link, background colours. Text stays text: you can select, search and copy it, which matters for invoices and resumes that get read by software. No header or footer is added, and there's no watermark.

## Convert HTML and CSS to PDF: a minimal example

```html
<!doctype html>
<html>
<head>
<style>
  @page { size: A4; margin: 15mm; }
  body { font-family: Arial, sans-serif; }
  h1 { color: #2f6bf3; }
  .row { break-inside: avoid; }
</style>
</head>
<body>
  <h1>Certificate of Completion</h1>
  <p>This certifies that <strong>A. Student</strong> completed the course.</p>
</body>
</html>
```

Paste that in, and the PDF follows the `@page` rule: A4 with 15 mm margins.

## HTML to PDF with page breaks

Long documents need clean breaks. Two CSS rules do most of the work:

- `break-before: page;` on a heading starts that section on a new page.
- `break-inside: avoid;` on a table row, card or signature block keeps it together.

That's how to get HTML to PDF with page breaks where you want them, not in the middle of a total.

## HTML to PDF with CSS styles: print or screen?

**CSS media** decides which styles apply. *Print* uses your `@media print` rules, like a browser's "Save as PDF" – good when you've hidden buttons or menus for printing. *Screen* ignores them and keeps the exact on-screen look. Turn **Background colours and images** off for an ink-friendly copy.

## HTML invoice to PDF and other templates

The tool suits any HTML template to PDF job: invoices and quotations, salary slips, certificates, resumes, event tickets, menus. Keep one HTML template, change the details, convert. For many documents, make the template once and reuse it.

## Common problems and fixes

| Problem | Fix |
|---|---|
| Image missing | Use a full https:// address or a data URI |
| Wrong font | Link a web font; local fonts aren't available |
| Content cut at the right | Set widths in % or use landscape |
| Script-built content empty | Turn on **Run JavaScript** |

## Save HTML file as PDF, or a web page?

To save HTML file as PDF from your computer, open it here with **Open .html file**. To save a public web page from its address instead, use [HTML to PDF]({home}/html-to-pdf/) – see [how to save a webpage as PDF]({home}/how-to-save-a-webpage-as-pdf/).

## HTML string to PDF for developers

Generated HTML from your app can be pasted the same way – a quick way to test an HTML string to PDF result before you build it into your own code.

## Free and private

How to convert HTML to PDF for free: no account, no watermark. The preview runs in your browser in a sandboxed frame; the PDF is made on Fileora's processing server and deleted after download or automatically. Scripts in your code are ignored unless you turn on **Run JavaScript**. Too large to email? [Compress PDF]({home}/compress-pdf/) – see [how to compress a PDF]({home}/how-to-compress-pdf/). Need a password on it? See [how to password protect a PDF]({home}/how-to-password-protect-a-pdf/).

More in [PDF Tools]({home}/category/pdf-tools/).

??? Is the text in the PDF selectable?
Yes. It stays real text, not a picture.

??? Can I use Bootstrap or Tailwind?
Yes, if you link them from a public CDN in your code.

??? Why is my image missing?
Relative paths can't be found. Use a full https:// address or a data URI.

??? Does JavaScript run?
Only if you turn on "Run JavaScript".
