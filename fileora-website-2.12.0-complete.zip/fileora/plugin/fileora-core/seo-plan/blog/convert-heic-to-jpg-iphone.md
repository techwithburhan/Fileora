---
title: How to Convert HEIC to JPG (iPhone Photos That Open Everywhere)
slug: convert-heic-to-jpg-iphone
seo_title: How to Convert HEIC to JPG on iPhone and Windows
description: How to convert HEIC to JPG for free when iPhone photos won't open on Windows, Android or upload forms, plus the one iPhone setting that stops HEIC for good.
focus_keyword: how to convert heic to jpg
category: Image Tools
tools: heic-to-jpg, compress-image, convert-image
keywords: how to convert heic to jpg | heic to jpg converter free | open heic files on windows | iphone photos to jpg | convert heic to jpg online | heic to png | batch convert heic to jpg | stop iphone saving heic | how to convert heic to jpg for free | heic to jpg without losing quality
titles: How to Convert HEIC to JPG on iPhone and Windows | HEIC to JPG Converter Free, No Upload | Open HEIC Files on Windows in One Step | iPhone Photos to JPG for Forms and WhatsApp | Convert HEIC to JPG Online, Many at Once | HEIC to PNG When You Need Lossless Images | Batch Convert HEIC to JPG From iCloud | Stop iPhone Saving HEIC: The Setting to Change | HEIC to JPG Without Losing Quality | What Is a HEIC File, and Why Can't I Open It?
---
You copy holiday photos from an iPhone to a Windows laptop and get a folder full of files that won't open. Or a job portal rejects your photo with "invalid format". The culprit is the .heic extension. Here's how to convert HEIC to JPG in seconds, and how to stop it happening again.

## What is HEIC, and why can't I open it?

HEIC is Apple's photo format. It stores pictures at roughly half the size of JPG with the same quality, which is why iPhones use it by default. The catch: many Windows PCs, older Android phones, printers and almost every government form expect JPG. That's why people search "open HEIC files on windows" – the files are fine, they're just in a format the computer doesn't understand.

## How to convert HEIC to JPG, step by step

1. Open [HEIC to JPG]({home}/heic-to-jpg/) on any phone or computer.
2. Add your .heic photos. You can batch convert HEIC to JPG – add dozens at once.
3. Choose **JPG** and a quality around 90%.
4. Convert and download.

[[cta:heic-to-jpg|HEIC to JPG|iPhone photos to JPG, privately in your browser.]]

## How to convert HEIC to JPG for free, privately

Personal photos are, well, personal. Most "HEIC to JPG converter free" sites upload them to a server. Fileora converts them in your browser, so the photos never leave your device. No sign-up, no watermark.

## HEIC to JPG without losing quality

At 90% quality the JPG looks the same as the HEIC on any screen. If you need a lossless copy – for editing or printing – choose PNG: it's the right way to do HEIC to PNG when every pixel matters, though the files will be bigger.

## Convert HEIC to JPG online from iCloud or a cable transfer

Photos downloaded from iCloud.com or copied with a cable often stay HEIC. Put them in one folder, then convert HEIC to JPG online in one batch. Once converted, iPhone photos to JPG work everywhere: WhatsApp on Android, Windows Photos, print shops and upload forms.

## Stop iPhone saving HEIC

On the iPhone, open **Settings → Camera → Formats** and choose **Most Compatible**. New photos are saved as JPG. Also set **Settings → Photos → Transfer to Mac or PC → Automatic**, so the iPhone converts when you copy by cable. Existing HEIC photos still need converting once.

## After converting

- Too big for a form? [Reduce the photo to a KB limit]({home}/how-to-reduce-image-size-in-kb/).
- For a website, [compress the images]({home}/how-to-compress-image-without-losing-quality/).
- Need WebP or PNG instead? [Convert Image]({home}/convert-image/) switches formats.
- Building a PDF from the photos? See [how to convert JPG to PDF]({home}/how-to-convert-jpg-to-pdf/).

## A note on Live Photos

A Live Photo is a still image plus a short video. Converting gives you the still picture as a JPG; the moving part isn't included. That's what forms and printers want anyway.

More in [Image Tools]({home}/category/image-tools/).

??? Why can't Windows open my HEIC photos?
Windows needs an extra codec for HEIC. Converting to JPG is the simplest fix.

??? Can I convert many HEIC photos at once?
Yes. Add them all and they're converted together.

??? How do I stop my iPhone taking HEIC photos?
Settings → Camera → Formats → Most Compatible.

??? Are my photos uploaded?
No. They're converted in your browser.
