---
title: How to Add Page Numbers to a PDF (Any Position, Any Format)
slug: how-to-add-page-numbers-to-pdf
seo_title: How to Add Page Numbers to PDF Online Free
description: How to add page numbers to PDF files for free: choose the position and format such as Page 1 of 10, skip the cover, start from any number, all in your browser.
focus_keyword: how to add page numbers to pdf
category: PDF Tools
tools: add-page-numbers-to-pdf, merge-pdf, bates-numbering
keywords: how to add page numbers to pdf | add page numbers to pdf online free | number pdf pages | page 1 of 10 in pdf | add page numbers without acrobat | skip first page numbering | page numbers bottom center | start page numbers from 2 | how to add page numbers to pdf for free | paginate pdf
titles: How to Add Page Numbers to PDF Online Free | Number PDF Pages in Any Position | Page 1 of 10 in PDF: Totals Added for You | Add Page Numbers Without Acrobat | Skip First Page Numbering on Your PDF | Page Numbers Bottom Center for Reports and Theses | Start Page Numbers From 2 (or Any Number) | Paginate PDF Files for Printing and Binding | Number a Merged PDF in One Go | Page Numbers for Court Bundles and Assignments
---
A 60-page report without page numbers is a nightmare to discuss on a call. "Go to the table, no, the other table." Here's how to add page numbers to PDF files so everyone is on the same page – literally – with the position and style you want.

## How to add page numbers to PDF files

1. Open [Page numbers]({home}/add-page-numbers-to-pdf/) and add your PDF (or several).
2. Pick the **Position**: bottom centre is the usual choice, top right is common in legal and academic work.
3. Pick the **Format**: `1`, `Page 1`, `1 of 12` or `Page 1 of 12`.
4. Set **Start at** if you need to start page numbers from 2 or any other number.
5. Turn on **Skip the first page (cover)** if needed.
6. Download the numbered file.

[[cta:add-page-numbers-to-pdf|Add Page Numbers|Number your pages exactly how you want.]]

## Page 1 of 10 in PDF

The "Page 1 of 12" format fills in the total for you, so you get page 1 of 10 in PDF style without counting anything. It's handy for contracts and forms, where a missing page should be obvious.

## Skip first page numbering on the cover

Covers usually don't get a number. Turn on the skip option and the cover stays clean while numbering continues on the next page. If you also have a certificate, declaration and index that shouldn't be counted, split them off first, number the rest from 1, and join everything again – our [splitting guide]({home}/how-to-split-pdf-pages/) and [merging guide]({home}/how-to-merge-pdf-files/) show both steps.

## Page numbers bottom center (and other styles)

| Document | Common choice |
|---|---|
| College project or thesis | Page numbers bottom center, format "1" |
| Contract or agreement | Bottom right, "Page 1 of 12" |
| Court bundle | Top right, or [Bates numbering]({home}/bates-numbering/) |
| Book or booklet | Bottom outside corner |

Always check your college or court format guide first.

## Number PDF pages after merging

If the document is made of several files, merge them first, then number PDF pages once so the count runs through the whole thing.

## Add page numbers without Acrobat

You don't need Acrobat to paginate PDF files. This tool works in your browser and doesn't upload your document, so you can add page numbers without Acrobat on any office or college computer. It's free, with no watermark: add page numbers to PDF online free as often as you like.

## Why page numbers matter more than you think

Numbers aren't just decoration. When a document is printed and dropped, they're how you put it back together. In meetings and reviews they let people say "see page 14" instead of describing a paragraph. In legal and government submissions, a missing page number can make a reviewer suspect a page is missing. And when a PDF is split into parts for uploading, numbered pages make it easy to check that nothing was lost along the way.

## How to add page numbers to PDF for free: details that look professional

- Use the same font size as your body text, or one size smaller.
- Leave the default margin; numbers too close to the edge get cut off when printing.
- After numbering, update your table of contents so it matches.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Can I skip the cover page?
Yes. Turn on "Skip the first page (cover)".

??? Can I start numbering from a different number?
Yes. Set the number in "Start at".

??? Will the numbers print?
Yes. They're part of the page.

??? Are my files uploaded?
No. Numbers are added in your browser.
