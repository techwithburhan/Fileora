---
title: How to Reverse PDF Pages, Duplicate Pages or Insert Blank Pages
slug: how-to-reverse-pdf-pages
seo_title: How to Reverse PDF Pages or Insert Blank Pages
description: How to reverse PDF pages for free: flip the page order of a scan, duplicate pages for printing, or insert blank pages after every page or every few pages.
focus_keyword: how to reverse pdf pages
category: PDF Tools
tools: reverse-pdf-pages, interleave-pdf, organize-pdf
keywords: how to reverse pdf pages | reverse pdf page order | flip pdf page order | insert blank page in pdf | add blank pages between pdf pages | duplicate pdf pages | scanned pdf in reverse order | add blank page for double sided printing | reverse pdf online free | how to reverse pdf pages for free
titles: How to Reverse PDF Pages or Insert Blank Pages | Reverse PDF Page Order in One Click | Flip PDF Page Order of a Backwards Scan | Insert Blank Page in PDF Anywhere | Add Blank Pages Between PDF Pages for Notes | Duplicate PDF Pages for Printing Copies | Scanned PDF in Reverse Order? Fix It | Add Blank Page for Double Sided Printing | Reverse PDF Online Free, No Upload | Page Tricks for Printing and Binding
---
Feed a stack of paper face-up into a scanner and the PDF comes out last page first. Or you want blank pages between slides for notes, or two copies of every page for a handout. Here's how to reverse PDF pages, duplicate them or insert blanks, all with one tool.

## How to reverse PDF pages

1. Open [Reverse & Insert Pages]({home}/reverse-pdf-pages/) and add your PDF.
2. Under **What to do**, choose **Reverse order**.
3. Download. The last page is now first.

That's all it takes to flip PDF page order.

[[cta:reverse-pdf-pages|Reverse & Insert Pages|Reverse the order, duplicate or add blank pages.]]

## Scanned PDF in reverse order

This is the most common reason people need to reverse PDF page order: a scanner or phone app that captured pages from the bottom of the stack. One click fixes the whole file; no dragging 40 thumbnails around.

## Insert blank page in PDF

Choose **Add blank pages**, then **Where**:

- **After every page** – space for handwritten notes after each slide.
- **After every N pages** – blanks between chapters or sections.
- **At the start** or **At the end** – a cover sheet or a closing page.

Set **Blank pages each time** for more than one. That's how to insert blank page in PDF documents without a desktop editor.

## Add blank page for double sided printing

When printing double-sided, a chapter that ends on a right-hand page pushes the next chapter onto the back. Adding a blank page where needed keeps chapters starting on the right. It's a small trick to add blank page for double sided printing that makes reports look properly bound.

## Duplicate PDF pages

Printing small cards or labels two to a sheet? Duplicating pages first means one print run gives you both copies.

Choose **Duplicate** and set **Copies of each page**, then the **Order**: 1,1,2,2,3,3 (each page repeated) or 1,2,3,1,2,3 (whole sets). To duplicate PDF pages for two-up cutting or handouts saves running the printer twice.

## Add blank pages between PDF pages for exam practice

Teachers and students sometimes add blank pages between PDF pages of question papers to write answers. "After every page" with one blank does exactly that.

## Check before you print

After reversing or inserting pages, scroll through the result once. Look at the first and last pages, and if you added blanks for double-sided printing, count that each chapter starts on an odd page. Then add page numbers if the document needs them – numbering after reorganising keeps them correct.

## Related fixes

- Pages scanned in two passes (fronts, then backs)? Use [Interleave PDF]({home}/interleave-pdf/).
- Need to move just a few pages? Our guide to [organizing PDF pages]({home}/how-to-organize-pdf-pages/) is quicker.
- Blank pages you don't want? See [removing blank pages]({home}/how-to-remove-blank-pages-from-pdf/).

## Reverse PDF online free and privately

All of this happens in your browser, so the file isn't uploaded – reverse PDF online free, with no account and no watermark.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Can I reverse only some pages?
This tool reverses the whole file. Use Organize PDF to move individual pages.

??? Can I add more than one blank page at a time?
Yes. Set "Blank pages each time".

??? What's the difference between the two duplicate orders?
1,1,2,2 repeats each page; 1,2,3,1,2,3 repeats the whole set.

??? Are my files uploaded?
No. Everything happens in your browser.
