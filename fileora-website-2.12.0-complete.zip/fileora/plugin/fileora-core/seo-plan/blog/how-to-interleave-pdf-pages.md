---
title: How to Interleave PDF Pages (Combine Front and Back Scans)
slug: how-to-interleave-pdf-pages
seo_title: How to Interleave PDF Pages – Fronts and Backs
description: How to interleave PDF pages for free: combine a scan of the fronts and a scan of the backs into one double-sided PDF, even when the backs are reversed.
focus_keyword: how to interleave pdf pages
category: PDF Tools
tools: interleave-pdf, reverse-pdf-pages, merge-pdf
keywords: how to interleave pdf pages | interleave pdf online free | merge odd and even pages pdf | combine front and back scans | double sided scan with single sided scanner | collate pdf pages | alternate merge pdf | scan both sides into one pdf | back pages in reverse order | how to interleave pdf pages for free
titles: How to Interleave PDF Pages – Fronts and Backs | Interleave PDF Online Free in One Step | Merge Odd and Even Pages PDF Correctly | Combine Front and Back Scans Into One File | Double Sided Scan With a Single Sided Scanner | Collate PDF Pages Without Shuffling by Hand | Alternate Merge PDF: 1, 2, 3, 4 in Order | Scan Both Sides Into One PDF | Back Pages in Reverse Order? Tick One Box | The Smart Way to Scan Double-Sided Documents
---
Your scanner only scans one side. So you scan the fronts of a 20-sheet document, flip the stack, scan the backs – and end up with two PDFs that need to become one, with pages alternating front, back, front, back. Here's how to interleave PDF pages without dragging 40 thumbnails around.

## What interleaving means

Merging puts one file after the other: 1, 3, 5… then 2, 4, 6…. Interleaving takes one page from each file in turn: 1, 2, 3, 4, 5, 6. It's also called an alternate merge – an alternate merge PDF tool is exactly what you need to merge odd and even pages PDF files from a one-sided scanner.

## How to interleave PDF pages

1. Open [Interleave PDF]({home}/interleave-pdf/).
2. Add the **front sides** first (pages 1, 3, 5…), then the **back sides** (pages 2, 4, 6…).
3. Keep **The back sides are in reverse order** ticked if you flipped the whole stack to scan the backs – that's the usual case.
4. Download the combined PDF.

[[cta:interleave-pdf|Interleave PDF|Shuffle front and back scans into the right order.]]

## Back pages in reverse order

When you turn the whole stack over, the last sheet's back is scanned first. So the backs come out in reverse: 20, 19, 18…. The tick box handles it. If you instead turned each sheet individually, untick it.

## Double sided scan with single sided scanner: the workflow

1. Scan all fronts into one PDF.
2. Turn the stack over (don't reshuffle), scan all backs into a second PDF.
3. Interleave, with "reverse order" ticked.
4. Check pages 1–4 to confirm.

This is the easiest way to scan both sides into one PDF on home and office scanners without a duplex feeder.

## What if the counts don't match?

If one file has more pages – a blank back you skipped, say – the extra pages go at the end, and the result tells you. Fix any leftover order with our guide to [organizing PDF pages]({home}/how-to-organize-pdf-pages/).

## Collate PDF pages from other sources

It's not just scans. To collate PDF pages of questions and answers, or English and translated pages, interleave the two files.

## Combine front and back scans vs merging

If you simply want one file after the other, see [how to merge PDF files]({home}/how-to-merge-pdf-files/). If all the pages are in one file but in reverse, our [reverse pages guide]({home}/how-to-reverse-pdf-pages/) fixes that in one click.

## Interleave PDF online free, privately

The pages are combined in your browser – nothing uploaded, no account, no watermark. That's how to interleave PDF pages for free.

## Avoiding common scanning mistakes

| Mistake | Result | Fix |
|---|---|---|
| Stack reshuffled between passes | Random order | Keep the stack together |
| Backs scanned upside down | Every second page inverted | [Rotate even pages 180°]({home}/how-to-rotate-pdf-pages/) |
| Blank backs skipped | Counts don't match | Scan blanks too, remove them later |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Which file goes first?
The front sides (1, 3, 5…), then the back sides.

??? What does "reverse order" mean?
Tick it if you flipped the whole stack to scan the backs, so they came out last page first.

??? What if the files have different page counts?
Extra pages are added at the end.

??? Are my files uploaded?
No. Everything happens in your browser.
