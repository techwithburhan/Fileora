---
title: How to Add a Header and Footer to a PDF (Titles, Dates, Names)
slug: how-to-add-header-and-footer-to-pdf
seo_title: How to Add Header and Footer to PDF Online Free
description: How to add header and footer to PDF files for free: put a title, date, company or roll number at the top or bottom of every page, left, centre or right.
focus_keyword: how to add header and footer to pdf
category: PDF Tools
tools: add-header-and-footer-to-pdf, add-page-numbers-to-pdf, watermark-pdf
keywords: how to add header and footer to pdf | add header to pdf online free | add footer to pdf | add text to top of every pdf page | add date to pdf pages | add name and roll number to pdf | pdf header and footer without acrobat | add company name to pdf pages | skip header on first page | how to add header and footer to pdf for free
titles: How to Add Header and Footer to PDF Online Free | Add Header to PDF Online Free, Every Page | Add Footer to PDF With Your Name or Date | Add Text to Top of Every PDF Page | Add Date to PDF Pages for Versions | Add Name and Roll Number to PDF Assignments | PDF Header and Footer Without Acrobat | Add Company Name to PDF Pages | Skip Header on First Page (the Cover) | Label Every Page of a Report in One Step
---
Teachers want your name and roll number on every page. Clients want the project name and date. Offices want "Confidential – Internal" at the top. Typing it into each page isn't an option once the PDF exists. Here's how to add header and footer to PDF files in one step.

## How to add header and footer to PDF files

1. Open [Header & Footer]({home}/add-header-and-footer-to-pdf/) and add your PDF.
2. Type the **Header** text and choose its position: left, centre or right.
3. Type the **Footer** text and its position.
4. Set the **Text size**, and turn on **Skip the first page** if your cover should stay clean.
5. Download.

You can fill just the header, just the footer, or both.

[[cta:add-header-and-footer-to-pdf|Header & Footer|Put text at the top and bottom of every page.]]

## Add name and roll number to PDF assignments

A header like "Riya Sharma · Roll No. 23 · Class XII-B" in the right corner and a footer with the subject helps teachers when pages get separated. To add name and roll number to PDF homework quickly, set it once and every page gets it.

## Add date to PDF pages and versions

Drafts go through rounds. A footer like "Draft 3 – 21 Oct 2026" makes it obvious which version someone printed. To add date to PDF pages this way prevents a lot of "which one is final?" confusion.

## Add company name to PDF pages

Put your company name on the left of the header and the client's name on the right – a simple way to add company name to PDF pages without a letterhead template.

## Add text to top of every PDF page vs watermarking

A header sits quietly in the margin. If you want text across the middle of the page – CONFIDENTIAL, DRAFT – use a watermark instead; our [PDF watermark guide]({home}/how-to-add-watermark-to-pdf/) covers that.

## Page numbers too?

Numbers have their own tool with formats like "Page 1 of 12": see [adding page numbers to a PDF]({home}/how-to-add-page-numbers-to-pdf/). Use a centre footer for numbers and left or right for your text so they don't overlap.

## Keep it short and consistent

Headers and footers work best when they're quiet: one short line, a small font, and the same position on every page. Long sentences crowd the margin and can collide with page numbers or a letterhead. If a page already has text near the edge – a scanned form, for example – try a smaller text size or move the header to the opposite corner.

## Skip header on first page

Covers and title pages usually look better clean. Turn on the option to skip header on first page and footers start on page 2.

## PDF header and footer without Acrobat

No software needed. This is a free way to add header to PDF online free on any computer, and add footer to PDF on a phone too. The file is processed in your browser and never uploaded.

## How to add header and footer to PDF for free: layout ideas

| Document | Header | Footer |
|---|---|---|
| Assignment | Name, roll no. (right) | Subject (left) |
| Client report | Client (left), project (right) | Date (left) |
| Internal memo | "Internal" (centre) | Version (right) |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Can I skip the cover page?
Yes. Turn on "Skip the first page".

??? Can I add only a footer?
Yes. Leave the header empty.

??? Will the text print?
Yes. It's part of each page.

??? Are my files uploaded?
No. Text is added in your browser.
