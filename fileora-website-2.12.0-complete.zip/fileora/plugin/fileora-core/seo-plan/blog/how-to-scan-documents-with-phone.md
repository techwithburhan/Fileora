---
title: How to Scan Documents With Your Phone and Save as PDF
slug: how-to-scan-documents-with-phone
seo_title: How to Scan Documents With Your Phone to PDF
description: How to scan documents with your phone and save them as a clean PDF: light, angle, multi-page scans and file size, using a free scanner that needs no app.
focus_keyword: scan documents with your phone
category: PDF Tools
tools: scan-to-pdf, compress-pdf, jpg-to-pdf
keywords: scan documents with your phone | scan to pdf online free | phone scanner without app | how to scan documents to pdf | scan multiple pages into one pdf | mobile document scanner | scan to pdf on android | scan to pdf on iphone | make scanned document clear | free pdf scanner online
titles: How to Scan Documents With Your Phone to PDF | Scan to PDF Online Free, Straight From the Camera | Phone Scanner Without App: It Works in Your Browser | Scan Multiple Pages Into One PDF | Mobile Document Scanner for Forms and Certificates | Scan to PDF on Android in Under a Minute | Scan to PDF on iPhone Without Downloading Anything | Make Scanned Document Clear: Light and Angle Tips | Free PDF Scanner Online With a Clean White Look | No Scanner at Home? Use Your Phone
---
Hardly anyone has a scanner at home any more, but almost everyone has a phone with a better camera than an old office scanner. The trick is turning a photo of paper into something that looks scanned: white page, dark text, straight edges. Here's how to scan documents with your phone and save them as a proper PDF.

## How to scan documents with your phone: step by step

1. Open [Scan to PDF]({home}/scan-to-pdf/) in your phone's browser.
2. Tap the box and take a photo of the first page, or choose photos you already took.
3. Add the remaining pages and drag them into order.
4. Choose the **Look**: **Document** for text (white paper, dark letters), **Greyscale** to remove yellow light, **Original** for colour certificates.
5. Create the PDF and download.

[[cta:scan-to-pdf|Scan to PDF|Your phone camera as a document scanner. No app.]]

## Phone scanner without app

Think of it as a mobile document scanner that lives in a web page.

You don't need to install a scanning app. This phone scanner without app works in Chrome or Safari, uses your camera directly, and processes the pages on your phone. Nothing is uploaded – important when you're scanning ID cards or medical papers.

## Make scanned document clear: five habits

- **Light**: daylight or a bright room. No flash.
- **Angle**: phone parallel to the paper, straight above.
- **Contrast**: white paper on a dark table.
- **Focus**: tap on the text before you shoot.
- **Frame**: the whole page with a small border.

Get these right and the Document look will make scanned document clear enough to pass any upload check.

## Scan multiple pages into one PDF

Add each page as you go and you'll scan multiple pages into one PDF in order. For double-sided papers, scan front, then back, for each sheet. Wrong order? Drag the thumbnails.

## Scan to PDF on Android and iPhone

To scan to PDF on Android, open the page in Chrome and allow camera access when asked. To scan to PDF on iPhone, use Safari the same way. Both save the PDF to your downloads.

## Free PDF scanner online vs plain photos

If your photos are already sharp and you just want them in a PDF unchanged, [JPG to PDF]({home}/jpg-to-pdf/) keeps them exactly as they are – see [our JPG to PDF guide]({home}/how-to-convert-jpg-to-pdf/). Scan to PDF is the better choice when you want that clean, scanned look. Either way it's a free PDF scanner online, with no sign-up.

## What changes with the Document look

The Document setting raises contrast, turns the paper white and makes faint pencil or ballpoint darker. It also removes colour casts from tube lights and yellow bulbs. For a colourful certificate with a seal or a photo, use Original instead so the colours stay true.

## Scans too big for the portal?

Phone scans are big. [Compress the PDF]({home}/how-to-compress-pdf/) before uploading; Balanced usually gets a multi-page scan well under 1 MB.

## Scan to PDF online free: what to scan

Marksheets, certificates, signed forms, rent agreements, bills and receipts. For ID cards you want printed at real size, try ID Card Print instead.

More in [PDF Tools]({home}/category/pdf-tools/).

??? How to scan documents to PDF without a scanner or an app?
Use your phone camera with Scan to PDF in the browser. No scanner or app is needed.

??? How do I make the scan look clean and white?
Choose the Document look and shoot in good light, straight from above.

??? Can I scan several pages into one PDF?
Yes. Add each page; they become one PDF.

??? Are my scans uploaded?
No. The PDF is made on your phone.
