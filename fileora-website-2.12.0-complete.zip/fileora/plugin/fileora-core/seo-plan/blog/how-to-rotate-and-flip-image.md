---
title: How to Rotate and Flip an Image (Fix Sideways and Mirrored Photos)
slug: how-to-rotate-and-flip-image
seo_title: How to Rotate and Flip Image Online Free
description: How to rotate and flip image files for free: turn sideways photos 90° or 180°, mirror selfies and flip pictures upside down, many at once, in your browser.
focus_keyword: how to rotate and flip image
category: Image Tools
tools: rotate-image, crop-image, resize-image
keywords: how to rotate and flip image | rotate image online free | flip image horizontally | mirror image online | rotate photo 90 degrees | flip image upside down | fix sideways photo | unmirror selfie | rotate multiple images | how to rotate image for free
titles: How to Rotate and Flip Image Online Free | Rotate Image Online Free, Saved for Good | Flip Image Horizontally in One Click | Mirror Image Online for Text and Selfies | Rotate Photo 90 Degrees Left or Right | Flip Image Upside Down Without an Editor | Fix Sideways Photo Before You Upload It | Unmirror Selfie Text That Reads Backwards | Rotate Multiple Images at Once | Sideways in the Form, Upright on Your Phone?
---
Your photo looks fine in the gallery, but uploads sideways. Your selfie shows the text on your T-shirt backwards. A scanned picture came out upside down. All three are one click away from fixed. Here's how to rotate and flip image files for good.

## How to rotate and flip image files

1. Open [Rotate & Flip Image]({home}/rotate-image/) and add your pictures – you can rotate multiple images at once.
2. Choose **Rotate**: none, 90° right, 180° or 90° left.
3. Turn on **Mirror left to right** to flip image horizontally, or **Flip upside down** for a vertical flip.
4. Download.

[[cta:rotate-image|Rotate & Flip Image|Turn and mirror photos in your browser.]]

## Fix sideways photo uploads

Phones often save a photo in one direction and add a tag saying "show this rotated". Your gallery reads the tag; many websites don't. That's why a picture can look right on your phone and sideways in a form. To fix sideways photo problems permanently, rotate it here: the pixels are actually turned, so every app shows it the same way.

## Rotate photo 90 degrees

"90° right" turns the picture clockwise, "90° left" anticlockwise. Use them to rotate photo 90 degrees when a landscape shot was taken holding the phone upright – or the other way round.

## Mirror image online: unmirror selfie

Front cameras show a mirror view, and some save it that way. Text reads backwards, and your parting is on the "wrong" side. Mirror left to right to unmirror selfie pictures. It's the same switch to mirror image online for design work or reversed scans.

## Flip image upside down

Turn on **Flip upside down** for a vertical mirror, or use 180° to turn the picture all the way round. They're different: flipping mirrors the picture, rotating turns it. For a photo that's simply upside down, 180° is what you want.

## Common situations

- **Exam or job form photo uploads sideways** – rotate it here, then check the form preview again.
- **Document photos taken in landscape** – turn them upright before putting them into a PDF.
- **Product photos for a marketplace** – a consistent, upright orientation makes a listing look professional.
- **Old scanned prints** – scanners don't know which way is up; rotate after scanning.

## Rotate image online free, privately

Everything happens in your browser: your photos aren't uploaded, there's no sign-up and no watermark. This is how to rotate image for free on any phone or computer.

## Next steps

- Crop to a clean shape: [how to crop images]({home}/how-to-crop-image-online/).
- Set exact pixels: [how to resize images]({home}/how-to-resize-image-online/).
- PDF pages sideways too? See [rotating PDF pages]({home}/how-to-rotate-pdf-pages/).

## Rotate vs flip at a glance

| Problem | Setting |
|---|---|
| Photo lying on its side | 90° right or left |
| Photo upside down | 180° |
| Text in a selfie backwards | Mirror left to right |
| Reflection or reversed scan | Flip upside down |

More in [Image Tools]({home}/category/image-tools/).

??? Will rotating reduce quality?
Turning by 90° or 180° keeps the picture sharp.

??? Can I rotate several photos at once?
Yes. Add them all; the same rotation is applied to each.

??? What's the difference between flipping and rotating?
Flipping mirrors the picture; rotating turns it.

??? Are my photos uploaded?
No. Everything happens in your browser.
