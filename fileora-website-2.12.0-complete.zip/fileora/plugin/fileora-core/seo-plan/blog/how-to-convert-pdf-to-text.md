---
title: How to Convert PDF to Text (Copy All the Words, Cleanly)
slug: how-to-convert-pdf-to-text
seo_title: How to Convert PDF to Text – Free TXT Converter
description: How to convert PDF to text for free: copy all the words out of a PDF into a clean .txt file with joined paragraphs and page markers, without uploading the file.
focus_keyword: how to convert pdf to text
category: PDF Tools
tools: pdf-to-text, ocr-pdf, pdf-to-markdown
keywords: how to convert pdf to text | pdf to text converter free | extract text from pdf | copy text from pdf | pdf to txt | convert pdf to plain text | extract text from pdf online | pdf to text without losing paragraphs | copy text from scanned pdf | how to convert pdf to text for free
titles: How to Convert PDF to Text – Free TXT Converter | PDF to Text Converter Free, No Upload | Extract Text From PDF in One Click | Copy Text From PDF Without Broken Lines | PDF to TXT for Notes, Translation and AI Tools | Convert PDF to Plain Text on Any Device | Extract Text From PDF Online, Privately | PDF to Text Without Losing Paragraphs | Copy Text From Scanned PDF: Use OCR First | When You Just Need the Words, Not the Layout
---
You try to copy a paragraph from a PDF and get every line as a separate sentence, hyphens in the middle of words and page numbers stuck in the text. If you've ever tried to copy text from PDF files this way, you know the mess. When you just need the words, here's how to convert PDF to text cleanly.

## How to convert PDF to text

1. Open [PDF to Text]({home}/pdf-to-text/) and add the PDF.
2. Turn on **Join lines into paragraphs** so sentences aren't broken at every line ending.
3. Turn on **Mark where each page starts** if you want to know which page a passage came from.
4. Convert and download the .txt file.

[[cta:pdf-to-text|PDF to Text|Copy all the words from a PDF into a .txt file.]]

## PDF to text without losing paragraphs

The paragraph option is what makes this better than select-all and copy. PDFs store text as positioned lines, not paragraphs. Joining them gives you PDF to text without losing paragraphs, ready to paste into an email, a notes app or a translator.

## What PDF to TXT is good for

- **Translation**: paste clean text into a translator instead of a messy copy.
- **AI tools and chatbots**: they work better with plain text than a pasted PDF.
- **Word counts and search**: open the .txt anywhere.
- **Accessibility**: screen-reader users often prefer plain text.

A plain .txt file opens on every device, so PDF to TXT is the most portable way to extract text from PDF documents.

## Copy text from scanned PDF

Scanned PDFs contain pictures of words, not words. If you can't select text in your PDF, a text extractor finds nothing. To copy text from scanned PDF files, run [OCR PDF]({home}/ocr-pdf/) first and choose **Text file** as the output – it supports Hindi and many Indian languages.

## Want headings and lists too?

Plain text loses structure. If you want headings, bullet lists and tables kept as text, use [PDF to Markdown]({home}/pdf-to-markdown/) instead. To keep the full layout and edit it, convert to Word.

## Extract text from PDF online, privately

This is a PDF to text converter free of uploads: it runs in your browser, so contracts, letters and reports never leave your device. You can extract text from PDF online without an account and without a watermark – there's nothing to watermark in a text file anyway.

## Convert PDF to plain text: troubleshooting

| Problem | Cause | Fix |
|---|---|---|
| Empty result | It's a scan | Use OCR PDF first |
| Odd characters in Hindi | Old non-Unicode fonts | Use OCR PDF on the pages |
| Words run together | Unusual layout | Turn off joining lines |
| Columns mixed up | Multi-column page | Copy one column at a time |

## How to convert PDF to text for free: one tip

If you only need one page, take it out first with [Split PDF]({home}/split-pdf/) – see [how to split PDF pages]({home}/how-to-split-pdf-pages/) – and convert just that page.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Does it work on scanned PDFs?
No, scans contain pictures. Use OCR PDF with the Text file output.

??? Can I keep page numbers?
Yes. Turn on "Mark where each page starts".

??? Will tables be kept?
Tables become plain lines of text. Use PDF to Markdown or PDF to Excel for tables.

??? Are my files uploaded?
No. Text is extracted in your browser.
