---
title: What Is Bates Numbering, and How to Add It to PDFs
slug: what-is-bates-numbering-pdf
seo_title: How to Add Bates Numbering to PDF Files, Free
description: What Bates numbering is and how to add it to PDF files for free: a prefix, running number and suffix across many documents, for legal and audit bundles.
focus_keyword: bates numbering
category: PDF Tools
tools: bates-numbering, add-page-numbers-to-pdf, merge-pdf
keywords: bates numbering | what is bates numbering | add bates numbers to pdf | bates numbering online free | bates stamp pdf | legal document numbering | bates numbering multiple pdfs | bates prefix and suffix | court document page numbering | bates numbering without acrobat
titles: How to Add Bates Numbering to PDF Files, Free | What Is Bates Numbering? A Plain Explanation | Add Bates Numbers to PDF Bundles | Bates Numbering Online Free, No Upload | Bates Stamp PDF Pages With Prefix and Digits | Legal Document Numbering Made Simple | Bates Numbering Multiple PDFs in One Run | Bates Prefix and Suffix: How to Choose Them | Court Document Page Numbering That Holds Up | Bates Numbering Without Acrobat
---
Lawyers, auditors and compliance teams need to refer to one exact page among thousands: "see ABC000417". That's Bates numbering. If you've been asked to "Bates the bundle" and aren't sure what it means, here's a plain explanation – and how to add Bates numbering to your PDFs in minutes.

## What is Bates numbering?

A unique identifier stamped on every page of a set of documents, running continuously across all files. It usually has a **prefix** (a case or client code), a **number** padded with zeros, and sometimes a **suffix**: `ABC000001`, `ABC000002`…. Unlike normal page numbers, it doesn't restart in each document. That's what makes it legal document numbering you can cite precisely.

## How to add Bates numbers to PDF files

1. Open [Bates Numbering]({home}/bates-numbering/) and add your PDFs in the order they should be numbered.
2. Set the **Prefix** (e.g. `ABC`), **First number**, **Digits** (6 gives 000001) and an optional **Suffix**.
3. Choose the **Position** and **Text size**.
4. Download the numbered files.

Numbers continue from one file to the next, which is what makes Bates numbering multiple PDFs in one run possible.

[[cta:bates-numbering|Bates Numbering|Number pages across many PDFs with a prefix and digits.]]

## Bates prefix and suffix: choosing them

- **Prefix**: a short code for the matter, party or source – `PLT` for plaintiff, a client code, a case number.
- **Digits**: enough for the whole production; 6 digits covers 999,999 pages.
- **Suffix**: optional, e.g. `-CONF` for confidential sets.

Agree the format with the other side or the court before you start, and use the same one for every later production in the matter.

## Bates stamp PDF: position

Bottom right is the convention, away from content. A bates stamp PDF number should never cover text; use a small margin or a smaller text size if pages are full.

## Court document page numbering vs normal page numbers

For a single report, ordinary numbers are simpler – see [adding page numbers to a PDF]({home}/how-to-add-page-numbers-to-pdf/). Court document page numbering for productions and bundles usually calls for Bates numbers. Some bundles use both: Bates bottom right, the document's own page numbers bottom centre.

## Prepare the set first

Put documents in order, then number. If they're many small files, [merging them]({home}/how-to-merge-pdf-files/) into logical groups first keeps the production tidy.

## Bates numbering without Acrobat

Acrobat Pro has Bates numbering, but you don't need it. Bates numbering online free, in your browser, with no upload – important for privileged and confidential material. That's Bates numbering without Acrobat.

## Keep a production log

Alongside the numbered files, keep a simple index: the Bates range for each document (ABC000001–ABC000014: Lease agreement), the date produced and who received it. When someone later asks about "page 417", you'll know immediately which document and which version it came from. A spreadsheet is enough.

## Quick format examples

| Use | Example |
|---|---|
| Plaintiff production | PLT000001 |
| Client audit set | CLI-2026-00001 |
| Confidential subset | ABC000001-CONF |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Do Bates numbers restart in each file?
No. They continue across all the files in the order you add them.

??? How many digits should I use?
Enough for the total pages; 6 is common.

??? Can I add a suffix?
Yes, optionally.

??? Are my files uploaded?
No. Numbering happens in your browser.
