---
title: How to Make a Booklet From a PDF (Print, Fold, Done)
slug: how-to-make-a-booklet-from-pdf
seo_title: How to Make a Booklet From PDF – Print and Fold
description: How to make a booklet from PDF files for free: rearrange pages into booklet order, print double-sided and fold into an A5 booklet. Right-to-left booklets too.
focus_keyword: how to make a booklet from pdf
category: PDF Tools
tools: pdf-booklet-maker, n-up-pdf, add-page-numbers-to-pdf
keywords: how to make a booklet from pdf | pdf booklet maker online free | print pdf as booklet | booklet printing a4 to a5 | saddle stitch booklet pdf | print a booklet at home | booklet page order | fold pdf into booklet | right to left booklet | how to make a booklet from pdf for free
titles: How to Make a Booklet From PDF – Print and Fold | PDF Booklet Maker Online Free | Print PDF as Booklet on Any Printer | Booklet Printing A4 to A5, Step by Step | Saddle Stitch Booklet PDF for Events and Shops | Print a Booklet at Home in Minutes | Booklet Page Order Explained Simply | Fold PDF Into Booklet Without Mistakes | Right to Left Booklet for Urdu and Arabic | Wedding Cards, Menus and Programmes as Booklets
---
Event programmes, menus, small manuals, wedding card inserts, a school magazine: a folded booklet looks far more finished than a stapled stack. The hard part is the page order, which isn't 1, 2, 3, 4 at all. Here's how to make a booklet from PDF files and print PDF as booklet pages without doing that maths.

## Booklet page order, explained

When you fold a sheet in half, one side of it holds the last page and the first page; the other side holds page 2 and the second-to-last. For an 8-page booklet, the sheets print as 8|1, 2|7, 6|3, 4|5. The [Booklet Maker]({home}/pdf-booklet-maker/) works this out for you, adding blank pages at the end if the total isn't a multiple of four.

## How to make a booklet from PDF

1. Open [Booklet Maker]({home}/pdf-booklet-maker/) and add your PDF.
2. Choose **Print on**: A4 (pages shrink to A5), US Letter, or twice the page size.
3. Turn on **Right-to-left booklet** for Urdu, Arabic and other right-to-left documents.
4. Download the booklet PDF.
5. Print double-sided, **flipping on the short edge**, then fold the stack in half and staple along the fold.

[[cta:pdf-booklet-maker|Booklet Maker|Rearrange pages for printing and folding.]]

## Booklet printing A4 to A5

The usual home setup: your A5-sized pages are placed two per A4 sheet. Booklet printing A4 to A5 gives a handy, pocket-sized booklet from an ordinary printer.

## Print a booklet at home: the double-sided setting

Most mistakes happen here. Choose **two-sided**, and **flip on short edge** (sometimes called "short-edge binding"). If your printer can't print double-sided, print odd pages, turn the stack over, and print even pages – test with two sheets first.

## Saddle stitch booklet PDF

Staples through the fold are called saddle stitching. For a saddle stitch booklet PDF that a print shop will accept, keep the total page count at 8, 12, 16 or more in fours, and leave a little extra margin on the outside edges, because inner sheets stick out slightly after folding.

## Fold PDF into booklet: tips

- Add page numbers before making the booklet: see [adding page numbers to a PDF]({home}/how-to-add-page-numbers-to-pdf/).
- Fold the whole stack at once and press firmly with a ruler.
- For more than about 40 pages, make two booklets or use perfect binding at a shop.

## Choosing paper

Ordinary 70–80 gsm paper is fine for internal booklets. For something people will keep – a programme, a menu, a wedding insert – 100 gsm feels noticeably better, and a slightly thicker cover sheet makes it look printed rather than photocopied. Very thick paper cracks along the fold, so score the fold with a ruler and a blunt edge first.

## Right to left booklet

For documents read from right to left, turn on the option and the pages are arranged so the booklet opens from the other side.

## Booklet or N-up?

If you just want several pages per sheet to read flat, our [guide to printing multiple pages per sheet]({home}/how-to-print-multiple-pages-per-sheet-pdf/) is the better fit.

## Free and private

This PDF booklet maker online free tool builds the file in your browser – nothing is uploaded. That's how to make a booklet from PDF for free.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Why does my booklet have blank pages at the end?
Booklets need a multiple of four pages; blanks fill the gap.

??? Which way do I flip when printing?
On the short edge.

??? Can I make an A5 booklet on A4 paper?
Yes. Choose A4 and the pages shrink to A5.

??? Are my files uploaded?
No. The booklet is made in your browser.
