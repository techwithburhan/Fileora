---
title: How to Split Scanned Pages in Half (Book Scans to Single Pages)
slug: how-to-split-scanned-pages-in-half
seo_title: How to Split Scanned Pages in Half – Book Scans
description: How to split scanned pages in half for free: cut two-page book and A3 scans into single pages, keep covers whole, and handle right-to-left books.
focus_keyword: how to split scanned pages in half
category: PDF Tools
tools: split-scanned-pages-in-half, crop-pdf, ocr-pdf
keywords: how to split scanned pages in half | split pdf page in half | cut pdf pages down the middle | split two page scan | book scan to single pages | split a3 to a4 pdf | divide pdf page vertically | split double page spread pdf | split scanned book pdf | how to split scanned pages in half for free
titles: How to Split Scanned Pages in Half – Book Scans | Split PDF Page in Half Down the Middle | Cut PDF Pages Down the Middle in Seconds | Split Two Page Scan Into Single Pages | Book Scan to Single Pages for Reading and OCR | Split A3 to A4 PDF Pages | Divide PDF Page Vertically or Horizontally | Split Double Page Spread PDF Files | Split Scanned Book PDF, Covers Kept Whole | Right-to-Left Books: Split in the Correct Order
---
Scanning a book flat on the glass gives you two pages per image. That's fine until you want to read it on a phone, print single pages, or run text recognition. Here's how to split scanned pages in half – in other words, cut PDF pages down the middle – so each book page becomes its own PDF page.

## How to split scanned pages in half

1. Open [Split Pages in Half]({home}/split-scanned-pages-in-half/) and add your PDF.
2. Choose **Cut**: **Down the middle** for open books and spreads, **Across the middle** for pages stacked top and bottom.
3. Tick **Keep the first page whole (cover)** and **Keep the last page whole (back cover)** if your covers were scanned as single pages.
4. For Arabic, Urdu or Japanese books, tick **Right page first**.
5. Download.

[[cta:split-scanned-pages-in-half|Split Pages in Half|Cut two-page scans into single pages.]]

## Split two page scan files from books

To split two page scan images is the most common use.

## Book scan to single pages

The usual case: you scanned a textbook or notebook open on the glass. Cut down the middle and you get book scan to single pages output in reading order. To split scanned book PDF files with a cover, keep the first page whole.

## Split A3 to A4 PDF

An A3 sheet is two A4 sheets side by side. To split A3 to A4 PDF pages – drawings, newspapers, broadsheets – cut down the middle and each half becomes an A4-shaped page.

## Divide PDF page vertically or across

"Down the middle" divides PDF page vertically into left and right halves. "Across the middle" splits top and bottom – useful for forms or slips printed two per page.

## Split double page spread PDF

Magazine and brochure PDFs exported as spreads show two pages side by side. To split double page spread PDF files into normal pages makes them readable on phones and easier to print.

## Right page first

In right-to-left books, the right-hand page comes first. Tick the option and the halves are placed right, then left.

## Clean up before or after

- Uneven dark edges from the book spine? Trim them with our [PDF cropping guide]({home}/how-to-crop-pdf/).
- Want to search or copy the text? Run the split file through [OCR PDF]({home}/ocr-pdf/).
- Want everything A4? See [resizing PDF pages]({home}/how-to-resize-pdf-pages-to-a4/).

## Notebooks and exam answer sheets

Students often scan their notebooks two pages at a time to save effort. Splitting afterwards gives a clean, page-by-page PDF that teachers can read on a phone, and that prints properly on A4. The same goes for answer sheets photographed as spreads.

## Tips for better book scans

- Press the book flat gently; a curved page near the spine distorts text.
- Put the spine exactly in the centre of the scanner glass so the cut lands in the gutter.
- Scan at 300 dpi for text you'll OCR.

## Split PDF page in half online, privately

Pages are cut in your browser – nothing is uploaded, which matters for personal notes and copyrighted books alike. It's free, with no watermark: how to split scanned pages in half for free.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Can I keep the cover as one page?
Yes. Tick "Keep the first page whole (cover)".

??? Can I split top and bottom instead?
Yes. Choose "Across the middle".

??? Does it work for right-to-left books?
Yes. Tick "Right page first".

??? Are my files uploaded?
No. Everything happens in your browser.
