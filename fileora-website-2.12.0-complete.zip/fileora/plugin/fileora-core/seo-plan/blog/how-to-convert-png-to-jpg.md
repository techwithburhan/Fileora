---
title: How to Convert PNG to JPG (Smaller Files That Every Form Accepts)
slug: how-to-convert-png-to-jpg
seo_title: How to Convert PNG to JPG Online Free
description: How to convert PNG to JPG for free: make large PNG screenshots and images into small JPG files that forms accept, choose the quality and convert many at once.
focus_keyword: how to convert png to jpg
category: Image Tools
tools: png-to-jpg, jpg-to-png, compress-image
keywords: how to convert png to jpg | png to jpg converter free | convert png to jpeg | png to jpg online | change png to jpg | png to jpg without losing quality | batch convert png to jpg | convert screenshot to jpg | png to jpg on mobile | how to convert png to jpg for free
titles: How to Convert PNG to JPG Online Free | PNG to JPG Converter Free, Many Files at Once | Convert PNG to JPEG for Upload Forms | PNG to JPG Online Without Uploading | Change PNG to JPG in Seconds | PNG to JPG Without Losing Quality | Batch Convert PNG to JPG for Websites | Convert Screenshot to JPG and Shrink It | PNG to JPG on Mobile, No App | Why Your PNG Is So Big, and the Fix
---
"Only JPG/JPEG files are allowed." You've got a PNG – maybe a screenshot, maybe a photo some app saved as PNG – and the upload box won't take it. Here's how to convert PNG to JPG in a few seconds, and why the result is usually much smaller too.

## How to convert PNG to JPG

1. Open [PNG to JPG]({home}/png-to-jpg/) and add your images. You can batch convert PNG to JPG – add as many as you like.
2. Set the **Quality**: 90% looks like the original; 75–80% gives smaller files.
3. Convert and download.

[[cta:png-to-jpg|PNG to JPG|Turn PNG images into smaller JPG files.]]

## Why convert PNG to JPEG?

JPG and JPEG are the same format. People convert PNG to JPEG because:

- **Forms accept it.** Most exam, job and government portals only take JPG.
- **It's smaller.** PNG stores every pixel exactly; for photos that's wasteful.
- **Everything opens it.** Old phones, printers, email clients.

## Convert screenshot to JPG

Screenshots on many phones and on Windows are saved as PNG. If you need to send one as proof of payment or an error message, convert screenshot to JPG and it'll often be several times smaller. Text stays readable at 85–90% quality.

## What happens to transparent backgrounds?

JPG has no transparency, so transparent areas become white. That's what forms want for photos and signatures. Keep PNG for logos that must stay transparent, or see [JPG to PNG]({home}/jpg-to-png/) for the opposite direction.

## PNG to JPG without losing quality

At 90% quality, a photo looks the same after conversion. For PNG to JPG without losing quality on text-heavy images, stay at 90% or above; lower settings can leave faint marks around letters.

## Change PNG to JPG and hit a size limit

Converting usually shrinks the file a lot, but not to an exact number. If a form needs "under 50 KB", change PNG to JPG first, then use our [guide to reducing image size in KB]({home}/how-to-reduce-image-size-in-kb/). For general web use, [compressing images]({home}/how-to-compress-image-without-losing-quality/) is the next step.

## When to keep PNG instead

Converting isn't always the right move. Keep PNG for logos with transparent backgrounds, for diagrams with thin lines and sharp colour edges, and for images you're still editing – every JPG save loses a little detail. A good rule: photos and screenshots you're sending somewhere become JPG; graphics you're working on stay PNG until they're finished.

## PNG to JPG online, privately, and on mobile

This PNG to JPG converter free tool converts in your browser – nothing uploaded, no sign-up. Converting PNG to JPG on mobile works the same way: open the page in Chrome or Safari, pick images from your gallery, download.

## How to convert PNG to JPG for free: quick answers

| Question | Answer |
|---|---|
| Will it be smaller? | Usually, often much smaller |
| Transparent parts? | Become white |
| Best quality setting? | 90% |
| Many files? | Yes, all at once |

More in [Image Tools]({home}/category/image-tools/).

??? Is JPEG the same as JPG?
Yes. They're two names for the same format.

??? What happens to transparent areas?
They become white, because JPG doesn't support transparency.

??? Can I convert many PNG files at once?
Yes. Add them all together.

??? Are my images uploaded?
No. Everything happens in your browser.
