---
title: How to Crop an Image Online (Square, 4:5, 9:16, 16:9 and More)
slug: how-to-crop-image-online
seo_title: How to Crop Image Online Free – Any Shape
description: How to crop image files online for free: cut photos to square, portrait, story or widescreen with a live preview, pick the part to keep and download.
focus_keyword: how to crop image
category: Image Tools
tools: crop-image, resize-image, compress-image-to-20kb
keywords: how to crop image | crop image online free | crop photo to square | crop image for instagram | crop image to 16:9 | crop picture on phone | crop image without losing quality | crop image for profile picture | how to crop image for free | aspect ratio cropper
titles: How to Crop Image Online Free – Any Shape | Crop Image Online Free With a Live Preview | Crop Photo to Square for Profile Pictures | Crop Image for Instagram: 1:1, 4:5 and 9:16 | Crop Image to 16:9 for YouTube and Slides | Crop Picture on Phone Without an App | Crop Image Without Losing Quality | Aspect Ratio Cropper for Every Platform | Crop First, Then Compress: The Form-Photo Trick | Cut Out the Background Clutter in Seconds
---
Half of a good photo is what you leave out. Crop away the clutter, the stranger in the background, or the extra wall above your head, and the same picture suddenly works. Here's how to crop image files to exactly the shape you need, without installing an editor.

## How to crop image files

1. Open [Crop Image]({home}/crop-image/) and add your photo.
2. Choose the **Shape**: Original, Square (1:1), Portrait (4:5), Story (9:16), Landscape (4:3), Photo (3:2) or Widescreen (16:9).
3. Use **Crop size** to zoom in from 100% down to 20%.
4. Use **Keep this part** to slide the frame: top, centre, bottom, left or right.
5. Crop and download.

[[cta:crop-image|Crop Image|Cut photos to any shape with a live preview.]]

## Crop photo to square for profile pictures

WhatsApp, Instagram and most sites show profile photos as circles cut from a square. Crop photo to square, keep your face in the centre, and nothing important gets trimmed. That's the whole trick to a good crop image for profile picture use.

## Crop image for Instagram

| Post type | Shape |
|---|---|
| Feed (square) | 1:1 |
| Feed (portrait, more space) | 4:5 |
| Story or Reel | 9:16 |

Portrait 4:5 takes up more of the feed, which is why many creators prefer it when they crop image for Instagram.

## Crop image to 16:9

YouTube thumbnails, presentation slides and most TV-shaped screens are 16:9. Choose Widescreen and the frame matches. After cropping, set the exact pixels (1280 × 720 for thumbnails) with [Resize Image]({home}/resize-image/) – our [resizing guide]({home}/how-to-resize-image-online/) shows how.

## Crop image without losing quality

Cropping just removes pixels; the part you keep stays exactly as sharp as the original. To crop image without losing quality, start from the original photo rather than a copy that has been forwarded on WhatsApp.

## Crop picture on phone

Open fileora.in/crop-image in your browser, pick a photo, choose the shape, slide the frame with the position buttons and download. It's an aspect ratio cropper that works with your thumb.

## Composition tips that make crops look better

- **Leave a little space** in the direction a person is looking or moving.
- **Don't cut at joints** – chins, elbows and knees look awkward on the edge of a frame.
- **Use the rule of thirds**: put the subject a third of the way in, not dead centre, for posts and banners. (Profile pictures are the exception: centre them.)
- **Straight horizons** matter more than you'd think; rotate first if the photo is tilted.

## Crop first, then compress

For form photos with a KB limit, cropping first is the best quality trick there is. A head-and-shoulders crop leaves the KB budget for your face instead of the background. Then [reduce the image to the KB you need]({home}/how-to-reduce-image-size-in-kb/).

## How to crop image for free and privately

This crop image online free tool runs in your browser, so your photos aren't uploaded. No watermark, no account.

More in [Image Tools]({home}/category/image-tools/).

??? How do I crop a photo to a square?
Choose Square (1:1) and move the frame with Keep this part.

??? Does cropping reduce quality?
No. The part you keep stays at its original quality.

??? Can I crop to exact pixels?
Crop to the shape first, then set exact pixels with Resize Image.

??? Is my photo uploaded?
No. Cropping happens in your browser.
