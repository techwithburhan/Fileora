---
title: How to Edit PDF Metadata (Title, Author, Keywords) or Remove It
slug: how-to-edit-pdf-metadata
seo_title: How to Edit PDF Metadata – Title, Author, Remove
description: How to edit PDF metadata for free: change the title, author, subject and keywords stored inside a PDF, or remove them all before sharing. No upload needed.
focus_keyword: how to edit pdf metadata
category: PDF Tools
tools: edit-pdf-metadata, remove-exif-data, flatten-pdf
keywords: how to edit pdf metadata | edit pdf metadata online free | change pdf title | change pdf author name | remove metadata from pdf | pdf properties editor | pdf document title for seo | hide author name in pdf | clear pdf metadata before sharing | how to edit pdf metadata for free
titles: How to Edit PDF Metadata – Title, Author, Remove | Edit PDF Metadata Online Free | Change PDF Title That Shows in Browser Tabs | Change PDF Author Name in Seconds | Remove Metadata From PDF Before Sharing | PDF Properties Editor Without Acrobat | PDF Document Title for SEO: Why It Matters | Hide Author Name in PDF Files | Clear PDF Metadata Before Sharing a CV | What Your PDF Says About You Behind the Scenes
---
Open the Properties of almost any PDF and you'll find a title, an author and the software that made it. Sometimes the title is "Microsoft Word – final_v7_REAL.docx" and the author is the name of the colleague who wrote the template years ago. Here's how to edit PDF metadata, or clear it out completely.

## What is PDF metadata?

Information stored inside the file, separate from what you see on the pages: **title**, **author**, **subject**, **keywords**, plus the creator software and dates. Browsers show the title in the tab, search engines can show it in results, and anyone can read the author.

## How to edit PDF metadata

1. Open [Edit PDF Metadata]({home}/edit-pdf-metadata/) and add your PDF.
2. Under **What to do**, choose **Edit details** to see and change the stored values, or **Remove all details**.
3. Change the title, author, subject and keywords.
4. Download the updated PDF.

[[cta:edit-pdf-metadata|Edit PDF Metadata|Change or remove the details stored inside a PDF.]]

## Change PDF title

When you open a PDF in a browser, the tab shows its stored title – or the file name if there is none. To change PDF title text from "Document1" to something meaningful takes ten seconds, and it looks far more professional when you send a proposal or a CV.

## PDF document title for SEO

If you publish PDFs on a website – brochures, price lists, reports – Google can show the PDF in search results, often using its title. A clear PDF document title for SEO, with the words people search for, helps those files get found and clicked.

## Change PDF author name, or hide it

Templates carry the original author's name for years. Change PDF author name to yours or your company's, or hide author name in PDF files entirely by removing it.

## Remove metadata from PDF before sharing

CVs, applications and documents sent to strangers don't need to reveal who wrote the template, which software you use, or when the file was created. Clear PDF metadata before sharing with **Remove all details**. It's the PDF version of [removing location from photos]({home}/how-to-remove-location-from-photos/).

## PDF properties editor without software

You don't need Acrobat's document properties dialog. This PDF properties editor works in your browser, so the file isn't uploaded. It's free, with no watermark: edit PDF metadata online free on any device.

## A quick privacy test

Open any PDF you're about to send, right-click and choose Properties (or Document Properties in your viewer). Look at Title, Author, Subject, Keywords and Application. If anything there surprises you – an old colleague's name, an internal project code, a file path from your laptop – that's exactly what the person you send it to can see too.

## What metadata doesn't cover

Text on the pages, comments and form fields aren't metadata. To lock forms and comments, see [how to flatten a PDF]({home}/how-to-flatten-pdf/). To hide text on the page, use Redact PDF.

## How to edit PDF metadata for free: recommended values

| Field | Example |
|---|---|
| Title | Fileora Price List – October 2026 |
| Author | Your name or company |
| Subject | One sentence about the document |
| Keywords | 3–6 relevant words |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Does editing metadata change the pages?
No. Only the stored details change.

??? Can I remove all metadata?
Yes. Choose "Remove all details".

??? Does Google use PDF titles?
It can show a PDF's title in search results, so a clear title helps.

??? Are my files uploaded?
No. Editing happens in your browser.
