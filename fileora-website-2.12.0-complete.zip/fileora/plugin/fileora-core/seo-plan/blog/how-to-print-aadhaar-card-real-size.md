---
title: How to Print Aadhaar Card at Real Size (Front and Back on One Page)
slug: how-to-print-aadhaar-card-real-size
seo_title: How to Print Aadhaar Card at Real Size – Free
description: How to print Aadhaar card at real size: open your e-Aadhaar PDF with its password, put the front and back on one A4 page, and print it card-sized at home, free.
focus_keyword: how to print aadhaar card
category: PDF Tools
tools: aadhaar-card-print, unlock-pdf, id-card-print
keywords: how to print aadhaar card | aadhaar card print size | e-aadhaar print | aadhaar card print on a4 | aadhaar front and back print | e-aadhaar pdf password | print aadhaar card at home | aadhaar card size in cm | how to print aadhaar card for free | pvc aadhaar card
titles: How to Print Aadhaar Card at Real Size – Free | Aadhaar Card Print Size: Get the Real Card Size | e-Aadhaar Print: Front and Back on One Page | Aadhaar Card Print on A4, Ready to Cut | Print Aadhaar Card at Home Without a Shop | Aadhaar Front and Back Print in One Step | e-Aadhaar PDF Password Explained, Then Print | Aadhaar Card Size in cm and How to Match It | Wallet-Size Aadhaar From Your e-Aadhaar PDF | PVC Aadhaar Card vs a Home Print
---
Downloading e-Aadhaar is easy. Getting a good e-Aadhaar print is the hard part. Getting it to look like a card is not: the PDF prints as a full A4 page with a huge letter on top and a tiny card at the bottom. Here's how to print Aadhaar card copies at real size, with the front and back side by side, ready to cut out.

## What you need

- Your **e-Aadhaar PDF**, downloaded from the official UIDAI website or the mAadhaar app.
- Its **e-Aadhaar PDF password**: the first four letters of your name in CAPITALS followed by your year of birth, for example `RAHU1990`. For short names, spaces are skipped and a dot counts as a letter (so “S. Kumar” becomes `S.KU`).
- A printer, ideally with thicker paper.

## How to print Aadhaar card, step by step

1. Open [Aadhaar Card Print]({home}/aadhaar-card-print/) and add your e-Aadhaar PDF.
2. Type the password. The page opens in your browser.
3. Two boxes appear over the card. Move one onto the front and one onto the back.
4. Choose side by side or one above the other, how many copies, and A4.
5. Press **Create print page**, download, and print.

[[cta:aadhaar-card-print|Aadhaar Card Print|Front and back at real card size on one A4 page.]]

## The setting that matters: actual size

In the print dialog, choose **Actual size** or **100%**. "Fit to page" shrinks or stretches the card. This one setting is the difference between a neat card and something that won't fit your wallet.

## Aadhaar card print size and size in cm

The standard Aadhaar card size in cm is about 8.56 × 5.4 – the same as a debit card (85.6 × 54 mm). The tool places each side at exactly that size, so the aadhaar card print size is right as long as you print at 100%.

## Aadhaar card print on A4: copies and cutting

You can put up to four copies on one A4 sheet, handy when an office wants several. Keep the dashed cutting lines on, cut with a ruler, and fold or laminate. An aadhaar front and back print side by side is easiest to fold into a card.

## Print Aadhaar card at home vs a shop

To print Aadhaar card at home you only need the steps above and an ordinary printer. If you go to a shop, take the downloaded print page rather than the original PDF, and ask them to print at actual size.

## How to print Aadhaar card for free, safely

Your e-Aadhaar contains your photo, address and number. Fileora's tool opens the PDF and makes the print page entirely in your browser; neither the file nor the password is uploaded. That's why it's free and private at the same time.

## What about the PVC Aadhaar card?

A home print is fine as a copy for most purposes; UIDAI says e-Aadhaar is as valid as the physical letter. If you want a durable plastic card, the PVC Aadhaar card can be ordered from the official UIDAI website for a small fee.

## Other cards

PAN, voter ID and driving licence can be printed the same way with [ID Card Print]({home}/id-card-print/). If you just want to remove the password from the PDF for good, use [Unlock PDF]({home}/unlock-pdf/).

More in [PDF Tools]({home}/category/pdf-tools/).

??? What is the e-Aadhaar PDF password?
The first four letters of your name in capitals followed by your year of birth, such as RAHU1990.

??? Why is my printed Aadhaar the wrong size?
Print at Actual size or 100%, not Fit to page.

??? Can I print several copies on one page?
Yes, up to four.

??? Is my Aadhaar uploaded?
No. Everything happens in your browser.
