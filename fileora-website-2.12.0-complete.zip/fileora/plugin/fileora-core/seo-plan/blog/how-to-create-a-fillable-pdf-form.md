---
title: How to Create a Fillable PDF Form From a Flat PDF
slug: how-to-create-a-fillable-pdf-form
seo_title: How to Create a Fillable PDF Form Free – Auto Fields
description: How to create a fillable PDF form for free: turn blank lines and boxes in a flat PDF into text fields and checkboxes people can type into and save.
focus_keyword: how to create a fillable pdf form
category: PDF Tools
tools: pdf-forms, word-to-pdf, flatten-pdf
keywords: how to create a fillable pdf form | make pdf fillable free | fillable pdf form maker | how to create a fillable pdf form for free | convert pdf to fillable form | add text fields to pdf | pdf checkbox | fillable form from word document | fill pdf form online | editable pdf form
titles: How to Create a Fillable PDF Form Free – Auto Fields | Make PDF Fillable Free in One Step | Fillable PDF Form Maker for Schools and Offices | Convert PDF to Fillable Form Automatically | Add Text Fields to PDF Without Acrobat | PDF Checkbox Fields From Printed Boxes | Fillable Form From Word Document in Two Steps | Editable PDF Form People Can Save | Fill PDF Form Online or on a Phone | Stop Asking People to Print, Fill and Scan
---
Admission forms, leave applications, registration sheets: most are flat PDFs made for printing. People print them, fill them by hand, scan them crookedly and send them back. Here's how to create a fillable PDF form so they can type straight into it instead.

## How to create a fillable PDF form

1. Open [PDF Forms]({home}/pdf-forms/) and add your PDF.
2. Choose what to **Detect**: *All fields*, *Text only* or *Checkboxes*.
3. Press **Create fillable form** and download.

The new file ends in *-fillable.pdf*.

[[cta:pdf-forms|PDF Forms|Turn blank lines and boxes into fillable fields.]]

## A fillable PDF form maker that finds the blanks for you

Most tools make you draw every box by hand. Here the blanks are found automatically, so you convert PDF to fillable form in one step and only check the result. It's the quickest way to add text fields to PDF forms that were designed for printing.

## What becomes a field

- **Blank lines typed with underscores** (Name: ________) become text fields.
- **Drawn horizontal lines** with empty space above them become text fields.
- **Box characters** (☐ □) become a PDF checkbox you can tick.

The text size adjusts to the field, so long answers still fit. If the tool finds no blank lines or boxes, it says so instead of giving you an unchanged file.

## Fillable form from Word document

Designing a new form? Type it in Word with underscore lines and ☐ boxes, convert it with [Word to PDF]({home}/word-to-pdf/) – see [how to convert Word to PDF]({home}/how-to-convert-word-to-pdf/) – and then make PDF fillable free here. Two minutes, no form software.

## Fill PDF form online, then save

The person filling it opens the file in Adobe Acrobat Reader, Chrome, Edge, Firefox or most phone PDF apps, types into the fields, and saves. They can send it back by email – no printer, no scanner.

## Test before you share

Open the fillable file yourself, type a long name into each field, tick each box and save. Reopen it to make sure the answers stayed. An editable PDF form that works for you will work for the people you send it to.

## Lock the answers

When a filled form should no longer be changed, [Flatten PDF]({home}/flatten-pdf/) turns the typed answers into normal page content. Our [flattening guide]({home}/how-to-flatten-pdf/) shows when to do it.

## What it doesn't make

Drop-down lists, date pickers, signature boxes and calculated totals aren't detected. For a signature, people can use [Sign PDF]({home}/sign-pdf/) on the filled form – see [how to sign a PDF without printing]({home}/how-to-sign-pdf-without-printing/).

## Tips for clean detection

- Give each answer its own line; don't run two blanks together.
- Leave a little space above each line for the typed text.
- Use real box characters (☐) for options, not little drawn squares.

## Free

How to create a fillable PDF form for free: no Acrobat, no sign-up, no watermark. The file is processed on Fileora's processing server and deleted after download or automatically.

| Form type | Detect setting |
|---|---|
| Name and address form | Text only |
| Survey with options | All fields |
| Checklist | Checkboxes |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Which apps can fill the form?
Acrobat Reader, Chrome, Edge, Firefox and most phone PDF apps.

??? Can it add drop-down lists?
No. It creates text fields and checkboxes.

??? Can I make a scanned form fillable?
Only if the scan has real text; run OCR PDF first and test.

??? How do I stop answers being changed later?
Flatten the filled form.
