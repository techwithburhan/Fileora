---
title: How to Resize Photo and Signature for an Exam Form (Pixels and KB)
slug: how-to-resize-photo-and-signature-for-exam-form
seo_title: Resize Photo and Signature for Exam Form – Free Tool
description: Resize photo and signature for exam form uploads: exact pixels and a KB range for SSC, UPSC, IBPS, NEET and more, free in your browser so files stay private.
focus_keyword: resize photo and signature for exam form
category: Image Tools
tools: exam-form-photo-signature-resizer, compress-image-to-20kb, passport-size-photo-maker
keywords: resize photo and signature for exam form | photo and signature resizer | exam photo resize online | signature resize 140x60 | photo resize 200x230 | ssc photo and signature resize | ibps photo resize | how to resize photo for online form | photo signature size for government exams | resize signature to 20kb
titles: Resize Photo and Signature for Exam Form – Free Tool | Photo and Signature Resizer for SSC, UPSC and IBPS | Exam Photo Resize Online: Exact Pixels and KB | Signature Resize 140x60, 10–20 KB, in Seconds | Photo Resize 200x230 for Bank Exam Forms | SSC Photo and Signature Resize Without Rejection | IBPS Photo Resize: Photo, Thumb and Declaration | Resize Signature to 20KB on Your Phone | Photo Signature Size for Government Exams | Exam Form Uploads That Pass First Time
---
Exam forms are unforgiving. The photo must be 200 × 230 pixels, between 20 and 50 KB. The signature 140 × 60, between 10 and 20 KB. Miss by one pixel and you're looking at an error message at midnight before the deadline. Here's how to resize photo and signature for exam form uploads without guesswork.

## Exam photo resize online: two numbers, not one

Most forms check **dimensions in pixels** and **file size in KB**. Ordinary compressors only handle KB; ordinary resizers only handle pixels. The [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/) sets both in one go and also respects the minimum size, which many tools ignore.

## How to resize photo and signature for exam form uploads

1. Open the [photo and signature resizer]({home}/exam-form-photo-signature-resizer/) and add your picture.
2. Under **This is a**, choose **Photo** (200 × 230 px, 20–50 KB) or **Signature** (140 × 60 px, 10–20 KB).
3. If your notification says different numbers, type them in.
4. Choose **Fill** to crop to the exact shape, or **Fit** to keep everything with white edges. With Fill, use **Keep this part** to centre your face.
5. Press **Resize for the form** and upload the JPG.

[[cta:exam-form-photo-signature-resizer|Exam Photo & Signature Resizer|Exact pixels and KB, ready for upload.]]

## Photo resize 200x230 and signature resize 140x60

These two sizes are the ones bank forms like IBPS and SBI have used for years, and many others copy them. A photo resize 200x230 at 20–50 KB and a signature resize 140x60 at 10–20 KB will be correct for a large number of forms. But always check: SSC now captures your photo live with the camera, UPSC asks for three signatures on one image, and NTA exams allow bigger files. Read the “how to apply” section of your notification for the exact numbers.

## SSC photo and signature resize

For SSC exams, you mostly need the signature, because the photo is taken live during the application. Sign on white paper, photograph it, and resize it to 10–20 KB. The width and height depend on the notice, so read it once and type the numbers.

## IBPS photo resize: four uploads

Bank exams want a photo, a signature, a left thumb impression and a handwritten declaration. Choose Custom in the tool for the thumb (240 × 240 px) and declaration (800 × 400 px) if your notice lists those sizes.

## How to resize photo for online form when you only have a phone

- Stand against a plain light wall, facing a window.
- Ask someone to shoot at eye level from about 1.5 metres.
- Open the resizer in your phone's browser, add the photo and choose Photo.

If you'd rather print passport photos too, the [Passport Photo Maker]({home}/passport-size-photo-maker/) puts several on one sheet.

## Resize signature to 20KB cleanly

Use a dark gel pen and plain white paper, sign normally (not in capitals), and photograph it straight from above. Thin, faint lines are what turn grey and blotchy when you resize signature to 20KB, so press a little harder than usual.

## Photo signature size for government exams: quick checks

| Check | Why |
|---|---|
| KB inside the range | Too small is rejected as well as too big |
| Exact pixels | Many forms check dimensions |
| JPG format | PNG renamed to .jpg gets rejected |
| Recent photo, light background | Visual checks at verification |

Our tool keeps your files in your browser, so your photo and signature are never uploaded. More in [Image Tools]({home}/category/image-tools/), or read [how to reduce image size in KB]({home}/how-to-reduce-image-size-in-kb/).

??? What is the usual photo size for exam forms?
Many bank and recruitment forms use 200 × 230 pixels and 20–50 KB, but each exam sets its own rule.

??? What is the usual signature size?
Often 140 × 60 pixels and 10–20 KB. Check your notification.

??? My photo is cut off. What do I do?
Choose Fit (white edges), or move the frame with Keep this part.

??? Is my photo uploaded?
No. The resizer works in your browser.
