---
title: How to Convert an Image to Base64 (Data URI for HTML, CSS and JSON)
slug: how-to-convert-image-to-base64
seo_title: How to Convert Image to Base64 – Data URI, Free
description: How to convert image to Base64 for free: get a data URI, raw Base64, a CSS rule or an HTML img tag from a small image, ready to paste into code.
focus_keyword: how to convert image to base64
category: Image Tools
tools: image-to-base64, compress-image, svg-to-png
keywords: how to convert image to base64 | image to base64 converter | base64 image encoder | image to data uri | base64 to img tag | base64 background image css | embed image in html without file | png to base64 | base64 image in json | how to convert image to base64 for free
titles: How to Convert Image to Base64 – Data URI, Free | Image to Base64 Converter for Developers | Base64 Image Encoder That Runs Locally | Image to Data URI in One Click | Base64 to Img Tag, Ready to Paste | Base64 Background Image CSS Snippet | Embed Image in HTML Without a File | PNG to Base64 for Emails and Widgets | Base64 Image in JSON and APIs | When Base64 Images Help, and When They Hurt
---
Sometimes you can't ship an image file: an HTML email, a single-file widget, a JSON payload, a CSS snippet you'll paste somewhere. Base64 turns the image into text you can put right inside the code. Here's how to convert image to Base64, and when it's a good idea.

## How to convert image to Base64

1. Open [Image to Base64]({home}/image-to-base64/) and add your image.
2. Choose the **Output**:
    - **Data URI** – `data:image/png;base64,...`, ready for `src`.
    - **Base64 only** – the raw string, for APIs and JSON.
    - **CSS** – a `background-image` rule.
    - **HTML `<img>`** – a complete tag.
3. Copy the result.

[[cta:image-to-base64|Image to Base64|Data URIs and snippets for HTML, CSS and JSON.]]

## Image to data URI

A data URI includes the file type and the encoded data, so a browser can show it directly: `<img src="data:image/png;base64,iVBOR...">`. Image to data URI conversion is the usual choice for HTML and CSS.

## Base64 to img tag and CSS

The HTML output gives you a ready **base64 to img tag** with the data inside. The CSS output gives a **base64 background image CSS** rule. Both save you from typing the prefix by hand.

## Embed image in HTML without a file

Useful for:

- Single-file HTML pages, prototypes and offline reports.
- HTML email signatures and templates (support varies by email client – test first).
- Small icons in widgets you paste into other sites.

That's how you embed image in HTML without file uploads or extra requests: the picture travels inside the page itself.

## PNG to Base64 and image size

Base64 makes data about a third larger than the original file. So PNG to Base64 is great for tiny icons and logos, and a bad idea for photos. Compress or resize first – our [image compression guide]({home}/how-to-compress-image-without-losing-quality/) helps – and keep embedded images to a few KB. For crisp icons from SVG, export a small PNG with our [SVG to PNG guide]({home}/how-to-convert-svg-to-png/).

## Base64 image in JSON

APIs sometimes expect an image as a Base64 string field. Choose "Base64 only" for a base64 image in JSON, without the `data:` prefix, unless the API asks for it.

## How to check the result

Paste the data URI into your browser's address bar: if the image appears, the string is complete. In code, a broken image usually means the string was cut off while copying, or the type in the prefix doesn't match the file (for example `image/png` for a JPG). Copy again with the copy button rather than selecting by hand – long strings are easy to truncate.

## When not to use Base64

- Large images: they bloat pages and can't be cached separately.
- Images used on many pages: a normal file is cached once.
- Anything you need to update often.

## Private and free

This base64 image encoder works in your browser, so the image isn't uploaded – useful for unreleased logos and internal screenshots. It's an image to Base64 converter with no sign-up: how to convert image to Base64 for free.

## Quick reference

| Output | Looks like |
|---|---|
| Data URI | data:image/png;base64,iVBOR… |
| CSS | background-image:url(data:…) |
| HTML | <img src="data:…" alt=""> |
| Raw | iVBOR… |

More in [Image Tools]({home}/category/image-tools/).

??? Does Base64 make images bigger?
Yes, by about a third. Use it for small images.

??? Can I convert SVG to Base64?
Yes, if your browser can read the file; for maximum compatibility, convert to PNG first.

??? Do all email clients show Base64 images?
No. Support varies, so test before sending.

??? Is my image uploaded?
No. Encoding happens in your browser.
