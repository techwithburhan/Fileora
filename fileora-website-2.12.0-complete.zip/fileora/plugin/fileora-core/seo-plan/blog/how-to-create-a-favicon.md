---
title: How to Create a Favicon for Your Website (Every Size You Need)
slug: how-to-create-a-favicon
seo_title: How to Create a Favicon – ICO and App Icons, Free
description: How to create a favicon for free: turn your logo into favicon.ico, Apple and Android icons and a web manifest, then add them to WordPress or any website.
focus_keyword: how to create a favicon
category: Image Tools
tools: favicon-generator, svg-to-png, png-to-svg
keywords: how to create a favicon | favicon generator free | favicon.ico generator | create favicon from logo | favicon size | apple touch icon | add favicon to wordpress | favicon not showing | site icon for google search | how to create a favicon for free
titles: How to Create a Favicon – ICO and App Icons, Free | Favicon Generator Free: Every Size in One Download | Favicon.ico Generator From Your Logo | Create Favicon From Logo in a Minute | Favicon Size Guide: 16, 32, 180, 192, 512 | Apple Touch Icon and Android Icons Explained | Add Favicon to WordPress the Right Way | Favicon Not Showing? Check These Five Things | Site Icon for Google Search Results | The Tiny Icon That Makes Your Site Look Real
---
That tiny icon in the browser tab – and next to your site in Google results – is the favicon. Without one, browsers show a blank page icon and your site looks unfinished. Here's how to create a favicon from your logo, in every size modern browsers and phones ask for.

## Favicon size guide

| File | Size | Used by |
|---|---|---|
| favicon.ico | 16, 32, 48 px | Browser tabs, Google results |
| PNG icons | 16 and 32 px | Modern browsers |
| apple-touch-icon | 180 × 180 | iPhone and iPad home screens |
| Android icons | 192 and 512 px | Android home screens, web app |

You don't need to make each size by hand.

## How to create a favicon

1. Open the [Favicon Generator]({home}/favicon-generator/) and add a square logo – ideally at least 512 × 512 px.
2. Choose **Shape**: fit inside or crop to square.
3. Choose **Background**: transparent, white or dark, and whether to round the corners.
4. Type your **Site name** for the web app manifest.
5. Download the pack and upload the files to your site.

[[cta:favicon-generator|Favicon Generator|favicon.ico and app icons in every size.]]

## Create favicon from logo: what works at 16 pixels

A full logo with text becomes a smudge at 16 px. Use just the symbol, or the first letter of your brand, in strong contrast. If your logo is only available as a small PNG, trace it to a crisp vector first with our [PNG to SVG guide]({home}/how-to-convert-png-to-svg/), then export a big PNG with [SVG to PNG]({home}/svg-to-png/).

## Apple touch icon

iPhones ignore favicon.ico for home screen shortcuts and use the apple touch icon instead – 180 × 180. iOS fills transparent areas with black, so choose a White or Dark background in the generator rather than Transparent.

## Add favicon to WordPress

The easiest way: **Appearance → Customize → Site Identity → Site Icon**, upload a 512 × 512 PNG, publish. WordPress then creates the sizes itself. If your theme offers a built-in favicon, a Site Icon overrides it. For other sites, upload the pack to your web root and add the link tags the generator lists.

## What's in the download

You get favicon.ico (16, 32 and 48 px in one file), favicon-16x16.png, favicon-32x32.png, apple-touch-icon.png, the two Android icons and a site.webmanifest, plus the exact `<link>` lines to paste into your page's `<head>`. Put all the files in your website's main folder so `/favicon.ico` works directly – that's where browsers and Google look first.

## Favicon not showing?

1. Clear your browser cache, or test in a private window.
2. Purge your site's cache (LiteSpeed, WP Rocket, Cloudflare).
3. Open `yoursite.com/favicon.ico` directly – it should show the icon.
4. Check that the file isn't blocked by a security plugin.
5. Be patient with Google: the site icon for Google search results updates after Google recrawls your homepage, which can take days or weeks.

## Favicon.ico generator, privately

This favicon generator free tool creates everything in your browser, so your logo isn't uploaded. No sign-up, no watermark: how to create a favicon for free.

More in [Image Tools]({home}/category/image-tools/).

??? What size should a favicon be?
Make a set: favicon.ico with 16, 32 and 48 px, plus 180 px for Apple and 192/512 px for Android.

??? Can I use a PNG as a favicon?
Yes, modern browsers accept PNG; keep favicon.ico for older ones and Google.

??? Why doesn't Google show my favicon?
It updates after Google recrawls your homepage. Make sure /favicon.ico works.

??? Is my logo uploaded?
No. The icons are generated in your browser.
