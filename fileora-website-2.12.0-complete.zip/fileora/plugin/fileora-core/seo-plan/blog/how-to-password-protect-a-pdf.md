---
title: How to Password Protect a PDF (AES-256, Free)
slug: how-to-password-protect-a-pdf
seo_title: How to Password Protect a PDF Free – AES-256
description: How to password protect a PDF for free: add an open password with AES-256 encryption, and optionally block printing and copying, before you email or share it.
focus_keyword: how to password protect a pdf
category: PDF Tools
tools: protect-pdf, unlock-pdf, redact-pdf
keywords: how to password protect a pdf | protect pdf with password free | encrypt pdf | how to password protect a pdf for free | lock pdf | add password to pdf online | pdf password protection | restrict printing pdf | secure pdf before email | password protect pdf on mobile
titles: How to Password Protect a PDF Free – AES-256 | Protect PDF With Password Free, in Seconds | Encrypt PDF Before You Email It | Lock PDF Files With a Strong Password | Add Password to PDF Online, No Acrobat | Restrict Printing PDF and Copying | Secure PDF Before Email: A Short Checklist | Password Protect PDF on Mobile | How to Share the Password Safely | PDF Password Protection: What It Does and Doesn't Do
---
Salary slips, medical reports, ID copies, client contracts – some PDFs shouldn't be readable by anyone who happens to get the file. A password fixes that. Here's how to password protect a PDF so it can't be opened without the password.

## How to password protect a PDF

1. Open [Protect PDF]({home}/protect-pdf/) – the simplest way to add password to PDF online.
2. Add your PDF. Up to 20 at a time.
3. Type a **Password** (at least 6 characters) and repeat it.
4. Optional: turn on **Block printing and copying**.
5. Protect and download.

[[cta:protect-pdf|Protect PDF|Add a password with AES-256 encryption.]]

## What PDF password protection does

The PDF is encrypted with AES-256. Without the password, PDF viewers can't open it at all – the content is scrambled, not just hidden. Anyone who has the password can open, read and save it.

**Restrict printing PDF and copying** adds permissions on top: most viewers then block printing, copying text and editing. Not every app respects those permissions, so treat them as a polite lock. The open password is the strong part.

## Choose a password that works

- Long beats clever: a short sentence like *Mango-Tree-Rain-82* is strong and easy to remember.
- Don't use your name, phone number or date of birth.
- Keep it somewhere safe. If you forget it, nobody can open the file – not even Fileora.

## Secure PDF before email: share the password separately

Send the PDF by email, and the password by SMS or a call. If the email is forwarded or the account is hacked, the file alone is useless.

## Encrypt PDF or remove details?

A password protects the whole file. If you need to share a document but hide only a few details – an account number, a phone number – use [Redact PDF]({home}/redact-pdf/) instead, so those details are gone for everyone.

## Which PDFs deserve a password?

- Anything with your PAN, Aadhaar, passport or bank details.
- Salary slips, Form 16 and tax papers.
- Medical reports and prescriptions.
- Client contracts and price quotes you don't want forwarded.

## Lock PDF files on a phone

Password protect PDF on mobile works the same in any browser: add, type, download, share.

## Protect PDF with password free, with no account

How to password protect a PDF for free: no sign-up, no watermark. Files travel over an encrypted connection to Fileora's processing server and are deleted after download or automatically. The password travels with the file over the encrypted connection, is used only to lock it, and isn't saved with your task.

Need to remove the password later? Use [Unlock PDF]({home}/unlock-pdf/) with the password you set.

| Situation | Do this |
|---|---|
| Emailing salary or medical PDFs | Password + share it by SMS |
| Sending a contract to sign | Password only (they need to print) |
| Sharing a public copy | Redact instead |

More in [PDF Tools]({home}/category/pdf-tools/).

??? How strong is the encryption?
AES-256, the strongest standard PDF encryption.

??? What if I forget the password?
The file can't be opened. Keep the password safe.

??? Can I block printing?
Yes. Turn on "Block printing and copying". Most viewers respect it.

??? Can I protect many PDFs at once?
Yes. Up to 20, all with the same password.
