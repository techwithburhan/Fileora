---
title: How to Flatten a PDF (Lock Form Fields and Annotations)
slug: how-to-flatten-pdf
seo_title: How to Flatten PDF – Lock Forms and Comments
description: How to flatten PDF files for free: lock filled-in form fields, comments and annotations so nobody can change them, and fix forms that print blank.
focus_keyword: how to flatten pdf
category: PDF Tools
tools: flatten-pdf, sign-pdf, protect-pdf
keywords: how to flatten pdf | flatten pdf online free | lock pdf form fields | make pdf form not editable | flatten annotations pdf | filled pdf form prints blank | flatten pdf before sending | convert fillable pdf to regular pdf | flatten pdf without acrobat | how to flatten pdf for free
titles: How to Flatten PDF – Lock Forms and Comments | Flatten PDF Online Free in One Step | Lock PDF Form Fields Before You Send | Make PDF Form Not Editable for Submissions | Flatten Annotations PDF Reviewers Added | Filled PDF Form Prints Blank? Flatten It | Flatten PDF Before Sending to Anyone | Convert Fillable PDF to Regular PDF | Flatten PDF Without Acrobat | Why Your Form Answers Disappear on Phones
---
You filled in a PDF form perfectly. Then the receiver opens it on their phone and half the answers are missing. Or they edit a field you didn't want changed. Flattening fixes both: it turns form fields and annotations into ordinary page content. Here's how to flatten PDF files properly.

## What does flattening do?

A fillable PDF stores your answers in separate, editable fields that sit on top of the page. Different apps show them differently, and anyone can change them. Flattening "prints" the fields onto the page itself, so the result looks the same everywhere and can't be edited. It's how to convert fillable PDF to regular PDF.

## How to flatten PDF files

1. Open [Flatten PDF]({home}/flatten-pdf/) and add your filled-in PDF.
2. Choose what to **Flatten**: **Form fields**, or **Everything** (fields, comments, drawings).
3. If you chose Everything, choose the **Quality**: Smaller, Balanced or Sharp.
4. Download the flattened file.

[[cta:flatten-pdf|Flatten PDF|Lock filled-in fields and annotations.]]

## Filled PDF form prints blank?

This is the classic symptom. Some printers and phone viewers don't draw form fields. Flatten the form first and the answers become part of the page, so a filled PDF form prints blank no more.

## Lock PDF form fields before sending

Applications, declarations and agreements shouldn't be editable after you sign. To lock PDF form fields, flatten before sending. Combine it with [Sign PDF]({home}/sign-pdf/) – see our [signing guide]({home}/how-to-sign-pdf-without-printing/) – and the document is final. For extra protection, add a password with Protect PDF.

## Flatten annotations PDF reviewers added

Comments, highlights and drawings from a review can be flattened too with Everything. That's useful to flatten annotations PDF reviewers marked up before sharing the final version, so nobody deletes the highlights by accident.

## Make PDF form not editable: Form fields or Everything?

| You want | Choose |
|---|---|
| Lock answers, keep text selectable elsewhere | Form fields |
| Lock everything, including comments and drawings | Everything |
| Smallest file after flattening everything | Everything + Smaller |

"Everything" turns pages into images, which is why there's a quality setting.

## Flatten PDF before sending: checklist

1. Fill in every field and check spelling.
2. Sign if needed.
3. Flatten.
4. Open the result on your phone to confirm everything shows.

## Who needs to flatten PDFs?

Students submitting filled application forms, HR teams sending offer letters with filled fields, accountants sharing tax forms, and anyone returning a government form by email. If the receiver shouldn't change it – or might open it on a phone – flattening is the safe last step.

## Flatten PDF without Acrobat, privately

The flattening happens in your browser. Your filled-in form – often full of personal data – isn't uploaded. This is how to flatten PDF for free: flatten PDF online free, and flatten PDF without Acrobat on any device.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Can a flattened PDF be edited again?
Not the flattened fields. Keep an unflattened copy if you may need to change answers.

??? Why are my form answers missing on a phone?
Some viewers don't show form fields. Flattening fixes it.

??? Does flattening reduce quality?
"Form fields" keeps pages as they are. "Everything" makes pages images, so pick Sharp for small text.

??? Are my files uploaded?
No. Flattening happens in your browser.
