---
title: How to Convert Excel to PDF (Without Cut-Off Columns)
slug: how-to-convert-excel-to-pdf
seo_title: How to Convert Excel to PDF Free – Fit on One Page
description: How to convert Excel to PDF for free: XLSX, XLS and CSV to tidy PDF pages, each sheet on one page so no column gets cut off at the edge.
focus_keyword: how to convert excel to pdf
category: PDF Tools
tools: excel-to-pdf, pdf-to-excel, merge-pdf
keywords: how to convert excel to pdf | excel to pdf converter free | xlsx to pdf | how to convert excel to pdf for free | excel to pdf fit to page | excel to pdf without cutting columns | csv to pdf | xls to pdf online | excel to pdf landscape | convert spreadsheet to pdf
titles: How to Convert Excel to PDF Free – Fit on One Page | Excel to PDF Converter Free for XLSX, XLS and CSV | Excel to PDF Without Cutting Columns | XLSX to PDF in Landscape, the Readable Way | CSV to PDF for Reports and Records | Excel to PDF Fit to Page, Explained | Convert Spreadsheet to PDF for Invoices and Fees | XLS to PDF Online for Old Excel Files | Share a Spreadsheet Nobody Can Accidentally Edit | Excel to PDF for 20 Files at Once
---
Print a wide spreadsheet straight from Excel and you often get six pages: two columns on each, with the totals on a page of their own. Here's how to convert Excel to PDF so the sheet is readable – every column on the page, in the right orientation.

## How to convert Excel to PDF

1. Open [Excel to PDF]({home}/excel-to-pdf/).
2. Add your file: XLSX, XLS, ODS or CSV. Up to 20 files at once.
3. Keep **Fit all columns on one page** on.
4. Convert and download.

[[cta:excel-to-pdf|Excel to PDF|Spreadsheets to readable PDF pages, columns fitted.]]

## Excel to PDF fit to page

With "Fit all columns on one page" on, each worksheet becomes a single PDF page, and the page is made as big as the sheet. Nothing is split or cut, so this is Excel to PDF without cutting columns. It's perfect for reading on screen and zooming in. For a very large sheet the page gets large too – hide columns nobody needs before converting.

Want normal A4 pages for printing? Turn the option off. The converter then follows the Page Setup saved in your file: in Excel, choose *Page Layout → Orientation* and *Fit to 1 page wide*, set a print area if you need one, save, and convert.

## XLSX to PDF and XLS to PDF online

Modern .xlsx and older .xls convert the same way. Every worksheet in the workbook goes into the PDF, in order. To leave a sheet out, delete or hide it first in a copy of the file.

## CSV to PDF

A CSV file has no formatting, so the PDF is a plain table. For a neater result, open the CSV in Excel or Google Sheets, make the header row bold, set column widths, save as XLSX and convert that.

## Excel to PDF landscape or portrait?

For printed pages, set this in Excel's Page Setup before converting (with "fit" off):

| Sheet | Choose |
|---|---|
| Many columns, few rows (fees, attendance) | Landscape |
| Few columns, many rows (lists, ledgers) | Portrait |
| Invoice or form-style sheet | Portrait |

For on-screen sharing, keep "fit" on and orientation doesn't matter: each sheet gets a page of its own shape.

## Why convert spreadsheet to PDF?

- People can read it without Excel, on any phone.
- Nobody can accidentally change a number or a formula.
- It prints the way you intended.

Need the numbers back in Excel later? [PDF to Excel]({home}/pdf-to-excel/) pulls tables out of PDFs. To send several sheets as one file, use [Merge PDF]({home}/merge-pdf/).

## An Excel to PDF converter free for everyday office work

How to convert Excel to PDF for free: no account, no watermark, no Excel needed – it works on a phone too. Files are converted on Fileora's processing server over an encrypted connection and deleted after download or automatically.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Will formulas show in the PDF?
No. The PDF shows the calculated values, as Excel displays them.

??? Can I convert only one sheet?
Delete or hide the other sheets in a copy, then convert.

??? Does it keep cell colours and borders?
Yes, the formatting you see in Excel carries over.

??? Can I convert a CSV file?
Yes. It becomes a simple table.

??? Can I choose A4 landscape?
Yes. Set it in Excel's Page Setup, save, then convert with "Fit all columns on one page" off.
