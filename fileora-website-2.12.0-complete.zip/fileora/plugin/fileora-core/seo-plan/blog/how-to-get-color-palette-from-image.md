---
title: How to Get a Colour Palette From an Image (HEX and RGB Codes)
slug: how-to-get-color-palette-from-image
seo_title: How to Get Color Palette From Image – HEX Codes
description: How to get color palette from image files for free: pull the 4, 6, 8 or 10 main colours from a photo or logo as HEX and RGB codes for design and websites.
focus_keyword: how to get color palette from image
category: Image Tools
tools: color-palette-from-image, image-to-base64, png-to-svg
keywords: how to get color palette from image | color palette from image | color picker from image | extract colors from image | hex code from image | image color extractor online | find colors in a logo | brand colors from logo | rgb values from photo | how to get color palette from image for free
titles: How to Get Color Palette From Image – HEX Codes | Color Palette From Image in One Click | Color Picker From Image Without Photoshop | Extract Colors From Image for Your Brand | HEX Code From Image: Find the Exact Shade | Image Color Extractor Online, No Upload | Find Colors in a Logo You Don't Have Files For | Brand Colors From Logo for Website and Print | RGB Values From Photo for Designers | Build a Website Theme From One Photo
---
You love the colours in a photo, a poster or a client's old logo, and you need the exact codes for a website, a presentation or a printer. Guessing gets you close but not right. Here's how to get color palette from image files, with HEX and RGB codes you can copy.

## How to get color palette from image files

1. Open [Colour Palette from Image]({home}/color-palette-from-image/) and add your picture.
2. Choose the **Number of colours**: 4, 6, 8 or 10.
3. See the palette with HEX and RGB codes, and copy the ones you need.

[[cta:color-palette-from-image|Colour Palette from Image|Pull the main colours from any photo.]]

## Brand colors from logo

Many small businesses have a logo but no record of its colours. To find colors in a logo, use 4 colours – logos rarely have more – and you'll get the exact brand colors from logo artwork for your website, visiting cards and social posts. If the logo is a blurry PNG, trace a clean version first with our [PNG to SVG guide]({home}/how-to-convert-png-to-svg/).

## Hex code from image vs RGB values from photo

| Code | Example | Used in |
|---|---|---|
| HEX | #1D4ED8 | Websites, CSS, Canva, Figma |
| RGB | 29, 78, 216 | Office apps, some editors |

Both describe the same colour; copy whichever your tool asks for. The hex code from image results is usually what designers want, RGB values from photo results suit PowerPoint and Word.

## Extract colors from image for a website theme

Pick a photo that represents your brand – your shop, your product, a landscape – and extract colors from image with 6 or 8 colours. Use the darkest for text, the lightest for backgrounds, and one strong colour for buttons. Check that text and background have enough contrast to read comfortably; accessibility guidelines recommend at least 4.5 : 1 for body text.

## Color picker from image vs palette

A color picker from image lets you click one pixel; a palette groups the whole picture into its main colours. For branding and themes, the palette is more useful because single pixels can be noise. This image color extractor online gives you the overall look.

## Picking a palette that works

Too many strong colours fight each other. A common rule is 60-30-10: about 60% a neutral background, 30% a secondary colour, and 10% an accent for buttons and highlights. Extract 6 colours, pick one neutral, one secondary and one accent from them, and leave the rest out. Test the result on a real page before committing.

## Private and free

The colours are calculated in your browser – the image isn't uploaded. That's how to get color palette from image for free, even from unreleased designs.

## Related tools

- Turn a small icon into code for a web page with [Image to Base64]({home}/image-to-base64/).
- Need the logo itself at different sizes? [Convert SVG to PNG]({home}/how-to-convert-svg-to-png/).

More in [Image Tools]({home}/category/image-tools/).

??? How many colours should I choose?
4 for logos, 6–8 for photos, 10 for detailed artwork.

??? What's the difference between HEX and RGB?
They're two ways of writing the same colour.

??? Can I use the colours in Canva or Figma?
Yes. Copy the HEX codes.

??? Is my image uploaded?
No. Everything happens in your browser.
