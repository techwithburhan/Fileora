---
title: How to Print PAN, Voter ID or Driving Licence (Both Sides, Real Size)
slug: how-to-print-pan-voter-id-card-both-sides
seo_title: How to Print ID Card Both Sides on One Page
description: How to print ID card copies at real size: PAN, voter ID, driving licence or college ID, front and back on one A4 page for self-attested copies. Free.
focus_keyword: how to print id card
category: PDF Tools
tools: id-card-print, aadhaar-card-print, watermark-pdf
keywords: how to print id card | id card print both sides | pan card print on a4 | voter id card print | driving licence print copy | print card front and back on one page | self attested copy of id | id card photocopy online | print id card at real size | how to print id card for free
titles: How to Print ID Card Both Sides on One Page | ID Card Print Both Sides at Real Size | PAN Card Print on A4 for Self-Attested Copies | Voter ID Card Print From a Phone Photo | Driving Licence Print Copy, Front and Back | Print Card Front and Back on One Page | Self Attested Copy of ID: Print It Right | ID Card Photocopy Online Without a Shop | Print ID Card at Real Size, Not Stretched | Four Copies of Your ID on One Sheet
---
"Bring two self-attested copies of your ID." The photocopy shop is closed, or the queue is long, and you only have a photo of the card on your phone. Here's how to print ID card copies yourself – front and back on one page, at the real size of the card.

## Which cards work?

Any card the size of a debit card: PAN, voter ID (EPIC), driving licence, college or employee ID, ration card in card format. For Aadhaar, there's a dedicated tool that opens the e-Aadhaar PDF directly – see our [Aadhaar printing guide]({home}/how-to-print-aadhaar-card-real-size/).

## How to print ID card copies

1. Open [ID Card Print]({home}/id-card-print/).
2. Add **two photos** (front first, then back), or one photo or PDF that shows both sides.
3. If you added one picture with both sides, move the two boxes over the front and the back.
4. Choose layout, number of copies and paper size, and keep the dashed cutting lines on.
5. Create the print page, download and print at **Actual size (100%)**.

[[cta:id-card-print|ID Card Print|Both sides of any card on one page, at real size.]]

## ID card print both sides: front and back on one page

The tool puts both sides side by side or one above the other, so you print card front and back on one page instead of two sheets. Choose up to four copies per page when an office wants several.

## PAN card print on A4

A PAN card print on A4 at real size is exactly what most banks and offices expect for KYC. Print at 100%, sign across it, and you've got your self attested copy of ID.

## Voter ID card print and driving licence print copy

Photograph the card on a dark surface, straight from above, without flash (laminated cards glare). Then follow the steps above. A voter ID card print or driving licence print copy made this way is sharper than most photocopies.

## Photo tips for a crisp copy

Lay the card on a dark cloth or table so its edges stand out. Turn off the flash and tilt the card slightly away from the window if the lamination reflects light. Fill most of the frame with the card, keep the phone parallel to it, and tap to focus on the printed text. A clear photo here makes a far better copy than a worn photocopier.

## Self attested copy of ID, done properly

1. Print the page and cut out the card if needed.
2. Write "Self-attested" and sign across the copy, partly on the card image.
3. Add the date.
4. For digital submissions, add a purpose line with [Watermark PDF]({home}/watermark-pdf/) – our [watermarking guide]({home}/how-to-add-watermark-to-pdf/) shows how.

## Print ID card at real size

The card is placed at 85.6 × 54 mm. Printers shrink pages if "Fit to page" is selected, so always print at actual size if you want to print ID card at real size.

## ID card photocopy online, privately

An ID card photocopy online usually means uploading your card to a stranger's server. Here the images stay in your browser; nothing is uploaded. That's how to print ID card for free without giving your documents away.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Which cards can I print?
Any card the size of a debit card: PAN, voter ID, driving licence, college ID and similar.

??? Why is my printed card the wrong size?
Choose Actual size or 100% in the print dialog.

??? Can I use two separate photos?
Yes. Add the front first, then the back.

??? Are my card images uploaded?
No. Everything happens in your browser.
