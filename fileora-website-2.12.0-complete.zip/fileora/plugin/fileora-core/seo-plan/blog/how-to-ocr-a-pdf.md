---
title: How to OCR a PDF (Make Scans Searchable in 23 Languages)
slug: how-to-ocr-a-pdf
seo_title: How to OCR a PDF Free – Hindi, English and More
description: How to OCR a PDF for free: turn scanned pages into searchable text in English, Hindi, Tamil, Bengali and 15 more languages, as a PDF or a plain text file.
focus_keyword: how to ocr a pdf
category: PDF Tools
tools: ocr-pdf, pdf-to-word, redact-pdf
keywords: how to ocr a pdf | ocr pdf online free | hindi ocr | how to ocr a pdf for free | make scanned pdf searchable | extract text from scanned pdf | image pdf to text | ocr in tamil and bengali | searchable pdf | scanned pdf to text
titles: How to OCR a PDF Free – Hindi, English and More | OCR PDF Online Free in 23 Languages | Hindi OCR That Reads Devanagari Properly | Make Scanned PDF Searchable With Ctrl+F | Extract Text From Scanned PDF Into a Text File | Image PDF to Text Without Retyping | OCR in Tamil and Bengali, Telugu and Marathi | Searchable PDF: Same Look, Text Underneath | Copy Text From Scanned PDF in Seconds | Better Scans, Better OCR: Five Tips
---
A scanned PDF is a stack of photos. You can't search it, select a sentence or copy a number. OCR (optical character recognition) reads the letters in those photos and turns them into real text. Here's how to OCR a PDF – in English, Hindi and 21 other languages.

## How to OCR a PDF

1. Open [OCR PDF]({home}/ocr-pdf/).
2. Add your scanned PDF. Up to 10 at a time.
3. Choose the **Document language**.
4. Choose **Output**: *Searchable PDF* or *Text file*.
5. Run and download.

[[cta:ocr-pdf|OCR PDF|Scans into searchable text, 23 languages.]]

## Searchable PDF or text file?

A **searchable PDF** looks exactly like your scan, with invisible text underneath. Ctrl+F finds words, and you can select and copy. A **text file** gives you just the words, to paste into an email or document. Use searchable PDF to make scanned PDF searchable for records; use text to extract text from scanned PDF for reuse – the quickest scanned PDF to text route.

## Hindi OCR and Indian languages

Pick the language the document is written in: English, Hindi, Marathi, Bengali, Tamil, Telugu, Gujarati, Kannada, Malayalam, Punjabi, Urdu, plus Arabic, Chinese, Japanese, Korean, French, German, Spanish, Portuguese, Italian, Russian, Turkish and Indonesian. Hindi OCR reads Devanagari, including matras and conjuncts, from clean printed pages. OCR in Tamil and Bengali works the same way. Handwriting is much harder for any OCR – expect mistakes.

## Five tips for better results

- Scan at 300 dpi, or photograph in daylight with the page flat.
- Don't worry about slightly crooked or sideways pages: OCR straightens them and turns them the right way up automatically.
- Avoid shadows across the text.
- One language per run gives the best accuracy.
- Already-typed PDFs don't need OCR: if you can select text, it's already there.

## OCR PDF online free: what happens to your file

The file is processed on Fileora's processing server, so you don't need to install OCR software – OCR PDF online free from any browser. Pages that already contain real text are left as they are; only the scanned pages are read. Each file can take from a few seconds to a couple of minutes, depending on the number of pages.

## When OCR is worth it

- Old certificates and letters you need to search later.
- Scanned notes or books you want to quote from.
- Forms and agreements before you redact or translate them.

## Image PDF to text, then what?

- Edit it: [PDF to Word]({home}/pdf-to-word/).
- Hide personal details: [Redact PDF]({home}/redact-pdf/) can now find the words.
- Pull tables into a sheet: see [how to convert PDF to Excel]({home}/how-to-convert-pdf-to-excel/).

## Copy text from scanned PDF on a phone

It works in any mobile browser. Open the searchable PDF in your phone's PDF viewer and long-press to copy.

## Free

How to OCR a PDF for free: no account, no watermark. OCR runs on Fileora's processing server; files travel over an encrypted connection and are deleted after download or automatically. Password-protected files need unlocking first.

| Page quality | Expect |
|---|---|
| Office scanner, 300 dpi | Very accurate |
| Phone photo, good light | Good, check numbers |
| Faded photocopy | Mixed |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Does the PDF look different after OCR?
No. The text is added invisibly behind the scan.

??? Can it read handwriting?
Printed text works best; handwriting often comes out wrong.

??? Which languages are supported?
23, including Hindi, Marathi, Bengali, Tamil, Telugu and Urdu.

??? Can I get just the text?
Yes. Choose "Text file" as the output.
