---
title: How to Redact a PDF (Black Out Text So It's Really Gone)
slug: how-to-redact-a-pdf
seo_title: How to Redact a PDF Free – Black Out Text for Good
description: How to redact a PDF for free: black out names, account numbers, emails and phone numbers so the text is removed from the file, not just covered by a box.
focus_keyword: how to redact a pdf
category: PDF Tools
tools: redact-pdf, ocr-pdf, protect-pdf
keywords: how to redact a pdf | redact pdf online free | black out text in pdf | how to redact a pdf for free | remove sensitive information from pdf | hide phone number in pdf | redact email addresses | permanently remove text from pdf | redact aadhaar number | pdf redaction tool
titles: How to Redact a PDF Free – Black Out Text for Good | Redact PDF Online Free, No Acrobat | Black Out Text in PDF the Safe Way | Remove Sensitive Information From PDF Before Sharing | Hide Phone Number in PDF Automatically | Redact Email Addresses Across Every Page | Permanently Remove Text From PDF, Not Just Cover It | Redact Aadhaar Number and Account Numbers | Why a Black Box in Word Isn't Redaction | A Free PDF Redaction Tool for Everyday Documents
---
To black out text in PDF files safely, drawing a black rectangle in an editor isn't enough – it doesn't remove the text. Anyone can select it, copy it, or delete the rectangle. Real redaction removes the words from the file. Here's how to redact a PDF properly.

## How to redact a PDF

This free PDF redaction tool works in a few clicks:

1. Open [Redact PDF]({home}/redact-pdf/) and add your PDF.
2. In **Words to black out**, type each word or phrase on its own line: a name, an account number, an address.
3. Keep **Email addresses** and **Phone numbers** on to find them automatically.
4. Redact and download.

Every match on every page gets a solid black box, and the text under it is deleted.

[[cta:redact-pdf|Redact PDF|Black out text so it's removed from the file.]]

## Permanently remove text from PDF

After redaction, searching the PDF for a redacted word finds nothing, and copying the area gives nothing. That's the difference between real redaction and covering. Unused leftovers in the file are cleaned out when it's saved, too.

## Hide phone number in PDF and redact email addresses

The two switches catch emails and phone numbers (10–15 digits, with or without +91, spaces or dashes) wherever they appear. Turn a switch off if you want to keep, say, your office number.

## Redact Aadhaar number and account numbers

Type the number exactly as it appears in the PDF – for Aadhaar often with spaces, like *1234 5678 9012*. If it appears in different formats, add each one on its own line. Capitals don't matter.

## Scanned documents

A scan is a picture, so there are no words to find yet. Run [OCR PDF]({home}/ocr-pdf/) first – see [how to OCR a PDF]({home}/how-to-ocr-a-pdf/) – then redact, and check every page of the result carefully before sharing.

## Always check the result

Redaction finds exactly what you typed. A name spelled two ways, or a number split across two lines, needs both versions. Open the redacted file, search for each item, and look over each page. If nothing matched at all, the tool tells you instead of giving you an unchanged file.

## Redact, or protect?

Redact when the document will be shared but some details mustn't be. Use a password when the whole file is private – see [how to password protect a PDF]({home}/how-to-password-protect-a-pdf/).

## Redact PDF online free

How to redact a PDF for free: no sign-up, no watermark. It's the quickest way to remove sensitive information from PDF files before you upload them anywhere. The file is processed on Fileora's processing server and deleted after download or automatically. Always keep your original, because redaction can't be undone in the new file.

| Document | Usually redact |
|---|---|
| ID copy for a rental | Most of the ID number |
| Bank statement for a visa | Other people's names |
| Court or RTI papers | Phone numbers, addresses |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Is the text really gone?
Yes. It's deleted from the file, not just covered.

??? Does it find words regardless of capitals?
Yes. "RAHUL" and "Rahul" both match.

??? Can I undo a redaction?
Not in the new file. Keep your original.

??? Does it work on scans?
Run OCR PDF first, then redact and check the result.
