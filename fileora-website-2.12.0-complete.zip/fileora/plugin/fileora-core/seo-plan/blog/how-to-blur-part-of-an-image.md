---
title: How to Blur Part of an Image (Faces, Number Plates, Addresses)
slug: how-to-blur-part-of-an-image
seo_title: How to Blur Part of an Image Online Free
description: How to blur part of an image for free: hide faces, number plates, addresses and account numbers by blurring, pixelating or blacking out any area.
focus_keyword: how to blur part of an image
category: Image Tools
tools: blur-image, remove-exif-data, crop-image
keywords: how to blur part of an image | blur image online free | blur face in photo | pixelate image online | blur number plate | hide personal information in screenshot | censor part of image | black out text in image | blur background of photo | how to blur image for free
titles: How to Blur Part of an Image Online Free | Blur Image Online Free: Faces, Plates, Text | Blur Face in Photo Before You Post | Pixelate Image Online in Seconds | Blur Number Plate on Car Photos | Hide Personal Information in Screenshot | Censor Part of Image Without an Editor | Black Out Text in Image, Permanently | Blur Background of Photo? Here's the Limit | Pixelate, Blur or Black Box: Which Is Safest?
---
You want to share a screenshot of a payment, but not the account number. A photo of your street for a delivery, without the neighbour's car plate. A group picture, minus the person who asked not to be posted. Here's how to blur part of an image in a minute, without any photo editor.

## How to blur part of an image

1. Open [Blur Part of Image]({home}/blur-image/) and add your picture.
2. Drag on the picture to mark each area to hide. Add as many boxes as you need.
3. Choose the **Effect**: **Pixelate**, **Blur** or **Black box**, and set the strength.
4. Download the edited image.

[[cta:blur-image|Blur Part of Image|Hide faces, plates and private details.]]

## Pixelate, blur or black box: which is safest?

| Effect | Looks | Safety |
|---|---|---|
| Black box | Obvious | Safest for text and numbers |
| Pixelate (strong) | Classic "censored" | Safe at high strength |
| Blur (strong) | Softest | Fine for faces; use strong |

For numbers and text – account numbers, phone numbers, addresses – choose Black box. A light blur on text can sometimes still be read. That's why we suggest you black out text in image files rather than blur it.

## Pixelate image online, or blur it?

If you want that classic TV-style censoring, pixelate image online with the Pixelate effect at a high strength; each block hides the detail underneath.

## Blur face in photo

For people who didn't agree to be posted, children in school photos, or bystanders, blur face in photo areas with a strong blur or pixelate. Mark a slightly bigger box than the face so hair and outline don't give it away.

## Blur number plate

Posting your car for sale? Blur number plate areas on other cars in the background, and consider your own too until you share it with a serious buyer.

## Hide personal information in screenshot

Payment confirmations, chat screenshots and bank apps show more than you think: UPI IDs, phone numbers, names in the chat header, battery and network icons. To hide personal information in screenshot images, black-box anything you wouldn't read aloud to a stranger.

## Censor part of image vs cropping

If the private part is at the edge, cropping it off is cleaner – see [how to crop images]({home}/how-to-crop-image-online/). If it's in the middle, censor part of image areas with this tool.

## A checklist before you post

- Zoom in on the edited image at full size; small reflections and mirrors can show what you hid.
- Check names in the corners of screenshots – chat headers, email "To:" lines, notification banners.
- Look for documents in the background of room photos: envelopes, ID cards on a table, a screen.

## Blur background of photo?

This tool hides chosen areas, it doesn't create a smooth portrait-mode background. To blur background of photo for an artistic effect, you'd need a portrait editor. For privacy, though, marking the background areas works fine.

## Blur image online free, without uploading

The editing happens in your browser, so the original – with everything you wanted to hide – is never uploaded. This is how to blur image for free without creating a new privacy problem.

## One more privacy step

Photos can also contain a hidden GPS location. Remove it before sharing – our guide on [removing location from photos]({home}/how-to-remove-location-from-photos/) explains how.

More in [Image Tools]({home}/category/image-tools/).

??? Can blurred text be recovered?
Light blur sometimes can be guessed. Use Black box for text and numbers.

??? Can I hide several areas?
Yes. Drag to add as many boxes as you need.

??? Does it change the rest of the picture?
No. Only the marked areas are changed.

??? Is my image uploaded?
No. Editing happens in your browser.
