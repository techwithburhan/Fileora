---
title: How to Combine Images Into One (Side by Side, Stacked or Grid)
slug: how-to-combine-images-into-one
seo_title: How to Combine Images Into One – Free Collage
description: How to combine images into one picture for free: put photos side by side, stacked or in a grid, set spacing and background, and save as JPG or PNG.
focus_keyword: how to combine images into one
category: Image Tools
tools: combine-images, crop-image, compress-image
keywords: how to combine images into one | combine images online free | merge photos into one | put two pictures side by side | photo grid maker | stitch images vertically | before and after photo | combine screenshots into one image | collage maker without app | how to combine images for free
titles: How to Combine Images Into One – Free Collage | Combine Images Online Free in Any Layout | Merge Photos Into One Picture in Seconds | Put Two Pictures Side by Side | Photo Grid Maker for Posts and Catalogues | Stitch Images Vertically Like a Long Screenshot | Before and After Photo in One Image | Combine Screenshots Into One Image | Collage Maker Without App or Watermark | Front and Back of a Document in One Picture
---
Two photos that tell a story together – before and after, front and back, product and packaging – work better as one picture. Some upload forms also allow only one image where you need to show two. Here's how to combine images into one, cleanly, in a minute – a simple way to merge photos into one picture and combine images online free of apps and watermarks.

## How to combine images into one

1. Open [Combine Images]({home}/combine-images/) and add your photos.
2. Drag them into order.
3. Choose the **Layout**: **Side by side**, **One above another** or **Grid**. For a grid, decide whether to **crop to fill each cell**.
4. Set **Spacing**, **Background**, **Picture size** (800, 1200 or 2000 px) and **Save as** JPG or PNG.
5. Combine and download.

[[cta:combine-images|Combine Images|Join photos in a row, a column or a grid.]]

## Put two pictures side by side

The most common use. Choose Side by side, a little spacing, white background. To put two pictures side by side neatly, crop them to the same shape first with [Crop Image]({home}/crop-image/) – see our [cropping guide]({home}/how-to-crop-image-online/).

## Before and after photo

Renovations, haircuts, cleaning services, edits: a before and after photo is the clearest way to show a change. Side by side for landscape shots, one above another for portrait shots. Keep the same framing in both photos and the difference will speak for itself.

## Stitch images vertically

Choose One above another to stitch images vertically – handy for combining a long conversation or several receipts into one tall image.

## Combine screenshots into one image

Need to send three screenshots of an error or a payment flow? Combine screenshots into one image so people see them in order, and nothing gets lost in a chat. Blur anything private first – our guide on [blurring part of an image]({home}/how-to-blur-part-of-an-image/) shows how.

## Photo grid maker for catalogues and posts

Choose Grid for a photo grid maker effect: 4, 6 or 9 product shots in one image for a WhatsApp catalogue or an Instagram post. With "crop to fill" on, every cell is the same size.

## Front and back of a document

Some forms allow only one upload for both sides of a card or certificate. Combining the front and back into one image is exactly what's needed. For ID cards you'll print, [ID Card Print]({home}/id-card-print/) places both sides at real size instead.

## Collage maker without app, and without uploads

This collage maker without app runs in your browser: photos aren't uploaded, there's no sign-up and no watermark. That's how to combine images for free without a phone full of apps.

## Make the combined picture look intentional

- Use photos with similar lighting and colours, or the joined image looks patchy.
- Keep the spacing small (or zero) for a continuous strip, larger for a "gallery" look.
- White backgrounds feel clean for products; a dark background suits photography.
- Pick a picture size that matches where it's going: 1200 px is plenty for WhatsApp and Instagram.

## After combining

The result can be large. Shrink it with our [image compression guide]({home}/how-to-compress-image-without-losing-quality/), or [reduce it to an exact KB]({home}/how-to-reduce-image-size-in-kb/) for a form.

More in [Image Tools]({home}/category/image-tools/).

??? Can I combine more than two pictures?
Yes. Add as many as you like and choose a grid for many.

??? Will my photos be stretched?
No. With "crop to fill" off, pictures keep their shape; with it on, they're cropped to equal cells.

??? Which format should I save as?
JPG for photos, PNG for screenshots with text.

??? Are my photos uploaded?
No. Everything happens in your browser.
