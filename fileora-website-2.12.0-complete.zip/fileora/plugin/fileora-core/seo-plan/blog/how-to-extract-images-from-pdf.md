---
title: How to Extract Images From a PDF (Original Quality, No Screenshots)
slug: how-to-extract-images-from-pdf
seo_title: How to Extract Images From PDF in Original Quality
description: How to extract images from PDF files for free: save every photo, logo and picture in a PDF as a separate PNG or JPG in original quality, with no screenshots.
focus_keyword: how to extract images from pdf
category: PDF Tools
tools: extract-images-from-pdf, pdf-to-jpg, compress-image
keywords: how to extract images from pdf | extract images from pdf online free | save images from pdf | get pictures out of pdf | pdf image extractor | extract photos from pdf | download images from pdf | extract images from pdf without losing quality | extract logo from pdf | how to extract images from pdf for free
titles: How to Extract Images From PDF in Original Quality | Extract Images From PDF Online Free | Save Images From PDF Without Screenshots | Get Pictures Out of PDF Brochures and Catalogues | PDF Image Extractor That Skips Tiny Icons | Extract Photos From PDF in PNG or JPG | Download Images From PDF in One Go | Extract Logo From PDF for Reuse | Extract Images From PDF Without Losing Quality | Screenshot vs Extraction: Why Quality Differs
---
A supplier sends a PDF catalogue but not the product photos. A brochure has the perfect picture, and you only have the PDF. Taking screenshots works, badly: you get the wrong size, the wrong crop and lower quality. Here's how to extract images from PDF files in their original quality.

## How to extract images from PDF files

1. Open [Extract Images]({home}/extract-images-from-pdf/) and add your PDF.
2. Choose **Save as**: **PNG (exact)** keeps every pixel; **JPG (smaller)** makes lighter files.
3. Choose **Skip images smaller than** 16, 64 or 200 px, to leave out icons, bullets and decorative lines.
4. Run it and download the images.

[[cta:extract-images-from-pdf|Extract Images|Save every picture inside a PDF.]]

## Extract images from PDF without losing quality

A screenshot captures what's on your screen, at your screen's resolution. Extraction saves the picture as it is stored in the file – often much larger and sharper. That's how to extract images from PDF without losing quality: choose PNG and you get exactly what's inside.

## Why not just take a screenshot?

Because screenshots get the picture at whatever size it happens to be on your screen, include bits of the page around it, and often add compression from your phone. If you want to get pictures out of PDF files for a website, a print job or a product listing, extraction gives you the real file the PDF was made with – often several times larger and much sharper than what you see.

## Extract photos from PDF catalogues

Catalogues and brochures are full of small icons and design elements. Set "Skip images smaller than" to 200 px and you'll mostly get the real photos. To extract photos from PDF files with fewer leftovers, that's the most useful setting.

## Extract logo from PDF

Letterheads and invoices often contain the company logo. To extract logo from PDF files, use a small threshold (16 or 64 px) so small logos aren't skipped. For a sharper, scalable version afterwards, try tracing it to SVG.

## Pictures inside vs. whole pages

This tool is a PDF image extractor: it saves pictures embedded in the PDF. If you want each page as an image, text included, use [PDF to JPG]({home}/pdf-to-jpg/) – our [PDF to JPG guide]({home}/how-to-convert-pdf-to-jpg/) explains the settings. For scanned PDFs, both give similar results because each page is one big image.

## Save images from PDF privately

The extraction happens in your browser, so the PDF isn't uploaded. You can save images from PDF reports and contracts without sharing them with anyone. It's free, with no watermark: extract images from PDF online free on any device.

## Download images from PDF and then...

- Make them lighter for a website: [compress images]({home}/how-to-compress-image-without-losing-quality/).
- Change the format: [convert image formats]({home}/how-to-convert-image-format/).
- Put selected photos into a new PDF: [JPG to PDF]({home}/how-to-convert-jpg-to-pdf/).

## A word on rights

Getting pictures out of a PDF is technically easy; using them is a separate question. Product photos, stock images and logos belong to someone. Use what you're allowed to use.

## How to extract images from PDF for free: summary

| Goal | Setting |
|---|---|
| Real photos only | PNG, skip under 200 px |
| Everything, including logos | PNG, skip under 16 px |
| Light files for the web | JPG, skip under 64 px |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Are images extracted in full quality?
Yes, with PNG. JPG is smaller but slightly compressed.

??? Why are some small images missing?
They're below the size you chose to skip. Lower the threshold.

??? Can I save whole pages as images?
Use PDF to JPG for that.

??? Are my files uploaded?
No. Extraction happens in your browser.
