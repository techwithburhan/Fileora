---
title: How to Add a Border to an Image (Colour, Thickness, Rounded Corners)
slug: how-to-add-border-to-image
seo_title: How to Add Border to Image Online Free
description: How to add border to image files for free: a white or coloured frame, any thickness, rounded corners and transparent edges, right in your browser.
focus_keyword: how to add border to image
category: Image Tools
tools: add-border-to-image, crop-image, combine-images
keywords: how to add border to image | add border to photo online free | add white border to image | rounded corners image online | add frame to photo | instagram white border | border for passport photo | coloured border around image | transparent rounded corners png | how to add border to image for free
titles: How to Add Border to Image Online Free | Add Border to Photo Online Free in Seconds | Add White Border to Image for Instagram | Rounded Corners Image Online, Transparent Edges | Add Frame to Photo Without an Editor | Instagram White Border Without Cropping | Border for Passport Photo Prints | Coloured Border Around Image for Posts | Transparent Rounded Corners PNG for Websites | Clean Frames for Product and Profile Photos
---
A simple border makes a photo look finished: a white frame for Instagram, a thin line around a product shot, rounded corners for a website card. You don't need a photo editor for that. Here's how to add border to image files in a few clicks.

## How to add border to image files

1. Open [Add Border to Image]({home}/add-border-to-image/) and add your photos.
2. Set the **Border** thickness.
3. Choose the **Border colour** – white, black or any colour.
4. Set **Rounded corners** if you want them.
5. Choose what goes **Outside the corners**: transparent or white.
6. Download.

[[cta:add-border-to-image|Add Border to Image|Frames and rounded corners for photos.]]

## Add white border to image for Instagram

An Instagram white border gives every post the same clean, gallery-style frame. Crop to 1:1 or 4:5 first with our [cropping guide]({home}/how-to-crop-image-online/), then add a white border to image edges evenly – the frame keeps the picture's shape, so the crop decides the final ratio.

## Rounded corners image online

Rounded corners make images feel softer and match modern app and website design. To make rounded corners image online with truly transparent edges, choose transparent outside the corners and save as PNG – a transparent rounded corners PNG sits cleanly on any background colour.

## Coloured border around image

Brand colours make a coloured border around image posts instantly recognisable. Pick your HEX code – our guide on [getting a colour palette from an image]({home}/how-to-get-color-palette-from-image/) helps find it – and use the same thickness on every post.

## Border for passport photo prints

A thin white or light grey border around each photo on a print sheet makes cutting easier. Add it before laying the photos out with the Passport Photo Maker – see [making passport size photos]({home}/how-to-make-passport-size-photo-online/).

## Add frame to photo for products

Marketplaces with white backgrounds can make product photos blend in. A 1–2 px light grey frame separates the picture from the page. Add frame to photo files in a batch so your whole catalogue matches.

## Private and free

Borders are drawn in your browser, so you can add border to photo online free – nothing is uploaded, no watermark, no account. That's how to add border to image for free, even for a hundred photos.

## Tips for a clean frame

- **Crop first, border second.** A border shows the exact edge of the picture, so straighten and crop before you add it.
- **Match thickness to size.** A 20 px border looks heavy on a small thumbnail and thin on a large poster. Try a value, check the preview, adjust.
- **Keep one style per set.** Profile pictures, product shots and gallery posts look more professional when every image uses the same colour and thickness.
- **Pick the right format.** Use PNG when the outside of the corners is transparent; JPG has no transparency and will fill it in.

## Thickness guide

| Use | Border | Corners |
|---|---|---|
| Instagram gallery look | Thick white | Square |
| Product photo | 1–2 px grey | Square |
| Website card | None or thin | Rounded |
| Print sheet | Thin white | Square |

To join bordered pictures into one image, see [how to combine images]({home}/how-to-combine-images-into-one/).

More in [Image Tools]({home}/category/image-tools/).

??? Can I use any colour for the border?
Yes. Pick any colour.

??? How do I get transparent rounded corners?
Choose transparent outside the corners and save as PNG.

??? Can I add borders to many photos at once?
Yes. Add them all together.

??? Are my photos uploaded?
No. Everything happens in your browser.
