---
title: How to Convert PowerPoint to PDF (With or Without Notes)
slug: how-to-convert-powerpoint-to-pdf
seo_title: How to Convert PowerPoint to PDF Free – PPT, PPTX
description: How to convert PowerPoint to PDF for free: PPT and PPTX slides to a PDF that opens on any device, with or without speaker notes. Up to 20 files at once.
focus_keyword: how to convert powerpoint to pdf
category: PDF Tools
tools: powerpoint-to-pdf, compress-pdf, n-up-pdf
keywords: how to convert powerpoint to pdf | ppt to pdf converter free | pptx to pdf | how to convert powerpoint to pdf for free | powerpoint to pdf with notes | ppt to pdf online | convert slides to pdf | powerpoint to pdf on mobile | multiple slides per page pdf | odp to pdf
titles: How to Convert PowerPoint to PDF Free – PPT, PPTX | PPT to PDF Converter Free, No PowerPoint Needed | PowerPoint to PDF With Speaker Notes | PPTX to PDF for Assignments and Seminars | Convert Slides to PDF Before You Email Them | Multiple Slides per Page PDF for Handouts | PPT to PDF Online on a Phone | Share a Deck That Opens on Every Device | ODP to PDF From LibreOffice Impress | Make Your Presentation PDF Smaller to Send
---
Your presentation looks perfect on your laptop. On the professor's computer, the fonts change and an animation hides half a slide. Sending a PDF avoids that. Here's how to convert PowerPoint to PDF – slides only, or with your speaker notes.

## How to convert PowerPoint to PDF

1. Open [PowerPoint to PDF]({home}/powerpoint-to-pdf/).
2. Add your deck: PPTX, PPT, PPS, PPSX or ODP. Up to 20 files at once.
3. Turn on **Include speaker notes** if you want them.
4. Convert and download.

Each slide becomes one PDF page, in order.

[[cta:powerpoint-to-pdf|PowerPoint to PDF|Slide decks to PDF, with or without notes.]]

## PowerPoint to PDF with notes

With **Include speaker notes** on, each page shows the slide with its notes underneath – handy for a teacher who wants to see what you will say, or for practising. Leave it off for a clean set of slides to share.

## PPTX to PDF: what changes

- **Animations and transitions** don't exist in a PDF. Every slide shows its final state, so text that "flies in" is simply there.
- **Videos and audio** don't play; the slide shows their poster frame.
- **Fonts** that aren't common may be replaced. If a font matters, use a standard one or check the result.
- **Hidden slides** may be included; delete them from a copy first if they shouldn't be seen.

## Convert slides to PDF before you share them

A PDF is smaller to email, opens without PowerPoint, and nobody can accidentally move a text box. Teachers, recruiters and conference organisers often ask for one. To convert slides to PDF is the safest way to make sure they see what you see.

## PPT to PDF online, even on a phone

You don't need PowerPoint installed. The conversion runs on Fileora's processing server, so PowerPoint to PDF on mobile works in any browser – useful when the deck arrives on WhatsApp and the PDF has to go to a portal.

## Multiple slides per page PDF

For printed handouts, put 2, 4 or 6 slides on each sheet with [Pages per Sheet]({home}/n-up-pdf/), as explained in our [guide to printing multiple pages per sheet]({home}/how-to-print-multiple-pages-per-sheet-pdf/). It saves paper and still leaves slides readable.

## Before you convert

- Remove draft slides and any slide marked "backup".
- Check that slide numbers are switched on if your teacher wants them.
- Make sure images are not cropped by the slide edge – the PDF shows exactly what fits on the slide.

## Make the PDF smaller

Image-heavy decks give large PDFs. If an email bounces, run [Compress PDF]({home}/compress-pdf/) – see [how to compress a PDF]({home}/how-to-compress-pdf/).

## A PPT to PDF converter free to use

How to convert PowerPoint to PDF for free: no sign-up, no watermark. ODP to PDF works too, for decks made in LibreOffice Impress. Files are deleted after download or automatically.

| Need | Setting |
|---|---|
| Slides to share | Notes off |
| Practice copy | Notes on |
| Handout | Notes off, then Pages per Sheet |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Will animations work in the PDF?
No. Each slide shows how it looks at the end of its animations.

??? Can I include speaker notes?
Yes. Turn on "Include speaker notes".

??? Can I convert Google Slides?
Download it as PPTX first, then convert.

??? Does it work for ODP files?
Yes. ODP from LibreOffice Impress converts too.
