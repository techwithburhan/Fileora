---
title: How to Convert PDF to Excel (Tables Into Real Spreadsheet Cells)
slug: how-to-convert-pdf-to-excel
seo_title: How to Convert PDF to Excel Free – Tables to XLSX
description: How to convert PDF to Excel for free: pull tables from statements, invoices and reports into XLSX, with numbers as real numbers you can add up. Up to 10 files.
focus_keyword: how to convert pdf to excel
category: PDF Tools
tools: pdf-to-excel, ocr-pdf, excel-to-pdf
keywords: how to convert pdf to excel | pdf to excel converter free | pdf to xlsx | how to convert pdf to excel for free | extract table from pdf to excel | pdf table to excel | invoice pdf to excel | pdf to excel online | scanned pdf to excel | copy table from pdf
titles: How to Convert PDF to Excel Free – Tables to XLSX | PDF to Excel Converter Free for Statements and Bills | Extract Table From PDF to Excel in One Step | PDF Table to Excel With Numbers You Can Sum | Invoice PDF to Excel for Accounts and GST Work | PDF to XLSX: One Sheet per Page or All in One | Copy Table From PDF Without Broken Columns | Scanned PDF to Excel: What Works and What Doesn't | PDF to Excel Online, No Software | Stop Retyping Tables From PDFs
---
Copying a table out of a PDF usually ends in a mess: every row pasted into one cell, columns shifted, numbers stored as text so SUM gives zero. Here's how to convert PDF to Excel so each value lands in its own cell, ready to sort, filter and total.

## How to convert PDF to Excel

1. Open [PDF to Excel]({home}/pdf-to-excel/).
2. Add your PDF. Up to 10 at a time.
3. Choose **Worksheets**: *One per page* or *All in one*.
4. Convert and download the XLSX.

[[cta:pdf-to-excel|PDF to Excel|Tables from PDFs into spreadsheet cells.]]

## Extract table from PDF to Excel: what you get

The converter looks for tables on every page – ruled tables first, then tables lined up by spacing – and writes each row into the sheet. Numbers like 1,25,000 or 4,520.50 become real numbers, so formulas work straight away. Text outside tables (headings, paragraphs) is left out; this is a PDF table to Excel tool, not a page copier.

## PDF to XLSX: which files work best

The output is a standard PDF to XLSX file that opens in Excel, Google Sheets, LibreOffice and WPS. Computer-made PDFs with clear columns give the cleanest result; tables drawn as pictures, or pages photographed at an angle, need OCR and more checking.

## One sheet per page or all in one?

| Choose | When |
|---|---|
| One per page | Each page is a different table (a report) |
| All in one | One long table spread over many pages (statement, ledger) |

With *All in one*, every page's rows follow each other on a single sheet, with a "Page N" line in between that you can filter out.

## Invoice PDF to Excel and statements

Invoices, GST summaries, fee receipts, bank and card statements made by software convert best, because their text is real text. If the PDF asks for a password, remove it first with [Unlock PDF]({home}/unlock-pdf/), using the password you know.

## Scanned PDF to Excel

A scan is a picture, so there's no table to read yet. Run [OCR PDF]({home}/ocr-pdf/) first to add a text layer, then convert. Expect to check numbers carefully: OCR can misread a 5 as 6 on faint scans. If the converter finds no table, it tells you instead of giving you an empty file.

## Copy table from PDF: cleaning up

- Delete the "Page N" separator rows with a filter.
- Merge headers that wrapped onto two lines.
- Use *Find & replace* to remove "Cr" / "Dr" labels before totalling.

## Free, online, no software

How to convert PDF to Excel for free: no account, no watermark, and PDF to Excel online works on a phone too. Files travel over an encrypted connection and are deleted after download or automatically. Need it back as a PDF later? Use [Excel to PDF]({home}/excel-to-pdf/) – see [how to convert Excel to PDF]({home}/how-to-convert-excel-to-pdf/).

## A PDF to Excel converter free for small businesses too

Shops, tutors and freelancers often get supplier price lists and statements only as PDFs. Converting them once a month takes a minute and saves an evening of typing.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Will formulas work on the numbers?
Yes. Numbers are stored as numbers, not text.

??? Why are some rows missing?
Only tables are copied. Headings and paragraphs are left out.

??? Can it read scanned PDFs?
Run OCR PDF first, then convert.

??? Is there a limit?
Up to 10 PDFs at a time.
