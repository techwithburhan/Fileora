---
title: How to Read a PDF in Dark Mode (Invert Colours or Greyscale)
slug: how-to-read-pdf-in-dark-mode
seo_title: How to Read PDF in Dark Mode – Invert Colours
description: How to read PDF in dark mode: turn white pages dark for night reading, invert colours to a negative, or switch to greyscale for printing, in a new PDF you keep.
focus_keyword: how to read pdf in dark mode
category: PDF Tools
tools: invert-pdf-colors, crop-pdf, compress-pdf
keywords: how to read pdf in dark mode | dark mode pdf | invert pdf colors | pdf night mode | black background pdf | greyscale pdf | convert pdf to black and white | reduce eye strain reading pdf | dark pdf for phone | how to read pdf in dark mode for free
titles: How to Read PDF in Dark Mode – Invert Colours | Dark Mode PDF for Night Reading | Invert PDF Colors in One Click | PDF Night Mode on Any Phone or Reader | Black Background PDF for Easy Studying | Greyscale PDF for Cheaper Printing | Convert PDF to Black and White | Reduce Eye Strain Reading PDF Late at Night | Dark PDF for Phone Reading | Dark Mode That Works in Every PDF App
---
Studying from a bright white PDF at midnight feels like staring at a lamp. Some apps have a night mode, many don't, and the setting disappears when you switch devices. Here's how to read PDF in dark mode everywhere: make a dark version of the file itself.

## How to read PDF in dark mode

1. Open [Dark Mode PDF]({home}/invert-pdf-colors/) and add your PDF.
2. Choose the **Look**:
    - **Dark mode** – dark background, light text, colours kept recognisable.
    - **Negative** – a full colour inversion.
    - **Greyscale** – removes colour, for printing or calmer reading.
3. Choose the **Quality**: Smaller, Balanced or Sharp.
4. Download and open it in any app.

[[cta:invert-pdf-colors|Dark Mode PDF|Dark, negative or greyscale versions of any PDF.]]

## Dark mode PDF vs invert PDF colors

Inverting turns black into white and white into black – and also turns blue into orange and skin tones into strange colours. "Dark mode" is gentler: dark background, light text, with colours that still look like themselves. Use Negative when you want a pure invert PDF colors effect, for example on black-and-white diagrams.

## PDF night mode that follows the file

Because the result is a new PDF, the PDF night mode works in every reader: Chrome, your phone's Files app, Kindle-like readers, a tablet. A dark PDF for phone reading means no hunting for settings.

## Reduce eye strain reading PDF files

Dark backgrounds help many people in low light. Combine with a slightly larger text size – crop the margins with our [PDF cropping guide]({home}/how-to-crop-pdf/) so text fills the screen – and long reading sessions get easier. To reduce eye strain reading PDF files, also take breaks and keep screen brightness low.

## Greyscale PDF and black and white printing

Choose Greyscale to convert PDF to black and white. It saves colour ink when printing, and some offices ask for greyscale scans. A greyscale PDF is also calmer to read for some people.

## Black background PDF: quality setting

Pages are redrawn as images, so pick **Sharp** for small text and diagrams, **Smaller** if the file must stay light. Text in the new file isn't selectable; keep the original for copying text.

## Who finds dark PDFs helpful

Students revising late, people who read long reports on phones in bed, and many readers with light sensitivity or migraines. Some people with low vision prefer light text on dark; others find it harder. There's no single right answer – try a few pages both ways and keep whichever is more comfortable for your eyes.

## Private and free

The pages are processed in your browser – nothing is uploaded, no watermark, no account. That's how to read PDF in dark mode for free.

## When to keep the original

| Need | Use |
|---|---|
| Copy or search text | Original PDF |
| Night reading | Dark mode version |
| Cheaper printing | Greyscale version |

More in [PDF Tools]({home}/category/pdf-tools/).

??? Is the text still selectable?
No. Pages become images; keep the original for copying text.

??? What's the difference between Dark mode and Negative?
Dark mode keeps colours recognisable; Negative inverts everything.

??? Can I print the greyscale version?
Yes, and it saves colour ink.

??? Is my PDF uploaded?
No. Processing happens in your browser.
