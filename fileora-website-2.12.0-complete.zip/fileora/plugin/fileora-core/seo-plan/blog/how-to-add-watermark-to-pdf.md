---
title: How to Add a Watermark to a PDF (Text, Tiled or Centred)
slug: how-to-add-watermark-to-pdf
seo_title: How to Add Watermark to PDF Online Free
description: How to add watermark to PDF files for free: stamp CONFIDENTIAL, DRAFT or your name on every page, centred or tiled, with your own size, angle and opacity.
focus_keyword: how to add watermark to pdf
category: PDF Tools
tools: watermark-pdf, protect-pdf, add-stamp-to-pdf
keywords: how to add watermark to pdf | watermark pdf online free | add text watermark to pdf | confidential watermark pdf | draft watermark | watermark id copy | how to add watermark to pdf for free | watermark all pages of pdf | transparent watermark pdf | watermark pdf without acrobat
titles: How to Add Watermark to PDF Online Free | Watermark PDF Online Free: Text on Every Page | Add Text Watermark to PDF in a Minute | Confidential Watermark PDF for Sensitive Files | Draft Watermark for Documents Still in Review | Watermark ID Copy Before You Send It | Watermark All Pages of PDF at Once | Transparent Watermark PDF That Stays Readable | Watermark PDF Without Acrobat | Protect Your Aadhaar Copy With One Line of Text
---
Every time you send a copy of your PAN or Aadhaar, it sits in someone's inbox forever. A watermark won't stop a determined fraudster, but it makes a copy much harder to reuse for something else. It's also how offices mark drafts and confidential reports. Here's how to add watermark to PDF files in a few clicks.

## How to add watermark to PDF files

1. Open [Watermark PDF]({home}/watermark-pdf/) and add one or more PDFs.
2. Type the **Watermark text**: DRAFT, CONFIDENTIAL, your company name, or a sentence.
3. Choose the **Layout**: once in the centre of each page, or tiled across it.
4. Set the angle, text size, opacity and colour.
5. Download the watermarked PDF.

[[cta:watermark-pdf|Watermark PDF|Stamp text across every page, privately.]]

## Watermark ID copy: the line that matters

When you watermark ID copy files, write what the copy is for and the date: "For HDFC account opening only – 21 Oct 2026". A tiled, light watermark over the whole page makes the copy useless for anything else, while the details stay readable for the person who needs them.

## Confidential watermark PDF and draft watermark

For internal reports, a large confidential watermark PDF at 45° and 20–30% opacity is the classic look. A draft watermark works the same way and reminds reviewers not to forward an unfinished version. Change the colour to red for drafts if you want it to really stand out.

## Transparent watermark PDF that doesn't get in the way

Opacity is the key setting. For a transparent watermark PDF that people can still read through:

| Purpose | Layout | Opacity |
|---|---|---|
| Draft or confidential | Centred, 45° | 20–30% |
| ID copy | Tiled | 15–25% |
| Company name | Centred, 0° | 10–20% |

## Watermark all pages of PDF at once

The text is added to every page automatically, so you can watermark all pages of PDF files in one go – and several PDFs at once.

## Watermark PDF online free, without uploading

Fileora adds the watermark in your browser. Your document isn't uploaded, there's no sign-up, and Fileora doesn't add a watermark of its own (which, ironically, many "free" watermark tools do). So you can watermark PDF online free and watermark PDF without Acrobat on any computer.

## Add text watermark to PDF vs adding a logo

This tool is built to add text watermark to PDF pages. If you'd rather place a logo or a company seal, use [Add Image or Stamp]({home}/add-stamp-to-pdf/).

## Go further

- Add a password with [Protect PDF]({home}/protect-pdf/) for sensitive files.
- Combine documents first with our [merging guide]({home}/how-to-merge-pdf-files/), then watermark once.
- Got photos instead? [Watermark Image]({home}/watermark-image/) does the same for pictures.

## How to add watermark to PDF for free: three mistakes to avoid

- **Too dark**: at 80% opacity the document becomes unreadable.
- **Too small**: a tiny corner watermark can be cropped off in seconds.
- **No date**: a dated watermark ties a copy to one purpose and one moment.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Can I add a watermark to every page?
Yes. The text is added to every page automatically.

??? Can I make the watermark see-through?
Yes. Lower the opacity.

??? Can someone remove a watermark?
It's part of the page, but it isn't tamper-proof. Combine it with Protect PDF for sensitive files.

??? Are my files uploaded?
No. The watermark is added in your browser.
