---
title: How to Crop a PDF: Trim Margins and Scanner Borders
slug: how-to-crop-pdf
seo_title: How to Crop PDF Pages Online Free – Trim Margins
description: How to crop PDF pages for free: trim wide margins, black scanner borders and table edges from every page with a live preview, in millimetres, without uploading.
focus_keyword: how to crop pdf
category: PDF Tools
tools: crop-pdf, resize-pdf-pages, split-scanned-pages-in-half
keywords: how to crop pdf | crop pdf online free | trim pdf margins | remove white margins from pdf | crop scanned pdf | cut pdf page | crop pdf for kindle | crop pdf without acrobat | crop all pages of pdf | how to crop pdf for free
titles: How to Crop PDF Pages Online Free – Trim Margins | Crop PDF Online Free With a Live Preview | Trim PDF Margins for Easier Reading on a Phone | Remove White Margins From PDF in Seconds | Crop Scanned PDF Borders and Shadows | Cut PDF Page Edges Without Software | Crop PDF for Kindle and Small Screens | Crop PDF Without Acrobat | Crop All Pages of PDF in One Go | Bigger Text on Your Phone: Crop the PDF
---
Reading an academic paper on a phone is painful: two-thirds of the screen is white margin and the text is microscopic. Scans have the opposite problem – thick black borders and the edge of the desk. Here's how to crop PDF pages so you see the content, not the frame.

## How to crop PDF pages

1. Open [Crop PDF]({home}/crop-pdf/) and add your file.
2. Under **Trim from each edge (mm)**, set the top, right, bottom and left values.
3. Watch the preview: the shaded area is what will be removed.
4. Crop and download.

Every page is trimmed by the same amount, so you crop all pages of PDF documents in one step.

[[cta:crop-pdf|Crop PDF|Trim the margins of every page, with a live preview.]]

## Remove white margins from PDF for phone reading

Most papers and books have 20–25 mm margins. Trim 15 mm from each side and the text grows noticeably when the page fits your screen width. That's the simplest way to remove white margins from PDF files you read on the go, and it's how people crop PDF for Kindle and other e-readers too.

## Crop scanned PDF borders

Scanners and phone photos often leave dark edges, staple shadows or a strip of table. To crop scanned PDF pages, start with 5–10 mm on each side and check the preview. If the border is uneven, trim to the widest part.

## Trim PDF margins before printing

When you print a document on a different paper size, wide margins waste space. Trim PDF margins first, then change the page size with [Resize PDF Pages]({home}/resize-pdf-pages/) so the content fills the new page.

## Cut PDF page in half?

If a scan has two book pages side by side on one sheet, cropping isn't what you want. Use [Split Pages in Half]({home}/split-scanned-pages-in-half/) to cut PDF page images down the middle into separate pages.

## Cropping slides and exported documents

PDFs exported from PowerPoint or Google Slides often have a thin white border, and some reports have huge header bands. A few millimetres of cropping makes slides look edge-to-edge when shared, and a larger top trim removes repeated letterhead space if you're making a reading copy for yourself.

## Cropping hides, it doesn't delete

Here's something many people don't know: cropping a PDF hides the trimmed area, but the content is usually still inside the file. Anyone with the right software could reveal it. So never crop to hide a phone number or account number; use [Redact PDF]({home}/redact-pdf/) for that.

## Crop PDF online free, without Acrobat

This tool works in your browser, so you can crop PDF without Acrobat on any computer, and your file isn't uploaded. Crop PDF online free with no watermark and no account.

## How to crop PDF for free: settings that work

| Situation | Trim each edge |
|---|---|
| Academic paper on a phone | 15–20 mm |
| Scan with dark borders | 5–10 mm |
| Slide deck exported as PDF | 0–5 mm |
| Book with uneven scan | Adjust each side separately |

Our guide on [rotating PDF pages]({home}/how-to-rotate-pdf-pages/) helps if pages are also sideways, and [organizing pages]({home}/how-to-organize-pdf-pages/) fixes the order.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Can I crop just one page?
This tool trims every page by the same amount. Split the page out first if it needs different margins.

??? Does cropping reduce quality?
No. Pages are trimmed, not redrawn.

??? Is the cropped area deleted?
It's hidden, not deleted. Use Redact PDF to remove private content.

??? Are my files uploaded?
No. Cropping happens in your browser.
