---
title: How to Convert PDF to PDF/A for Archiving and E-Filing
slug: how-to-convert-pdf-to-pdf-a
seo_title: How to Convert PDF to PDF/A Free – 1b, 2b, 3b
description: How to convert PDF to PDF/A for free: make archive-ready PDF/A-1b, 2b or 3b files for courts, universities and records offices that ask for long-term PDFs.
focus_keyword: how to convert pdf to pdf/a
category: PDF Tools
tools: pdf-to-pdf-a, unlock-pdf, compress-pdf
keywords: how to convert pdf to pdf/a | pdf to pdf/a converter free | pdf/a-2b | how to convert pdf to pdf/a for free | what is pdf/a | pdf/a for e-filing | pdf/a-1b vs 2b vs 3b | pdf to pdfa online | archive pdf format | pdf/a for thesis submission
titles: How to Convert PDF to PDF/A Free – 1b, 2b, 3b | PDF to PDF/A Converter Free for E-Filing | What Is PDF/A, in Plain Words | PDF/A-2b: The Safe Default for Most Portals | PDF/A-1b vs 2b vs 3b Explained | PDF to PDFA Online, No Acrobat Needed | Archive PDF Format for Records That Last | PDF/A for Thesis Submission | Why a Portal Rejects Your PDF and How to Fix It | Long-Term PDFs for Offices and Courts
---
A portal rejects your file with "PDF/A required", or the university library wants your thesis "in archival format". Both mean the same thing. Here's how to convert PDF to PDF/A, which level to choose, and what changes in the file.

## How to convert PDF to PDF/A

1. Open [PDF to PDF/A]({home}/pdf-to-pdf-a/).
2. Add your PDF. Up to 10 at a time.
3. Choose the **Conformance level**: PDF/A-1b, PDF/A-2b (recommended) or PDF/A-3b.
4. Convert and download.

[[cta:pdf-to-pdf-a|PDF to PDF/A|Archive-ready PDF/A-1b, 2b or 3b.]]

## What is PDF/A?

PDF/A is a version of PDF made for keeping documents readable for decades. The file must carry everything it needs inside it: fonts are embedded, colours are defined, and things that depend on the outside world – encryption, external links to content, scripts – are not allowed. A normal PDF may look fine today and break on a computer in 2040 that lacks a font; a PDF/A shouldn't.

## When to use the archive PDF format

The archive PDF format is worth it for anything you may need to open years from now: property papers, certificates, signed agreements, scanned family records, a thesis. For everyday sharing, a normal PDF is fine.

## Good habits for archived files

- Name files clearly: *2026-10-Sale-Deed-Plot-14.pdf*, not *scan0003.pdf*.
- Keep two copies in different places, like a drive and cloud storage.
- Convert to PDF/A after you've finished editing – changes later may break conformance.

## PDF/A-1b vs 2b vs 3b

| Level | Use when |
|---|---|
| PDF/A-1b | The portal or archive asks for "PDF/A-1" specifically |
| PDF/A-2b | No level is stated – the safe default |
| PDF/A-3b | You must keep attachments (like an XML invoice) inside the PDF |

The "b" means the file looks right (basic conformance). If the instructions name a level, use that one.

## PDF/A for e-filing and thesis submission

Some courts' e-filing systems, university repositories and records offices ask for PDF/A. Read their instructions for the level and size limit, convert, and upload. PDF/A for thesis submission usually means PDF/A-1b or 2b.

## If the PDF has a password

PDF/A can't be encrypted. Remove the password first with [Unlock PDF]({home}/unlock-pdf/), using the password you know, then convert.

## Size and appearance

The converted file looks the same. It can get larger, because fonts are now embedded. If it's over the portal's limit, try [Compress PDF]({home}/compress-pdf/) – our [compression guide]({home}/how-to-compress-pdf/) explains the levels – and check with the portal whether the compressed file still passes.

## If a checker still rejects it

Validators differ. Try the other level the portal accepts, and make sure you upload the converted file, not the original. Very unusual PDFs (broken fonts, damaged files) may need [Repair PDF]({home}/repair-pdf/) first – see [how to repair a corrupted PDF]({home}/how-to-repair-corrupted-pdf/).

## A PDF to PDF/A converter free of software

How to convert PDF to PDF/A for free: no Acrobat, no sign-up. PDF to PDFA online runs on Fileora's processing server; files are deleted after download or automatically.

More in [PDF Tools]({home}/category/pdf-tools/).

??? Which PDF/A level should I choose?
PDF/A-2b, unless the instructions name another level.

??? Will my PDF look different?
No. It should look the same.

??? Can a PDF/A have a password?
No. Archive files can't be encrypted.

??? Why did my file get bigger?
Fonts are embedded so the file is complete on its own.
