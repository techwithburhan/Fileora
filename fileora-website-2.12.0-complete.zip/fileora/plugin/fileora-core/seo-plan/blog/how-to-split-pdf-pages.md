---
title: How to Split a PDF: Extract Pages or Save Each Page Separately
slug: how-to-split-pdf-pages
seo_title: How to Split PDF Pages for Free – Extract Any Page
description: How to split PDF pages for free: extract one page, pull out page ranges or turn every page into its own PDF, online on phone or PC, without any software.
focus_keyword: how to split pdf
category: PDF Tools
tools: split-pdf, organize-pdf, merge-pdf
keywords: how to split pdf | split pdf online free | how to split pdf pages | extract pages from pdf | split pdf into multiple files | how to split pdf for free | separate pdf pages | split pdf by page range | save one page of a pdf | split pdf without software
titles: How to Split PDF Pages for Free – Extract Any Page | Split PDF Online Free: Pull Out the Pages You Need | Extract Pages From PDF in Three Clicks | Split PDF Into Multiple Files, One per Page | Separate PDF Pages Without Software | Split PDF by Page Range: 1-3, 7, 10-12 | Save One Page of a PDF as Its Own File | PDF Splitter for Big Scans and Upload Limits | Split a PDF on Your Phone, No App Needed | Break a Long PDF Into Smaller Parts
---
You need page 4 of a 30-page PDF. Maybe it's the signed page of an agreement, or one certificate from a bundle you scanned together. Sending the whole thing isn't right, and printing it just to scan one page is silly. This is how to split PDF files and extract pages from PDF documents, so you send exactly what's needed.

## Three ways to split PDF pages

Fileora's [Split PDF]({home}/split-pdf/) has three modes, and picking the right one saves time:

| You want | Mode | Example |
|---|---|---|
| Certain pages | Page ranges | `4` or `1-3, 7, 10-12` |
| Every page as its own file | Every page | 20 pages → 20 PDFs |
| Equal chunks | Fixed size | 10 pages per file |

## How to split PDF pages by range

1. Open [Split PDF]({home}/split-pdf/) and add your file.
2. Choose **Page ranges** and type the pages. Commas separate ranges; `8-` means page 8 to the end.
3. Tick **Put all ranges in one PDF** if you want them together, or leave it off for one file per range.
4. Download.

That's how to split PDF by page range, and it's also the quickest way to save one page of a PDF: type just that page number.

[[cta:split-pdf|Split PDF|Extract pages or split into parts, right in your browser.]]

## How to split PDF for free, without uploading

Split PDF online free tools are everywhere, but most upload your document to their servers. Fileora splits the file inside your browser, so nothing is uploaded. It's free, has no watermark, and you don't need an account. If you were wondering how to split PDF without software on an office PC where you can't install anything, this is it.

## Split PDF into multiple files

Choose **Every page** to separate PDF pages completely, which is handy when several different documents were scanned in one go. Or choose **Fixed size** to split PDF into multiple files of, say, 10 pages each, when a portal won't accept anything over 2 MB.

## Tips before you split

- **Check the page numbers in the viewer, not the printed ones.** A document whose cover is unnumbered has "page 1" printed on PDF page 2. Split uses the PDF's own page count.
- **Name the new files clearly.** "Offer-letter-signed-page.pdf" beats "split-1.pdf" when you attach it to an email.
- **Keep the original.** Splitting creates new files and doesn't touch your PDF, but it's easy to delete the wrong one when tidying up.
- **Big scans?** Split first, then compress each part. Smaller parts compress faster and are easier to upload one by one.

## Splitting on a phone

Open fileora.in/split-pdf in your mobile browser, pick the PDF from Files or WhatsApp documents, type the pages and download. On a phone it's easier to type ranges than to tap through thumbnails, so this mode works well.

## Split or organize?

If you want to remove a page but keep everything else as one file, [Organize PDF]({home}/organize-pdf/) is quicker: delete the page and save. Split is for when you want new, separate files. And if you need to put pages from different files together afterwards, [our guide to merging PDF files]({home}/how-to-merge-pdf-files/) covers that.

Browse more guides in the [PDF Tools]({home}/category/pdf-tools/) section.

??? How do I extract pages from a PDF?
Use Page ranges in Split PDF, type the pages you want, and download the new file.

??? Can I split a PDF into individual pages?
Yes. Choose Every page and each page becomes its own PDF.

??? Does splitting reduce quality?
No. Pages are copied exactly; nothing is re-compressed.

??? Can I split a password-protected PDF?
Remove the password first with Unlock PDF, using the password you know.
