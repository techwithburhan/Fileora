---
title: How to Make a Passport Size Photo Online (35×45 mm, Print-Ready)
slug: how-to-make-passport-size-photo-online
seo_title: How to Make Passport Size Photo Online – Free
description: How to make passport size photo prints online for free: crop to 35×45 mm or 2×2 inch, fit many copies on a 4×6 sheet, and print at any photo shop.
focus_keyword: how to make passport size photo
category: Image Tools
tools: passport-size-photo-maker, exam-form-photo-signature-resizer, crop-image
keywords: how to make passport size photo | passport size photo maker online | passport photo 35x45 | passport size photo size in cm | 2x2 photo maker | passport photo on 4x6 sheet | make passport photo at home | free passport photo maker | passport size photo for visa | how to make passport size photo on mobile
titles: How to Make Passport Size Photo Online – Free | Passport Size Photo Maker Online: 35x45 mm | Passport Photo 35x45: Crop, Copy, Print | 2x2 Photo Maker for US Visa Photos | Passport Photo on 4x6 Sheet for a Few Rupees | Make Passport Photo at Home With Your Phone | Free Passport Photo Maker, No Watermark | Passport Size Photo Size in cm, Explained | Passport Size Photo for Visa Forms | Studio-Style Passport Photos Without a Studio
---
You need eight passport photos by tomorrow – for a SIM card, a bank form, and the college ID that somehow always needs two more. A studio charges per sheet and you need to get there. Here's how to make passport size photo prints yourself, online and free, and get them printed for a few rupees.

## Passport size photo size in cm

In India, a passport size photo is **3.5 × 4.5 cm** (35 × 45 mm), with your face taking up most of the height. The US uses **2 × 2 inches** (51 × 51 mm). Other forms sometimes ask for 3 × 4 cm or 2.5 × 3.5 cm. When you know the passport size photo size in cm, the rest is just cropping correctly.

## How to make passport size photo prints, step by step

1. Take or choose a photo against a plain, light background.
2. Open the [Passport Photo Maker]({home}/passport-size-photo-maker/) – a passport size photo maker online that runs in your browser – and add it.
3. Choose **35 × 45 mm**, the passport photo 35x45 size used in India (or 2 × 2 in for a US visa).
4. Move and resize the box so your head is centred with a little space above.
5. Choose **4 × 6 in photo** and **As many as fit**, keep the thin cutting lines, and download.

[[cta:passport-size-photo-maker|Passport Photo Maker|Passport photos on a 4×6 sheet, made in your browser.]]

## Make passport photo at home: the photo itself

The tool can't fix a bad photo, so spend two minutes on this:

- Stand in front of a plain white or cream wall.
- Face a window: light from the front, not from behind or above.
- Ask someone to shoot from about 1.5 metres, at your eye level.
- Neutral face, mouth closed, ears visible, no cap or tinted glasses.

## Passport photo on 4x6 sheet

A 4 × 6 inch print is the cheapest print size at any photo shop. Choose "As many as fit" and you get a full sheet of 35 × 45 mm photos. Ask the shop to print at **actual size** – not "fit" – then cut along the lines with a ruler.

## How to make passport size photo on mobile

Everything above works in your phone's browser. Open the maker, pick the photo from your gallery, drag the box with your finger, and download the sheet. Send it to a print shop on WhatsApp and pick it up in ten minutes.

## 2x2 photo maker and passport size photo for visa

For a US visa, choose 2 × 2 in. Other countries have their own rules on background colour, head size and glasses, so read the embassy's photo guidelines before you print. The tool handles the size; the rules on expression and background are up to you.

## Free passport photo maker, and private

There's no watermark and no sign-up. The photo is cropped and laid out in your browser and never uploaded.

## Need a digital file instead?

Online forms want a small file, not a printed photo. Use the [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/) – our [guide for exam form photos]({home}/how-to-resize-photo-and-signature-for-exam-form/) explains the sizes – or [reduce the photo to a KB limit]({home}/how-to-reduce-image-size-in-kb/).

More in [Image Tools]({home}/category/image-tools/).

??? What is the passport photo size in India?
35 × 45 mm (3.5 × 4.5 cm).

??? How many passport photos fit on a 4×6 print?
Several; choose "As many as fit" to fill the sheet.

??? Can I change the background colour?
No, so take the photo against a plain light wall.

??? Is my photo uploaded?
No. It's processed in your browser.
