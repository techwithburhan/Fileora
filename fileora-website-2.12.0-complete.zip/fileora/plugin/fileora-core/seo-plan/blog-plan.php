<?php
/**
 * The blog plan: one post a day, one for every tool (70 days).
 * Generated; the posts are the Markdown files in blog/. Each has 10 search keywords and 10 title ideas.
 *
 * Auto items: blog <slug>. If a post with that slug already exists, it is refreshed in place (undo restores it).
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

return array(
	1 => array(
		'title'  => 'How to Merge PDF Files Into One (Free, Online, No Software)',
		'why'    => 'PDF Tools · focus keyword “how to merge pdf files”. This refreshes the older post at the same address, so its links and ranking are kept.',
		'auto'   => array( array( 'blog', 'how-to-merge-pdf-files' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-merge-pdf-files/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	2 => array(
		'title'  => 'How to Compress a PDF Without Losing Quality (Free Guide)',
		'why'    => 'File Optimizer · focus keyword “how to compress pdf”.',
		'auto'   => array( array( 'blog', 'how-to-compress-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-compress-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	3 => array(
		'title'  => 'How to Split a PDF: Extract Pages or Save Each Page Separately',
		'why'    => 'PDF Tools · focus keyword “how to split pdf”. This refreshes the older post at the same address, so its links and ranking are kept.',
		'auto'   => array( array( 'blog', 'how-to-split-pdf-pages' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-split-pdf-pages/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	4 => array(
		'title'  => 'How to Convert JPG to PDF (Photos, Scans and Screenshots)',
		'why'    => 'PDF Tools · focus keyword “how to convert jpg to pdf”.',
		'auto'   => array( array( 'blog', 'how-to-convert-jpg-to-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-jpg-to-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	5 => array(
		'title'  => 'How to Convert PDF to JPG (Every Page as a Sharp Image)',
		'why'    => 'PDF Tools · focus keyword “how to convert pdf to jpg”.',
		'auto'   => array( array( 'blog', 'how-to-convert-pdf-to-jpg' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-pdf-to-jpg/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	6 => array(
		'title'  => 'How to Compress an Image Without Losing Quality (JPG, PNG, WebP)',
		'why'    => 'Image Tools · focus keyword “how to compress image”.',
		'auto'   => array( array( 'blog', 'how-to-compress-image-without-losing-quality' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-compress-image-without-losing-quality/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	7 => array(
		'title'  => 'How to Reduce Image Size in KB (20 KB, 50 KB, 100 KB) for Forms',
		'why'    => 'Image Tools · focus keyword “how to reduce image size in kb”.',
		'auto'   => array( array( 'blog', 'how-to-reduce-image-size-in-kb' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-reduce-image-size-in-kb/</code> and press <strong>Request indexing</strong>.' ),
			array( 'Weekly check', 'Search Console → Performance → Pages: filter by <code>/how-to</code> and note which posts get impressions. In Keyword Planner, check the volume of this week’s focus keywords for India; swap a keyword in the SEO box if a better variation turns up.' ),
		),
	),
	8 => array(
		'title'  => 'How to Resize Photo and Signature for an Exam Form (Pixels and KB)',
		'why'    => 'Image Tools · focus keyword “resize photo and signature for exam form”.',
		'auto'   => array( array( 'blog', 'how-to-resize-photo-and-signature-for-exam-form' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-resize-photo-and-signature-for-exam-form/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	9 => array(
		'title'  => 'How to Print Aadhaar Card at Real Size (Front and Back on One Page)',
		'why'    => 'PDF Tools · focus keyword “how to print aadhaar card”. This refreshes the older post at the same address, so its links and ranking are kept.',
		'auto'   => array( array( 'blog', 'how-to-print-aadhaar-card-real-size' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-print-aadhaar-card-real-size/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	10 => array(
		'title'  => 'How to Sign a PDF Without Printing It (Free, on Phone or PC)',
		'why'    => 'PDF Tools · focus keyword “how to sign a pdf”. This refreshes the older post at the same address, so its links and ranking are kept.',
		'auto'   => array( array( 'blog', 'how-to-sign-pdf-without-printing' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-sign-pdf-without-printing/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	11 => array(
		'title'  => 'How to Make a Passport Size Photo Online (35×45 mm, Print-Ready)',
		'why'    => 'Image Tools · focus keyword “how to make passport size photo”.',
		'auto'   => array( array( 'blog', 'how-to-make-passport-size-photo-online' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-make-passport-size-photo-online/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	12 => array(
		'title'  => 'How to Resize an Image Online (Pixels, Percent, Many at Once)',
		'why'    => 'Image Tools · focus keyword “how to resize image”.',
		'auto'   => array( array( 'blog', 'how-to-resize-image-online' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-resize-image-online/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	13 => array(
		'title'  => 'How to Scan Documents With Your Phone and Save as PDF',
		'why'    => 'PDF Tools · focus keyword “scan documents with your phone”. This refreshes the older post at the same address, so its links and ranking are kept.',
		'auto'   => array( array( 'blog', 'how-to-scan-documents-with-phone' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-scan-documents-with-phone/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	14 => array(
		'title'  => 'How to Convert HEIC to JPG (iPhone Photos That Open Everywhere)',
		'why'    => 'Image Tools · focus keyword “how to convert heic to jpg”. This refreshes the older post at the same address, so its links and ranking are kept.',
		'auto'   => array( array( 'blog', 'convert-heic-to-jpg-iphone' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/convert-heic-to-jpg-iphone/</code> and press <strong>Request indexing</strong>.' ),
			array( 'Weekly check', 'Search Console → Performance → Pages: filter by <code>/how-to</code> and note which posts get impressions. In Keyword Planner, check the volume of this week’s focus keywords for India; swap a keyword in the SEO box if a better variation turns up.' ),
		),
	),
	15 => array(
		'title'  => 'How to Organize PDF Pages: Reorder, Rotate and Delete',
		'why'    => 'PDF Tools · focus keyword “how to organize pdf pages”.',
		'auto'   => array( array( 'blog', 'how-to-organize-pdf-pages' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-organize-pdf-pages/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	16 => array(
		'title'  => 'How to Rotate PDF Pages and Save Them the Right Way Up',
		'why'    => 'PDF Tools · focus keyword “how to rotate pdf pages”.',
		'auto'   => array( array( 'blog', 'how-to-rotate-pdf-pages' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-rotate-pdf-pages/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	17 => array(
		'title'  => 'How to Add a Watermark to a PDF (Text, Tiled or Centred)',
		'why'    => 'PDF Tools · focus keyword “how to add watermark to pdf”.',
		'auto'   => array( array( 'blog', 'how-to-add-watermark-to-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-add-watermark-to-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	18 => array(
		'title'  => 'How to Add Page Numbers to a PDF (Any Position, Any Format)',
		'why'    => 'PDF Tools · focus keyword “how to add page numbers to pdf”.',
		'auto'   => array( array( 'blog', 'how-to-add-page-numbers-to-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-add-page-numbers-to-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	19 => array(
		'title'  => 'How to Convert PNG to JPG (Smaller Files That Every Form Accepts)',
		'why'    => 'Image Tools · focus keyword “how to convert png to jpg”.',
		'auto'   => array( array( 'blog', 'how-to-convert-png-to-jpg' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-png-to-jpg/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	20 => array(
		'title'  => 'How to Convert JPG to PNG (and When You Actually Should)',
		'why'    => 'Image Tools · focus keyword “how to convert jpg to png”.',
		'auto'   => array( array( 'blog', 'how-to-convert-jpg-to-png' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-jpg-to-png/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	21 => array(
		'title'  => 'How to Convert Image Formats: JPG, PNG and WebP Explained',
		'why'    => 'Image Tools · focus keyword “how to convert image format”.',
		'auto'   => array( array( 'blog', 'how-to-convert-image-format' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-image-format/</code> and press <strong>Request indexing</strong>.' ),
			array( 'Weekly check', 'Search Console → Performance → Pages: filter by <code>/how-to</code> and note which posts get impressions. In Keyword Planner, check the volume of this week’s focus keywords for India; swap a keyword in the SEO box if a better variation turns up.' ),
		),
	),
	22 => array(
		'title'  => 'How to Crop an Image Online (Square, 4:5, 9:16, 16:9 and More)',
		'why'    => 'Image Tools · focus keyword “how to crop image”.',
		'auto'   => array( array( 'blog', 'how-to-crop-image-online' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-crop-image-online/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	23 => array(
		'title'  => 'How to Crop a PDF: Trim Margins and Scanner Borders',
		'why'    => 'PDF Tools · focus keyword “how to crop pdf”.',
		'auto'   => array( array( 'blog', 'how-to-crop-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-crop-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	24 => array(
		'title'  => 'How to Print PAN, Voter ID or Driving Licence (Both Sides, Real Size)',
		'why'    => 'PDF Tools · focus keyword “how to print id card”.',
		'auto'   => array( array( 'blog', 'how-to-print-pan-voter-id-card-both-sides' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-print-pan-voter-id-card-both-sides/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	25 => array(
		'title'  => 'How to Remove Blank Pages From a PDF Automatically',
		'why'    => 'PDF Tools · focus keyword “how to remove blank pages from pdf”.',
		'auto'   => array( array( 'blog', 'how-to-remove-blank-pages-from-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-remove-blank-pages-from-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	26 => array(
		'title'  => 'How to Convert PDF to Text (Copy All the Words, Cleanly)',
		'why'    => 'PDF Tools · focus keyword “how to convert pdf to text”.',
		'auto'   => array( array( 'blog', 'how-to-convert-pdf-to-text' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-pdf-to-text/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	27 => array(
		'title'  => 'How to Extract Images From a PDF (Original Quality, No Screenshots)',
		'why'    => 'PDF Tools · focus keyword “how to extract images from pdf”.',
		'auto'   => array( array( 'blog', 'how-to-extract-images-from-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-extract-images-from-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	28 => array(
		'title'  => 'How to Repair a Corrupted PDF That Won\'t Open',
		'why'    => 'File Optimizer · focus keyword “how to repair corrupted pdf”.',
		'auto'   => array( array( 'blog', 'how-to-repair-corrupted-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-repair-corrupted-pdf/</code> and press <strong>Request indexing</strong>.' ),
			array( 'Weekly check', 'Search Console → Performance → Pages: filter by <code>/how-to</code> and note which posts get impressions. In Keyword Planner, check the volume of this week’s focus keywords for India; swap a keyword in the SEO box if a better variation turns up.' ),
		),
	),
	29 => array(
		'title'  => 'How to Convert PNG or JPG to SVG (Real Vectors, Not a Wrapper)',
		'why'    => 'Image Tools · focus keyword “how to convert png to svg”.',
		'auto'   => array( array( 'blog', 'how-to-convert-png-to-svg' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-png-to-svg/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	30 => array(
		'title'  => 'How to Convert SVG to PNG (Any Size, Transparent or White)',
		'why'    => 'Image Tools · focus keyword “how to convert svg to png”.',
		'auto'   => array( array( 'blog', 'how-to-convert-svg-to-png' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-svg-to-png/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	31 => array(
		'title'  => 'How to Watermark Photos (Your Name, Brand or © on Every Picture)',
		'why'    => 'Image Tools · focus keyword “how to watermark photos”.',
		'auto'   => array( array( 'blog', 'how-to-watermark-photos' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-watermark-photos/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	32 => array(
		'title'  => 'How to Remove Location From Photos Before You Share Them',
		'why'    => 'Image Tools · focus keyword “how to remove location from photos”.',
		'auto'   => array( array( 'blog', 'how-to-remove-location-from-photos' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-remove-location-from-photos/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	33 => array(
		'title'  => 'How to Rotate and Flip an Image (Fix Sideways and Mirrored Photos)',
		'why'    => 'Image Tools · focus keyword “how to rotate and flip image”.',
		'auto'   => array( array( 'blog', 'how-to-rotate-and-flip-image' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-rotate-and-flip-image/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	34 => array(
		'title'  => 'How to Blur Part of an Image (Faces, Number Plates, Addresses)',
		'why'    => 'Image Tools · focus keyword “how to blur part of an image”.',
		'auto'   => array( array( 'blog', 'how-to-blur-part-of-an-image' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-blur-part-of-an-image/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	35 => array(
		'title'  => 'How to Combine Images Into One (Side by Side, Stacked or Grid)',
		'why'    => 'Image Tools · focus keyword “how to combine images into one”.',
		'auto'   => array( array( 'blog', 'how-to-combine-images-into-one' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-combine-images-into-one/</code> and press <strong>Request indexing</strong>.' ),
			array( 'Weekly check', 'Search Console → Performance → Pages: filter by <code>/how-to</code> and note which posts get impressions. In Keyword Planner, check the volume of this week’s focus keywords for India; swap a keyword in the SEO box if a better variation turns up.' ),
		),
	),
	36 => array(
		'title'  => 'How to Print Multiple PDF Pages on One Sheet (2, 4, 6 or 9 Up)',
		'why'    => 'PDF Tools · focus keyword “how to print multiple pages per sheet”.',
		'auto'   => array( array( 'blog', 'how-to-print-multiple-pages-per-sheet-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-print-multiple-pages-per-sheet-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	37 => array(
		'title'  => 'How to Make a Booklet From a PDF (Print, Fold, Done)',
		'why'    => 'PDF Tools · focus keyword “how to make a booklet from pdf”.',
		'auto'   => array( array( 'blog', 'how-to-make-a-booklet-from-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-make-a-booklet-from-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	38 => array(
		'title'  => 'How to Add a Header and Footer to a PDF (Titles, Dates, Names)',
		'why'    => 'PDF Tools · focus keyword “how to add header and footer to pdf”.',
		'auto'   => array( array( 'blog', 'how-to-add-header-and-footer-to-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-add-header-and-footer-to-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	39 => array(
		'title'  => 'How to Add a Stamp, Seal or Logo to a PDF',
		'why'    => 'PDF Tools · focus keyword “how to add stamp or logo to pdf”.',
		'auto'   => array( array( 'blog', 'how-to-add-stamp-or-logo-to-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-add-stamp-or-logo-to-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	40 => array(
		'title'  => 'How to Flatten a PDF (Lock Form Fields and Annotations)',
		'why'    => 'PDF Tools · focus keyword “how to flatten pdf”.',
		'auto'   => array( array( 'blog', 'how-to-flatten-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-flatten-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	41 => array(
		'title'  => 'How to Edit PDF Metadata (Title, Author, Keywords) or Remove It',
		'why'    => 'PDF Tools · focus keyword “how to edit pdf metadata”.',
		'auto'   => array( array( 'blog', 'how-to-edit-pdf-metadata' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-edit-pdf-metadata/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	42 => array(
		'title'  => 'How to Resize PDF Pages to A4 (or Letter, A3, A5, Legal)',
		'why'    => 'PDF Tools · focus keyword “how to resize pdf pages”.',
		'auto'   => array( array( 'blog', 'how-to-resize-pdf-pages-to-a4' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-resize-pdf-pages-to-a4/</code> and press <strong>Request indexing</strong>.' ),
			array( 'Weekly check', 'Search Console → Performance → Pages: filter by <code>/how-to</code> and note which posts get impressions. In Keyword Planner, check the volume of this week’s focus keywords for India; swap a keyword in the SEO box if a better variation turns up.' ),
		),
	),
	43 => array(
		'title'  => 'How to Reverse PDF Pages, Duplicate Pages or Insert Blank Pages',
		'why'    => 'PDF Tools · focus keyword “how to reverse pdf pages”.',
		'auto'   => array( array( 'blog', 'how-to-reverse-pdf-pages' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-reverse-pdf-pages/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	44 => array(
		'title'  => 'How to Interleave PDF Pages (Combine Front and Back Scans)',
		'why'    => 'PDF Tools · focus keyword “how to interleave pdf pages”.',
		'auto'   => array( array( 'blog', 'how-to-interleave-pdf-pages' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-interleave-pdf-pages/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	45 => array(
		'title'  => 'How to Split Scanned Pages in Half (Book Scans to Single Pages)',
		'why'    => 'PDF Tools · focus keyword “how to split scanned pages in half”.',
		'auto'   => array( array( 'blog', 'how-to-split-scanned-pages-in-half' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-split-scanned-pages-in-half/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	46 => array(
		'title'  => 'How to Compare Two PDF Files and See Exactly What Changed',
		'why'    => 'PDF Tools · focus keyword “how to compare two pdf files”.',
		'auto'   => array( array( 'blog', 'how-to-compare-two-pdf-files' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-compare-two-pdf-files/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	47 => array(
		'title'  => 'How to Convert PDF to Markdown (Headings, Lists and Tables)',
		'why'    => 'PDF Tools · focus keyword “how to convert pdf to markdown”.',
		'auto'   => array( array( 'blog', 'how-to-convert-pdf-to-markdown' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-pdf-to-markdown/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	48 => array(
		'title'  => 'How to Read a PDF in Dark Mode (Invert Colours or Greyscale)',
		'why'    => 'PDF Tools · focus keyword “how to read pdf in dark mode”.',
		'auto'   => array( array( 'blog', 'how-to-read-pdf-in-dark-mode' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-read-pdf-in-dark-mode/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	49 => array(
		'title'  => 'What Is Bates Numbering, and How to Add It to PDFs',
		'why'    => 'PDF Tools · focus keyword “bates numbering”.',
		'auto'   => array( array( 'blog', 'what-is-bates-numbering-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/what-is-bates-numbering-pdf/</code> and press <strong>Request indexing</strong>.' ),
			array( 'Weekly check', 'Search Console → Performance → Pages: filter by <code>/how-to</code> and note which posts get impressions. In Keyword Planner, check the volume of this week’s focus keywords for India; swap a keyword in the SEO box if a better variation turns up.' ),
		),
	),
	50 => array(
		'title'  => 'How to Create a Favicon for Your Website (Every Size You Need)',
		'why'    => 'Image Tools · focus keyword “how to create a favicon”.',
		'auto'   => array( array( 'blog', 'how-to-create-a-favicon' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-create-a-favicon/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	51 => array(
		'title'  => 'How to Get a Colour Palette From an Image (HEX and RGB Codes)',
		'why'    => 'Image Tools · focus keyword “how to get color palette from image”.',
		'auto'   => array( array( 'blog', 'how-to-get-color-palette-from-image' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-get-color-palette-from-image/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	52 => array(
		'title'  => 'How to Convert an Image to Base64 (Data URI for HTML, CSS and JSON)',
		'why'    => 'Image Tools · focus keyword “how to convert image to base64”.',
		'auto'   => array( array( 'blog', 'how-to-convert-image-to-base64' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-image-to-base64/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	53 => array(
		'title'  => 'How to Add a Border to an Image (Colour, Thickness, Rounded Corners)',
		'why'    => 'Image Tools · focus keyword “how to add border to image”.',
		'auto'   => array( array( 'blog', 'how-to-add-border-to-image' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-add-border-to-image/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	54 => array(
		'title'  => 'How to Convert Word to PDF (DOC, DOCX, Free and Without Office)',
		'why'    => 'PDF Tools · focus keyword “how to convert word to pdf”.',
		'auto'   => array( array( 'blog', 'how-to-convert-word-to-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-word-to-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	55 => array(
		'title'  => 'How to Convert Excel to PDF (Without Cut-Off Columns)',
		'why'    => 'PDF Tools · focus keyword “how to convert excel to pdf”.',
		'auto'   => array( array( 'blog', 'how-to-convert-excel-to-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-excel-to-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	56 => array(
		'title'  => 'How to Convert PowerPoint to PDF (With or Without Notes)',
		'why'    => 'PDF Tools · focus keyword “how to convert powerpoint to pdf”.',
		'auto'   => array( array( 'blog', 'how-to-convert-powerpoint-to-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-powerpoint-to-pdf/</code> and press <strong>Request indexing</strong>.' ),
			array( 'Weekly check', 'Search Console → Performance → Pages: filter by <code>/how-to</code> and note which posts get impressions. In Keyword Planner, check the volume of this week’s focus keywords for India; swap a keyword in the SEO box if a better variation turns up.' ),
		),
	),
	57 => array(
		'title'  => 'How to Convert PDF to Word You Can Edit (Including Scans)',
		'why'    => 'PDF Tools · focus keyword “how to convert pdf to word”.',
		'auto'   => array( array( 'blog', 'how-to-convert-pdf-to-word' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-pdf-to-word/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	58 => array(
		'title'  => 'How to Convert PDF to Excel (Tables Into Real Spreadsheet Cells)',
		'why'    => 'PDF Tools · focus keyword “how to convert pdf to excel”.',
		'auto'   => array( array( 'blog', 'how-to-convert-pdf-to-excel' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-pdf-to-excel/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	59 => array(
		'title'  => 'How to Convert PDF to PowerPoint (and Present It Properly)',
		'why'    => 'PDF Tools · focus keyword “how to convert pdf to powerpoint”.',
		'auto'   => array( array( 'blog', 'how-to-convert-pdf-to-powerpoint' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-pdf-to-powerpoint/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	60 => array(
		'title'  => 'How to Save a Webpage as PDF (Without the Ads and Pop-ups)',
		'why'    => 'PDF Tools · focus keyword “how to save a webpage as pdf”.',
		'auto'   => array( array( 'blog', 'how-to-save-a-webpage-as-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-save-a-webpage-as-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	61 => array(
		'title'  => 'How to OCR a PDF (Make Scans Searchable in 23 Languages)',
		'why'    => 'PDF Tools · focus keyword “how to ocr a pdf”.',
		'auto'   => array( array( 'blog', 'how-to-ocr-a-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-ocr-a-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	62 => array(
		'title'  => 'How to Convert PDF to PDF/A for Archiving and E-Filing',
		'why'    => 'PDF Tools · focus keyword “how to convert pdf to pdf/a”.',
		'auto'   => array( array( 'blog', 'how-to-convert-pdf-to-pdf-a' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-pdf-to-pdf-a/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	63 => array(
		'title'  => 'How to Password Protect a PDF (AES-256, Free)',
		'why'    => 'PDF Tools · focus keyword “how to password protect a pdf”.',
		'auto'   => array( array( 'blog', 'how-to-password-protect-a-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-password-protect-a-pdf/</code> and press <strong>Request indexing</strong>.' ),
			array( 'Weekly check', 'Search Console → Performance → Pages: filter by <code>/how-to</code> and note which posts get impressions. In Keyword Planner, check the volume of this week’s focus keywords for India; swap a keyword in the SEO box if a better variation turns up.' ),
		),
	),
	64 => array(
		'title'  => 'How to Unlock a PDF You\'re Allowed to Open',
		'why'    => 'PDF Tools · focus keyword “how to unlock a pdf”.',
		'auto'   => array( array( 'blog', 'how-to-unlock-a-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-unlock-a-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	65 => array(
		'title'  => 'How to Redact a PDF (Black Out Text So It\'s Really Gone)',
		'why'    => 'PDF Tools · focus keyword “how to redact a pdf”.',
		'auto'   => array( array( 'blog', 'how-to-redact-a-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-redact-a-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	66 => array(
		'title'  => 'How to Create a Fillable PDF Form From a Flat PDF',
		'why'    => 'PDF Tools · focus keyword “how to create a fillable pdf form”.',
		'auto'   => array( array( 'blog', 'how-to-create-a-fillable-pdf-form' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-create-a-fillable-pdf-form/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	67 => array(
		'title'  => 'How to Summarize a PDF With AI (Short, Medium or Detailed)',
		'why'    => 'PDF Tools · focus keyword “how to summarize a pdf”. The post stays a draft until the tool is switched on (it needs an AI API key on the processing server).',
		'auto'   => array( array( 'blog', 'how-to-summarize-a-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-summarize-a-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	68 => array(
		'title'  => 'How to Translate a PDF Into Hindi, English and 21 More Languages',
		'why'    => 'PDF Tools · focus keyword “how to translate a pdf”. The post stays a draft until the tool is switched on (it needs an AI API key on the processing server).',
		'auto'   => array( array( 'blog', 'how-to-translate-a-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-translate-a-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	69 => array(
		'title'  => 'How to Edit a PDF for Free: Text, Signatures, Images and Pages',
		'why'    => 'PDF Tools · focus keyword “how to edit a pdf”.',
		'auto'   => array( array( 'blog', 'how-to-edit-a-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-edit-a-pdf/</code> and press <strong>Request indexing</strong>.' ),
		),
	),
	70 => array(
		'title'  => 'How to Convert HTML to PDF: Paste Your Code, Download a PDF',
		'why'    => 'PDF Tools · focus keyword “how to convert html to pdf”. It also gives the new HTML Code to PDF tool page its full text, FAQ and SEO fields.',
		'auto'   => array( array( 'blog', 'how-to-convert-html-to-pdf' ), array( 'tool', 'html-code-to-pdf' ), ),
		'manual' => array(
			array( 'Read and publish', 'Open the draft from the link above, read it through, check the CTA and links, then press <strong>Publish</strong>. Prefer to publish from here? Use <strong>Publish</strong> on this card.' ),
			array( 'Request indexing', 'After publishing, open <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → URL inspection, paste <code>/how-to-convert-html-to-pdf/</code> and press <strong>Request indexing</strong>.' ),
			array( 'Weekly check', 'Search Console → Performance → Pages: filter by <code>/how-to</code> and note which posts get impressions. In Keyword Planner, check the volume of this week’s focus keywords for India; swap a keyword in the SEO box if a better variation turns up.' ),
			array( 'Review the whole plan', 'Look at Performance for the last 3 months. For posts with impressions but few clicks, try another of the 10 title ideas as the SEO title.' ),
		),
	),
);
