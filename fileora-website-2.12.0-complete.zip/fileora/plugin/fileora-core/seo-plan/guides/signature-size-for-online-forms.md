---
title: Signature Size for Online Forms: 10–20 KB and the Right Pixels
slug: signature-size-for-online-forms
seo_title: Signature Size for Online Forms (10–20 KB) Explained
description: What signature size do online forms want? KB limits, pixel and cm sizes, ink, paper and scanning tips, and how to resize a signature to 10–20 KB for free.
focus_keyword: signature size
category: Exam Forms
tools: exam-form-photo-signature-resizer, compress-image-to-20kb
keywords: signature size | signature size for online forms | exam photo & signature resizer | signature box | invalid signature | 10–20 kb | signature resizer | 140 × 60 px | right pixels | file size
---
Your form keeps saying **“Invalid signature: file size must be between 10 KB and 20 KB”**. You are not alone: the signature is the upload that gets rejected most often. This guide explains what signature size forms usually want, and how to make yours fit in two minutes.

## The usual signature size

| Rule | Common value |
|---|---|
| File size | 10–20 KB (some forms allow up to 30 or 50 KB) |
| Pixels | 140 × 60 px on many bank and recruitment forms |
| Physical size | about 3.5 × 1.5 cm, 4 × 2 cm or 6 × 2 cm, depending on the exam |
| Format | JPG / JPEG |
| Ink | Black or blue, as the notification says |

These are common values, not universal rules. Some exams ask for something different; UPSC, for example, has asked for three signatures one below the other on one image. Always check the “how to apply” section of your notification.

## Step 1: sign on the right paper

- Use **plain white paper**, not ruled or coloured.
- Use a **black or blue gel or ball pen** with a firm line.
- Sign in your **normal running signature**, not in capital letters, unless the notification says otherwise.
- Sign a little larger than usual inside a box of roughly the right shape (wider than tall).

## Step 2: photograph or scan it

- Use daylight or a bright room, and no flash.
- Hold the phone straight above the paper, so the signature isn’t slanted.
- Fill most of the photo with the signature box.

## Step 3: resize it to the exact size

1. Open the [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/).
2. Add the photo of your signature and choose **Signature**. It fills in 140 × 60 px and 10–20 KB.
3. Change the numbers if your notification says something else.
4. Use **Fill** and move the frame so the whole signature sits inside it, or **Fit** to keep everything with white edges.
5. Press **Resize for the form** and upload the downloaded JPG.

[[cta:exam-form-photo-signature-resizer|Exam Photo & Signature Resizer|Exact pixels and KB for any form, in your browser.]]

Only a KB limit, no pixels? Use [Compress Image to KB]({home}/compress-image-to-20kb/) and choose **Other → 20**.

## Why signatures get rejected

- **Too small in KB**: a tiny, plain image can be under the 10 KB minimum. The resizer raises it to the minimum automatically.
- **Blurred or faint**: sign again with a darker pen.
- **Shadow or grey background**: photograph in better light or use white paper.
- **Signature in capitals** when the notification asks for running handwriting.
- **Cut-off edges**: move the frame or switch to Fit.

??? What is the standard signature size for online forms?
Many forms ask for 10–20 KB, often at 140 × 60 pixels, in JPG. Check your notification.

??? How do I make my signature exactly 20 KB?
Use the Exam Photo & Signature Resizer with 10 KB minimum and 20 KB maximum.

??? Can I use blue ink?
Only if the notification allows it. Many ask for black ink.

??? Is my signature uploaded when I resize it?
No. Fileora resizes it in your browser; it never leaves your phone.
