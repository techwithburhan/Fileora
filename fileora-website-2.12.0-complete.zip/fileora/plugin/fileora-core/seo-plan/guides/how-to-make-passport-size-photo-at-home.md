---
title: How to Make a Passport Size Photo at Home with Your Phone
slug: how-to-make-passport-size-photo-at-home
seo_title: How to Make Passport Size Photo at Home, Free
description: How to make a passport size photo at home: take it with your phone, crop it to 35×45 mm, fit several on one 4×6 sheet and print it for a few rupees.
focus_keyword: passport size photo at home
category: Image Guides
tools: passport-size-photo-maker, exam-form-photo-signature-resizer
keywords: passport size photo at home | passport size photo | passport photo maker | make a passport size photo | passport photos | photo paper | a4 photo | indian passport | photo lab | actual size
---
Need passport size photos today for a form, a SIM card or an admission? You can make them yourself with a phone and print several on one 4 × 6 sheet at any photo shop. Here is how to make a passport size photo at home that looks professional.

## Step 1: set up

- A **plain white or very light wall**, with nothing behind your head.
- **Daylight from a window in front of you**, not behind. Avoid overhead lights that cast shadows under the eyes.
- A friend to take the photo from about **1.5 metres**, phone at your eye level. A tripod and timer work too.

## Step 2: take the photo

- Look straight at the camera, mouth closed, neutral expression.
- Both ears visible, hair away from the eyes, no cap or dark glasses.
- Wear dark, plain clothes against the light wall.
- Take several shots and choose the sharpest.

## Step 3: crop and lay out

1. Open the [Passport Photo Maker]({home}/passport-size-photo-maker/).
2. Add your photo and choose **35 × 45 mm** (India) or **2 × 2 in** (USA).
3. Move and resize the box so the head is centred with a little space above it.
4. Choose **4 × 6 in photo** and **As many as fit**, with thin cutting lines.
5. Download the sheet.

[[cta:passport-size-photo-maker|Passport Photo Maker|Passport photos on a 4×6 sheet, made in your browser.]]

## Step 4: print

- Take the file to any photo lab or print shop and ask for a **4 × 6 glossy print at actual size**.
- Or print on A4 photo paper at home at 100% scale.
- Cut along the lines with a ruler and a sharp cutter.

## Passport size photo at home: sizes at a glance

| Use | Size |
|---|---|
| Indian passport, most Indian forms | 35 × 45 mm |
| US visa and passport | 2 × 2 in (51 × 51 mm) |
| Some ID cards and forms | 30 × 40 mm or 25 × 35 mm |

For an official passport application, follow the exact rules of the passport office; some offices take the photo themselves at the appointment.

## Need a digital photo for an online form?

Forms usually want a file of 20–50 KB at a set pixel size, not a print. Use the [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/).

??? What is the size of a passport photo in India?
35 × 45 mm, with the face taking up most of the height.

??? How many passport photos fit on a 4×6 print?
Several. Choose “As many as fit” in the tool to fill the sheet.

??? Can I use a mobile photo for a passport photo?
Yes, if it is sharp, evenly lit and taken against a plain light background.

??? Is my photo uploaded?
No. The Passport Photo Maker works entirely in your browser.
