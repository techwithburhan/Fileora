---
title: How to Compress a PDF for Email (Under 25 MB, or Much Smaller)
slug: compress-pdf-for-email
seo_title: Compress PDF for Email: Get Under 25 MB, Free
description: Compress PDF for email when Gmail or Outlook says the file is too big. Get large PDFs under 25 MB, or far smaller for fast sending, without losing readability.
focus_keyword: compress pdf for email
category: PDF Guides
tools: compress-pdf, split-pdf
keywords: compress pdf for email | compress pdf | file is too big | attachment limit | email under 25 mb | reduce pdf size | under 25 mb | split pdf | compress a pdf | gmail or outlook
---
Gmail and Outlook limit attachments to about 25 MB and 20 MB, and many office mail servers allow much less. A scanned report or a PDF full of photos easily goes over. Here is how to compress PDF for email so it sends first time.

## Step 1: check the size

On a computer, right-click the file and choose Properties (Windows) or Get Info (Mac). On a phone, the Files app shows the size under the name. Anything over 10 MB is worth compressing, even if it is under the limit: smaller files send and open faster.

## Step 2: compress PDF for email

1. Open [Compress PDF]({home}/compress-pdf/).
2. Add your file.
3. Choose **Balanced** for a big saving with good quality. Choose **Strong** if you need the smallest file.
4. Download, check the new size, and attach.

[[cta:compress-pdf|Compress PDF|Smaller PDFs for email and uploads.]]

## Still too large?

- **Split it**: send two or three parts with [Split PDF]({home}/split-pdf/), naming them “Part 1 of 3” and so on.
- **Remove unneeded pages**: blank pages, duplicates, long annexures.
- **Use a link**: upload to Google Drive or OneDrive and email the link. Set the sharing permission carefully.

## How much will it shrink?

How far you can reduce PDF size depends on what is inside the file:

| PDF type | Typical result |
|---|---|
| Scans and phone photos | Large reduction |
| Brochures and presentations with images | Good reduction |
| Text-only documents | Small reduction (they are already small) |

## Before sending

- Open the compressed file and zoom into small text and signatures to make sure they are readable.
- Keep the original for printing.
- Sensitive document? Add a password with [Protect PDF]({home}/protect-pdf/) and send the password by SMS.

??? What is Gmail’s attachment limit?
About 25 MB per email. Larger files are sent as a Google Drive link.

??? Will compressing make my PDF unreadable?
Balanced keeps documents easy to read. Check small print after using Strong.

??? Can I compress a PDF on my phone?
Yes. Compress PDF works in any mobile browser.

??? Is compression free?
Yes, with no sign-up.
