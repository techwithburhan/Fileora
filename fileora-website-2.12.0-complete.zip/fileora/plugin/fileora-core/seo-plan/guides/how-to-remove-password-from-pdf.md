---
title: How to Remove a Password from a PDF (When You Know It)
slug: how-to-remove-password-from-pdf
seo_title: How to Remove Password from PDF, Free and Easy
description: Remove password from PDF files you can open, like bank statements, e-Aadhaar and salary slips. Free online, plus Chrome and Adobe methods.
focus_keyword: remove password from pdf
category: PDF Guides
tools: unlock-pdf, protect-pdf
keywords: remove password from pdf | unlock pdf | remove a pdf password | pdf password | current password | save as pdf | e-aadhaar password | protect pdf | remove security | remove password from pdf files
---
Bank statements, credit card bills, salary slips and e-Aadhaar arrive as password-protected PDFs. That is good for security, but annoying when you need to open, merge, print or upload them again and again. Here is how to remove password from PDF files that you are allowed to open.

You need the current password. Removing a password you don’t know is a different matter and is not what this guide covers.

## Method 1: remove password from PDF with Unlock PDF

1. Open [Unlock PDF]({home}/unlock-pdf/).
2. Add the protected PDF.
3. Type the current password and confirm that you are allowed to unlock it.
4. Download the copy without a password.

It works on phones and computers and handles several files at once. Files travel over an encrypted connection and are deleted after download.

[[cta:unlock-pdf|Unlock PDF|Remove a known password in seconds.]]

## Method 2: Chrome’s Save as PDF

1. Open the PDF in Chrome and type the password.
2. Press **Ctrl + P** (or Cmd + P on Mac).
3. Choose **Save as PDF** as the printer and save.

The new copy has no password. On some PDFs that block printing, this method won’t work, and interactive form fields may be flattened.

## Method 3: Adobe Acrobat (paid)

In Acrobat Pro, open the file, go to **Protect → Encrypt → Remove Security**, and save. This needs the paid version.

## Where to find the password

- **Bank statements**: usually a part of your name and date of birth, or your customer ID. The pattern is in the email the statement came with.
- **e-Aadhaar**: the first 4 letters of your name in capitals plus your year of birth. See our [e-Aadhaar password guide]({home}/e-aadhaar-pdf-password/).
- **Salary slips and Form 16**: often your PAN in capitals, or PAN with date of birth. Ask your HR team if unsure.

## Forgot the password?

Ask the sender for the password or a new copy. Banks and employers can resend documents. Guessing or cracking passwords on files that aren’t yours is not something to attempt.

## Protect it again later

To share an unlocked file safely, add a new password with [Protect PDF]({home}/protect-pdf/) and send the password separately.

??? Can I remove a PDF password without knowing it?
No. You need the current password to unlock the file.

??? Is it legal to remove a PDF password?
For your own documents, such as your bank statement, yes. Only unlock files you have the right to change.

??? Does removing the password change the document?
No. The content stays exactly the same.

??? Can I unlock PDFs on my phone?
Yes. Unlock PDF works in any mobile browser.
