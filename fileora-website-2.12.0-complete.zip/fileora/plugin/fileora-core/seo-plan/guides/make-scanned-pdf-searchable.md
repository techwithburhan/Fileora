---
title: How to Make a Scanned PDF Searchable (OCR in English and Hindi)
slug: make-scanned-pdf-searchable
seo_title: Make a Scanned PDF Searchable with OCR, Free
description: Make a scanned PDF searchable so you can find, select and copy text. How OCR works, how to get accurate English and Hindi results, and what to do next.
focus_keyword: scanned pdf searchable
category: PDF Guides
tools: ocr-pdf, scan-to-pdf, pdf-to-word
keywords: scanned pdf searchable | make a scanned pdf searchable | ocr pdf | searchable pdf | english and hindi | ocr in english | copy text | pdf searchable ocr | scanned pdf | redact pdf
---
You press Ctrl+F in a scanned PDF and nothing is found, because the pages are pictures. Optical character recognition (OCR) fixes that: it reads the text in the images and adds it to the PDF. Here is how to make a scanned PDF searchable, and how to get accurate results.

## How to make a scanned PDF searchable

1. Open [OCR PDF]({home}/ocr-pdf/).
2. Add your scanned PDF (up to 10 at once).
3. Choose the **Document language**: English, Hindi, Marathi, Tamil, Bengali and more.
4. Choose **Searchable PDF** as the output.
5. Download. The pages look the same, but now you can search, select and copy text.

[[cta:ocr-pdf|OCR PDF|Searchable PDFs from scans, in Indian languages too.]]

## Getting accurate results

| Input | Result |
|---|---|
| Clean scan at 300 dpi | Excellent |
| Sharp phone photo in daylight | Good |
| Blurry, tilted or shadowed photo | Many mistakes |
| Handwriting | Poor |

- Clean up phone photos first with [Scan to PDF]({home}/scan-to-pdf/), using the Document look.
- Choose the language that most of the text is in.
- Old typewritten or faded pages need the best scan you can get.

## Hindi and other Indian languages

OCR for Hindi works well on printed text such as notices, books and government letters. Choose **Hindi** as the language. For mixed Hindi and English pages, choose the main language. Results for older pages with special fonts may need checking.

## What to do with the text

- Edit the document: convert the searchable PDF with [PDF to Word]({home}/pdf-to-word/).
- Just the words: choose **Text file** as the OCR output.
- Hide personal details: search and black them out with [Redact PDF]({home}/redact-pdf/).

??? What does OCR stand for?
Optical character recognition: software that reads text in images.

??? Can OCR read Hindi?
Yes. Choose Hindi as the document language.

??? Will the PDF look different after OCR?
No. An invisible text layer is added behind the page images.

??? Is OCR PDF free?
Yes, with no sign-up. Files are deleted after download.
