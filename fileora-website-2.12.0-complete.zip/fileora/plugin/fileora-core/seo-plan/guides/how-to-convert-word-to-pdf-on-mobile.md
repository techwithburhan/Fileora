---
title: How to Convert Word to PDF on Mobile (Android and iPhone)
slug: how-to-convert-word-to-pdf-on-mobile
seo_title: How to Convert Word to PDF on Mobile, Free
description: How to convert Word to PDF on mobile, Android or iPhone, in a minute: three free ways including a browser method with no app, plus font and size tips.
focus_keyword: word to pdf on mobile
category: PDF Guides
tools: word-to-pdf, compress-pdf, merge-pdf
keywords: word to pdf on mobile | convert word to pdf | word to pdf | microsoft word app | android and iphone | no app | word file | pdf on mobile | google docs | merge pdf
---
A recruiter wants your CV as a PDF, and you only have your phone. Good news: converting Word to PDF on mobile takes about a minute. Here are three ways that work on Android and iPhone.

## Method 1: in your browser (no app)

1. Open [Word to PDF]({home}/word-to-pdf/) in Chrome or Safari.
2. Tap the box and choose your .doc or .docx file from Files, Downloads, WhatsApp documents or Google Drive.
3. Tap convert and download the PDF.

This works for any Word file, even if you don’t have Microsoft Word installed, and keeps your fonts and layout. The file is converted on our server over an encrypted connection and deleted after download.

[[cta:word-to-pdf|Word to PDF|DOC and DOCX to PDF, free, on any phone.]]

## Method 2: from the Microsoft Word app

If you already have the Word app:

1. Open the document in Word.
2. Tap the **three dots** (Android) or the **File** menu (iPhone).
3. Choose **Save as** or **Export**, then **PDF**.

## Method 3: from Google Docs

1. Open the Word file in Google Docs.
2. Tap the **three dots → Share & export → Save as**.
3. Choose **PDF document**.

Google Docs sometimes changes fonts and spacing in Word files, so check the PDF before sending.

## Word to PDF on mobile: which method to use?

| Situation | Best method |
|---|---|
| No Word app, want the exact layout | Browser (Fileora) |
| Several files at once | Browser (up to 20 files) |
| You are editing in Word anyway | Word app |
| The file is already in Google Drive | Google Docs |

## Before you send the PDF

- **Check the first page** for shifted text or missing fonts.
- **Combine files** such as a cover letter and CV with [Merge PDF]({home}/merge-pdf/).
- **Too large for the portal?** Use [Compress PDF]({home}/compress-pdf/).
- **Name the file clearly**, for example `Priya-Sharma-CV.pdf`.

??? Can I convert Word to PDF on my phone for free?
Yes. Fileora’s Word to PDF works free in any mobile browser.

??? Do I need the Microsoft Word app?
No. The browser method works without it.

??? Will my CV look the same as PDF?
Yes in almost all cases. Check the result once for rare fonts.

??? Where is the PDF saved?
In Downloads on Android, and in the Files app on iPhone after you tap Save to Files.
