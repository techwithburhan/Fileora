---
title: How to Scan Documents with Your Phone and Save as PDF
slug: how-to-scan-documents-with-phone
seo_title: How to Scan Documents with Your Phone to PDF
description: How to scan documents with your phone and save them as a clean PDF: lighting, angle, multi-page scans and file size, with a free scanner that needs no app.
focus_keyword: scan documents with your phone
category: PDF Guides
tools: scan-to-pdf, ocr-pdf, compress-pdf
keywords: scan documents with your phone | scan to pdf | phone scan | scan documents | multi-page documents | phone camera | save as pdf | scan several | phone to pdf | scan several pages
---
You don’t need a scanner or a cyber café. You can scan documents with your phone and get a PDF that looks like it came from an office scanner: white page, dark text, straight edges. Here is how.

## What makes a good phone scan

| Do | Avoid |
|---|---|
| Daylight or a bright, even light | Flash and a single bulb overhead |
| Phone parallel to the page, straight above | Shooting at an angle |
| Dark surface under white paper | White page on a white bed sheet |
| Whole page in view with a small border | Cut-off corners |
| Steady hands, tap to focus | Motion blur |

## How to scan documents with your phone

1. Open [Scan to PDF]({home}/scan-to-pdf/) in your phone’s browser.
2. Tap the box and take a photo of the first page, or choose photos you already took.
3. Add the remaining pages in order.
4. Choose the **Document** look for text: it makes the paper white and the text dark. Use **Original** for coloured certificates and photos.
5. Create the PDF and download it.

[[cta:scan-to-pdf|Scan to PDF|Your phone camera as a document scanner. No app.]]

## Multi-page documents

Scan all pages into one PDF: add them one by one, then drag any page that is out of order. For double-sided papers, scan the front and back of each sheet in turn.

## Make it searchable

A scan is a picture of text. To search, copy or convert it to Word, run it through [OCR PDF]({home}/ocr-pdf/), which supports Hindi and many Indian languages.

## Make it smaller for upload

Phone scans can be several MB. If a portal limits uploads to 1 MB or less, use [Compress PDF]({home}/compress-pdf/). Our guide on [compressing PDFs to 100 KB or 200 KB]({home}/compress-pdf-to-100kb-200kb/) helps with strict limits.

## Which documents can I scan this way?

Marksheets, certificates, ID cards, signed forms, rent agreements, bills and receipts. For ID cards, [ID Card Print]({home}/id-card-print/) gives you a real-size printable copy instead.

??? Do I need an app to scan documents?
No. Fileora’s Scan to PDF works in your phone’s browser.

??? How do I make a phone scan look clean?
Use daylight, hold the phone straight above the page and choose the Document look.

??? Can I scan several pages into one PDF?
Yes. Add each page and they become one PDF.

??? Are my scans uploaded?
No. The PDF is made on your phone.
