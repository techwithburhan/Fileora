---
title: e-Aadhaar PDF Password: Format, Examples and What to Do If It Fails
slug: e-aadhaar-pdf-password
seo_title: e-Aadhaar PDF Password: Format and Examples
description: The e-Aadhaar PDF password is the first 4 letters of your name in capitals plus your year of birth. Examples, special cases and fixes when it doesn’t work.
focus_keyword: e-aadhaar pdf password
category: Aadhaar & ID
tools: unlock-pdf, aadhaar-card-print
keywords: e-aadhaar pdf password | e-aadhaar pdf password format | aadhaar pdf password | unlock pdf | remove the password | password format | year of birth | what to do if it fails | protected pdf | e-aadhaar pdf
---
You downloaded your Aadhaar from the UIDAI website, and the PDF asks for a password. The e-Aadhaar PDF password is not your Aadhaar number or your phone OTP. It follows a simple rule.

## The e-Aadhaar PDF password format

**First 4 letters of your name, in CAPITAL letters, followed by your year of birth (YYYY).**

Use the name exactly as it is printed on your Aadhaar.

| Name on Aadhaar | Year of birth | Password |
|---|---|---|
| Rahul Kumar | 1990 | RAHU1990 |
| Priya Sharma | 2001 | PRIY2001 |
| S. Kumar | 1985 | S.KU1985 |
| Om Prakash | 1978 | OMPR1978 |

## Special cases

- **Short first names**: spaces are not counted. “Om Prakash” uses OMPR.
- **Initials with a dot**: the dot counts as a character, as in S.KU.
- **Name shorter than 4 letters in total**: use the whole name, then the year, for example “Ram” born 1995 is RAM1995.
- **Only the year of birth on your Aadhaar**: you still use the year, so the rule is the same.

These follow the format UIDAI describes. If yours still doesn’t open, check the exact spelling on your card.

## If the password doesn’t work

1. Check capital letters: the four letters must all be uppercase.
2. Check the spelling and spacing of your name as printed on the Aadhaar, not as you usually write it.
3. Check the year of birth: some people have a different year on Aadhaar than on other documents.
4. Download the e-Aadhaar again, in case the file was damaged.

## Remove the password once

Typing the password every time is tiring, and some portals reject protected PDFs. Remove it with [Unlock PDF]({home}/unlock-pdf/): add the file, type the password once, and download a copy without it.

[[cta:unlock-pdf|Unlock PDF|Remove the password from a PDF you are allowed to open.]]

## Print it at card size

To get a wallet-size copy instead of a full A4 page, use [Aadhaar Card Print]({home}/aadhaar-card-print/). It opens the protected PDF with your password in your browser and lays out the front and back at real card size. Our guide on [printing Aadhaar at real size]({home}/how-to-print-aadhaar-card-real-size/) has the details.

??? What is the password of the e-Aadhaar PDF?
The first four letters of your name in capitals plus your year of birth, such as RAHU1990.

??? Is the password my Aadhaar number?
No. It is based on your name and year of birth.

??? Is it safe to unlock my Aadhaar PDF online?
Keep a protected original, and prefer tools that explain how they handle files. Fileora deletes files after download, and its Aadhaar Card Print tool works fully in your browser.

??? Can I remove the password permanently?
Yes. Unlock PDF gives you a copy without a password.
