---
title: How to Split PDF Pages: Extract One Page or Save Each Page Separately
slug: how-to-split-pdf-pages
seo_title: How to Split PDF Pages and Extract Pages, Free
description: How to split PDF pages: extract one page, save page ranges or turn every page into its own file, on phone or PC. Free, with no app and no upload.
focus_keyword: split pdf pages
category: PDF Guides
tools: split-pdf, organize-pdf, merge-pdf
keywords: split pdf pages | split pdf | extract pages | extract one page from a pdf | pages per file | page from a pdf | save each page separately | page ranges | new pdf | certain pages
---
Sometimes you need only page 3 of a 40-page PDF: one certificate, the signed page of a contract, or a single month’s statement. Here is how to split PDF pages in a few clicks, free, on a phone or a computer.

## Split PDF pages: three ways

The [Split PDF]({home}/split-pdf/) tool offers three modes:

| You want | Choose | Example |
|---|---|---|
| Certain pages only | **Page ranges** | `3` or `1-2, 5, 9-10` |
| Every page as its own file | **Every page** | 12 pages become 12 PDFs |
| Equal parts | **Fixed size** | 5 pages per file |

## How to extract one page from a PDF

1. Open [Split PDF]({home}/split-pdf/) and add your file.
2. Choose **Page ranges** and type the page number, for example `3`.
3. Download the new PDF with just that page.

To take several pages into one file, type them all (`1-2, 5`) and tick **Put all ranges in one PDF**.

[[cta:split-pdf|Split PDF|Extract pages or split into parts, in your browser.]]

## How to save every page as a separate PDF

Choose **Every page** and download. You get one file per page, numbered in order. Useful when several documents were scanned together in one go.

## How to split a large PDF for upload limits

Portals with a 2 MB or 5 MB limit can choke on long scanned files. Choose **Fixed size** and set pages per file, for example 10. Then compress each part with [Compress PDF]({home}/compress-pdf/) if needed.

## Split vs. organize

- **Split** makes new files from parts of a PDF.
- [Organize PDF]({home}/organize-pdf/) keeps one file but lets you reorder, rotate and delete pages.

To remove one page and keep the rest in one file, Organize is quicker.

## On a phone

Open fileora.in/split-pdf in your browser, pick the PDF from Files or WhatsApp documents, type the pages and download. No app needed.

??? How do I extract a single page from a PDF?
Use Page ranges in Split PDF and type the page number.

??? Can I split a PDF into individual pages?
Yes. Choose Every page.

??? Does splitting reduce quality?
No. Pages are copied without change.

??? Are my files uploaded?
No. Split PDF runs in your browser.
