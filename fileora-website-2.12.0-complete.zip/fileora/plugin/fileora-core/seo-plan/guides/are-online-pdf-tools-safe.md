---
title: Are Online PDF Tools Safe? What to Check Before You Upload
slug: are-online-pdf-tools-safe
seo_title: Are Online PDF Tools Safe? A Checklist
description: Are online PDF tools safe for Aadhaar, bank statements and certificates? What happens to your file, the risks, and a 6-point checklist.
focus_keyword: online pdf tools safe
category: PDF Guides
tools: merge-pdf, unlock-pdf, aadhaar-card-print
keywords: online pdf tools safe | are online pdf tools safe | browser-based tools | server tools | in-browser tools | is fileora safe | watermark pdf | redact pdf | protect pdf | privacy policy
---
You need to merge your Aadhaar with a bank statement, and the quickest way is a free website. But are online PDF tools safe for documents like these? The honest answer: it depends on how the tool handles your file. Here is what happens behind the upload button, and how to check.

## Two kinds of online PDF tools

| | Browser-based | Server-based |
|---|---|---|
| Where the work happens | On your own phone or computer | On the company’s computers |
| Does the file leave your device? | No | Yes, over the internet |
| What you rely on | The website’s code | The company deleting your file |
| Examples on Fileora | Merge, Split, JPG to PDF, Sign, Aadhaar Print, image tools | PDF to Word, Word to PDF, OCR, Unlock |

Some tasks, like converting PDF to Word, need software that browsers don’t have, so they must run on a server. That isn’t unsafe in itself, but it means trusting the service to protect and delete the file.

## Are online PDF tools safe? Six checks before you upload

1. **HTTPS**: the address starts with https and shows a lock.
2. **A clear privacy policy** that says what happens to files and when they are deleted.
3. **Says where processing happens**: in the browser or on a server.
4. **No unnecessary sign-up**: you shouldn’t need an account to merge two files.
5. **A real contact**: an email address or contact page, and a named organisation.
6. **Not too good to be true**: tools that ask for extra personal details or install software are a warning sign.

## Extra care for sensitive documents

- Prefer **browser-based tools** for Aadhaar, PAN, passport and bank documents.
- **Watermark** ID copies with their purpose before sending, using [Watermark PDF]({home}/watermark-pdf/).
- **Black out** account numbers you don’t need to share with [Redact PDF]({home}/redact-pdf/).
- **Keep passwords** on documents you email, using [Protect PDF]({home}/protect-pdf/).

## How Fileora handles files

Every Fileora tool page says whether it runs **In browser** or on our **Server**. In-browser tools never send your file anywhere. Server tools send it over HTTPS to our processing server, and it is deleted after download or automatically. Our [Security]({home}/security/) page lists every tool. No online service can promise zero risk, but you should always be able to see what happens to your file.

??? Is it safe to upload Aadhaar to a PDF website?
Prefer tools that process the file in your browser, such as Fileora’s Aadhaar Card Print, so the file never leaves your device.

??? Do online PDF tools keep my files?
Reputable services delete them after a short time and say so in their privacy policy. Browser-based tools never receive them.

??? How can I tell if a tool runs in my browser?
Look for a statement on the page. On Fileora, every tool is labelled In browser or Server.

??? Is Fileora safe?
Most tools run in your browser. Server tools delete files after download or automatically. Read our Security page for details.
