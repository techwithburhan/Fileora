---
title: How to Add Page Numbers to a Project Report or Thesis PDF
slug: number-pages-in-project-report
seo_title: Page Numbers in a Project Report PDF: Step by Step
description: Add page numbers in a project report or thesis PDF the way colleges want: skip the cover, start from 1 on chapter one, and keep the index correct.
focus_keyword: page numbers in a project report
category: PDF Guides
tools: add-page-numbers-to-pdf, split-pdf, merge-pdf
keywords: page numbers in a project report | add page numbers | project report pdf | skip the first page | cover page | roman numbers | thesis pdf | page ranges | first page | project report or thesis
---
Your report is ready, but the college format says: no number on the cover, Roman numbers on the front pages, and 1 on the first chapter. Here is how to put page numbers in a project report PDF correctly, even if the chapters came from different files.

## Page numbers in a project report: the usual college format

| Part | Numbering |
|---|---|
| Cover page | No number |
| Certificate, declaration, acknowledgement, index | Often i, ii, iii… or no numbers |
| Chapter 1 onwards | 1, 2, 3… at the bottom centre |

Check your university’s format guide: some want numbers at the top right or “Page 1 of N”.

## Step 1: put the whole report in one PDF

If each chapter is a separate file, join them in order with [Merge PDF]({home}/merge-pdf/). Fix any page in the wrong place with [Organize PDF]({home}/organize-pdf/).

## Step 2: separate the front pages

Use [Split PDF]({home}/split-pdf/) with page ranges:

- Range 1: the cover and front pages, for example `1-6`.
- Range 2: chapter one to the end, for example `7-58`.

## Step 3: add page numbers to the main part

1. Open [Add Page Numbers]({home}/add-page-numbers-to-pdf/) and add the main part.
2. Position: **bottom centre**. Format: **1**. Start at: **1**.
3. Download.

If you don’t need to separate front pages, just turn on **Skip the first page (cover)**.

[[cta:add-page-numbers-to-pdf|Add Page Numbers|Number pages with the position and format you choose.]]

## Step 4: join everything again

Merge the front pages and the numbered main part with [Merge PDF]({home}/merge-pdf/). Your cover stays clean and chapter one starts at page 1.

## Keep the index correct

Update the page numbers in your table of contents to match the final PDF before printing. Open the numbered file and note where each chapter starts.

## Printing and binding

- Print at 100% scale so numbers don’t get cut off at the edge.
- Leave a wider left margin for binding.
- Double-sided printing? Check that odd pages fall on the right.

??? How do I skip the cover page when numbering?
Turn on “Skip the first page (cover)”.

??? Can I start numbering from chapter one?
Yes. Split off the front pages, number the rest from 1, then merge them again.

??? Can I use “Page 1 of 50”?
Yes. Choose that format in the tool.

??? Is it free?
Yes, and it runs in your browser without uploading your report.
