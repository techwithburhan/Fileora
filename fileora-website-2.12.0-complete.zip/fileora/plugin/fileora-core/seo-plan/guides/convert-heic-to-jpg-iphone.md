---
title: How to Convert iPhone HEIC Photos to JPG (and Stop Saving HEIC)
slug: convert-heic-to-jpg-iphone
seo_title: Convert HEIC to JPG on iPhone and Windows, Free
description: Convert HEIC to JPG when iPhone photos won’t open on Windows, Android or an upload form, and change one iPhone setting so new photos save as JPG.
focus_keyword: convert heic to jpg
category: Image Guides
tools: heic-to-jpg, compress-image
keywords: convert heic to jpg | heic to jpg | convert iphone heic photos | iphone save jpg | heic files | open heic | convert heic to jpg on iphone | most compatible | invalid file type | heic photos
---
You copied photos from an iPhone and Windows says it can’t open them, or a form says “invalid file type”. The files end in **.heic**. Here is how to convert HEIC to JPG, and how to make your iPhone save JPG from now on.

## Why iPhones use HEIC

HEIC stores photos at about half the size of JPG at the same quality, so Apple uses it by default. iPhones, Macs and recent Android phones open it, but many Windows PCs, older apps and most government and job portals don’t.

## Convert HEIC to JPG in your browser

1. Open [HEIC to JPG]({home}/heic-to-jpg/) on any device.
2. Add your .heic photos. Add dozens at once if you like.
3. Choose **JPG** and a quality of about 90%.
4. Convert and download.

The photos are converted on your own device and never uploaded, which matters for personal pictures.

[[cta:heic-to-jpg|HEIC to JPG|iPhone photos to JPG, privately in your browser.]]

## Make your iPhone save JPG

1. Open **Settings → Camera → Formats**.
2. Choose **Most Compatible**.

New photos are saved as JPG. Photos you already took stay HEIC.

## Make transfers convert automatically

**Settings → Photos → Transfer to Mac or PC → Automatic** makes the iPhone convert to JPG when you copy photos by cable. Sharing by AirDrop, email or WhatsApp also usually sends JPG.

## Next steps

- Upload limit on a form? Use [Compress Image to KB]({home}/compress-image-to-20kb/).
- Many photos for a website? Use [Compress Image]({home}/compress-image/).
- Put photos into a PDF: [JPG to PDF]({home}/jpg-to-pdf/).

??? Why can’t I open HEIC files on Windows?
Windows needs an extra codec for HEIC. Converting to JPG is the simplest fix.

??? Does converting HEIC to JPG reduce quality?
At 90% quality the difference is hard to see.

??? How do I stop my iPhone taking HEIC photos?
Settings → Camera → Formats → Most Compatible.

??? Are my photos uploaded?
No. Fileora converts them in your browser.
