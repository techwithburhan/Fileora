---
title: How to Merge PDF Files on Phone and PC (Free, No App)
slug: how-to-merge-pdf-files
seo_title: How to Merge PDF Files on Phone and PC, Free
description: How to merge PDF files into one on Android, iPhone, Windows or Mac in under a minute: free, no app and no sign-up, with tips for order, size and passwords.
focus_keyword: merge pdf files
category: PDF Guides
tools: merge-pdf, compress-pdf, organize-pdf
keywords: merge pdf files | merge pdf | combine pdf | merge pdf files on phone | phone and pc | organize pdf | jpg to pdf | no app | files app | merge pdf online
---
Need to send your certificates, ID proof and marksheets as **one** file? Most application portals accept a single upload, and offices prefer one tidy PDF over ten attachments. Here is how to merge PDF files on any phone or computer, for free, without installing anything.

## What you need

- The PDF files you want to combine. Photos? Turn them into PDFs first with [JPG to PDF]({home}/jpg-to-pdf/).
- A browser: Chrome, Safari, Edge or Firefox.
- About one minute.

## How to merge PDF files on a computer

1. Open [Merge PDF]({home}/merge-pdf/) on Fileora.
2. Drag your PDF files from a folder into the box, or click the box to choose them.
3. Arrange them in the order you want. The file marked **1** becomes the first pages.
4. Click **Merge PDF** and download the combined file.

It feels like any merge PDF online service, but the merge happens in your browser, so your documents are never uploaded. That matters for ID proofs and certificates.

## How to merge PDF files on Android

1. Open Chrome and go to fileora.in/merge-pdf.
2. Tap the box and choose **Files** (or Google Drive) to select your PDFs. Hold a file to select several at once.
3. Use the arrows to put them in order.
4. Tap **Merge PDF**. The file is saved in your **Downloads** folder.

## How to merge PDF files on iPhone

1. Open Safari and go to fileora.in/merge-pdf.
2. Tap the box, then **Choose Files**, and pick the PDFs from the Files app or iCloud Drive.
3. Put them in order and tap **Merge PDF**.
4. Tap the download, then **Save to Files**.

[[cta:merge-pdf|Merge PDF|Combine PDFs in the order you want, free and in your browser.]]

## Which order should documents go in?

For job and exam applications, a common order is:

1. Application form or cover letter
2. ID proof (Aadhaar, PAN, passport)
3. Educational certificates, from highest to oldest
4. Experience letters, latest first
5. Category, income or other certificates

Always follow the order the notification asks for, if it gives one.

## The merged file is too big

Portals often allow only 1 or 2 MB. After merging, run the file through [Compress PDF]({home}/compress-pdf/). Scanned pages shrink the most. If it is still too large, remove pages you don’t need with [Organize PDF]({home}/organize-pdf/).

## Problems and fixes

- **“This PDF is password-protected”**: bank statements and e-Aadhaar often have a password. Remove it first with [Unlock PDF]({home}/unlock-pdf/), using the password you already know.
- **A page is sideways**: fix it in [Organize PDF]({home}/organize-pdf/) after merging.
- **Wrong page order inside one file**: merge first, then drag pages into place in Organize PDF.

??? Can I merge PDF files without installing software?
Yes. Fileora’s Merge PDF works in your browser on phones and computers.

??? Is merging PDFs free?
Yes, with no sign-up, no watermark and no limit on the number of files.

??? Does merging reduce quality?
No. Pages are copied as they are.

??? How do I merge PDF and JPG files together?
Convert the JPG images to PDF with JPG to PDF, then merge all the PDFs.
