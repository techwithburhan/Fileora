<?php
/**
 * The 60-day plan: what each day changes ("auto") and what you do yourself ("manual").
 * Generated from the plan table; content files are in tools/, guides/ and pages/.
 *
 * Auto items: home, sitemap, menu (list of slugs), tool <slug>, guide <slug>, page <slug>.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

return array(
	1 => array(
		'title'  => 'Fix the foundation',
		'why'    => 'The server tools and the homepage title come before everything else.',
		'auto'   => array( array( 'home' ), array( 'sitemap' ) ),
		'manual' => array(
			array( 'Connect the processing server', 'Go to <a href="admin.php?page=fileora-settings" target="_blank" rel="noopener">Fileora → Settings</a>, set <strong>Processing server</strong> to <code>https://api.fileora.in</code>, save, then press <strong>Test the connection</strong>. Until it passes, PDF to Word, Word to PDF, OCR and other server tools don’t work.' ),
			array( 'Check the site address redirects', 'Open <code>fileora.in</code> and <code>http://www.fileora.in</code> in a private window. Both must end on <code>https://www.fileora.in/</code>. Check with <a href="https://httpstatus.io/" target="_blank" rel="noopener">httpstatus.io</a>: one 301 redirect, then 200.' ),
			array( 'Purge the cache', 'LiteSpeed Cache → Toolbox → <strong>Purge All</strong>, so visitors and Google see the new homepage title.' ),
		),
	),
	2 => array(
		'title'  => 'Header menu and the two biggest tools',
		'why'    => 'The header menu is what Google reads to choose sitelinks.',
		'auto'   => array( array( 'menu', array( 'all-tools', 'merge-pdf', 'compress-pdf', 'pdf-to-word', 'jpg-to-pdf', 'image-tools', 'ats-resume', 'blog', 'contact' ) ), array( 'tool', 'merge-pdf' ), array( 'tool', 'compress-pdf' ) ),
		'manual' => array(
			array( 'Set up Google Search Console', 'In <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a>, add a <strong>Domain</strong> property for <code>fileora.in</code>. Copy the TXT record into Hostinger → Domains → DNS, wait 10–30 minutes, then press Verify.' ),
		),
	),
	3 => array(
		'title'  => 'PDF to Word and JPG to PDF',
		'why'    => 'Two of the most searched PDF tasks.',
		'auto'   => array( array( 'tool', 'pdf-to-word' ), array( 'tool', 'jpg-to-pdf' ) ),
		'manual' => array(
			array( 'Submit the sitemap', 'Search Console → Sitemaps → enter <code>wp-sitemap.xml</code> → Submit. The status should become “Success” within a day.' ),
		),
	),
	4 => array(
		'title'  => 'India first: KB compressor and exam resizer',
		'why'    => 'These searches have less competition and Fileora has the better tool.',
		'auto'   => array( array( 'tool', 'compress-image-to-20kb' ), array( 'tool', 'exam-form-photo-signature-resizer' ) ),
		'manual' => array(
			array( 'Add Bing Webmaster Tools', 'In <a href="https://www.bing.com/webmasters" target="_blank" rel="noopener">Bing Webmaster Tools</a>, choose <strong>Import from Google Search Console</strong>. One click, and Bing receives your sitemap too.' ),
		),
	),
	5 => array(
		'title'  => 'Aadhaar and passport photos',
		'why'    => 'High demand in India, almost no strong competitors.',
		'auto'   => array( array( 'tool', 'aadhaar-card-print' ), array( 'tool', 'passport-size-photo-maker' ), array( 'guide', 'how-to-merge-pdf-files' ) ),
		'manual' => array(
			array( 'Write down your starting numbers', 'Make a sheet with columns: date, Search Console clicks, impressions, average position, indexed pages, linking websites. Fill in today’s numbers: every later result is measured against them.' ),
		),
	),
	6 => array(
		'title'  => 'Split, Word to PDF, PDF to JPG',
		'why'    => 'Core PDF tools that every competitor ranks for.',
		'auto'   => array( array( 'tool', 'split-pdf' ), array( 'tool', 'word-to-pdf' ), array( 'tool', 'pdf-to-jpg' ) ),
		'manual' => array(
			array( 'Check speed on mobile', 'Run <a href="https://pagespeed.web.dev/" target="_blank" rel="noopener">PageSpeed Insights</a> on the homepage, /merge-pdf/ and /compress-image-to-20kb/ (Mobile tab). Note LCP, INP and CLS. Targets: LCP under 2.5 s, INP under 200 ms, CLS under 0.1.' ),
		),
	),
	7 => array(
		'title'  => 'Image basics',
		'why'    => 'Compress and resize are searched every day by millions.',
		'auto'   => array( array( 'tool', 'compress-image' ), array( 'tool', 'resize-image' ) ),
		'manual' => array(
			array( 'Weekly 30-minute review', 'In Search Console → Performance (last 7 days): note clicks, impressions and average position in your KPI sheet. Check Indexing → Pages for new errors. Open Fileora → Analytics → Tool usage and note which tools people finish.' ),
		),
	),
	8 => array(
		'title'  => 'Sign and unlock',
		'why'    => 'Completes the top-15 tools.',
		'auto'   => array( array( 'tool', 'sign-pdf' ), array( 'tool', 'unlock-pdf' ), array( 'guide', 'signature-size-for-online-forms' ) ),
		'manual' => array(
			array( 'Test your structured data', 'Open Google’s <a href="https://search.google.com/test/rich-results" target="_blank" rel="noopener">Rich Results Test</a> for the homepage, /merge-pdf/ and /aadhaar-card-print/. Fix anything shown as an error (warnings are fine).' ),
		),
	),
	9 => array(
		'title'  => 'Guide: PDF to Word formatting',
		'why'    => 'Guides catch “how to” searches and send readers to the tool.',
		'auto'   => array( array( 'guide', 'convert-pdf-to-word-without-losing-formatting' ) ),
		'manual' => array(
			array( 'Create the brand profiles', 'Create Fileora accounts on X, LinkedIn (company page), YouTube, Instagram, Facebook and Pinterest with the same name, logo and one-line description. Paste their addresses in <a href="admin.php?page=fileora-seo&tab=settings" target="_blank" rel="noopener">Fileora → SEO → Site settings → Social profiles</a>.' ),
		),
	),
	10 => array(
		'title'  => 'Protect PDF and HEIC to JPG',
		'why'    => 'Security and iPhone searches.',
		'auto'   => array( array( 'tool', 'protect-pdf' ), array( 'tool', 'heic-to-jpg' ) ),
		'manual' => array(
			array( 'List Fileora on AlternativeTo', 'On <a href="https://alternativeto.net/" target="_blank" rel="noopener">AlternativeTo</a>, add Fileora as an alternative to iLovePDF and Smallpdf. Describe it honestly: free, browser-based for most tools, Indian form tools.' ),
		),
	),
	11 => array(
		'title'  => 'Scan and OCR',
		'why'    => 'Phone-scanning and searchable PDFs.',
		'auto'   => array( array( 'tool', 'scan-to-pdf' ), array( 'tool', 'ocr-pdf' ) ),
		'manual' => array(
			array( 'Speed settings in LiteSpeed Cache', 'LiteSpeed Cache → Page Optimization: turn on CSS and JS minify, but add <code>fileora-engine</code> and <code>fileora-tools</code> to the JS excludes. Image Optimization: WebP on, lazy-load on. Then purge and test a tool still works.' ),
		),
	),
	12 => array(
		'title'  => 'Guide: Word to PDF on mobile',
		'why'    => 'Most Indian visitors are on phones.',
		'auto'   => array( array( 'guide', 'how-to-convert-word-to-pdf-on-mobile' ), array( 'tool', 'id-card-print' ) ),
		'manual' => array(
			array( 'Request indexing for the top tools', 'In Search Console → URL Inspection, paste each URL and press <strong>Request indexing</strong>: homepage, /all-tools/, /merge-pdf/, /compress-pdf/, /pdf-to-word/, /jpg-to-pdf/, /compress-image-to-20kb/, /exam-form-photo-signature-resizer/, /aadhaar-card-print/, /passport-size-photo-maker/. There is a daily limit; continue tomorrow if needed.' ),
		),
	),
	13 => array(
		'title'  => 'Office conversions',
		'why'    => 'Excel and PowerPoint round out the converter set.',
		'auto'   => array( array( 'tool', 'pdf-to-excel' ), array( 'tool', 'excel-to-pdf' ), array( 'tool', 'powerpoint-to-pdf' ) ),
		'manual' => array(
		),
	),
	14 => array(
		'title'  => 'Guide: e-Aadhaar password',
		'why'    => 'A question asked by everyone who downloads e-Aadhaar.',
		'auto'   => array( array( 'guide', 'e-aadhaar-pdf-password' ) ),
		'manual' => array(
			array( 'Weekly 30-minute review', 'In Search Console → Performance (last 7 days): note clicks, impressions and average position in your KPI sheet. Check Indexing → Pages for new errors. Open Fileora → Analytics → Tool usage and note which tools people finish.' ),
			array( 'Add product listings', 'Add Fileora to <a href="https://www.saashub.com/" target="_blank" rel="noopener">SaaSHub</a> and <a href="https://betalist.com/" target="_blank" rel="noopener">BetaList</a>. Use the same description everywhere. Skip paid or bulk directory submissions.' ),
		),
	),
	15 => array(
		'title'  => 'Rotate and organize',
		'why'    => 'Page tools used together with merge and split.',
		'auto'   => array( array( 'tool', 'rotate-pdf' ), array( 'tool', 'organize-pdf' ) ),
		'manual' => array(
			array( 'Add one screenshot to Merge PDF', 'Merge two PDFs, take a screenshot of the tool with the files in place, save it as WebP under 80 KB named <code>merge-pdf-tool.webp</code>, and add it to the Merge PDF text with alt text such as “Merge PDF tool combining two PDF files”.' ),
		),
	),
	16 => array(
		'title'  => 'Guide: remove a PDF password',
		'why'    => 'Strong search demand, linked to Unlock PDF.',
		'auto'   => array( array( 'guide', 'how-to-remove-password-from-pdf' ), array( 'tool', 'watermark-pdf' ) ),
		'manual' => array(
			array( 'Add your portfolio link', 'On techdeployers.com, add Fileora to your portfolio with a short description and a link to https://www.fileora.in/. A relevant link from your own site is a fair first backlink.' ),
		),
	),
	17 => array(
		'title'  => 'Page numbers and image crop',
		'why'    => 'Student and social media searches.',
		'auto'   => array( array( 'tool', 'add-page-numbers-to-pdf' ), array( 'tool', 'crop-image' ) ),
		'manual' => array(
			array( 'Screenshots for Compress PDF and JPG to PDF', 'Same as day 15: one clear screenshot per tool, WebP under 80 KB, descriptive file name and alt text.' ),
		),
	),
	18 => array(
		'title'  => 'Guide: passport photo at home',
		'why'    => 'Turns a common need into a Fileora visit.',
		'auto'   => array( array( 'guide', 'how-to-make-passport-size-photo-at-home' ), array( 'tool', 'convert-image' ) ),
		'manual' => array(
		),
	),
	19 => array(
		'title'  => 'PNG and JPG converters',
		'why'    => 'Simple, high-volume format searches.',
		'auto'   => array( array( 'tool', 'png-to-jpg' ), array( 'tool', 'jpg-to-png' ) ),
		'manual' => array(
			array( 'Check Search Console for errors', 'Indexing → Pages: look at “Why pages aren’t indexed”. “Discovered – currently not indexed” is normal for new pages. “Not found (404)” or “Server error” needs fixing: tell your developer which URLs.' ),
		),
	),
	20 => array(
		'title'  => 'Guide: split PDF pages',
		'why'    => 'Links to Split and Organize.',
		'auto'   => array( array( 'guide', 'how-to-split-pdf-pages' ) ),
		'manual' => array(
		),
	),
	21 => array(
		'title'  => 'PDF to PowerPoint and HTML to PDF',
		'why'    => 'Completes the converters.',
		'auto'   => array( array( 'tool', 'pdf-to-powerpoint' ), array( 'tool', 'html-to-pdf' ) ),
		'manual' => array(
			array( 'Weekly 30-minute review', 'In Search Console → Performance (last 7 days): note clicks, impressions and average position in your KPI sheet. Check Indexing → Pages for new errors. Open Fileora → Analytics → Tool usage and note which tools people finish.' ),
		),
	),
	22 => array(
		'title'  => 'Guide: sign a PDF without printing',
		'why'    => 'Links to Sign PDF.',
		'auto'   => array( array( 'guide', 'how-to-sign-pdf-without-printing' ), array( 'tool', 'crop-pdf' ) ),
		'manual' => array(
		),
	),
	23 => array(
		'title'  => 'Redact and PDF to text',
		'why'    => 'Privacy and text tools.',
		'auto'   => array( array( 'tool', 'redact-pdf' ), array( 'tool', 'pdf-to-text' ) ),
		'manual' => array(
			array( 'Screenshots for Aadhaar Card Print and the exam resizer', 'Use a sample card or blur personal details before taking the screenshot. Never publish a real Aadhaar.' ),
		),
	),
	24 => array(
		'title'  => 'Guide: scan documents with your phone',
		'why'    => 'Links to Scan to PDF and OCR.',
		'auto'   => array( array( 'guide', 'how-to-scan-documents-with-phone' ), array( 'tool', 'extract-images-from-pdf' ) ),
		'manual' => array(
		),
	),
	25 => array(
		'title'  => 'Repair PDF and Watermark Image',
		'why'    => 'Last PDF tool, plus a seller favourite.',
		'auto'   => array( array( 'tool', 'repair-pdf' ), array( 'tool', 'watermark-image' ) ),
		'manual' => array(
			array( 'Check Core Web Vitals', 'Search Console → Experience → Core Web Vitals (Mobile). If any URLs are “Poor” or “Need improvement”, run them in PageSpeed Insights and fix the biggest item it lists.' ),
		),
	),
	26 => array(
		'title'  => 'Guide: compress a PDF for email',
		'why'    => 'Links to Compress and Split.',
		'auto'   => array( array( 'guide', 'compress-pdf-for-email' ), array( 'tool', 'remove-exif-data' ) ),
		'manual' => array(
		),
	),
	27 => array(
		'title'  => 'Guide: HEIC to JPG on iPhone',
		'why'    => 'iPhone users searching for a fix.',
		'auto'   => array( array( 'guide', 'convert-heic-to-jpg-iphone' ) ),
		'manual' => array(
			array( 'Answer three real questions', 'Find three recent Quora or Reddit questions about merging, compressing or resizing for forms. Answer them properly in your own words, and mention Fileora only where it genuinely solves the problem, saying that you run it.' ),
		),
	),
	28 => array(
		'title'  => 'Guide: make a scanned PDF searchable',
		'why'    => 'Links to OCR PDF.',
		'auto'   => array( array( 'guide', 'make-scanned-pdf-searchable' ) ),
		'manual' => array(
			array( 'Weekly 30-minute review', 'In Search Console → Performance (last 7 days): note clicks, impressions and average position in your KPI sheet. Check Indexing → Pages for new errors. Open Fileora → Analytics → Tool usage and note which tools people finish.' ),
		),
	),
	29 => array(
		'title'  => 'Guide: convert a logo to SVG',
		'why'    => 'Designers and small businesses.',
		'auto'   => array( array( 'guide', 'convert-logo-to-svg' ), array( 'tool', 'png-to-svg' ) ),
		'manual' => array(
			array( 'Request indexing for the new guides', 'URL Inspection → Request indexing for each guide published so far.' ),
		),
	),
	30 => array(
		'title'  => 'Month 1 check',
		'why'    => 'All 40 tool pages now have full text. Check before moving on.',
		'auto'   => array( array( 'guide', 'number-pages-in-project-report' ) ),
		'manual' => array(
			array( 'Gate: every tool works', 'Open 10 tools on your phone, including PDF to Word and Word to PDF, and run each once. Fix anything broken before day 31.' ),
			array( 'Gate: compare with your starting numbers', 'Fill in today’s row in the KPI sheet. Impressions should be rising. If pages are “Crawled – currently not indexed”, improve them before adding more.' ),
			array( 'Overview score', 'Open <a href="admin.php?page=fileora-seo" target="_blank" rel="noopener">Fileora → SEO → Pages overview</a> and fix any tool page that scores below 80%.' ),
		),
	),
	31 => array(
		'title'  => 'Exam pages: IBPS and SBI',
		'why'    => 'Pages built for exam searches, with the tool set to that exam.',
		'auto'   => array( array( 'page', 'ibps-photo-signature-size' ), array( 'page', 'sbi-photo-signature-size' ) ),
		'manual' => array(
			array( 'Check the sizes, then publish', 'Open each draft page, compare every number with the official notification linked on it, correct anything that changed, tick “I checked the sizes” and press Publish. Test the tool on the page with a real photo.' ),
		),
	),
	32 => array(
		'title'  => 'Exam pages: SSC CGL and CHSL',
		'why'    => 'SSC searches peak around every notification.',
		'auto'   => array( array( 'page', 'ssc-cgl-photo-signature-size' ), array( 'page', 'ssc-chsl-photo-signature-size' ) ),
		'manual' => array(
			array( 'Check the sizes, then publish', 'Same as yesterday. SSC signature sizes have differed between notices, so read the latest one on ssc.gov.in carefully.' ),
		),
	),
	33 => array(
		'title'  => 'Exam pages: UPSC and RRB NTPC',
		'why'    => 'Two exams with unusual rules people search for.',
		'auto'   => array( array( 'page', 'upsc-photo-signature-size' ), array( 'page', 'rrb-ntpc-photo-signature-size' ) ),
		'manual' => array(
			array( 'Check the sizes, then publish', 'Compare with upsconline.nic.in and the RRB notice, then tick and publish.' ),
		),
	),
	34 => array(
		'title'  => 'Exam pages: NEET, JEE Main, CUET',
		'why'    => 'NTA exams, searched by millions of students.',
		'auto'   => array( array( 'page', 'neet-photo-signature-size' ), array( 'page', 'jee-main-photo-signature-size' ), array( 'page', 'cuet-photo-signature-size' ) ),
		'manual' => array(
			array( 'Check the sizes, then publish', 'Compare with the information bulletins on the NTA websites, then tick and publish.' ),
		),
	),
	35 => array(
		'title'  => 'The exam size list',
		'why'    => 'One reference page that links every exam page: the page others will link to.',
		'auto'   => array( array( 'page', 'exam-photo-signature-size-list' ) ),
		'manual' => array(
			array( 'Weekly 30-minute review', 'In Search Console → Performance (last 7 days): note clicks, impressions and average position in your KPI sheet. Check Indexing → Pages for new errors. Open Fileora → Analytics → Tool usage and note which tools people finish.' ),
			array( 'Check, publish and request indexing', 'Publish the list after checking it, then request indexing for it and for the nine exam pages.' ),
		),
	),
	36 => array(
		'title'  => 'KB pages: 50 KB and 100 KB',
		'why'    => 'Exact sizes Indian forms ask for.',
		'auto'   => array( array( 'page', 'compress-image-to-50kb' ), array( 'page', 'compress-image-to-100kb' ) ),
		'manual' => array(
			array( 'Test each KB page', 'Open the page on your phone, compress a real photo and check the result is under the size.' ),
		),
	),
	37 => array(
		'title'  => 'KB pages: 10, 30 and 200 KB',
		'why'    => 'Completes the size family.',
		'auto'   => array( array( 'page', 'compress-image-to-10kb' ), array( 'page', 'compress-image-to-30kb' ), array( 'page', 'compress-image-to-200kb' ) ),
		'manual' => array(
		),
	),
	38 => array(
		'title'  => 'Hindi guide: PDF का साइज',
		'why'    => 'Hindi searches have very little good content.',
		'auto'   => array( array( 'guide', 'pdf-ka-size-kaise-kam-kare' ) ),
		'manual' => array(
			array( 'Make your outreach list', 'Collect 30 websites that could link to the exam size list: coaching institutes, exam news blogs, college “useful links” pages. Search Google for <code>"exam photo size" resizer</code> and <code>"useful links" site:ac.in</code>. Note a contact email for each.' ),
		),
	),
	39 => array(
		'title'  => 'Hindi guide: फोटो का साइज KB में',
		'why'    => 'Links to the KB compressor.',
		'auto'   => array( array( 'guide', 'photo-ka-size-kb-me-kaise-kam-kare' ) ),
		'manual' => array(
			array( 'Send the first 5 outreach emails', 'Short and personal: who you are, the exact page that helps their readers (the exam size list), and that it is free with no sign-up. No mass templates.' ),
		),
	),
	40 => array(
		'title'  => 'Guide: bank statement to Excel',
		'why'    => 'Tax-season and expense-tracking searches.',
		'auto'   => array( array( 'guide', 'bank-statement-pdf-to-excel' ) ),
		'manual' => array(
		),
	),
	41 => array(
		'title'  => 'Hindi guide: मोबाइल से PDF',
		'why'    => 'Phone-first Hindi readers.',
		'auto'   => array( array( 'guide', 'mobile-se-pdf-kaise-banaye' ) ),
		'manual' => array(
			array( 'Contact 5 YouTube creators', 'Find Hindi channels that make “form kaise bhare” videos. Offer the exam resizer for their next tutorial; a link in the description brings real users.' ),
		),
	),
	42 => array(
		'title'  => 'Guide: are online PDF tools safe?',
		'why'    => 'A trust page that answers a real worry.',
		'auto'   => array( array( 'guide', 'are-online-pdf-tools-safe' ) ),
		'manual' => array(
			array( 'Weekly 30-minute review', 'In Search Console → Performance (last 7 days): note clicks, impressions and average position in your KPI sheet. Check Indexing → Pages for new errors. Open Fileora → Analytics → Tool usage and note which tools people finish.' ),
			array( 'Send 5 more outreach emails', 'Continue your list. Reply to anyone who answered.' ),
		),
	),
	43 => array(
		'title'  => 'Hindi guide: आधार कार्ड प्रिंट',
		'why'    => 'Links to Aadhaar Card Print.',
		'auto'   => array( array( 'guide', 'aadhaar-card-print-kaise-kare' ) ),
		'manual' => array(
		),
	),
	44 => array(
		'title'  => 'Rewrite weak titles',
		'why'    => 'Search Console shows which titles people skip.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Find pages with a low click rate', 'Search Console → Performance → Pages, last 28 days, sort by impressions. For pages with many impressions but a CTR under 2%, rewrite the SEO title and description in the SEO box: clearer, with the benefit up front.' ),
		),
	),
	45 => array(
		'title'  => 'Hindi guide: PDF को Word में',
		'why'    => 'Links to PDF to Word.',
		'auto'   => array( array( 'guide', 'pdf-ko-word-me-kaise-badle' ) ),
		'manual' => array(
			array( 'Prepare a Product Hunt page', 'Draft the <a href="https://www.producthunt.com/" target="_blank" rel="noopener">Product Hunt</a> listing: name, one-line tagline, 4 screenshots, first comment explaining why you built Fileora. Pick a launch day (Tuesday–Thursday) after day 60.' ),
		),
	),
	46 => array(
		'title'  => 'Hindi guide: PDF को एक करें',
		'why'    => 'Links to Merge PDF.',
		'auto'   => array( array( 'guide', 'do-pdf-ko-ek-kaise-kare' ) ),
		'manual' => array(
			array( 'Send 5 more outreach emails', 'Focus on coaching institutes this time.' ),
		),
	),
	47 => array(
		'title'  => 'Guide: Fileora vs iLovePDF',
		'why'    => 'An honest comparison for people choosing a tool.',
		'auto'   => array( array( 'guide', 'fileora-vs-ilovepdf' ) ),
		'manual' => array(
			array( 'Read it once more', 'Make sure every statement about iLovePDF is still true on their website today. Fairness is what makes a comparison page trusted.' ),
		),
	),
	48 => array(
		'title'  => 'Improve pages ranking 8–20',
		'why'    => 'Pages on page 2 of Google are the quickest wins.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Find page-2 pages', 'Search Console → Performance → Queries, filter Position greater than 7. For each page there, add one useful section or FAQ answering that exact query, and link to it from two related pages.' ),
		),
	),
	49 => array(
		'title'  => 'Week 7 review',
		'why'    => 'Check indexing of the new pages.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Weekly 30-minute review', 'In Search Console → Performance (last 7 days): note clicks, impressions and average position in your KPI sheet. Check Indexing → Pages for new errors. Open Fileora → Analytics → Tool usage and note which tools people finish.' ),
			array( 'Check the new pages are indexed', 'Indexing → Pages. If many exam or KB pages are “Crawled – currently not indexed”, add more exam-specific detail to them before creating anything new.' ),
		),
	),
	50 => array(
		'title'  => 'Share the exam size list',
		'why'    => 'Your most linkable page.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Post it where students ask', 'Share the exam size list in answers to real questions on Quora and Reddit, and on your brand profiles. Don’t spam groups.' ),
		),
	),
	51 => array(
		'title'  => 'Internal links check',
		'why'    => 'Make sure every new page is linked from somewhere.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Link new pages from old ones', 'Open the exam resizer page: published exam pages appear under “Guides for” automatically. Also add a link to the exam size list from your three most visited blog posts.' ),
		),
	),
	52 => array(
		'title'  => 'Outreach follow-up',
		'why'    => 'Most links come from the second message.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Follow up', 'Send a short, polite follow-up to people who didn’t reply after a week. Thank everyone who linked.' ),
		),
	),
	53 => array(
		'title'  => 'Refresh old blog posts',
		'why'    => 'Updated posts often climb again.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Update the four starter posts', 'Open the Aadhaar, compress-to-100 KB, exam photo and JPG to PDF posts. Add a link to the new related guides and the exam size list, and correct anything out of date.' ),
		),
	),
	54 => array(
		'title'  => 'Speed check 2',
		'why'    => 'New pages can slow things down.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'PageSpeed Insights again', 'Test the exam size list and two exam pages on mobile. Compress any large image on them.' ),
		),
	),
	55 => array(
		'title'  => 'Backlink check',
		'why'    => 'See who links to you.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Ahrefs Webmaster Tools', 'Verify the site in <a href="https://ahrefs.com/webmaster-tools" target="_blank" rel="noopener">Ahrefs Webmaster Tools</a> (free) and note how many websites link to Fileora. Thank new linkers.' ),
		),
	),
	56 => array(
		'title'  => 'Week 8 review',
		'why'    => 'One more full check of the numbers.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Weekly 30-minute review', 'In Search Console → Performance (last 7 days): note clicks, impressions and average position in your KPI sheet. Check Indexing → Pages for new errors. Open Fileora → Analytics → Tool usage and note which tools people finish.' ),
		),
	),
	57 => array(
		'title'  => 'Exam calendar',
		'why'    => 'Exam pages need updating every season.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Set reminders for new notifications', 'Make a calendar of when SSC, IBPS, SBI, RRB, UPSC and NTA usually publish notifications. When one comes out, update that exam’s page and the size list the same day.' ),
		),
	),
	58 => array(
		'title'  => 'Second round of titles',
		'why'    => 'Repeat what worked on day 44.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Rewrite three more titles', 'Pick three more pages with high impressions and low CTR and improve their titles and descriptions.' ),
		),
	),
	59 => array(
		'title'  => 'Plan the next 30 days',
		'why'    => 'Keep the momentum after the plan ends.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Choose the next work', 'Based on your numbers: Hindi versions of the top tools, more exam pages for state exams, the Product Hunt launch and a data story from Fileora Analytics.' ),
		),
	),
	60 => array(
		'title'  => 'Day 60 review',
		'why'    => 'Compare everything with day 5.',
		'auto'   => array(  ),
		'manual' => array(
			array( 'Final KPI row', 'Fill in the KPI sheet and compare with day 5: impressions, clicks, pages in the top 10, indexed pages, linking websites and completed tool tasks.' ),
			array( 'Celebrate and keep going', 'SEO keeps compounding. Keep publishing one useful page a week and updating exam pages each season.' ),
		),
	),
);
