---
seo_title: Rotate PDF – Turn PDF Pages Online Free
description: Rotate PDF pages online for free. Turn all, odd or even pages 90° right, 90° left or 180°, for one file or a batch. No sign-up; files stay on your device.
focus_keyword: rotate pdf
excerpt: Turn pages the right way up, for one file or a whole batch at once.
---
Rotate PDF turns pages that came out sideways or upside down, which often happens with scans and phone photos. Rotate every page, or only the odd or even pages, and save the PDF the right way up. It is free and runs in your browser.

## How to rotate PDF pages

1. Choose or drop one or more PDFs into the box above.
2. Choose how to **Rotate**: 90° right, 180° or 90° left.
3. Choose the **Pages**: all, odd or even.
4. Press the rotate button and download the corrected PDF.

## Odd and even pages

Double-sided documents scanned in a feeder sometimes have every second page upside down. Choose **Even** and **180°** to fix just those pages in one step.

## Rotating only one or two pages

If only a few pages are wrong, open the PDF in [Organize PDF]({home}/organize-pdf/). Each page has its own rotate button, and you can also reorder or delete pages there.

## Does rotation stay when I share the file?

Yes. The rotation is saved in the PDF, so the pages appear the right way up in every reader, on phones and when printed. Quality is not affected: the pages are turned, not re-drawn.

## Related tools

- Combine the corrected file with others in [Merge PDF]({home}/merge-pdf/).
- Trim scanner borders with [Crop PDF]({home}/crop-pdf/).
- Photographed pages? [Scan to PDF]({home}/scan-to-pdf/) creates a clean PDF from photos.

## Private by design

Rotation happens in your browser. Your PDF is never uploaded.

??? Is Rotate PDF free?
Yes. It is free with no sign-up and no watermark.

??? Can I rotate just one page?
Use Organize PDF, where every page has its own rotate button.

??? Does rotating reduce quality?
No. Pages are turned without being re-compressed.

??? Can I rotate several PDFs at once?
Yes. Add several files and they are all rotated the same way.

??? Will the rotation be saved permanently?
Yes. The new orientation is saved in the PDF.

??? Are my files uploaded?
No. Everything happens in your browser.
