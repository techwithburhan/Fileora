---
seo_title: Protect PDF – Add a Password to PDF Free
description: Protect PDF files with a password for free. Lock a PDF so only people with the password can open it, and block printing or copying. Deleted after download.
focus_keyword: protect pdf
excerpt: Add a password so only the right people can open the file.
---
Protect PDF adds a password to a PDF, so only people who know it can open the file. You can also block printing and copying of the text. Use it before you email salary slips, ID copies, contracts or medical reports.

## How to protect PDF files

1. Choose or drop your PDF files into the box above. Up to 20 at once.
2. Type a **Password** and type it again in **Repeat password**.
3. Turn on **Block printing and copying** if readers should only view the document.
4. Press the protect button and download the locked PDF.

## Choosing a good password

- Use at least 8 characters, mixing letters and numbers. Avoid your name or date of birth alone.
- Send the password separately from the file, for example by SMS or a phone call, not in the same email.
- Keep a copy of the password somewhere safe. A forgotten password can’t be recovered by Fileora or anyone else.

## What the protection does

The PDF is encrypted with the password, so PDF readers ask for it before showing anything. Blocking printing and copying is respected by standard readers such as Adobe Acrobat, Chrome and most phone apps; treat it as a strong hint rather than an absolute guarantee.

## Related tools

- Need to remove a password from a file you can open? Use [Unlock PDF]({home}/unlock-pdf/).
- Want to hide just a name or number instead of the whole file? Use [Redact PDF]({home}/redact-pdf/).
- Want to mark copies as yours? Add a [watermark]({home}/watermark-pdf/) first, then protect the file.

## How your file is handled

Protect PDF runs on our processing server. Your file and password travel over an encrypted connection, the password is used only to lock the file, and the files are deleted after download or automatically.

??? Is Protect PDF free?
Yes. It is free with no sign-up and no watermark.

??? Can I protect several PDFs at once?
Yes. Add up to 20 files; each gets the same password.

??? What if I forget the password?
It can’t be recovered. Keep the unprotected original or note the password somewhere safe.

??? Can I stop people from printing the PDF?
Yes. Turn on “Block printing and copying”. Standard PDF readers respect it.

??? Is my password stored?
No. It is used only to encrypt the file and is not saved.

??? How do I remove the password later?
Use Unlock PDF with the password you set.
