---
seo_title: Aadhaar Card Print – Real Size, Front & Back
description: Aadhaar card print at real size: put the front and back of your e-Aadhaar on one A4 page, ready to cut. Free, in your browser; the PDF never leaves your device.
focus_keyword: aadhaar card print
excerpt: Put the front and back of your e-Aadhaar on one A4 page at real card size, ready to print and cut.
---
Aadhaar card print puts the front and back of your e-Aadhaar side by side on one A4 page, at the real size of a card (85.6 × 54 mm). Print it, cut along the dashed lines and fold or laminate it: you get a wallet-sized copy instead of a full page.

## How to make an Aadhaar card print

1. Add your e-Aadhaar PDF to the box above. You can also add two photos: the front, then the back.
2. Type the **e-Aadhaar password**: the first 4 letters of your name in CAPITALS followed by your year of birth, for example `RAHU1990`.
3. Two boxes appear on the card. Move them so one covers the front and one the back.
4. Choose the **Layout** (side by side, or one above the other), the number of **Copies on the page**, and the **Paper** size. Keep **Dashed cutting lines** on.
5. Press **Create print page**, download the PDF and print it.

## Print at actual size

In the print dialog, choose **Actual size** or **100%**, not “Fit to page”. Otherwise the printer shrinks or enlarges the card. Thick paper or photo paper gives the best result.

## Where to get your e-Aadhaar

Download it from the official UIDAI website or the mAadhaar app using your Aadhaar number or enrolment ID and the OTP sent to your registered mobile number. The downloaded PDF is password-protected; this tool opens it with the password you type.

## Is a printed e-Aadhaar valid?

UIDAI states that e-Aadhaar is as valid as the physical Aadhaar letter. A home print is fine as an identity copy for most uses. If you want a durable plastic card, UIDAI sells an official PVC Aadhaar card on its website.

## Related tools

- Print a PAN card, voter ID or driving licence the same way: [ID Card Print]({home}/id-card-print/).
- Remove the password from the PDF: [Unlock PDF]({home}/unlock-pdf/).
- Mark a copy for one use: [Watermark PDF]({home}/watermark-pdf/).
- Step-by-step guide: [How to print an Aadhaar card at real size]({home}/how-to-print-aadhaar-card-real-size/).

## Private by design

Your Aadhaar PDF and its password stay in your browser. Nothing is uploaded or stored, so your Aadhaar details are never sent to Fileora.

??? What is the e-Aadhaar PDF password?
The first four letters of your name in capitals followed by your year of birth, for example RAHU1990.

??? What size is an Aadhaar card?
The standard card size, 85.6 × 54 mm, the same as a debit card.

??? Why does my print come out too big or too small?
Print at Actual size or 100%, not “Fit to page”.

??? Can I print several copies on one page?
Yes. Choose up to 4 copies on the page.

??? Can I use photos of my Aadhaar instead of the PDF?
Yes. Add two photos, front first, then back.

??? Is my Aadhaar uploaded anywhere?
No. Everything happens in your browser.
