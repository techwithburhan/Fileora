---
seo_title: Repair PDF – Fix Damaged or Corrupt PDF Free
description: Repair PDF files online for free. Recover what can be saved from a damaged, corrupt or half-downloaded PDF that won’t open. Files are deleted after download.
focus_keyword: repair pdf
excerpt: Recover what you can from a damaged or corrupt PDF.
---
Repair PDF tries to fix PDFs that won’t open, show blank pages or give an error such as “file is damaged and could not be repaired”. It rebuilds the file’s structure and recovers as many pages and as much content as possible.

## How to repair PDF files

1. Choose or drop the damaged PDF into the box above.
2. Press the repair button.
3. Download the repaired file and check that the pages you need are there.

## Why PDFs get damaged

- A download or email attachment that stopped part-way.
- A file copied from a failing pen drive or memory card.
- A program that crashed while saving the PDF.
- Files sent through apps that changed or cut them.

## What can and can’t be fixed

Repair can rebuild a broken table of contents, missing references and damaged structure, which solves most “won’t open” errors. If parts of the file are missing completely, those pages can’t be recovered. If you can, download the file again from its source first: it is often the quickest fix.

## After repairing

- Make it smaller: [Compress PDF]({home}/compress-pdf/).
- Remove pages that came back blank: [Organize PDF]({home}/organize-pdf/).

## How your file is handled

Repair PDF normally runs on our processing server, which has the strongest repair tools; if the server is unavailable it tries a simpler repair in your browser. Server copies are deleted after download or automatically.

??? Is Repair PDF free?
Yes. It is free with no sign-up.

??? Can every damaged PDF be fixed?
No. Damaged structure can usually be rebuilt, but content that is missing from the file can’t be recovered.

??? Will my text and images stay the same?
Recovered pages keep their original content.

??? What if the repaired file is still blank?
The content is probably missing. Try downloading the file again from where you got it.

??? Can I repair a password-protected PDF?
You need to know the password; unlock it first if you can.

??? Are my files deleted?
Yes. They are deleted after download or automatically.
