---
seo_title: PDF to Text – Extract Text from PDF Free
description: Convert PDF to text online for free. Copy all the words out of a PDF into a plain .txt file, with page markers and joined paragraphs. Runs in your browser.
focus_keyword: pdf to text
excerpt: Copy all the text out of a PDF into a plain .txt file.
---
PDF to Text pulls all the words out of a PDF and saves them as a plain text (.txt) file. Use it to copy content into an email, notes app, translator or AI tool without fighting with PDF selection.

## How to convert PDF to text

1. Choose or drop your PDF into the box above.
2. Turn on **Mark where each page starts** if you want page numbers in the text.
3. Turn on **Join lines into paragraphs** so sentences aren’t broken at the end of every line.
4. Press the button and download the .txt file.

## Good to know

- Works with PDFs that contain real text: documents created on a computer, e-books, reports.
- Scanned PDFs are pictures of text. Use [OCR PDF]({home}/ocr-pdf/) and choose “Text file” to get their words.
- Tables become lines of text. To keep them as tables, use [PDF to Excel]({home}/pdf-to-excel/).
- To keep the layout and edit the document, use [PDF to Word]({home}/pdf-to-word/).

## Why plain text?

A .txt file opens on every device, is tiny, and pastes cleanly anywhere. It is ideal for search, word counts, translation and accessibility tools.

## Private by design

Text extraction runs in your browser. Your PDF never leaves your device.

??? Is PDF to Text free?
Yes. It is free with no sign-up.

??? Does it work on scanned PDFs?
No, scans contain pictures. Use OCR PDF with the Text file output instead.

??? Does it support Hindi?
Yes, if the PDF contains real Hindi text. Some older PDFs use special fonts whose text doesn’t copy correctly.

??? Can I keep page numbers?
Yes. Turn on “Mark where each page starts”.

??? Will tables be kept?
Tables become plain lines of text. Use PDF to Excel for tables.

??? Are my files uploaded?
No. Everything happens in your browser.
