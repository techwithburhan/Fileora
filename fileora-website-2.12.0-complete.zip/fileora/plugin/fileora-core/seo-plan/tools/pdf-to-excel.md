---
seo_title: PDF to Excel Converter – Extract Tables Free
description: Convert PDF to Excel online for free. Pull tables from bank statements, invoices and reports into editable XLSX spreadsheets. Files are deleted after download.
focus_keyword: pdf to excel
excerpt: Pull tables out of PDFs straight into Excel spreadsheets.
---
PDF to Excel finds the tables in your PDF and puts them into an Excel spreadsheet (.xlsx), with rows and columns you can sort, filter and add up. It saves hours of retyping bank statements, price lists, invoices and reports.

## How to convert PDF to Excel

1. Choose or drop your PDF into the box above. Up to 10 files at once.
2. Choose the **Worksheets**: one sheet per page, or all tables in one sheet.
3. Press the convert button and download the .xlsx file.

## What converts best

- **PDFs created by software**, such as bank statements, GST invoices and system reports. Their text is real text, so numbers come across exactly.
- **Clear tables with ruled lines or even spacing.**
- **Scans** need text recognition first: run them through [OCR PDF]({home}/ocr-pdf/) and convert the searchable PDF.

## After converting

- Check that numbers are recognised as numbers (right-aligned in Excel). If a column shows as text, use Excel’s “Convert to Number”.
- Merged headings may be split across cells; tidy them before sorting.
- To go back to PDF after editing, use [Excel to PDF]({home}/excel-to-pdf/).

## Bank statements

Many people convert statements to track expenses or prepare tax returns. If the statement PDF has a password, remove it first with [Unlock PDF]({home}/unlock-pdf/).

## How your file is handled

PDF to Excel runs on our processing server. Your file travels over an encrypted connection, is converted automatically and is deleted after download or automatically. Nobody looks at your documents.

??? Is PDF to Excel free?
Yes. It is free with no sign-up and no watermark.

??? Can I convert a bank statement to Excel?
Yes. Unlock it first if it has a password, then convert it.

??? Does it work with scanned PDFs?
Run the scan through OCR PDF first, then convert the searchable PDF.

??? Will each page become a separate sheet?
Choose “One per page” for that, or “All in one” for a single sheet.

??? Does it open in Google Sheets?
Yes. Upload the .xlsx file to Google Sheets or open it in LibreOffice.

??? Are my files deleted?
Yes. They are deleted after download or automatically.
