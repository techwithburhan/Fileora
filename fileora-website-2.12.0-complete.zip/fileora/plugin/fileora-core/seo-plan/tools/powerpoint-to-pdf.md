---
seo_title: PowerPoint to PDF – Convert PPT & PPTX Free
description: Convert PowerPoint to PDF online for free. Turn PPT and PPTX slides into a PDF that opens anywhere, with speaker notes if you want them. Deleted after download.
focus_keyword: powerpoint to pdf
excerpt: Turn PPT and PPTX slide decks into PDFs that are easy to share.
---
PowerPoint to PDF converts .ppt and .pptx presentations into PDF, one slide per page. A PDF opens on any phone or computer without PowerPoint, keeps your fonts and layout, and is easy to email, print or upload.

## How to convert PowerPoint to PDF

1. Choose or drop your presentations into the box above. Up to 20 at once.
2. Turn on **Include speaker notes** if you want your notes under each slide.
3. Press the convert button and download the PDF.

## Why share slides as a PDF?

- **It looks the same everywhere.** Fonts and layouts don’t shift on other computers.
- **Smaller and simpler.** Good for WhatsApp, email and college portals.
- **Easy to print** as handouts.

Animations and videos don’t carry over to PDF: each slide is saved as it looks at the end of its animations.

## Tips

- Use standard fonts, or embed fonts in PowerPoint, so the PDF matches your design.
- Too large to email? Use [Compress PDF]({home}/compress-pdf/).
- Need to edit slides you only have as a PDF? [PDF to PowerPoint]({home}/pdf-to-powerpoint/) turns pages back into slides.

## How your file is handled

PowerPoint to PDF runs on our processing server using LibreOffice. Files travel over an encrypted connection, are converted automatically and are deleted after download or automatically.

??? Is PowerPoint to PDF free?
Yes. It is free with no sign-up and no watermark.

??? Does it work with old .ppt files?
Yes. Both .ppt and .pptx are supported.

??? Can I include speaker notes?
Yes. Turn on “Include speaker notes”.

??? Are animations kept?
No. A PDF shows each slide as a still page.

??? Can I convert on my phone?
Yes. It works in any modern mobile browser.

??? Are my files deleted?
Yes. They are deleted after download or automatically.
