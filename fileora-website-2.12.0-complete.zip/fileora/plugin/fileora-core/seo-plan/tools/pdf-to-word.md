---
seo_title: PDF to Word Converter – Free, Editable DOCX
description: Convert PDF to Word online for free and get an editable DOCX that keeps text, tables and layout. Files are deleted from our server after download.
focus_keyword: pdf to word
excerpt: Turn PDFs into editable Word documents that keep the layout.
---
PDF to Word turns a PDF into an editable Microsoft Word document (.docx). Headings, paragraphs, tables and images are rebuilt so you can change the text in Word, Google Docs or LibreOffice instead of retyping it.

## How to convert PDF to Word

1. Choose or drop your PDF into the box above. You can convert up to 10 files at once.
2. If the PDF is a scan or a photo of paper, turn on **Recognize text in scanned pages** so the words become editable text.
3. Press the convert button and download your .docx file.

## What converts well

- **PDFs created from Word or other programs**: text, fonts, tables and images usually come out very close to the original.
- **Forms, letters and reports** that you need to update with new details.
- **Scanned documents** with text recognition turned on. The cleaner the scan, the better the result.

Complex designs, such as magazines with many overlapping boxes, may need some tidying after conversion. Check line breaks and table borders before you send the document.

## PDF to Word on mobile

Open this page in your phone’s browser, pick the PDF from your files and download the .docx. You can edit it in the Word or Google Docs app.

## Tips for better results

- Use the original PDF, not a printed-and-scanned copy, whenever you can.
- For scans, straighten and crop pages first with [Scan to PDF]({home}/scan-to-pdf/).
- Need only the words, without layout? [PDF to Text]({home}/pdf-to-text/) is faster.
- When you are done editing, turn the document back into a PDF with [Word to PDF]({home}/word-to-pdf/).

## How your file is handled

PDF to Word runs on our processing server, because building a Word file needs software that browsers don’t have. Your PDF travels over an encrypted connection (HTTPS), is converted automatically and is deleted after you download the result, or automatically if you don’t. Nobody looks at your files.

??? Is PDF to Word free?
Yes. You can convert PDFs to Word for free, without an account and without a watermark.

??? Can I edit the Word file after converting?
Yes. You get a normal .docx file that opens in Microsoft Word, Google Docs, WPS Office and LibreOffice.

??? Does it work with scanned PDFs?
Yes. Turn on “Recognize text in scanned pages” so the text in the scan becomes editable.

??? Will the formatting stay the same?
Most layouts, fonts and tables are kept. Very complex page designs may need small fixes afterwards.

??? Is my PDF safe?
Files go over an encrypted connection to our server and are deleted after download or automatically.

??? Can I convert PDF to Word on my phone?
Yes. It works in any mobile browser, with no app to install.
