---
seo_title: Add Page Numbers to PDF Online Free
description: Add page numbers to PDF files online for free. Choose position, format such as Page 1 of 12, starting number and size, and skip the cover. Runs in your browser.
focus_keyword: add page numbers to pdf
excerpt: Number your pages with the position, format and size you choose.
---
Add page numbers to PDF files in a few seconds: choose where the numbers go, how they look and which number to start from. It is useful for project reports, theses, assignments, legal bundles and any document that will be printed. It is free and runs in your browser.

## How to add page numbers to PDF files

1. Choose or drop one or more PDFs into the box above.
2. Pick the **Position**, for example bottom centre or top right.
3. Pick the **Format**: `1`, `Page 1`, `1 of 12` or `Page 1 of 12`.
4. Set **Start at** if numbering should begin from a number other than 1.
5. Set the **Text size**, and turn on **Skip the first page (cover)** if needed.
6. Press the button and download the numbered PDF.

## Tips for reports and theses

- Colleges often ask for numbers at the bottom centre. Check your format guide.
- If the front pages (cover, certificate, index) should not be counted, split them off with [Split PDF]({home}/split-pdf/), number the main part starting at 1, then join them again with [Merge PDF]({home}/merge-pdf/).
- Add numbers **after** merging all chapters, so the numbering runs through the whole document.

## Related tools

- Legal and court documents often need Bates numbers: [Bates Numbering]({home}/bates-numbering/).
- Add a title or date at the top of each page: [Header & Footer]({home}/add-header-and-footer-to-pdf/).

## Private by design

Numbers are added in your browser. Your PDF is never uploaded.

??? Is it free to add page numbers to a PDF?
Yes. It is free with no sign-up and no watermark.

??? Can I skip the cover page?
Yes. Turn on “Skip the first page (cover)”.

??? Can I start numbering from a different number?
Yes. Set the number in “Start at”.

??? Can I use the format Page 1 of 10?
Yes. Choose “Page 1 of 12” under Format; the total is filled in automatically.

??? Will the numbers print correctly?
Yes. They are part of the page, so they print like the rest of the text.

??? Are my files uploaded?
No. Everything happens in your browser.
