---
seo_title: PDF to PowerPoint – Convert PDF to PPTX Free
description: Convert PDF to PowerPoint online for free. Each PDF page becomes a full-size PPTX slide, ready to present or reuse in PowerPoint or Google Slides.
focus_keyword: pdf to powerpoint
excerpt: Turn each PDF page into a PowerPoint slide, ready to present.
---
PDF to PowerPoint turns each page of a PDF into a PowerPoint slide (.pptx). It helps when you only have the PDF of a presentation and need to present it, add slides of your own around it, or show a report as slides.

## How to convert PDF to PowerPoint

1. Choose or drop your PDF into the box above. Up to 10 files at once.
2. Press the convert button.
3. Download the .pptx file and open it in PowerPoint, Google Slides or Keynote.

## What to expect

- Each PDF page becomes one slide, in the same order.
- Each slide shows the page as a sharp picture, exactly as it looks in the PDF – fonts and layout never shift.
- The text on the slides is part of the picture, so it can't be edited. To change the text, convert with [PDF to Word]({home}/pdf-to-word/) instead, edit there, and copy what you need.
- You can add your own text boxes, arrows and new slides on top, in PowerPoint or Google Slides.

## Good uses

- Presenting a PDF in PowerPoint or Google Slides, with notes and presenter view.
- Turning a report or brochure into slides for a meeting or class.
- Reusing a few pages in a new deck: convert, then copy the slides you need.

## Related tools

- Going the other way: [PowerPoint to PDF]({home}/powerpoint-to-pdf/).
- Only need some pages as slides? Take them out with [Split PDF]({home}/split-pdf/) first.

## How your file is handled

PDF to PowerPoint runs on our processing server. Files travel over an encrypted connection, are converted automatically and are deleted after download or automatically.

??? Is PDF to PowerPoint free?
Yes. It is free with no sign-up and no watermark.

??? Can I edit the text on the slides?
No. Each page becomes a picture on its slide. Add new text boxes on top, or use PDF to Word to edit the text.

??? Does it open in Google Slides?
Yes. Upload the .pptx file to Google Slides.

??? What happens to scanned PDFs?
They convert the same way: each page becomes a picture on a slide.

??? Is there a page limit?
No fixed limit, but very long PDFs take longer to convert.

??? Are my files deleted?
Yes. They are deleted after download or automatically.
