---
seo_title: Crop PDF – Trim PDF Margins Online Free
description: Crop PDF pages online for free. Trim white margins or scanner borders from every page in millimetres, with a live preview. No sign-up; runs in your browser.
focus_keyword: crop pdf
excerpt: Trim the margins of every page, with a live preview.
---
Crop PDF trims the edges of every page in your PDF. Remove wide white margins so text looks bigger on a phone, or cut off the dark borders and table edges that scanners and phone photos leave behind. A live preview shows exactly what will be removed.

## How to crop PDF pages

1. Choose or drop your PDF into the box above.
2. Under **Trim from each edge (mm)**, set how much to cut from the top, right, bottom and left.
3. Watch the preview: the shaded area is what will be removed.
4. Press the crop button and download the cropped PDF.

## Common uses

- **Reading on a phone**: smaller margins mean larger text on a small screen.
- **Cleaning up scans**: remove black borders, staple shadows and the edge of the desk.
- **Printing**: trim a page before fitting it onto a different paper size.

## Good to know

Cropping hides the trimmed area in every PDF reader and when printing. The content is still in the file, though, so don’t rely on cropping to hide private information. Use [Redact PDF]({home}/redact-pdf/) to remove it for good.

## Related tools

- Change the paper size of the pages: [Resize PDF Pages]({home}/resize-pdf-pages/).
- Turn pages the right way up: [Rotate PDF]({home}/rotate-pdf/).
- Cut a double page scan into two: [Split Scanned Pages]({home}/split-scanned-pages-in-half/).

## Private by design

Cropping runs in your browser. Your PDF is never uploaded.

??? Is Crop PDF free?
Yes. It is free with no sign-up and no watermark.

??? Can I crop just one page?
This tool trims every page by the same amount. Split the page out first if it needs different margins.

??? Does cropping reduce quality?
No. Pages are not re-drawn, only trimmed.

??? Is the cropped part deleted?
It is hidden, not deleted. Use Redact PDF to remove private content.

??? What units are the margins in?
Millimetres from each edge of the page.

??? Are my files uploaded?
No. Everything happens in your browser.
