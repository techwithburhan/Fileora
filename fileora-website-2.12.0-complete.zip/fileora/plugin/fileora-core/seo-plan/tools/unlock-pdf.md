---
seo_title: Unlock PDF – Remove PDF Password Online Free
description: Unlock PDF files online for free. Remove the password from a PDF you are allowed to open, such as e-Aadhaar or bank statements. Deleted after download.
focus_keyword: unlock pdf
excerpt: Remove the password from a PDF you are allowed to open.
---
Unlock PDF removes the password from a PDF you are allowed to open, so you don’t have to type it every time. It is useful for e-Aadhaar, bank and credit card statements, salary slips and other documents that arrive password-protected. You need to know the current password: this tool does not crack or guess passwords.

## How to unlock PDF files

1. Choose or drop the protected PDF into the box above.
2. Type its **Current password**.
3. Tick **I own this file or have permission to unlock it**.
4. Press the unlock button and download the PDF without a password.

## Common passwords for Indian documents

Many statements use a pattern made from your details. Check the email or SMS that came with the file. Two common examples:

- **e-Aadhaar**: the first 4 letters of your name in capitals, followed by your year of birth, for example `RAHU1990`.
- **Bank and card statements**: often a part of your name with your date of birth, or a customer ID. The exact pattern is in the bank’s email.

## Why unlock a PDF?

- To merge it with other files, compress it or print it without entering the password each time.
- To upload it to portals that reject password-protected files.
- To open it on devices that struggle with protected PDFs.

After unlocking you can [Merge PDF]({home}/merge-pdf/), [Compress PDF]({home}/compress-pdf/) or print an [Aadhaar card]({home}/aadhaar-card-print/) at real size.

## How your file is handled

Unlock PDF runs on our processing server. The file and password travel over an encrypted connection, the password is used once to open the file and is not stored, and the files are deleted after download or automatically.

Only unlock documents that belong to you or that you have permission to change.

??? Is Unlock PDF free?
Yes. It is free with no sign-up.

??? Can it remove a password I don’t know?
No. You must type the current password. The tool removes protection from files you can already open.

??? What is the e-Aadhaar PDF password?
The first four letters of your name in capitals followed by your year of birth, for example RAHU1990.

??? Is my password stored?
No. It is used only to open the file and is not saved.

??? Are my files deleted?
Yes. They are deleted from the server after download or automatically.

??? Can I add a password back later?
Yes. Use Protect PDF to set a new password.
