---
seo_title: Split PDF – Extract Pages from a PDF Free
description: Split PDF files online for free. Extract page ranges, save every page as its own file, or cut a PDF into equal parts. No sign-up; it runs in your browser.
focus_keyword: split pdf
excerpt: Pull out page ranges or break a PDF into separate files.
---
Split PDF breaks one PDF into smaller files. Take out just the pages you need, save every page separately, or cut a long document into parts of the same size. It is free, has no sign-up, and the splitting happens in your browser.

## How to split PDF files

1. Choose or drop your PDF into the box above.
2. Choose how to **Split by**:
    - **Page ranges**: type the pages you want, for example `1-3, 7, 10-12`. Tick **Put all ranges in one PDF** to get a single file, or leave it off to get one file per range.
    - **Every page**: each page becomes its own PDF.
    - **Fixed size**: set **Pages per file** to cut the document into equal parts.
3. Press the split button and download the files.

## When people split PDFs

- **Sending one page** of a long document, such as a single certificate or the signature page of a contract.
- **Upload limits**: break a large scanned file into parts small enough for a portal.
- **Separating documents** that were scanned together into one PDF.
- **Removing pages** you don’t want to share: extract only the ones you do.

## Split PDF on mobile

Open this page in your phone’s browser, choose the PDF, type the page numbers and download. It works on Android and iPhone without an app.

## Related tools

- To move, rotate or delete pages and keep one file, use [Organize PDF]({home}/organize-pdf/).
- To put pages from different files together, use [Merge PDF]({home}/merge-pdf/).
- To turn pages into pictures, use [PDF to JPG]({home}/pdf-to-jpg/).

## Private by design

Splitting runs in your browser on your own device. Your PDF is not uploaded to Fileora or any other service.

??? Is Split PDF free?
Yes. It is free with no sign-up and no watermark.

??? How do I extract only certain pages?
Choose Page ranges and type the pages, for example 2-4, 9. Tick “Put all ranges in one PDF” to get them in one file.

??? Can I save every page as a separate PDF?
Yes. Choose Every page.

??? Will splitting reduce quality?
No. Pages are copied as they are, without re-compression.

??? Are my files uploaded?
No. Everything happens in your browser.

??? Can I split a password-protected PDF?
Remove the password first with Unlock PDF if you are allowed to open the file.
