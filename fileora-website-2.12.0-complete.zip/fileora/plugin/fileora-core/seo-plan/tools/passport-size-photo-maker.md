---
seo_title: Passport Size Photo Maker Online – 35×45 mm
description: Passport size photo maker: crop a photo to 35×45 mm, 2×2 inch and more, and print many copies on one 4×6 or A4 sheet. Free; the photo stays on your device.
focus_keyword: passport size photo
excerpt: Crop a photo to passport size and print several copies on one 4×6 or A4 sheet.
---
Make passport size photo prints at home or at any print shop. Crop your photo to the right size, then get a sheet with as many copies as fit on 4 × 6 inch photo paper or A4. One sheet costs a few rupees to print, much less than a studio.

## How to make a passport size photo

1. Choose or drop your photo into the box above.
2. Choose the **Photo size**:
    - **35 × 45 mm**: Indian passport, visa forms, most Indian applications.
    - **2 × 2 in (51 × 51 mm)**: US visa and passport.
    - **30 × 40 mm** and **25 × 35 mm**: other forms and ID cards.
3. Move and resize the box so the head is centred with a little space above it.
4. Choose **Print on** (4 × 6 in photo, A4 paper, or just one photo), the number of **Copies**, and **Thin cutting lines**.
5. Create the sheet and download it for printing.

## Taking a good passport photo with a phone

- Stand in front of a plain white or light wall, facing a window for even light.
- Ask someone to take the photo from about 1.5 metres away at eye level.
- Look straight at the camera with a neutral expression, both ears visible, no cap or dark glasses.
- Avoid shadows on the face and behind the head.

## Printing the sheet

- **4 × 6 in**: send it to any photo lab or a phone-photo printing shop; ask for it to be printed at actual size.
- **A4**: print on a photo printer or glossy paper at 100% scale.
- Cut along the thin lines with a ruler and cutter for straight edges.

## For online forms

Online applications usually need a digital file with a KB limit instead of a print. Use the [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/) or [Compress Image to KB]({home}/compress-image-to-20kb/).

## Private by design

Your photo is cropped and laid out in your browser. It is never uploaded.

??? What is the passport size photo size in India?
35 × 45 mm, with the face taking up most of the height.

??? How many photos fit on a 4×6 sheet?
Several 35 × 45 mm photos fit on one 4 × 6 sheet; choose “As many as fit” to use the whole sheet.

??? Can I make a 2×2 inch photo for a US visa?
Yes. Choose 2 × 2 in (51 × 51 mm).

??? Can I change the background colour?
The tool doesn’t replace backgrounds, so take the photo against a plain light wall.

??? Can I print it at a shop?
Yes. Take the downloaded file and ask for it to be printed at actual size.

??? Is my photo uploaded?
No. Everything happens on your device.
