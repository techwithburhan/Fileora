---
seo_title: Crop Image Online – Square, 16:9 or Any Shape
description: Crop image files online for free. Cut photos to square, portrait, story, 4:3 or 16:9 with a live preview, and choose which part to keep. Runs in your browser.
focus_keyword: crop image
excerpt: Cut photos to a square, 16:9 or any shape, with a live preview.
---
Crop image files to the shape you need: a square profile picture, a 4:5 Instagram post, a 9:16 story, or a 16:9 YouTube thumbnail. A live preview shows the frame on your photo, and you choose which part to keep. It is free and runs in your browser.

## How to crop image files

1. Choose or drop your photo into the box above.
2. Choose the **Shape**: original, square (1:1), portrait (4:5), story (9:16), landscape (4:3), photo (3:2) or widescreen (16:9).
3. Use **Crop size** to zoom in, from 100% (largest frame) down to 20%.
4. Use **Keep this part** to move the frame to the top, centre, bottom, left or right.
5. Press **Crop image** and download.

## Which shape for which use

| Use | Shape |
|---|---|
| WhatsApp, Instagram profile picture | Square (1:1) |
| Instagram feed post | Portrait (4:5) |
| Instagram or WhatsApp story, Reels | Story (9:16) |
| YouTube thumbnail, presentation slide | Widescreen (16:9) |
| Printed 4×6 photo | Photo (3:2) |

## Cropping photos for forms

Crop away extra background before reducing a photo for a form: the face gets more of the limited KB and looks clearer. Then use [Compress Image to KB]({home}/compress-image-to-20kb/) or the [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/).

## Related tools

- Exact pixel size after cropping: [Resize Image]({home}/resize-image/).
- Turn a sideways photo upright: [Rotate & Flip Image]({home}/rotate-image/).

## Private by design

Your photo is cropped in your browser and never uploaded.

??? Is Crop Image free?
Yes. It is free with no sign-up and no watermark.

??? How do I crop a photo to a square?
Choose Square (1:1) and move the frame with Keep this part.

??? Can I choose which part of the photo to keep?
Yes. Use Keep this part to move the frame.

??? Does cropping reduce quality?
No. The kept area stays at its original quality.

??? Can I crop to a custom pixel size?
Crop to the shape first, then set exact pixels with Resize Image.

??? Is my photo uploaded?
No. Everything happens on your device.
