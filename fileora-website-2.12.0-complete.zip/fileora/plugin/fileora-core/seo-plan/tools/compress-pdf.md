---
seo_title: Compress PDF – Reduce PDF File Size Free
description: Compress PDF files online for free. Reduce PDF size for email and government forms, often under 1 MB, while keeping them readable. No sign-up.
focus_keyword: compress pdf
excerpt: Make PDFs smaller for email and online forms while keeping them readable.
---
Compress PDF reduces the file size of your PDF so it fits email limits and upload boxes on job, exam and government portals. Choose how strongly to compress, check the new size and download. It is free and needs no account.

## How to compress PDF files

1. Choose or drop one or more PDF files into the box above.
2. Pick a compression level:
    - **Light** keeps the best quality and gives smaller savings.
    - **Balanced** gives a much smaller file that is still easy to read. It suits most uses.
    - **Strong** makes the smallest file, for strict upload limits and email.
3. Press **Compress PDF** and compare the old and new size before downloading.

## How much smaller will my PDF get?

It depends on what is inside. PDFs made of scanned pages or phone photos usually shrink the most, often to a fraction of their size. PDFs that are mostly text are already small, so the savings are modest. If the result is still too big, try Strong, or remove pages you don’t need with [Split PDF]({home}/split-pdf/).

## Getting a PDF under 100 KB, 200 KB or 1 MB

Upload limits are common on Indian portals. Start with Balanced; if the file is still over the limit, use Strong. For a one-page document such as a certificate, Strong usually reaches 100–200 KB. Our guide [How to compress a PDF to 100 KB or 200 KB]({home}/compress-pdf-to-100kb-200kb/) walks through the details.

## Where the compression happens

Compress PDF normally runs on our processing server, which keeps text selectable. If the server can’t be reached, it can run in your browser instead; then Balanced and Strong turn each page into an image to save space. In both cases files travel over an encrypted connection or stay on your device, and server copies are deleted after download or automatically.

## Tips

- Compress **after** merging, so the whole document is reduced once.
- For photos you want to add to a PDF, compress them first with [Compress Image]({home}/compress-image/).
- Keep the original: compression can’t be undone on the smaller copy.

??? Is Compress PDF free?
Yes. It is free to use with no sign-up and no watermark.

??? Will compressing make my PDF blurry?
Light and Balanced keep documents easy to read. Strong lowers image resolution to reach the smallest size, so check small print before you submit it.

??? How do I compress a PDF to 100 KB?
Use Strong on a short document. If it is still too large, remove extra pages or scan at a lower resolution, then compress again.

??? Can I compress several PDFs at once?
Yes. Add up to 20 files and each is compressed separately.

??? Is text still selectable after compression?
On our server, yes. When the tool runs in your browser, Balanced and Strong turn pages into images, so text is no longer selectable.

??? Are my files kept?
No. Files on the server are deleted after download or automatically, and nothing is kept when the tool runs in your browser.
