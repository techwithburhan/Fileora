---
seo_title: Word to PDF Converter – DOC & DOCX to PDF Free
description: Convert Word to PDF online for free: DOC and DOCX files become PDFs that look the same on every device. No sign-up; files are deleted after download.
focus_keyword: word to pdf
excerpt: Convert DOC and DOCX files into PDFs that look the same everywhere.
---
Word to PDF converts Microsoft Word documents (.doc and .docx) into PDF files. A PDF looks the same on every phone, computer and printer, which is why job portals, colleges and offices usually ask for one.

## How to convert Word to PDF

1. Choose or drop your Word files into the box above. You can convert up to 20 at once.
2. Press the convert button.
3. Download each PDF, or all of them together.

Fonts, page size, margins, headers and footers, tables and images are kept as they appear in Word.

## Why send a PDF instead of a Word file?

- **It looks the same everywhere.** A Word file can shift when opened on a different computer or phone; a PDF does not.
- **It is harder to change by accident.** Good for CVs, applications, letters and invoices.
- **Portals expect it.** Most online forms accept PDF uploads only.

## Word to PDF on your phone

Open this page in Chrome or Safari, choose the document from your files or Google Drive, and download the PDF. No app needed.

## Tips

- Check the PDF before sending: unusual fonts that are not embedded in the Word file may be replaced by a similar font.
- Need the PDF smaller for an upload limit? Use [Compress PDF]({home}/compress-pdf/) afterwards.
- Combining a cover letter and CV? Convert both, then join them with [Merge PDF]({home}/merge-pdf/).
- Going the other way? Use [PDF to Word]({home}/pdf-to-word/).

## How your file is handled

Word to PDF runs on our processing server, using LibreOffice to lay out the pages exactly. Your file travels over an encrypted connection, is converted automatically, and is deleted after download or automatically if you don’t download it.

??? Is Word to PDF free?
Yes. It is free with no sign-up and no watermark.

??? Does it work with old .doc files?
Yes. Both .doc and .docx files are supported.

??? Will my fonts and layout stay the same?
Yes in almost all cases. Rare fonts that your document doesn’t include may be swapped for a close match, so give the PDF a quick look.

??? Can I convert several Word files at once?
Yes. Add up to 20 files and each becomes its own PDF.

??? Are my documents stored?
No. They are deleted from our server after you download the PDFs, or automatically.

??? Can I do this on my phone?
Yes. It works in any modern mobile browser.
