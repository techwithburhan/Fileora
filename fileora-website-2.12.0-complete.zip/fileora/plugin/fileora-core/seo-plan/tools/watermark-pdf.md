---
seo_title: Watermark PDF – Add Text Watermark Online Free
description: Watermark PDF pages online for free. Stamp text like CONFIDENTIAL or your name, centred or tiled, in the angle, size, colour and opacity you choose.
focus_keyword: watermark pdf
excerpt: Stamp text across your pages. Choose size, angle, colour and opacity.
---
Watermark PDF stamps text across the pages of your PDF: a word like CONFIDENTIAL, DRAFT or COPY, your company name, or a line such as “Submitted for KYC only”. It is free, has no sign-up and runs in your browser.

## How to watermark PDF files

1. Choose or drop one or more PDFs into the box above.
2. Type the **Watermark text**.
3. Choose the **Layout**: centred once on each page, or tiled across the page.
4. Set the **Angle**, **Text size**, **Opacity** and **Colour**.
5. Press the watermark button and download the stamped PDF.

## Watermarking ID copies

Before you send a copy of your Aadhaar, PAN or passport, add a line that says what the copy is for, such as “For bank account opening only, 21 Oct 2026”. A tiled, light watermark across the page makes the copy harder to reuse for something else, while keeping the details readable.

## Choosing the right settings

| Purpose | Layout | Opacity |
|---|---|---|
| Draft or confidential mark | Centred, 45° | 20–30% |
| ID copy protection | Tiled | 15–25% |
| Brand name on documents | Centred, 0° | 10–20% |

## Related tools

- Add a password as well: [Protect PDF]({home}/protect-pdf/).
- Black out details permanently: [Redact PDF]({home}/redact-pdf/).
- Watermark photos instead: [Watermark Image]({home}/watermark-image/).

## Private by design

The watermark is added in your browser. Your PDF never leaves your device.

??? Is Watermark PDF free?
Yes. It is free with no sign-up, and Fileora adds no watermark of its own.

??? Can I add a watermark to every page?
Yes. The text is added to every page of the PDF.

??? Can I make the watermark see-through?
Yes. Lower the Opacity so the text underneath stays readable.

??? Can I add an image or logo as a watermark?
This tool adds text. For a logo, place it as an image with Sign PDF’s upload option, or watermark images with Watermark Image.

??? Can someone remove the watermark?
A watermark is part of the page, but it is not tamper-proof. Combine it with Protect PDF for sensitive files.

??? Are my files uploaded?
No. Everything happens in your browser.
