---
seo_title: HTML to PDF – Save a Web Page as PDF Free
description: Convert HTML to PDF online for free. Paste a web page address and save it as a PDF in A4, US Letter or one long page, with ads and pop-ups hidden.
focus_keyword: html to pdf
excerpt: Save any web page as a PDF, exactly as it looks.
---
HTML to PDF saves a web page as a PDF document. Paste the address of an article, receipt, booking confirmation or online result page, and get a PDF you can keep, print or share, even if the page changes or disappears later.

## How to convert HTML to PDF

1. Paste the web address into the box above, for example `https://example.com/article`.
2. Choose the **Page size**: A4, US Letter, or one long page that keeps the whole page in one piece.
3. Choose the **Orientation**.
4. Keep **Hide ads and pop-ups** on for a cleaner result.
5. Press the convert button and download the PDF.

## Good uses

- Keeping a copy of an online result, admit card page or receipt.
- Saving articles and documentation to read offline.
- Archiving a web page as proof of what it said on a certain date.

## Pages that need a login

Our server opens the page as a visitor who is not logged in. Pages behind a login, such as your bank or email, can’t be saved this way. For those, use your browser’s own Print → Save as PDF.

## Related tools

- Combine several saved pages: [Merge PDF]({home}/merge-pdf/).
- Make the PDF smaller: [Compress PDF]({home}/compress-pdf/).
- Have HTML code or an .html file instead of an address? Use [HTML Code to PDF]({home}/html-code-to-pdf/).

## How it works

HTML to PDF runs on our processing server: it opens the address you give it, renders the page and saves it as PDF. The PDF is deleted after download or automatically. Only paste addresses of pages you are allowed to save.

??? Is HTML to PDF free?
Yes. It is free with no sign-up and no watermark.

??? Can I save the whole page as one long PDF page?
Yes. Choose “One long page” as the page size.

??? Can it save pages that need a login?
No. Use your browser’s Print → Save as PDF for those.

??? Will ads appear in the PDF?
Keep “Hide ads and pop-ups” on to remove most of them.

??? Can I convert an HTML file from my computer?
Yes, with HTML Code to PDF: open the .html file or paste its code, check the preview and download the PDF.

??? Is the PDF stored?
No. It is deleted after download or automatically.
