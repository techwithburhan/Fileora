---
seo_title: Sign PDF Online Free – Add Your Signature
description: Sign PDF documents online for free. Draw or type your signature, place it on the first, last or every page and add the date. No sign-up needed.
focus_keyword: sign pdf
excerpt: Draw or type your signature and place it on the page.
---
Sign PDF adds your signature to a PDF without printing and scanning. Draw it with your finger or mouse, type your name, or upload a photo of your signature, then place it on the page. It is free, needs no account, and the signing happens in your browser.

## How to sign PDF documents

1. Choose or drop your PDF into the box above.
2. Create **Your signature**: draw it, type your name, or upload a photo of your signature.
3. Choose the **Pages** to sign: first, last or all pages.
4. Set the **Position on the page** and the **Size**. Turn on **Add today’s date under it** if the document needs a date.
5. Press the sign button, check the preview and download the signed PDF.

## Good uses

- Offer letters, rental agreements and declarations that ask for a signature.
- School and college forms, consent letters and NOCs.
- Invoices and delivery receipts.

## Is this a legally valid signature?

This tool adds a picture of your signature, like signing on paper. Many offices and companies accept that for everyday documents. Some legal and government processes in India require a certified digital signature (DSC) or Aadhaar eSign instead. When in doubt, ask the organisation that wants the signed document.

## Tips for a neat signature

- On a phone, turn it sideways for more space to draw.
- Sign slowly and keep the signature a little larger than you need: you can make it smaller on the page.
- Need your signature as a clean image for forms? [PNG to SVG]({home}/png-to-svg/) or the [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/) can help.

## Private by design

Your PDF and your signature stay in your browser. Nothing is uploaded or stored, so your signature can’t be reused by anyone else.

??? Is Sign PDF free?
Yes. It is free with no sign-up and no watermark.

??? Can I sign a PDF on my phone?
Yes. Draw your signature with your finger in any mobile browser.

??? Can I sign every page?
Yes. Choose All pages to place the signature on each page.

??? Can I add the date?
Yes. Turn on “Add today’s date under it”.

??? Is my signature saved anywhere?
No. It is created and used in your browser only.

??? Is this the same as a digital signature certificate?
No. It places an image of your signature. Documents that require a DSC or Aadhaar eSign need those services.
