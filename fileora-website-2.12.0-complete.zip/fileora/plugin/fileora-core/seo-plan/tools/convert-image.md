---
seo_title: Convert Image – JPG, PNG and WebP Converter Free
description: Convert image files online for free between JPG, PNG and WebP. Change many photos at once, for websites, apps and forms. Runs in your browser.
focus_keyword: convert image
excerpt: Change photos between JPG, PNG and WebP.
---
Convert image files between the three formats used everywhere today: JPG, PNG and WebP. Turn WebP pictures downloaded from websites into JPG that every app opens, make PNG screenshots smaller as JPG, or save photos as WebP for a faster website.

## How to convert image files

1. Choose or drop your images into the box above. Many at once is fine.
2. Choose **Convert to**: JPG, PNG or WebP.
3. Set the **Quality** for JPG and WebP.
4. Press convert and download.

## Which format should I use?

| Format | Best for | Transparency | File size |
|---|---|---|---|
| JPG | Photos, forms, sharing | No | Small |
| PNG | Logos, screenshots, text images | Yes | Large |
| WebP | Websites and apps | Yes | Smallest |

## WebP to JPG

Images saved from websites are often WebP, which some older apps and portals don’t accept. Choose JPG to convert them into a format that works everywhere.

## Related tools

- iPhone HEIC photos: [HEIC to JPG]({home}/heic-to-jpg/).
- Make files smaller: [Compress Image]({home}/compress-image/).
- Vector logos: [PNG to SVG]({home}/png-to-svg/).

## Private by design

Conversion runs in your browser. Your images are never uploaded.

??? Is Convert Image free?
Yes. It is free with no sign-up and no watermark.

??? Can I convert WebP to JPG?
Yes. Add the WebP images and choose JPG.

??? What happens to transparency when converting to JPG?
Transparent areas become white, because JPG has no transparency.

??? Which format makes the smallest files?
WebP, followed by JPG. PNG is the largest for photos.

??? Can I convert many images at once?
Yes. Add them all and they are converted together.

??? Are my images uploaded?
No. Everything happens on your device.
