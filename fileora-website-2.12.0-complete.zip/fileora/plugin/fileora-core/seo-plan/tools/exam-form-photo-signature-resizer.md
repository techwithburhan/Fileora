---
seo_title: Exam Photo and Signature Resizer – SSC, UPSC, IBPS
description: Exam photo and signature resizer: set the exact pixels and KB that SSC, UPSC, IBPS, NEET and other forms ask for. Free, in your browser, no sign-up.
focus_keyword: photo and signature resizer
excerpt: Resize a photo or signature to the exact pixel size and KB limit an exam form asks for.
---
The exam photo and signature resizer prepares your photo and signature for online application forms in one step. It sets the exact width and height in pixels, keeps the file between the smallest and largest size allowed, and fills the frame properly, so the form doesn’t reject your upload.

## How to use the photo and signature resizer

1. Choose or drop your photo or signature into the box above.
2. Under **This is a**, pick **Photo** or **Signature**. Common sizes are filled in: photo 200 × 230 px, 20–50 KB; signature 140 × 60 px, 10–20 KB.
3. Change **Width**, **Height**, **Smallest file size** and **Largest file size** if your notification gives different numbers.
4. Choose **Fit**: **Fill (crop edges)** fills the whole frame, and **Fit (white edges)** keeps the whole picture and adds white space. With Fill, move the frame with **Keep this part**.
5. Press **Resize for the form** and download the JPG.

## Always check your notification

Every exam publishes its own sizes, and they change between years. Some exams now capture your photo live with the webcam or phone camera, and only ask you to upload a signature. Read the “how to apply” section of the official notification and type its numbers into the tool. Our guide to [exam photo and signature sizes]({home}/exam-photo-signature-size-20kb-50kb/) explains the common rules.

## Photo checklist that avoids rejection

- Recent colour photo, face covering most of the frame, both ears visible.
- Plain white or very light background, no shadows on the face or behind it.
- No cap, dark glasses or filters. Normal glasses only if you always wear them.
- Some exams want your name and the date on the photo; follow the notification.

## Signature checklist

- Sign in black or blue ink, as the notification says, on plain white paper.
- Use your normal running signature, not capital letters.
- Photograph or scan it in good light, then let the tool crop and size it.
- For a clean, transparent version for other documents, see [PNG to SVG]({home}/png-to-svg/).

## Related tools

- Need only a KB limit without pixels? [Compress Image to KB]({home}/compress-image-to-20kb/).
- Need printed passport photos? [Passport Photo Maker]({home}/passport-size-photo-maker/).

## Private by design

Your photo and signature are resized in your browser and never uploaded.

??? What is the usual photo size for government exams?
Many forms ask for about 200 × 230 pixels and 20–50 KB, but each exam sets its own size. Check the notification.

??? What is the usual signature size?
Often 140 × 60 pixels and 10–20 KB. Some exams use centimetres or ask for three signatures; follow the notification.

??? My photo gets cut off. What should I do?
Choose Fit (white edges), or keep Fill and move the frame with “Keep this part”.

??? Why is my file below the minimum size?
The tool raises the size to the minimum automatically. If it still can’t, increase the width and height a little.

??? Can I use a phone photo?
Yes. Use daylight, a plain wall behind you, and hold the phone at eye level.

??? Are my photos uploaded?
No. Everything happens on your device.
