---
seo_title: Resize Image Online – Change Photo Size in Pixels
description: Resize image files online for free. Change photo width and height in pixels or by percentage, for one photo or many at once. No upload; runs in your browser.
focus_keyword: resize image
excerpt: Change the size of photos in pixels or by percentage, one or many at once.
---
Resize image files to the exact width and height you need, or scale them by a percentage. Use it for website banners, profile pictures, product photos, or any upload box that asks for specific pixel dimensions. It works on many photos at once and runs in your browser.

## How to resize image files

1. Choose or drop your images into the box above.
2. Choose **Resize by**: **Pixels** for exact dimensions, or **Percentage** to scale, for example to 50%.
3. Type the **Width** and **Height**, or the **Size** in percent.
4. Press resize and download the new images.

## Pixels, KB and centimetres

- **Pixels** (px) are the dimensions of the picture, for example 1080 × 1080.
- **KB** is the file size. Resizing to fewer pixels also makes the file smaller, but to hit an exact KB limit use [Compress Image to KB]({home}/compress-image-to-20kb/).
- **Centimetres** only matter when printing. For forms that give centimetres, such as 3.5 × 4.5 cm, use the [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/) with the pixel size from the notification.

## Popular sizes

| Use | Size in pixels |
|---|---|
| Instagram square post | 1080 × 1080 |
| Instagram story, WhatsApp status | 1080 × 1920 |
| YouTube thumbnail | 1280 × 720 |
| Website banner (Full HD) | 1920 × 1080 |
| Many exam photo uploads | 200 × 230 |

## Keeping the shape

To avoid stretched faces, change only one side and let the other follow, or crop first to the right shape with [Crop Image]({home}/crop-image/).

## Private by design

Resizing runs in your browser. Your photos are never uploaded.

??? Is Resize Image free?
Yes. It is free with no sign-up and no watermark.

??? Can I resize several photos at once?
Yes. Add them all and they are resized together.

??? How do I resize a photo for an exam form?
Use the Exam Photo & Signature Resizer, which also keeps the file within the KB limit.

??? Will a resized image lose quality?
Making a picture smaller keeps it sharp. Making a small picture much bigger can look blurry.

??? Can I resize by percentage?
Yes. Choose Percentage and type the size.

??? Are my photos uploaded?
No. Everything happens on your device.
