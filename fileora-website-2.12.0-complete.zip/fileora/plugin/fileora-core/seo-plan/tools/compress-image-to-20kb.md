---
seo_title: Compress Image to 20 KB Online – Photo Under 20KB
description: Compress image to 20 KB, 50 KB, 100 KB or any size for SSC, UPSC, bank and job forms. Free and instant in your browser; the photo never leaves your phone.
focus_keyword: compress image to 20 kb
excerpt: Make a photo exactly 20 KB, 50 KB, 100 KB or any size you need for online forms.
---
Compress image to 20 KB, 50 KB, 100 KB or any size an online form asks for. Instead of guessing a quality level, you set the target size and the tool finds the best quality that fits under it. It is made for Indian application forms, where an upload is rejected if it is even 1 KB too big.

## How to compress image to 20 KB

1. Choose or drop your photo or signature into the box above. JPG, PNG and WebP all work.
2. Choose the **Target size**: 20 KB, 50 KB, 100 KB, 200 KB, 500 KB, or **Other** to type any number.
3. Keep **Save as** on JPG, which almost every form accepts.
4. Keep **Make the picture smaller if needed** on. If the best quality is still too big, the width and height are reduced until it fits.
5. Press **Compress to size** and download. The result shows the final size, pixels and quality.

## Which size does my form need?

| Upload | Common limit on Indian forms |
|---|---|
| Passport-size photo | 20–50 KB |
| Signature | 10–20 KB |
| Thumb impression | 20–50 KB |
| Handwritten declaration | 50–100 KB |
| Scanned certificate as image | 100–300 KB |

These are common ranges, not rules: every exam and portal sets its own. Our [exam photo and signature guide]({home}/exam-photo-signature-size-20kb-50kb/) lists the details, and the [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/) also sets the exact pixel size.

## When the form also asks for pixels or centimetres

Many forms give both a KB limit and a size such as 200 × 230 pixels or 3.5 × 4.5 cm. This tool controls the KB; for exact pixels, use the [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/) or [Resize Image]({home}/resize-image/) first.

## Tips for a clear photo at 20 KB

- Crop away extra background first with [Crop Image]({home}/crop-image/): fewer pixels leave more KB for the face.
- Use a plain, light background. Busy backgrounds take more KB.
- Start from the original photo, not a WhatsApp copy, which is already compressed.

## Private by design

Compression runs in your browser, on your phone or computer. Your photo and signature are not uploaded, which matters for documents tied to your identity.

??? How do I reduce a photo to exactly 20 KB?
Choose 20 KB as the target and press Compress to size. The result will be at or just under 20 KB.

??? Can I compress to a size that isn’t listed, like 30 KB?
Yes. Choose Other and type any size in KB.

??? Will my photo become blurry?
The tool keeps the highest quality that fits. Very small targets such as 10 KB need a smaller picture, so crop away extra background for the clearest result.

??? Does it work for signatures?
Yes. Most forms ask for signatures of 10–20 KB; choose Other and type the size.

??? Can I compress several photos at once?
Yes. Add several images and each one is compressed to the target.

??? Are my photos uploaded?
No. Everything happens on your device.
