---
seo_title: Redact PDF – Black Out Text Permanently Free
description: Redact PDF files online for free. Permanently black out names, account numbers, emails and phone numbers so they can’t be copied or recovered. Free, no sign-up.
focus_keyword: redact pdf
excerpt: Permanently black out names, numbers and other sensitive text.
---
Redact PDF removes sensitive text from a PDF and covers it with black boxes. Unlike drawing a black rectangle on top, real redaction deletes the words underneath, so they can’t be copied, searched or revealed later.

## How to redact PDF files

1. Choose or drop your PDF into the box above.
2. Under **Words to black out**, type each word or phrase on its own line: a name, an account number, an address.
3. Keep **Email addresses** and **Phone numbers** on to find and remove those automatically.
4. Press **Redact PDF**, check the result and download it.

## When to redact

- Sharing a bank statement as proof of address, with account numbers hidden.
- Sending documents to a landlord, employer or school with unrelated personal details removed.
- Publishing reports or RTI replies without names of private individuals.

## Check before you share

Redaction works on text the PDF really contains. Scanned pages are pictures, so their words can’t be found; make them searchable first with [OCR PDF]({home}/ocr-pdf/), then redact. Always open the result and search for the words you removed to confirm they are gone.

## Related tools

- Hide a whole document behind a password: [Protect PDF]({home}/protect-pdf/).
- Mark a copy for one purpose: [Watermark PDF]({home}/watermark-pdf/).

## How your file is handled

Redact PDF runs on our processing server. Your file travels over an encrypted connection, is processed automatically and is deleted after download or automatically. The words you type are used only for this file and are not stored.

??? Is Redact PDF free?
Yes. It is free with no sign-up and no watermark.

??? Is the hidden text really removed?
Yes. The words are deleted from the page, not just covered.

??? Can I redact a scanned PDF?
Run OCR PDF first so the text can be found, then redact.

??? Can it find all phone numbers and emails?
Yes. Turn on those options and the tool finds them for you.

??? Can I undo a redaction?
No. Keep your original file if you might need the full version.

??? Are my files deleted?
Yes. They are deleted after download or automatically.
