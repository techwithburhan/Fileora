---
seo_title: HEIC to JPG Converter – iPhone Photos to JPG
description: Convert HEIC to JPG online for free. Turn iPhone HEIC photos into JPG or PNG that open on Windows, Android and every website. No upload; runs in your browser.
focus_keyword: heic to jpg
excerpt: Convert iPhone HEIC photos into JPG or PNG that open everywhere.
---
HEIC to JPG converts the photos your iPhone saves in HEIC format into JPG (or PNG) images. HEIC saves space on the phone, but many Windows computers, older Android phones and government or job portals can’t open or accept it. JPG works everywhere.

## How to convert HEIC to JPG

1. Choose or drop your .heic or .heif photos into the box above. Add as many as you like.
2. Choose **Convert to**: JPG for photos, or PNG if you need lossless images.
3. Set the **Quality** for JPG. 90% keeps photos looking like the original.
4. Press convert and download the JPG files.

## Why does my iPhone save HEIC?

Apple uses HEIC (High Efficiency Image Container) because it stores photos at about half the size of JPG with the same quality. When you AirDrop or email a photo, the iPhone sometimes converts it automatically, but files copied by cable, from iCloud or from a backup often stay HEIC.

## Stop the iPhone from saving HEIC

On the iPhone, go to **Settings → Camera → Formats** and choose **Most Compatible**. New photos are then saved as JPG. Existing HEIC photos still need converting.

## After converting

- Make photos smaller for upload: [Compress Image]({home}/compress-image/).
- Put them into a PDF: [JPG to PDF]({home}/jpg-to-pdf/).
- Remove the photo’s location before sharing: [Remove Photo Location]({home}/remove-exif-data/).

## Private by design

HEIC photos are converted in your browser. Your personal photos are never uploaded.

??? Is HEIC to JPG free?
Yes. It is free with no sign-up and no watermark.

??? Can I convert many HEIC photos at once?
Yes. Add all of them and they are converted together.

??? Will the JPG lose quality?
At 90% quality the difference is very hard to see.

??? Can I convert HEIC to PNG?
Yes. Choose PNG under Convert to.

??? Does it work on Windows and Android?
Yes. It works in any modern browser.

??? Are my photos uploaded?
No. Everything happens on your device.
