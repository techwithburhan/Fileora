---
seo_title: OCR PDF – Make Scanned PDF Searchable Free
description: OCR PDF files online for free. Turn scanned PDFs into searchable, selectable text in English, Hindi and other languages. Deleted after download.
focus_keyword: ocr pdf
excerpt: Turn scanned PDFs into searchable text you can select and copy.
---
OCR PDF recognises the text in scanned PDFs and photos of documents. The result is a searchable PDF that looks the same as before, but where you can search, select and copy words. You can also get the recognised text as a plain text file.

## How to OCR PDF files

1. Choose or drop your scanned PDFs into the box above. Up to 10 at once.
2. Choose the **Document language**. Hindi and other languages are supported as well as English.
3. Choose the **Output**: a searchable PDF, or a text file.
4. Press the button and download the result.

## What OCR is good for

- **Searching** old scanned records, books or notices for a name or number.
- **Copying text** out of a scan instead of retyping it.
- **Accessibility**: screen readers can read a searchable PDF aloud.
- **Preparing for conversion**: a searchable PDF converts better with [PDF to Word]({home}/pdf-to-word/).

## How to get accurate results

- Scan at 300 dpi if you can. Phone photos work too, if they are sharp and evenly lit.
- Straighten and clean up photographed pages with [Scan to PDF]({home}/scan-to-pdf/) first.
- Pick the right language. Mixed Hindi and English documents work best when the main language is chosen.
- Handwriting is much harder to read than print, so expect mistakes with handwritten pages.

## How your file is handled

OCR PDF runs on our processing server, which uses the open-source OCRmyPDF and Tesseract engines. Your file travels over an encrypted connection, is processed automatically, and is deleted after download or automatically.

??? Is OCR PDF free?
Yes. It is free with no sign-up and no watermark.

??? Does it support Hindi?
Yes. Choose Hindi as the document language.

??? Will my PDF look different after OCR?
No. The page images stay the same; an invisible text layer is added so you can search and copy.

??? Can it read handwriting?
Printed text works best. Handwriting is often recognised poorly.

??? Can I get just the text?
Yes. Choose “Text file” as the output.

??? Are my files deleted?
Yes. They are deleted from the server after download or automatically.
