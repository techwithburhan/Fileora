---
seo_title: Watermark Image – Add Text to Photos Free
description: Watermark image files online for free. Add your name, brand or © text to photos, once or tiled, with your size, angle, colour and opacity. Runs in your browser.
focus_keyword: watermark image
excerpt: Add your name or brand to photos, once or tiled across the picture.
---
Watermark image files with your name, shop name, website or a © line before you post them. It helps photographers, sellers and creators get credit and makes copying less tempting. It also protects ID photos you send, with a line saying what they are for.

## How to watermark image files

1. Choose or drop your photos into the box above. Many at once is fine.
2. Type the **Watermark text**, for example `© Priya Studio` or `For KYC only`.
3. Choose the **Layout**: once, or tiled across the whole picture.
4. Choose the **Position**, **Text size**, **Opacity**, **Angle** and **Colour**.
5. Press the button and download the watermarked photos.

## Settings that work

| Purpose | Layout | Opacity |
|---|---|---|
| Brand on product photos | Once, bottom corner | 40–60% |
| Protecting photography | Tiled, −30° | 15–25% |
| ID or document photo | Tiled | 20–30% |

## For online sellers

Marketplace and social media photos are often copied by other sellers. A small, consistent watermark with your shop name tells buyers where the photo came from. Keep it away from the product itself so the item stays clear.

## Related tools

- Watermark PDF documents: [Watermark PDF]({home}/watermark-pdf/).
- Remove location data before posting: [Remove Photo Location]({home}/remove-exif-data/).
- Make photos smaller for upload: [Compress Image]({home}/compress-image/).

## Private by design

Watermarks are added in your browser. Your photos are never uploaded.

??? Is Watermark Image free?
Yes. It is free with no sign-up, and Fileora adds no mark of its own.

??? Can I watermark many photos at once?
Yes. Add them all and the same watermark is applied to each.

??? Can I make the watermark transparent?
Yes. Lower the Opacity.

??? Can I add a logo image as a watermark?
This tool adds text. Type your brand name, website or © line.

??? Will the watermark reduce photo quality?
No. The text is added on top and the photo keeps its quality.

??? Are my photos uploaded?
No. Everything happens on your device.
