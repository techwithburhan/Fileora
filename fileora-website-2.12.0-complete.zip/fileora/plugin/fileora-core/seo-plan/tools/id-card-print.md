---
seo_title: ID Card Print – PAN, Voter ID & Licence on A4
description: ID card print for PAN, voter ID, driving licence or any card: put both sides on one A4 page at real card size, ready to cut. Free, in your browser.
focus_keyword: id card print
excerpt: Print both sides of a voter ID, driving licence, PAN or any card on one page at real card size.
---
ID card print puts the front and back of a card side by side on one page, at the real size of the card. Use it for PAN, voter ID (EPIC), driving licence, college ID, ration card or any card the size of a debit card, when an office asks for a self-attested copy.

## How to make an ID card print

1. Add a PDF or photo that shows both sides, or two photos: the front first, then the back.
2. If you added one picture with both sides, move the two boxes over the front and the back.
3. Choose the **Layout**, **Copies on the page**, **Paper** and **Dashed cutting lines**.
4. Press **Create print page**, download and print at **Actual size (100%)**.

## Tips for a sharp copy from a phone photo

- Lay the card on a dark surface and photograph it straight from above.
- Avoid flash: it causes glare on laminated cards.
- Fill most of the photo with the card, then fine-tune the box.

## For self-attested copies

Print the page, sign across each copy and write “self-attested” with the date, as the office asks. For digital submissions, you can add a line such as “For KYC at XYZ bank only” with [Watermark PDF]({home}/watermark-pdf/) before sending.

## Related tools

- Aadhaar from the e-Aadhaar PDF: [Aadhaar Card Print]({home}/aadhaar-card-print/).
- Turn the card photos into a normal PDF: [JPG to PDF]({home}/jpg-to-pdf/).

## Private by design

Your card images stay in your browser. Nothing is uploaded or stored.

??? Which cards can I print?
Any card the size of a debit card: PAN, voter ID, driving licence, college ID and similar.

??? Can I print both sides on one page?
Yes. Front and back go side by side or one above the other.

??? Why is the printed card the wrong size?
Choose Actual size or 100% in the print dialog.

??? Can I use two separate photos?
Yes. Add the front first, then the back.

??? Can I print on US Letter paper?
Yes. Choose US Letter under Paper.

??? Are my card images uploaded?
No. Everything happens in your browser.
