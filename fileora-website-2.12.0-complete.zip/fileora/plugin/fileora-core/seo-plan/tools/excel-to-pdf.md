---
seo_title: Excel to PDF Converter – XLSX to PDF Free
description: Convert Excel to PDF online for free. Turn XLSX, XLS and CSV sheets into tidy PDF pages, with each sheet on one page so no columns are cut off.
focus_keyword: excel to pdf
excerpt: Convert spreadsheets into PDFs with tidy, readable pages.
---
Excel to PDF turns spreadsheets into PDF pages that anyone can open and print, without Excel. It works with .xlsx, .xls and .csv files, and can fit wide sheets onto the page so no columns are cut off.

## How to convert Excel to PDF

1. Choose or drop your spreadsheets into the box above. Up to 20 at once.
2. Keep **Fit all columns on one page** on: each sheet becomes one PDF page, sized to fit the whole sheet, so nothing is split or cut off. Turn it off to use the page setup saved in the Excel file (paper size, orientation, print area).
3. Press the convert button and download the PDF.

## Tips for a clean PDF

- Set a print area in Excel if you only want part of the sheet.
- Hide helper columns and empty rows before converting.
- For printing on A4, turn “fit all columns” off and set the orientation and “Fit to page” in Excel’s Page Setup first.
- Need several sheets or files in one PDF? Convert them, then join with [Merge PDF]({home}/merge-pdf/).

## When to send a PDF instead of Excel

- **Invoices, quotations and price lists** for customers.
- **Reports and mark lists** that should not be edited.
- **Attendance and salary sheets** for printing.

To get the data back into a spreadsheet later, use [PDF to Excel]({home}/pdf-to-excel/).

## How your file is handled

Excel to PDF runs on our processing server using LibreOffice. Files travel over an encrypted connection, are converted automatically and are deleted after download or automatically.

??? Is Excel to PDF free?
Yes. It is free with no sign-up and no watermark.

??? Can I convert CSV files?
Yes. CSV, XLS and XLSX files are supported.

??? How do I stop columns being cut off?
Keep “Fit all columns on one page” on. Each sheet becomes a single page, sized to fit.

??? Are formulas kept in the PDF?
The PDF shows the results of formulas, as they appear when printed.

??? Can I convert several workbooks?
Yes. Add up to 20 files.

??? Are my files deleted?
Yes. They are deleted after download or automatically.
