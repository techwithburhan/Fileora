---
seo_title: Scan to PDF – Phone Camera Document Scanner
description: Scan to PDF with your phone or webcam for free. Photograph paper documents and get a clean, high-contrast PDF, page by page. No app; photos stay on your device.
focus_keyword: scan to pdf
excerpt: Use your phone or webcam to capture paper documents as a clean PDF.
---
Scan to PDF turns your phone camera or webcam into a document scanner. Photograph each page, or pick photos you already took, and get one clean PDF with a white background and dark, readable text. No app to install, and the photos stay on your device.

## How to scan to PDF

1. Tap the box above and take a photo of the first page, or choose existing photos from your gallery.
2. Add the other pages. Drag them into order if needed.
3. Choose the **Look**:
    - **Document**: high-contrast black and white, best for text.
    - **Greyscale**: removes yellow or blue tints from room lighting.
    - **Original**: keeps the colours, for photos and coloured forms.
4. Choose the page size and margins, then create and download the PDF.

## How to take a good scan with a phone

- Put the page on a dark, flat surface so its edges stand out.
- Use daylight or a bright room, and avoid your own shadow over the page.
- Hold the phone straight above the page, with the whole page in view.
- Tap the screen to focus on the text before taking the photo.

## What people scan

- Marksheets, certificates and ID cards for online applications.
- Signed forms and agreements that must be returned as PDF.
- Notes, receipts and bills to keep a digital copy.

## Next steps

- Make the text searchable with [OCR PDF]({home}/ocr-pdf/).
- Reduce the size for upload with [Compress PDF]({home}/compress-pdf/).
- Already have clear photos and just need a PDF? [JPG to PDF]({home}/jpg-to-pdf/) keeps them exactly as they are.

## Private by design

The photos are processed in your browser. Nothing is uploaded to Fileora or anyone else.

??? Is Scan to PDF free?
Yes. It is free with no sign-up and no watermark.

??? Do I need to install an app?
No. It works in your phone’s browser and uses its camera directly.

??? Can I scan several pages into one PDF?
Yes. Add each page and they become one PDF in the order shown.

??? How do I make the text clearer?
Choose the Document look and take the photo in good light, straight from above.

??? Can I search the text in my scan?
Run the PDF through OCR PDF to make it searchable.

??? Are my photos uploaded?
No. Everything happens on your device.
