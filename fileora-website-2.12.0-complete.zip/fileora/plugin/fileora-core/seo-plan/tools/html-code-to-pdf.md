---
seo_title: HTML Code to PDF – Paste HTML & CSS, Get a PDF
description: Convert HTML code to PDF online for free. Paste HTML and CSS or open an .html file, check the live preview, and download a PDF with real, selectable text.
focus_keyword: html code to pdf
excerpt: Paste HTML and CSS, see the live preview, and download it as a PDF.
---
HTML Code to PDF turns your own HTML and CSS into a PDF. Paste the code of an invoice, a certificate, a resume or a report template, see it in the live preview, and download a PDF with real, selectable text – no browser print dialog, no extension.

## How to convert HTML code to PDF

1. Paste or type your HTML in the editor above, or press **Open .html file**. Put your CSS in a `<style>` block.
2. Check the **Live preview** as you type.
3. Choose the **Page size** (A4, US Letter or Fit content), **Orientation** and **Margins**.
4. Choose **CSS media**: *Print* uses your `@media print` styles, *Screen* keeps the on-screen look.
5. Press **Convert to PDF** and download.

## Tips for a clean PDF

- **Images:** use full addresses (`https://…/logo.png`) or data URIs. Relative paths like `images/logo.png` can't be found, because your computer's folders aren't sent.
- **Fonts:** web fonts from a public link (such as Google Fonts) work. Fonts installed only on your computer don't – the PDF falls back to a similar font.
- **Page breaks:** add `break-before: page` to start a section on a new page, and `break-inside: avoid` to keep a table row or card together.
- **Page size from CSS:** an `@page { size: A4; margin: 15mm; }` rule in your code takes priority over the options.

## JavaScript

Scripts in your code are ignored unless you turn on **Run JavaScript** – useful for charts or content built by scripts. Scripts then run in an isolated browser that can only reach the public internet.

## Related tools

- Save a public web page from its address: [HTML to PDF]({home}/html-to-pdf/).
- Make the PDF smaller: [Compress PDF]({home}/compress-pdf/).
- Add more files to it: [Merge PDF]({home}/merge-pdf/).

## How your code is handled

The live preview runs in your browser, in a sandboxed frame that can't touch the rest of this site. To make the PDF, the code travels over an encrypted connection to our processing server, is rendered by a headless browser and deleted after download or automatically.

??? Is HTML Code to PDF free?
Yes. It's free with no sign-up and no watermark.

??? Is the text in the PDF selectable?
Yes. Text stays real text, not a picture, so you can search and copy it.

??? Why is my image missing?
Use a full https:// address or a data URI. Relative paths can't be found.

??? Can I use CSS frameworks like Bootstrap or Tailwind?
Yes, if you link them from a public CDN in your code.

??? How large can the code be?
Up to 5 MB, including embedded images.

??? Can I print without the server?
Yes. Use "Print with my browser instead" under the preview.
