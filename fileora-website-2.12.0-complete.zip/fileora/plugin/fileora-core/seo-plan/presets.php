<?php
/**
 * Settings a tool opens with on a preset page: [fileora tool="examphoto" preset="ibps"].
 *
 * Exam sizes were collected in October 2026 from coaching-site summaries of the
 * latest notifications (linked on each page). Exams change them: the plan asks
 * you to check each page against the official notification before it goes live,
 * and to update this file and the page when a new notification comes out.
 *
 * Pixel sizes marked "chosen" are not set by the exam; they are a size inside
 * the allowed range that gives a sharp result.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

$tip = 'Sizes from the latest %s notification we found. Check them against the official notice before you upload.';

return array(
	'ssc-cgl'  => array(
		'tip'     => sprintf( $tip, 'SSC CGL' ),
		'choices' => array(
			'sign' => array( 'label' => 'Signature', 'w' => 160, 'h' => 80, 'min' => 10, 'max' => 20 ),
		),
	),
	'ssc-chsl' => array(
		'tip'     => sprintf( $tip, 'SSC CHSL' ),
		'choices' => array(
			'sign' => array( 'label' => 'Signature', 'w' => 240, 'h' => 80, 'min' => 10, 'max' => 20 ),
		),
	),
	'upsc'     => array(
		'tip'     => sprintf( $tip, 'UPSC' ),
		'choices' => array(
			'photo' => array( 'label' => 'Photo', 'w' => 450, 'h' => 550, 'min' => 20, 'max' => 200 ),
			'sign'  => array( 'label' => '3 signatures', 'w' => 500, 'h' => 500, 'min' => 20, 'max' => 100 ),
		),
	),
	'ibps'     => array(
		'tip'     => sprintf( $tip, 'IBPS' ),
		'choices' => array(
			'photo' => array( 'label' => 'Photo', 'w' => 200, 'h' => 230, 'min' => 20, 'max' => 50 ),
			'sign'  => array( 'label' => 'Signature', 'w' => 140, 'h' => 60, 'min' => 10, 'max' => 20 ),
			'thumb' => array( 'label' => 'Thumb', 'w' => 240, 'h' => 240, 'min' => 20, 'max' => 50 ),
			'decl'  => array( 'label' => 'Declaration', 'w' => 800, 'h' => 400, 'min' => 50, 'max' => 100 ),
		),
	),
	'sbi'      => array(
		'tip'     => sprintf( $tip, 'SBI' ),
		'choices' => array(
			'photo' => array( 'label' => 'Photo', 'w' => 200, 'h' => 230, 'min' => 20, 'max' => 50 ),
			'sign'  => array( 'label' => 'Signature', 'w' => 140, 'h' => 60, 'min' => 10, 'max' => 20 ),
			'thumb' => array( 'label' => 'Thumb', 'w' => 240, 'h' => 240, 'min' => 20, 'max' => 50 ),
			'decl'  => array( 'label' => 'Declaration', 'w' => 800, 'h' => 400, 'min' => 50, 'max' => 100 ),
		),
	),
	'rrb-ntpc' => array(
		'tip'     => sprintf( $tip, 'RRB NTPC' ),
		'choices' => array(
			'sign' => array( 'label' => 'Signature', 'w' => 280, 'h' => 120, 'min' => 30, 'max' => 49 ),
		),
	),
	'neet'     => array(
		'tip'     => sprintf( $tip, 'NEET UG' ),
		'choices' => array(
			'photo'    => array( 'label' => 'Passport photo', 'w' => 350, 'h' => 450, 'min' => 10, 'max' => 200 ),
			'postcard' => array( 'label' => 'Postcard photo', 'w' => 800, 'h' => 1200, 'min' => 10, 'max' => 200 ),
			'sign'     => array( 'label' => 'Signature', 'w' => 300, 'h' => 100, 'min' => 4, 'max' => 30 ),
		),
	),
	'jee-main' => array(
		'tip'     => sprintf( $tip, 'JEE Main' ),
		'choices' => array(
			'photo' => array( 'label' => 'Photo', 'w' => 350, 'h' => 450, 'min' => 10, 'max' => 300 ),
			'sign'  => array( 'label' => 'Signature', 'w' => 300, 'h' => 100, 'min' => 10, 'max' => 50 ),
		),
	),
	'cuet'     => array(
		'tip'     => sprintf( $tip, 'CUET UG' ),
		'choices' => array(
			'photo' => array( 'label' => 'Photo', 'w' => 200, 'h' => 230, 'min' => 10, 'max' => 200 ),
			'sign'  => array( 'label' => 'Signature', 'w' => 140, 'h' => 60, 'min' => 10, 'max' => 50 ),
		),
	),
);
