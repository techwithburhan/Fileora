---
title: SSC CGL Photo and Signature Size: Live Photo Rules and Signature 10–20 KB
slug: ssc-cgl-photo-signature-size
seo_title: SSC CGL Photo and Signature Size 2026 Explained
description: SSC CGL photo and signature size: the photo is now captured live, and the signature must be 10–20 KB at about 4 × 2 cm. Resize your signature free here.
focus_keyword: ssc cgl photo and signature size
excerpt: SSC CGL now captures your photo live. Prepare the signature to the right size here.
verify: yes
tools: exam-form-photo-signature-resizer
---
SSC changed how photos work: for recent exams, including CGL, you no longer upload a photo file. The application module captures a **live photo** with your webcam or phone camera. The SSC CGL photo and signature size question is therefore mainly about the signature, which you still upload as a 10–20 KB JPG. The tool below is set for it.

[fileora tool="examphoto" preset="ssc-cgl"]

## SSC CGL photo and signature size at a glance

| Item | Requirement |
|---|---|
| Photo | Captured live during the application; no file upload |
| Signature format | JPG / JPEG |
| Signature file size | 10–20 KB |
| Signature dimensions | About 4.0 cm wide × 2.0 cm high |

As reported for SSC CGL 2026 ([source](https://www.pw.live/ssc/exams/ssc-cgl-photo-and-signature-size-2026)). Other reports for SSC exams mention 6.0 × 2.0 cm, so read the notice on [ssc.gov.in](https://ssc.gov.in/) and change the width in the tool if needed. The tool uses 160 × 80 pixels, which keeps the 2 : 1 shape.

## Live photo: how to get it right first time

- Sit facing a window or a bright light, against a plain wall.
- Keep the camera at eye level and look straight into it.
- Remove cap, mask and glasses.
- Keep your whole face inside the frame shown on screen, not too close.
- If the webcam doesn’t work, SSC has offered a QR code that opens its app on your phone to capture the photo.

## Signature tips

- Sign in your normal running hand, with a dark pen, on white paper.
- Photograph it straight from above, in good light, with no shadow.
- In the tool, use **Fill** and move the frame so the full signature is inside.

## Visually impaired candidates

SSC notices have allowed a thumb impression in place of the signature for visually impaired candidates. Use **Custom** in the tool with the size the notice gives.

??? Do I need to upload a photo for SSC CGL?
Recent SSC notices capture the photo live in the application instead of an upload. Follow the current notice.

??? What is the SSC CGL signature size?
10–20 KB in JPG, about 4 × 2 cm as reported for 2026.

??? Can I use my phone for the live photo?
Yes, SSC has provided a phone option through its app.

??? Is my signature uploaded to Fileora?
No. It is resized in your browser.
