---
title: UPSC Photo and Signature Size: New Rules, 20–200 KB Photo, 3 Signatures
slug: upsc-photo-signature-size
seo_title: UPSC Photo and Signature Size 2026 – New Rules
description: UPSC photo and signature size: photo JPG 20–200 KB on white background, three signatures on one image at 20–100 KB, plus live photo. Resize both here, free.
focus_keyword: upsc photo and signature size
excerpt: UPSC’s photo and three-signature rules, with a resizer set to them.
verify: yes
tools: exam-form-photo-signature-resizer
---
UPSC applications, including the Civil Services Examination, have their own photo rules and an unusual signature rule: **three signatures, one below the other, on a single image**. Many forms are rejected because of it. Here is the UPSC photo and signature size, with a resizer already set up.

[fileora tool="examphoto" preset="upsc"]

## UPSC photo and signature size table

| Item | Requirement |
|---|---|
| Photo format | JPG |
| Photo file size | 20–200 KB |
| Photo background | Plain white; face covering most of the photo, both ears visible |
| Signature | Three signatures in black ink, one below the other, on white paper, scanned as one image |
| Signature file size | 20–100 KB |
| Signature dimensions | 350–500 pixels reported |
| Live photo | Also captured during submission; it must match the uploaded photo |

As reported for UPSC CSE 2026 ([source](https://blog.visionias.in/blog/english/upsc-new-photo-signature-rules-2026-dos-and-donts)). Read the instructions on [upsconline.nic.in](https://upsconline.nic.in/) for your exam. The tool uses 450 × 550 px for the photo and 500 × 500 px for the signature image, inside the reported ranges.

## The three-signature image

1. On plain white paper, sign three times with a black pen, one signature below the other.
2. Keep the signatures in a column, not side by side.
3. Photograph the page straight from above in good light.
4. Choose **3 signatures** in the tool, use **Fit** so none is cut, and download.

Blue ink, ruled paper, signatures side by side, or a rotated image have been reasons for rejection.

## Photo rules that trip people up

- Dark or coloured backgrounds are not accepted: use plain white.
- No shadows on the face or the wall.
- Eyes open, no hair over the eyes, no dark glasses.
- Don’t sign on the photo.

## Keep the same photo

UPSC compares your uploaded photo with the live photo and with you at the exam and interview. Use one recent photo for every stage.

??? What is the UPSC photo size?
JPG, 20–200 KB, white background, as reported for 2026.

??? Why three signatures?
UPSC has asked for three signatures on one image to check consistency. Follow the current instructions.

??? Can I use blue ink?
Reports for 2026 say black ink only.

??? Is my photo uploaded to Fileora?
No. Resizing happens in your browser.
