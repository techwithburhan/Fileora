---
title: Exam Photo and Signature Size List 2026: SSC, UPSC, IBPS, SBI, RRB, NEET, JEE, CUET
slug: exam-photo-signature-size-list
seo_title: Exam Photo and Signature Size List 2026 (All Exams)
description: Exam photo and signature size list for 2026: SSC, UPSC, IBPS, SBI, RRB NTPC, NEET, JEE Main and CUET in one table, with sources and a free resizer for each.
focus_keyword: exam photo and signature size list
excerpt: Every major exam’s photo and signature rules in one table, with a resizer for each.
verify: yes
tools: exam-form-photo-signature-resizer, compress-image-to-20kb
---
This exam photo and signature size list puts the upload rules of India’s major recruitment and entrance exams in one place. Each row links to a page with the details and a resizer already set to that exam’s sizes. We update it when new notifications come out; the date at the bottom shows the last check.

## Exam photo and signature size list

| Exam | Photo | Signature | Other uploads | Details |
|---|---|---|---|---|
| SSC CGL | Live capture, no upload | 10–20 KB, about 4 × 2 cm | – | [SSC CGL]({home}/ssc-cgl-photo-signature-size/) |
| SSC CHSL | Live capture, no upload | 10–20 KB, about 6 × 2 cm | – | [SSC CHSL]({home}/ssc-chsl-photo-signature-size/) |
| UPSC CSE | 20–200 KB, white background | 3 signatures on one image, 20–100 KB | Live photo too | [UPSC]({home}/upsc-photo-signature-size/) |
| IBPS (PO, Clerk, RRB, SO) | 200 × 230 px, 20–50 KB | 140 × 60 px, 10–20 KB | Thumb 20–50 KB, declaration 50–100 KB | [IBPS]({home}/ibps-photo-signature-size/) |
| SBI (PO, Clerk) | 20–50 KB | 10–20 KB | Thumb 20–50 KB, declaration 50–100 KB | [SBI]({home}/sbi-photo-signature-size/) |
| RRB NTPC | Live capture, no upload | 30–49 KB, min 140 × 60 px | SC/ST certificate PDF | [RRB NTPC]({home}/rrb-ntpc-photo-signature-size/) |
| NEET UG | Passport and postcard, 10–200 KB each | 4–30 KB | Thumb impressions | [NEET]({home}/neet-photo-signature-size/) |
| JEE Main | 10–300 KB, 3.5 × 4.5 cm | 10–50 KB | – | [JEE Main]({home}/jee-main-photo-signature-size/) |
| CUET UG | 200 × 230 px, 10–200 KB | 140 × 60 px, 10–50 KB | – | [CUET]({home}/cuet-photo-signature-size/) |

Values as reported for the 2026 cycle by the sources listed below, checked in October 2026. Notifications change: the official notice for your exam always wins.

## What has changed recently

- **Live photos**: SSC and the Railway boards now capture the photo with your camera during the application instead of accepting a file.
- **Stricter photo checks**: UPSC and NTA reject photos with dark backgrounds, shadows or faces that are too small.
- **Three signatures**: UPSC has asked for three signatures on one image.

## Rules that apply to almost every exam

1. Recent colour photo, plain white or light background, face covering most of the frame.
2. No cap or dark glasses; ears visible.
3. Signature in running handwriting, dark ink, white paper, never in capitals.
4. JPG / JPEG files within both the minimum and maximum size.
5. Keep the same photo for every stage: application, admit card, exam and verification.

## Tools

- Exact pixels and KB for any exam: [Exam Photo & Signature Resizer]({home}/exam-form-photo-signature-resizer/).
- Only a KB limit: [Compress Image to KB]({home}/compress-image-to-20kb/).
- Printed photos: [Passport Photo Maker]({home}/passport-size-photo-maker/).

## Sources

Summaries of the 2026 notifications we used: [SSC CGL](https://www.pw.live/ssc/exams/ssc-cgl-photo-and-signature-size-2026), [SSC CHSL](https://www.pw.live/ssc/exams/ssc-chsl-photo-and-signature-size), [UPSC](https://blog.visionias.in/blog/english/upsc-new-photo-signature-rules-2026-dos-and-donts), [IBPS](https://www.adda247.com/jobs/ibps-rrb-photo-and-signature-size/), [SBI PO](https://edutap.in/sbi-po/registration/), [RRB NTPC](https://www.oliveboard.in/blog/rrb-ntpc-photo-and-signature-details/), [NEET UG](https://medicine.careers360.com/articles/neet-photo-requirements-2026), [JEE Main](https://www.pw.live/iit-jee/exams/jee-main-photo-and-signature-guidelines), [CUET UG](https://university.careers360.com/articles/cuet-photo-size-2026). Official websites: [ssc.gov.in](https://ssc.gov.in/), [upsconline.nic.in](https://upsconline.nic.in/), [ibps.in](https://www.ibps.in/), [sbi.co.in/careers](https://sbi.co.in/web/careers), [nta.ac.in](https://nta.ac.in/).

*Last checked: October 2026*

??? Which exams capture the photo live?
SSC exams and RRB NTPC, as reported for 2026. You only upload the signature.

??? What is the most common photo size?
20–50 KB at 200 × 230 pixels on bank forms; NTA forms allow up to 200 or 300 KB.

??? What if my notification says something different?
Follow the notification and type its numbers into the resizer’s Custom option.

??? Can I use this table for state exams?
State exams set their own rules. The resizer works for them too: type the numbers from the notice.
