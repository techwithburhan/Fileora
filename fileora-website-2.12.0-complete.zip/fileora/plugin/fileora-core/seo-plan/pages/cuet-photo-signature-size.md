---
title: CUET UG Photo and Signature Size: 200 × 230 Photo, 140 × 60 Signature
slug: cuet-photo-signature-size
seo_title: CUET Photo and Signature Size 2026 – Resize Online
description: CUET photo and signature size: photo 10–200 KB at 200 × 230 px, signature 10–50 KB at 140 × 60 px, JPG on a light background. Resize both here for free.
focus_keyword: cuet photo and signature size
excerpt: Resize your CUET UG photo and signature to NTA’s sizes.
verify: yes
tools: exam-form-photo-signature-resizer
---
CUET UG gives exact pixel sizes as well as KB limits, which makes the photo and signature easy to get right with the correct tool. Here is the CUET photo and signature size, with the resizer set to it.

[fileora tool="examphoto" preset="cuet"]

## CUET photo and signature size table

| Item | Pixels | File size | Format |
|---|---|---|---|
| Photograph | 200 × 230 (about 3.5 × 4.5 cm) | 10–200 KB | JPG / JPEG |
| Signature | 140 × 60 | 10–50 KB | JPG / JPEG |

As reported for CUET UG 2026 ([source](https://university.careers360.com/articles/cuet-photo-size-2026)). Confirm in the information bulletin on [cuet.nta.nic.in](https://cuet.nta.nic.in/).

## Photo rules

- Recent passport-size photo, colour or black and white.
- White or very light background.
- At least 80% of the face visible, including ears; no mask.
- No cap or dark glasses.

## Steps

1. Take the photo against a light wall in daylight, or scan a studio photo.
2. Choose **Photo** in the tool: 200 × 230 px and 10–200 KB are set.
3. Use **Fill** and move the frame so the face is centred.
4. Repeat with **Signature** for a photo of your signature on white paper.

## Why CUET uploads get rejected

- **Wrong pixels**: a photo straight from the phone is several thousand pixels wide. The tool sets exactly 200 × 230.
- **Too heavy**: a file over 200 KB is refused. The tool keeps it inside the range.
- **Dark or patterned background**, or a face lit from one side only.
- **Signature photographed at an angle**, so it looks slanted or cut off. Hold the phone parallel to the paper.

If you need to correct a photo after submitting, NTA usually opens a short correction window. Watch the official website for the dates.

## After CUET

Universities may ask for the same photo during admission. Keep the resized files and the original photo together in one folder.

??? What is the CUET photo size?
200 × 230 pixels and 10–200 KB in JPG, as reported for 2026.

??? What is the CUET signature size?
140 × 60 pixels and 10–50 KB.

??? Can the CUET photo be black and white?
Reports for 2026 say colour or black and white are accepted.

??? Is my photo uploaded to Fileora?
No. It is resized in your browser.
