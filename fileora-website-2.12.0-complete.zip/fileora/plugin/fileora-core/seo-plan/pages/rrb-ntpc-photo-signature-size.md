---
title: RRB NTPC Photo and Signature Size: Live Photo and 30–49 KB Signature
slug: rrb-ntpc-photo-signature-size
seo_title: RRB NTPC Photo and Signature Size 2026 Explained
description: RRB NTPC photo and signature size: live photo capture with webcam or phone, and a JPG signature of 30–49 KB, at least 140 × 60 px. Resize your signature free.
focus_keyword: rrb ntpc photo and signature size
excerpt: Railway NTPC captures your photo live. Prepare the signature here.
verify: yes
tools: exam-form-photo-signature-resizer
---
Railway Recruitment Boards now capture the candidate photo live during the NTPC application, so old advice about a 20–50 KB photo no longer applies. What you still upload is the signature, and the RRB NTPC photo and signature size rules for it are different from most other exams: a larger file of about 30–49 KB.

[fileora tool="examphoto" preset="rrb-ntpc"]

## RRB NTPC photo and signature size requirements

| Item | Requirement |
|---|---|
| Photo | Live capture through webcam or phone front camera; no upload |
| Signature format | JPG / JPEG |
| Signature file size | 30–49 KB |
| Signature dimensions | At least 140 × 60 pixels, scanned at 100 dpi or more |
| Signature box | About 35 × 20 mm, black ink on white paper |

As reported for RRB NTPC (Graduate) CEN 06/2026 ([source](https://www.oliveboard.in/blog/rrb-ntpc-photo-and-signature-details/)). Check the notice on your regional RRB website and the application portal. The tool uses 280 × 120 px to give a sharp signature in the 30–49 KB range.

## Live photo checklist for RRB

- Plain white background and dark, non-white clothes.
- Camera at eye level, face straight, neutral expression.
- No cap, mask or spectacles; eyes open.
- Good light on your face, no shadows.
- Never photograph a printed photo or a screen: it will be rejected.

## Signature steps

1. Sign in running handwriting (not capitals) with black ink on white paper.
2. Photograph it straight from above.
3. Add it to the tool above; it is set to 30–49 KB.
4. Use **Fill** and move the frame, or **Fit** to keep the whole signature.

## SC/ST travel certificate

Candidates claiming free travel upload a certificate as a PDF with its own size rules. Prepare it with [Scan to PDF]({home}/scan-to-pdf/) and [Compress PDF]({home}/compress-pdf/), following the notice.

??? Do I upload a photo for RRB NTPC?
No. The photo is captured live during the application, as reported for 2026.

??? What is the RRB NTPC signature size?
30–49 KB in JPG, at least 140 × 60 pixels, as reported for 2026.

??? Why is the RRB signature size larger than other exams?
Each board sets its own limits. Follow the current notice.

??? Is my signature uploaded?
No. The tool runs in your browser.
