---
title: NEET UG Photo and Signature Size: Passport, Postcard, Signature
slug: neet-photo-signature-size
seo_title: NEET Photo and Signature Size 2026 – Resize Online
description: NEET photo and signature size: passport photo 10–200 KB, postcard photo 10–200 KB, signature 4–30 KB in JPG, with name and date rules. Resize them free here.
focus_keyword: neet photo and signature size
excerpt: Prepare the NEET UG passport photo, postcard photo and signature.
verify: yes
tools: exam-form-photo-signature-resizer
---
NEET UG asks for more photos than most exams: a passport-size photo, a postcard-size photo and a signature, along with thumb impressions. Getting the NEET photo and signature size right avoids corrections later, when the form is locked. The tool below opens with NEET’s sizes.

[fileora tool="examphoto" preset="neet"]

## NEET photo and signature size table

| Upload | File size | Notes |
|---|---|---|
| Passport-size photo | 10–200 KB | JPG, white background, face about 80% of the photo |
| Postcard-size photo (4 × 6 in) | 10–200 KB | JPG, same photo rules |
| Signature | 4–30 KB | JPG, black ink, running handwriting |
| Thumb impressions | See the bulletin | Left and right, as listed in the bulletin |

As reported for NEET UG 2026 ([source](https://medicine.careers360.com/articles/neet-photo-requirements-2026)). The information bulletin on [neet.nta.nic.in](https://neet.nta.nic.in/) has the full rules, including the thumb impression sizes. The tool uses 350 × 450 px (passport shape), 800 × 1200 px (postcard shape) and 300 × 100 px for the signature.

## Name and date on the photo

Reports for NEET 2026 say the photo should be recent and show your name and the date the photo was taken. Many studios add this as a strip at the bottom. If you take the photo at home, keep space at the bottom and follow the bulletin’s exact instruction.

## Tips

- Use the same photo for the passport and postcard versions, taken against white.
- No cap or dark glasses; spectacles only if you wear them regularly.
- Keep printed copies of the same photo for the exam centre.

## Postcard photo

The postcard photo is a larger version (4 × 6 inches) of the same picture. Choose **Postcard photo** in the tool and use **Fit** so the whole photo is kept.

??? What is the NEET passport photo size?
10–200 KB in JPG, as reported for 2026.

??? What is the NEET signature size?
4–30 KB in JPG.

??? Do I need the name and date on the NEET photo?
Reports for 2026 say yes. Follow the information bulletin.

??? Is my photo uploaded to Fileora?
No. It is resized in your browser.
