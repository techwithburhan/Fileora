---
title: SBI PO and Clerk Photo and Signature Size: Resize All Four Uploads
slug: sbi-photo-signature-size
seo_title: SBI Photo and Signature Size 2026 – PO & Clerk
description: SBI photo and signature size for PO and Clerk: photo 20–50 KB, signature 10–20 KB, thumb 20–50 KB, declaration 50–100 KB. Resize them free in your browser.
focus_keyword: sbi photo and signature size
excerpt: Prepare your photo, signature, thumb impression and declaration for SBI PO and Clerk applications.
verify: yes
tools: exam-form-photo-signature-resizer
---
SBI PO and SBI Clerk applications ask for four scanned uploads. Getting the SBI photo and signature size right first time saves you from a rejected form and a second registration. The tool below opens with SBI’s sizes; choose the upload and add your picture.

[fileora tool="examphoto" preset="sbi"]

## SBI photo and signature size

| Upload | File size (SBI PO 2026) | Pixels used in the tool |
|---|---|---|
| Photograph | 20–50 KB | 200 × 230 |
| Signature | 10–20 KB | 140 × 60 |
| Left thumb impression | 20–50 KB | 240 × 240 |
| Handwritten declaration | 50–100 KB | 800 × 400 |

The KB ranges are from the SBI PO 2026 notification as summarised [here](https://edutap.in/sbi-po/registration/). The pixel sizes are the ones bank recruitment forms commonly use; SBI’s notification is the final word, so check the “how to apply” section on [sbi.co.in/careers](https://sbi.co.in/web/careers) and change the numbers in the tool if they differ.

## Step by step

1. Photograph each document in daylight on a plain white sheet.
2. In the tool, choose **Photo**, **Signature**, **Thumb** or **Declaration**.
3. Use **Fill** for the photo and thumb; use **Fit** for the declaration so every word stays in.
4. Download and upload to the SBI portal, one file at a time.

## Common mistakes on SBI forms

- Uploading the **signature in place of the photo** or the other way round. Name the files clearly, for example `photo.jpg` and `sign.jpg`.
- A **signature in capitals**, which SBI notifications have said will not be accepted.
- A **declaration** copied with different wording from the notification.
- A **photo older than a few months** that won’t match you at the exam centre.

## Keep copies for later

Save the resized files in a folder. You will need the same photo for the call letter and verification, and having it ready avoids a mismatch.

??? What is the SBI PO photo size?
20–50 KB in the 2026 notification. The tool uses 200 × 230 pixels, the usual bank form size.

??? What is the SBI signature size?
10–20 KB.

??? Do SBI Clerk and SBI PO use the same sizes?
They have been very similar. Check your own notification.

??? Is my photo uploaded anywhere?
No. Resizing happens in your browser.
