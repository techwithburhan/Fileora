---
title: Compress Image to 100 KB Online (Documents and Photos)
slug: compress-image-to-100kb
seo_title: Compress Image to 100 KB Online – Free, No Upload
description: Compress image to 100 KB for declarations, photographed certificates and portal uploads. Best quality under 100 KB, free; the file stays on your device.
focus_keyword: compress image to 100 kb
excerpt: A size that keeps photographed documents readable.
tools: compress-image-to-20kb, scan-to-pdf
---
100 KB is the usual limit for larger image uploads: a handwritten declaration, a photographed certificate, or a document page on a scholarship or admission portal. The compressor here is set to 100 KB, so you can compress image to 100 KB in one step and keep the text readable.

[fileora tool="imgkb" target="100"]

## Where 100 KB comes up

- The handwritten declaration on bank exam forms (often 50–100 KB).
- Photographed certificates, marksheets or ID proofs uploaded as images.
- Profile and cover pictures on some portals.

## Compress image to 100 KB and keep documents readable

Text needs sharp edges more than photos do. To get the most from 100 KB:

1. Photograph the page straight from above in daylight, without shadows.
2. Crop to the page edges with [Crop Image]({home}/crop-image/).
3. Compress here. If the text looks soft, try saving as **WebP** if the form accepts it, or crop tighter.

For several pages, or forms that want a PDF, use [Scan to PDF]({home}/scan-to-pdf/) and then [Compress PDF]({home}/compress-pdf/).

## Photo or document?

| Picture | Result at 100 KB |
|---|---|
| Passport photo | Excellent; more than enough |
| Half-page handwritten declaration | Clear |
| Full A4 page photographed | Readable when cropped tightly |
| Detailed photo for print | Too small; keep the original |

## Common problems

- **Text looks blurred**: the photo was taken from too far away. Move closer so the page fills the frame, then compress again.
- **Still over 100 KB**: keep “Make the picture smaller if needed” on; the tool will reduce the pixels until it fits.
- **Form says “invalid format”**: choose JPG under Save as. Some portals don’t accept WebP.
- **File too small**: if the form also has a minimum, such as 50 KB, use the Exam Photo & Signature Resizer, which raises small files to the minimum.

## Other sizes

[20 KB]({home}/compress-image-to-20kb/), [50 KB]({home}/compress-image-to-50kb/) and [200 KB]({home}/compress-image-to-200kb/) are one click away.

??? How do I compress a photo to 100 KB?
Add it here and press Compress to size.

??? Can I compress a document photo to 100 KB and still read it?
Yes, if it is sharp and cropped to the page edges.

??? Should I upload an image or a PDF?
Follow the form. For multi-page documents, a compressed PDF is usually better.

??? Is my file uploaded?
No. Everything happens on your device.
