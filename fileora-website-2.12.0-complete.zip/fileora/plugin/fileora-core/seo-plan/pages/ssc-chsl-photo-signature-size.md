---
title: SSC CHSL Photo and Signature Size: Live Photo and 6 × 2 cm Signature
slug: ssc-chsl-photo-signature-size
seo_title: SSC CHSL Photo and Signature Size 2026 – Signature
description: SSC CHSL photo and signature size: live photo capture, signature 10–20 KB at about 6.0 × 2.0 cm in JPG. Resize your CHSL signature here in seconds, free.
focus_keyword: ssc chsl photo and signature size
excerpt: CHSL captures your photo live. Get the 10–20 KB signature ready here.
verify: yes
tools: exam-form-photo-signature-resizer
---
For SSC CHSL, the photo is taken live through the application, so the only image file you prepare is the signature. The SSC CHSL photo and signature size rules for the signature are strict: JPG, 10–20 KB, about 6 cm wide and 2 cm high. The tool below is set to that shape.

[fileora tool="examphoto" preset="ssc-chsl"]

## SSC CHSL photo and signature size requirements

| Item | Requirement |
|---|---|
| Photo | Live capture with webcam or phone; no upload |
| Signature format | JPG / JPEG |
| Signature size | 10–20 KB |
| Signature dimensions | About 6.0 cm × 2.0 cm |

As reported for SSC CHSL 2026, citing the notice of 07.09.2026 ([source](https://www.pw.live/ssc/exams/ssc-chsl-photo-and-signature-size)). Confirm on [ssc.gov.in](https://ssc.gov.in/). The tool uses 240 × 80 pixels, a 3 : 1 shape matching 6 × 2 cm.

## Why a wide signature box?

A 6 × 2 cm box is three times as wide as it is tall. Sign normally across the paper, not in a tight square, so the signature fills the box without empty space at the sides. If your signature is short, use **Fit** so it isn’t stretched.

## Live photo checklist

- Plain background, good light from the front.
- Camera at eye level, look straight ahead.
- No cap, mask or glasses.
- Recapture if the preview is dark, blurred or cut off.
- Never point the camera at an existing printed photo: SSC rejects photos of photos.

## Same rules for other SSC exams?

SSC uses the same application module for CGL, CHSL, MTS, GD and other exams, but signature dimensions have differed between notices. Check each notice and see our [SSC CGL page]({home}/ssc-cgl-photo-signature-size/) for comparison.

??? What is the SSC CHSL signature size?
10–20 KB in JPG, about 6.0 × 2.0 cm as reported for 2026.

??? Do I upload a photo for CHSL?
No upload; the photo is captured live during the application.

??? My signature looks stretched. What should I do?
Choose Fit (white edges) in the tool.

??? Is my signature uploaded?
No. The tool runs in your browser.
