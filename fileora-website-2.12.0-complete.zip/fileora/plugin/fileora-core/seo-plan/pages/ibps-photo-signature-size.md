---
title: IBPS Photo and Signature Size: Resize Photo, Signature, Thumb and Declaration
slug: ibps-photo-signature-size
seo_title: IBPS Photo and Signature Size 2026 – Resize Online
description: IBPS photo and signature size: photo 200×230 px 20–50 KB, signature 140×60 px 10–20 KB, thumb and declaration. Resize all four free in your browser.
focus_keyword: ibps photo and signature size
excerpt: Resize your photo, signature, left thumb impression and handwritten declaration to IBPS sizes.
verify: yes
tools: exam-form-photo-signature-resizer
---
The IBPS photo and signature size rules apply to IBPS PO, Clerk, SO and RRB applications, and IBPS asks for four uploads, not two: photo, signature, left thumb impression and a handwritten declaration. The tool below is already set to the IBPS sizes. Pick which upload you are preparing, add the picture and download a JPG that fits.

[fileora tool="examphoto" preset="ibps"]

## IBPS photo and signature size table

| Upload | Pixels | File size | Notes |
|---|---|---|---|
| Photograph | 200 × 230 | 20–50 KB | Recent colour photo, light background |
| Signature | 140 × 60 | 10–20 KB | Black ink on white paper |
| Left thumb impression | 240 × 240 | 20–50 KB | Blue or black ink on white paper |
| Handwritten declaration | 800 × 400 | 50–100 KB | In English, in your handwriting, not in capitals |

Sizes as reported for the 2026 IBPS applications ([source](https://www.adda247.com/jobs/ibps-rrb-photo-and-signature-size/)). Check the “how to apply” section of your own notification on [ibps.in](https://www.ibps.in/) before uploading; IBPS has changed some ranges in past years.

## How to prepare each upload

1. **Photo**: stand against a plain light wall in daylight, face the camera, both ears visible. Choose **Photo** in the tool and use **Fill** to crop.
2. **Signature**: sign in black ink on white paper, photograph it straight from above, choose **Signature**.
3. **Thumb**: press your left thumb on an ink pad and then on white paper, photograph it, choose **Thumb**.
4. **Declaration**: write the declaration text from the notification on white paper in your own handwriting, photograph the whole text, choose **Declaration** and use **Fit** so no words are cut off.

## Why IBPS uploads get rejected

- Signature or declaration written in **capital letters**.
- Photo with a **cap, dark glasses** or a busy background.
- Thumb impression **smudged** or too light.
- File under the **minimum KB**. The tool pads small files up to the minimum automatically.

## The handwritten declaration

The wording is given in the notification; copy it exactly. It is usually a statement that the information you submitted is correct, ending with your name. Write it clearly on white paper with black ink and keep it inside a box of roughly 2 : 1 shape.

??? What is the IBPS photo size?
200 × 230 pixels and 20–50 KB in recent notifications. Check yours.

??? What is the IBPS signature size?
140 × 60 pixels and 10–20 KB.

??? Can I write the declaration in Hindi?
IBPS notifications have asked for it in English. Follow your notification.

??? Are my photo and signature uploaded to Fileora?
No. The resizer works in your browser.
