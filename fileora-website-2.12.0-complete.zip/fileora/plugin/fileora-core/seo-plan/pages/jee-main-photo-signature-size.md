---
title: JEE Main Photo and Signature Size: 10–300 KB Photo, 10–50 KB Signature
slug: jee-main-photo-signature-size
seo_title: JEE Main Photo and Signature Size 2026 – Resize
description: JEE Main photo and signature size: photo JPG 10–300 KB at 3.5 × 4.5 cm, signature 10–50 KB, white background, face 80%. Resize both free in your browser.
focus_keyword: jee main photo and signature size
excerpt: Resize your JEE Main photo and signature to the NTA limits.
verify: yes
tools: exam-form-photo-signature-resizer
---
NTA’s JEE Main form accepts a fairly wide range of file sizes, but rejects photos that break the visual rules. Here is the JEE Main photo and signature size, and a resizer set to the limits.

[fileora tool="examphoto" preset="jee-main"]

## JEE Main photo and signature size table

| Item | Requirement |
|---|---|
| Photo | Colour, passport size, about 3.5 × 4.5 cm |
| Photo format and size | JPG / JPEG, 10–300 KB |
| Face | At least 80% of the photo, both ears visible |
| Background | Plain white |
| Signature format and size | JPG / JPEG, 10–50 KB |
| Signature | On white paper in blue or black ink |

As reported for JEE Main 2026 ([source](https://www.pw.live/iit-jee/exams/jee-main-photo-and-signature-guidelines)). Check the information bulletin on [jeemain.nta.nic.in](https://jeemain.nta.nic.in/). The tool uses 350 × 450 px for the photo and 300 × 100 px for the signature.

## Photo checklist

- Recent photo, face centred, looking at the camera.
- White background without shadows.
- No cap or dark glasses; normal glasses only if you always wear them.
- Not a selfie at arm’s length: ask someone to take it at eye level.

## Signature checklist

- Running signature, not capitals.
- Neat and legible, on plain white paper.
- Photograph it straight from above and choose **Signature** in the tool.

## If NTA flags your photo

NTA has sent correction notices for photos that are blurred, too small or not matching the rules. If that happens, retake the photo following the checklist above, resize it again here, and upload it during the correction window shown on the JEE Main website.

## Same photo everywhere

Keep the same photo for JEE Main, JEE Advanced and counselling, and carry printed copies to the exam centre. A different photo at each stage causes verification problems.

??? What is the JEE Main photo size?
JPG, 10–300 KB, about 3.5 × 4.5 cm, as reported for 2026.

??? What is the JEE Main signature size?
10–50 KB in JPG.

??? Can I use blue ink?
Reports for 2026 allow blue or black ink. Follow the bulletin.

??? Is my photo uploaded to Fileora?
No. The resizer works in your browser.
