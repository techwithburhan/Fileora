<?php
/**
 * File Converter module: 7 tools processed by the Fileora processing server.
 *
 * 'needs' names the software the server must have; the Server Monitoring
 * screen shows whether the server reports it as available.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

return array(
	'id'     => 'converter',
	'name'   => 'File Converter',
	'desc'   => 'Turn Word, Excel, PowerPoint and web pages into PDFs, and back again.',
	'color'  => 'to',
	'order'  => 30,
	'script' => 'converter.js',
	'tools'  => array(
		array( 'id' => 'word2pdf', 'slug' => 'word-to-pdf', 'name' => 'Word to PDF', 'icon' => 'doc', 'exec' => 'server', 'accept' => 'word', 'max_files' => 20, 'needs' => 'LibreOffice',
			'desc' => 'Convert DOC and DOCX files into PDFs that look the same everywhere.',
			'keys' => 'docx doc word microsoft office' ),
		array( 'id' => 'excel2pdf', 'slug' => 'excel-to-pdf', 'name' => 'Excel to PDF', 'icon' => 'sheet', 'exec' => 'server', 'accept' => 'excel', 'max_files' => 20, 'needs' => 'LibreOffice',
			'desc' => 'Convert spreadsheets into PDFs with tidy, readable pages.',
			'keys' => 'xlsx xls csv spreadsheet sheet table' ),
		array( 'id' => 'ppt2pdf', 'slug' => 'powerpoint-to-pdf', 'name' => 'PowerPoint to PDF', 'icon' => 'slides', 'exec' => 'server', 'accept' => 'ppt', 'max_files' => 20, 'needs' => 'LibreOffice',
			'desc' => 'Turn PPT and PPTX slide decks into PDFs that are easy to share.',
			'keys' => 'pptx ppt slides presentation deck' ),
		array( 'id' => 'pdf2word', 'slug' => 'pdf-to-word', 'name' => 'PDF to Word', 'icon' => 'doc', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 10, 'needs' => 'pdf2docx',
			'desc' => 'Turn PDFs into editable Word documents that keep the layout.',
			'keys' => 'docx doc word editable microsoft office' ),
		array( 'id' => 'pdf2excel', 'slug' => 'pdf-to-excel', 'name' => 'PDF to Excel', 'icon' => 'sheet', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 10, 'needs' => 'pdfplumber, openpyxl',
			'desc' => 'Pull tables out of PDFs straight into Excel spreadsheets.',
			'keys' => 'xlsx xls csv table spreadsheet data extract' ),
		array( 'id' => 'pdf2ppt', 'slug' => 'pdf-to-powerpoint', 'name' => 'PDF to PowerPoint', 'icon' => 'slides', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 10, 'needs' => 'PyMuPDF, python-pptx',
			'desc' => 'Turn each PDF page into a PowerPoint slide, ready to present.',
			'keys' => 'pptx ppt slides presentation deck' ),
		array( 'id' => 'html2pdf', 'slug' => 'html-to-pdf', 'name' => 'HTML to PDF', 'icon' => 'html', 'exec' => 'server', 'accept' => 'url', 'max_files' => 0, 'needs' => 'Chromium (Playwright)',
			'desc' => 'Enter a web page address and save that page as a PDF.',
			'keys' => 'web page website url link html save' ),
		array( 'id' => 'code2pdf', 'slug' => 'html-code-to-pdf', 'name' => 'HTML Code to PDF', 'icon' => 'code', 'exec' => 'server', 'accept' => 'html', 'max_files' => 1, 'needs' => 'Chromium (Playwright)',
			'desc' => 'Paste HTML and CSS, see the live preview, and download it as a PDF.',
			'keys' => 'html code css source markup render invoice template resume print' ),
	),
);
