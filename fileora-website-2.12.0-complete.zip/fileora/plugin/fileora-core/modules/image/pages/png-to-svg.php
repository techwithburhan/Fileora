<?php
/**
 * Starter page for PNG & JPG to SVG: content and FAQ written for search.
 * Used once, when the tool page is created; edit the page in WordPress afterwards.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

$p  = function ( $t ) {
	return "<!-- wp:paragraph -->\n<p>" . $t . "</p>\n<!-- /wp:paragraph -->\n\n";
};
$h  = function ( $t ) {
	return "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html( $t ) . "</h2>\n<!-- /wp:heading -->\n\n";
};
$li = function ( array $items, $ordered = false ) {
	$out = '<!-- wp:list' . ( $ordered ? ' {"ordered":true}' : '' ) . " -->\n<" . ( $ordered ? 'ol' : 'ul' ) . ' class="wp-block-list">';
	foreach ( $items as $i ) {
		$out .= "<!-- wp:list-item -->\n<li>" . $i . "</li>\n<!-- /wp:list-item -->";
	}
	return $out . '</' . ( $ordered ? 'ol' : 'ul' ) . ">\n<!-- /wp:list -->\n\n";
};

return array(
	'content' =>
		$p( 'Convert PNG and JPG images into real <strong>SVG vector files</strong>. The tool traces the shapes and colours of your picture and redraws them as vectors, so the result stays sharp at any size: on a business card, a banner or a 4K screen. It works right here in your browser: your image is never uploaded to a server.' )
		. $h( 'How to convert PNG or JPG to SVG' )
		. $li(
			array(
				'Choose or drop your PNG, JPG or WebP image into the box above. You can add several at once.',
				'Pick <strong>Logo / icon</strong> for colour graphics, or <strong>Black &amp; white</strong> for signatures, stamps and line drawings.',
				'Set the number of colours and the detail level. Turn on <strong>Remove the background</strong> for a transparent SVG.',
				'Press <strong>Convert to SVG</strong>, check the preview and download your SVG file.',
			),
			true
		)
		. $h( 'What it works best for' )
		. $li(
			array(
				'<strong>Logos and icons</strong> with flat colours: get a scalable logo for print, websites and apps.',
				'<strong>Signatures</strong>: scan or photograph your signature on white paper and get a clean, transparent SVG in black or dark blue for documents and forms.',
				'<strong>Stamps, seals and line art</strong>: drawings, cartoons, diagrams, handwriting and text images.',
				'<strong>Cutting machines and laser engravers</strong> (Cricut, Silhouette, laser cutters) that need vector shapes.',
			)
		)
		. $p( '<strong>Photos are not a good fit.</strong> A photo has thousands of shades, so a traced photo looks like a poster and the SVG file becomes much larger than the original. For photos, keep JPG or use our Compress Image tool instead.' )
		. $h( 'Tips for the best result' )
		. $li(
			array(
				'Start with the biggest, sharpest version of the image you have. Blurry or very small images give rough edges.',
				'Use as few colours as the picture really has. A two-colour logo needs 2 or 3 colours, not 16.',
				'For a signature, use dark ink on plain white paper and take the photo in good light, without shadows.',
				'If thin lines disappear, choose <strong>High</strong> detail. If the file is too heavy, choose <strong>Low</strong> detail or fewer colours.',
			)
		)
		. $h( 'Is this a real vector SVG?' )
		. $p( 'Yes. Some converters only put your PNG inside an SVG file, so it is still made of pixels and gets blurry when enlarged. This tool redraws the picture as vector paths, which you can open, edit and scale in Illustrator, Inkscape, Figma, Canva or any browser.' )
		. $h( 'Private by design' )
		. $p( 'The tracing runs in your browser on your own phone or computer, using the free, public-domain ImageTracer.js library. Your image is not uploaded, stored or shared, and the tool keeps working even if your internet connection drops after the page has loaded.' ),
	'faq'     => array(
		array( 'Is PNG to SVG free?', 'Yes. The converter is free, with no sign-up, no watermark and no limit on the number of images.' ),
		array( 'Can I convert JPG or JPEG to SVG too?', 'Yes. The tool accepts PNG, JPG/JPEG and WebP images and turns each of them into an SVG vector file.' ),
		array( 'Are my images uploaded?', 'No. The conversion happens entirely in your browser, so your image never leaves your device.' ),
		array( 'Will my SVG have a transparent background?', 'Yes, if “Remove the background” is on. The colour around the edges of your picture, usually white, is left out, so the SVG is transparent.' ),
		array( 'Can I turn my signature into an SVG?', 'Yes. Photograph or scan your signature on white paper, choose “Black & white”, pick black or dark blue ink and keep “Remove the background” on. You get a clean, transparent signature that stays sharp at any size.' ),
		array( 'Why does my photo look like a poster?', 'Tracing turns areas of colour into flat shapes. That is ideal for logos and drawings, but photos have thousands of shades. More colours and higher detail help a little, but for photos JPG remains the better format.' ),
		array( 'Which programs can open the SVG file?', 'Every modern browser, Adobe Illustrator, Inkscape, Figma, Canva, CorelDRAW, Affinity Designer, and cutting-machine software such as Cricut Design Space.' ),
	),
);
