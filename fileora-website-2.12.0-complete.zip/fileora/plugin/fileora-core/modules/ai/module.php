<?php
/**
 * Fileora AI module: 2 tools processed by the Fileora processing server,
 * which calls the Claude API. They need ANTHROPIC_API_KEY in
 * /etc/fileora/fileora.env on the server and are switched off by default.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

return array(
	'id'     => 'ai',
	'name'   => 'Fileora AI',
	'desc'   => 'Summarize and translate documents with AI.',
	'color'  => 'ai',
	'order'  => 70,
	'script' => 'ai.js',
	'tools'  => array(
		array( 'id' => 'summarize', 'slug' => 'ai-pdf-summarizer', 'name' => 'AI Summarizer', 'icon' => 'summary', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 1, 'needs' => 'Claude API key', 'paid' => true, 'default_off' => true,
			'desc' => 'Get the key points of a long document in seconds.',
			'keys' => 'summary tldr ai key points digest abstract' ),
		array( 'id' => 'translate', 'slug' => 'translate-pdf', 'name' => 'Translate PDF', 'icon' => 'translate', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 1, 'needs' => 'Claude API key', 'paid' => true, 'default_off' => true,
			'desc' => 'Translate PDFs into another language while keeping the text structure.',
			'keys' => 'language translation ai hindi spanish french' ),
	),
);
