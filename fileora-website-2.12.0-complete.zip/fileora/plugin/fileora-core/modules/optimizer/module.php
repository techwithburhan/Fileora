<?php
/**
 * File Optimizer module: 4 tools.
 *
 * Compress and Repair are 'hybrid': they use the processing server when it is
 * connected and reports the tool as available, and fall back to a simpler
 * browser version otherwise. OCR and PDF/A need the server.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

return array(
	'id'     => 'optimizer',
	'name'   => 'File Optimizer',
	'desc'   => 'Shrink files, fix damaged ones and make scans searchable.',
	'color'  => 'optimize',
	'order'  => 40,
	'script' => 'optimizer.js',
	'tools'  => array(
		array( 'id' => 'compress', 'slug' => 'compress-pdf', 'name' => 'Compress PDF', 'icon' => 'compress', 'exec' => 'hybrid', 'accept' => 'pdf', 'max_files' => 20, 'needs' => 'Ghostscript',
			'desc' => 'Make PDFs smaller for email and uploads while keeping them readable.',
			'keys' => 'shrink reduce size smaller optimize email kb mb' ),
		array( 'id' => 'repair', 'slug' => 'repair-pdf', 'name' => 'Repair PDF', 'icon' => 'repair', 'exec' => 'hybrid', 'accept' => 'pdf', 'max_files' => 1, 'needs' => 'qpdf, Ghostscript',
			'desc' => 'Recover what you can from a damaged or corrupt PDF.',
			'keys' => 'fix broken corrupt damaged recover' ),
		array( 'id' => 'ocr', 'slug' => 'ocr-pdf', 'name' => 'OCR PDF', 'icon' => 'ocr', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 10, 'needs' => 'OCRmyPDF, Tesseract',
			'desc' => 'Turn scanned PDFs into searchable text you can select and copy.',
			'keys' => 'scan text recognition searchable selectable hindi' ),
		array( 'id' => 'pdfa', 'slug' => 'pdf-to-pdf-a', 'name' => 'PDF to PDF/A', 'icon' => 'archive', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 10, 'needs' => 'OCRmyPDF, Ghostscript',
			'desc' => 'Convert to PDF/A, the ISO standard for long-term archiving.',
			'keys' => 'archive iso standard long term pdfa' ),
	),
);
