<?php
/**
 * File Edit module: 2 tools.
 *
 * Edit PDF is marked 'pending': the processing server has no editing screen
 * yet, so the tool page explains that it is coming soon and cannot be run.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

return array(
	'id'     => 'editor',
	'name'   => 'File Edit',
	'desc'   => 'Turn flat PDFs into fillable forms and edit page content.',
	'color'  => 'edit',
	'order'  => 60,
	'script' => 'editor.js',
	'tools'  => array(
		array( 'id' => 'forms', 'slug' => 'pdf-forms', 'name' => 'PDF Forms', 'icon' => 'form', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 1, 'needs' => 'PyMuPDF',
			'desc' => 'Detect form fields automatically and turn flat PDFs into fillable forms.',
			'keys' => 'fillable fields checkbox form fill acroform' ),
		array( 'id' => 'edit', 'slug' => 'edit-pdf', 'name' => 'Edit PDF', 'icon' => 'edit', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 1, 'needs' => 'Editor screen (not built yet)', 'status' => 'pending',
			'desc' => 'Add text, images, shapes and freehand notes to any page.',
			'keys' => 'annotate text add write draw shapes modify' ),
	),
);
