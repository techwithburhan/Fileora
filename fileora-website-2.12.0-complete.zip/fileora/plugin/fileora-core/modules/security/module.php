<?php
/**
 * File Security module: 3 tools processed by the Fileora processing server.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

return array(
	'id'     => 'security',
	'name'   => 'File Security',
	'desc'   => 'Lock, unlock and permanently black out sensitive content.',
	'color'  => 'security',
	'order'  => 50,
	'script' => 'security.js',
	'tools'  => array(
		array( 'id' => 'protect', 'slug' => 'protect-pdf', 'name' => 'Protect PDF', 'icon' => 'lock', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 20, 'needs' => 'qpdf',
			'desc' => 'Add a password so only the right people can open the file.',
			'keys' => 'password encrypt lock secure' ),
		array( 'id' => 'unlock', 'slug' => 'unlock-pdf', 'name' => 'Unlock PDF', 'icon' => 'unlock', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 20, 'needs' => 'qpdf',
			'desc' => 'Remove the password from a PDF you are allowed to open.',
			'keys' => 'remove password decrypt open aadhaar' ),
		array( 'id' => 'redact', 'slug' => 'redact-pdf', 'name' => 'Redact PDF', 'icon' => 'redact', 'exec' => 'server', 'accept' => 'pdf', 'max_files' => 1, 'needs' => 'PyMuPDF',
			'desc' => 'Permanently black out names, numbers and other sensitive text.',
			'keys' => 'black out censor hide remove sensitive private gdpr' ),
	),
);
