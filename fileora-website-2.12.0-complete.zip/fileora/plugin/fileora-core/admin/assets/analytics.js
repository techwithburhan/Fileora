/* Fileora Visitor Analytics dashboard. Data: /wp-json/fileora/v1/admin/*.
   Refreshes every minute without reloading the page; pauses while the tab is hidden. */
(function () {
  'use strict';
  var C = window.FileoraAn;
  if (!C || !window.Chart) return;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var I = C.i18n;
  var css = getComputedStyle(document.getElementById('fo-an'));
  var SLOT = [1, 2, 3, 4, 5, 6, 7, 8].map(function (i) { return css.getPropertyValue('--s' + i).trim(); });
  var OTHER = css.getPropertyValue('--s-other').trim() || '#9a9a94';
  var INK2 = css.getPropertyValue('--ink-2').trim() || '#52514e';
  var GRID = css.getPropertyValue('--grid').trim() || '#ecebe7';
  var SURF = css.getPropertyValue('--surface').trim() || '#ffffff';
  Chart.defaults.font.family = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  Chart.defaults.font.size = 12;
  Chart.defaults.color = INK2;

  var state = { range: '24h', from: '', to: '', interval: '', level: 'country', days: '30', group: 'day', act: { page: 1 }, vis: { page: 1, orderby: 'last_seen', order: 'desc' }, ts: { page: 1 }, last: 0, busy: false };
  var KEEP = ['range', 'from', 'to', 'interval', 'level', 'days', 'group'];
  try { var saved = JSON.parse(localStorage.getItem('fileora.an') || '{}'); KEEP.forEach(function (k) { if (saved[k] != null) state[k] = String(saved[k]); }); } catch (e) { /* ignore */ }
  if (state.range === 'custom' && !(state.from && state.to)) state.range = '24h';
  function save() { var o = {}; KEEP.forEach(function (k) { o[k] = state[k]; }); try { localStorage.setItem('fileora.an', JSON.stringify(o)); } catch (e) { /* ignore */ } }
  /* the period chosen at the top, as request parameters */
  function period() { return state.range === 'custom' ? { range: 'custom', from: state.from, to: state.to } : { range: state.range }; }
  function extend(a, b) { Object.keys(b).forEach(function (k) { a[k] = b[k]; }); return a; }

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(n) { return Number(n || 0).toLocaleString(C.locale); }
  function pct(n, t) { return t ? (Math.round(n / t * 1000) / 10).toLocaleString(C.locale) + '%' : '0%'; }
  /* time in the site's time zone */
  function local(ts) { return new Date(ts * 1000 + C.offset * 1000); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function hm(ts) { var d = local(ts); return pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()); }
  function hms(ts) { var d = local(ts); return hm(ts) + ':' + pad(d.getUTCSeconds()); }
  function dt(ts) { var d = local(ts); return d.getUTCDate() + ' ' + I.months[d.getUTCMonth()] + ' ' + d.getUTCFullYear() + ', ' + hm(ts); }
  function day(ts) { var d = local(ts); return d.getUTCDate() + ' ' + I.months[d.getUTCMonth()] + ' ' + d.getUTCFullYear(); }
  function dm(ts) { var d = local(ts); return d.getUTCDate() + ' ' + I.months[d.getUTCMonth()]; }
  function dlabel(key, group) {
    var p = key.split('-'), m = I.months[+p[1] - 1];
    if (group === 'month') return m + ' ' + p[0];
    return (group === 'week' ? I.weekOf + ' ' : '') + (+p[2]) + ' ' + m;
  }
  function ago(ts) {
    var s = Math.max(0, Math.round(Date.now() / 1000 - ts));
    if (s < 60) return I.justNow;
    if (s < 3600) return I.minAgo.replace('%d', Math.round(s / 60));
    if (s < 86400) return I.hAgo.replace('%d', Math.round(s / 3600));
    return dt(ts);
  }

  function api(path, params) {
    var q = Object.keys(params || {}).filter(function (k) { return params[k] !== '' && params[k] != null && params[k] !== false; })
      .map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]); }).join('&');
    return fetch(C.root + path + (q ? '?' + q : ''), { headers: { 'X-WP-Nonce': C.nonce }, credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) {
        if (r.status === 401 || r.status === 403) throw new Error(I.authErr);
        if (!r.ok) throw new Error(I.loadErr + ' (' + r.status + ')');
        return r.json();
      });
  }

  /* ---------------- charts ---------------- */
  var charts = {};
  function locChart() {
    charts.loc = new Chart($('#c-loc'), {
      type: 'doughnut',
      data: { labels: [], datasets: [{ data: [], backgroundColor: [], borderColor: SURF, borderWidth: 2, hoverOffset: 6 }] },
      options: {
        cutout: '64%', responsive: true, maintainAspectRatio: false, animation: { duration: 300 },
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { var t = c.dataset.data.reduce(function (a, b) { return a + b; }, 0); return ' ' + c.label + ': ' + num(c.raw) + ' ' + I.visitors + ' (' + pct(c.raw, t) + ')'; } } } }
      }
    });
  }
  function rtChart() {
    charts.rt = new Chart($('#c-rt'), {
      type: 'bar',
      data: { labels: [], datasets: [] },
      options: {
        responsive: true, maintainAspectRatio: false, animation: { duration: 250 },
        interaction: { mode: 'index', intersect: false },
        scales: {
          x: { stacked: true, grid: { display: false }, ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: 7 } },
          y: { stacked: true, beginAtZero: true, ticks: { precision: 0 }, grid: { color: GRID }, border: { display: false } }
        },
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { title: function (it) { return it[0].label; }, label: function (c) { return c.raw ? ' ' + c.dataset.label + ': ' + num(c.raw) : null; }, footer: function (it) { var t = state.rt ? state.rt.total[it[0].dataIndex] : 0; return I.total + ': ' + num(t); } } }
        }
      }
    });
  }
  function cmpChart() {
    charts.cmp = new Chart($('#c-cmp'), {
      data: { labels: [], datasets: [
        { type: 'bar', label: I.uniqueVisitors, data: [], backgroundColor: SLOT[0], borderRadius: { topLeft: 4, topRight: 4 }, borderSkipped: 'bottom', maxBarThickness: 28, order: 2 },
        { type: 'line', label: I.toolRuns, data: [], borderColor: SLOT[1], backgroundColor: SLOT[1], borderWidth: 2, pointRadius: 4, pointHoverRadius: 6, pointBorderColor: SURF, pointBorderWidth: 2, tension: 0.25, order: 1 }
      ] },
      options: {
        responsive: true, maintainAspectRatio: false, animation: { duration: 250 },
        interaction: { mode: 'index', intersect: false },
        scales: { x: { grid: { display: false }, ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: 10 } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: GRID }, border: { display: false } } },
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return ' ' + c.dataset.label + ': ' + num(c.raw); } } } }
      }
    });
  }

  function tsChart() {
    var line = function (label, color) { return { type: 'line', label: label, data: [], borderColor: color, backgroundColor: color, borderWidth: 2, pointRadius: 0, pointHoverRadius: 5, pointBorderColor: SURF, pointBorderWidth: 2, tension: 0.2 }; };
    charts.ts = new Chart($('#c-ts'), {
      type: 'line',
      data: { labels: [], datasets: [line(I.uniqueVisitors, SLOT[0]), line(I.toolRuns, SLOT[1]), line(I.filesProcessed, SLOT[2])] },
      options: {
        responsive: true, maintainAspectRatio: false, animation: { duration: 250 },
        interaction: { mode: 'index', intersect: false },
        scales: { x: { grid: { display: false }, ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: 8 } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: GRID }, border: { display: false } } },
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: {
            title: function (it) { var r = state.tsData && state.tsData.rows[it[0].dataIndex]; return r ? tsLabel(r.t, state.tsData.interval, true) : ''; },
            label: function (c) { return ' ' + c.dataset.label + ': ' + num(c.raw); },
            footer: function (it) { var r = state.tsData && state.tsData.rows[it[0].dataIndex]; if (!r) return ''; var out = [I.visitsN.replace('%s', num(r.visits)) + ' · ' + I.viewsN.replace('%s', num(r.views))]; if (r.locations && r.locations.length) out.push(r.locations.map(function (l) { return l[0] + ' (' + num(l[1]) + ')'; }).join(', ')); return out; }
          } }
        }
      }
    });
  }
  /* label for a bucket start */
  function tsLabel(t, iv, long) {
    if (iv === 'day') return long ? day(t) : dm(t);
    var multi = state.tsData && state.tsData.rows.length && local(state.tsData.rows[0].t).getUTCDate() !== local(state.tsData.rows[state.tsData.rows.length - 1].t).getUTCDate();
    return (multi || long ? dm(t) + ' ' : '') + hm(t);
  }

  /* ---------------- render: summary ---------------- */
  function renderKpis(s) {
    var v = { visits: s.visits, visitors: s.visitors, active: s.active, page_views: s.page_views, tool_runs: s.tool_runs, files: s.files };
    Object.keys(v).forEach(function (k) { var el = $('[data-kpi="' + k + '"] .fo-kpi-v'); if (el) el.textContent = num(v[k]); });
    $('[data-kpi="tool_runs"] .fo-kpi-s').textContent = I.runsSplit.replace('%1$s', num(s.browser_runs)).replace('%2$s', num(s.server_runs)) + (s.failed ? ' · ' + I.failedN.replace('%s', num(s.failed)) : '');
    $('[data-kpi="visitors"] .fo-kpi-s').textContent = s.new_visitors ? I.newN.replace('%s', num(s.new_visitors)) : I.uniqueSub;
    $('#fo-kpis').setAttribute('aria-busy', 'false');
  }
  function renderLoc(l) {
    var items = l.items || [], total = l.total || 0;
    $('#loc-total').textContent = num(total);
    $('#loc-empty').hidden = !!items.length;
    $('.fo-loc').hidden = !items.length;
    var k = 0;
    var colors = items.map(function (it) { return it.other || !it.country ? OTHER : SLOT[k++ % SLOT.length]; });
    charts.loc.data.labels = items.map(function (it) { return it.label; });
    charts.loc.data.datasets[0].data = items.map(function (it) { return it.n; });
    charts.loc.data.datasets[0].backgroundColor = colors;
    charts.loc.update();
    $('#loc-legend').innerHTML = items.map(function (it, i) {
      return '<li><i class="fo-sw" style="background:' + colors[i] + '"></i><span class="fo-lg-l">' + esc(it.label) + '</span><span class="fo-lg-n">' + num(it.n) + '</span><span class="fo-lg-p">' + pct(it.n, total) + '</span></li>';
    }).join('');
    var unknown = total - (l.known || 0);
    $('#loc-note').textContent = (unknown > 0 && items.length ? I.unknownLoc.replace('%s', num(unknown)) + ' ' : '') + (l.note || '');
  }
  function renderRt(rt) {
    state.rt = rt;
    var labels = rt.labels.map(function (ms) { return hm(ms / 1000); });
    var n = rt.series.length;
    charts.rt.data.labels = labels;
    charts.rt.data.datasets = rt.series.map(function (s, si) {
      return {
        label: s.label, data: s.data,
        backgroundColor: s.other ? OTHER : SLOT[si % SLOT.length],
        borderColor: SURF, borderWidth: { top: 2, right: 0, bottom: 0, left: 0 }, borderSkipped: 'bottom', maxBarThickness: 18,
        borderRadius: function (ctx) {
          var i = ctx.dataIndex, top = -1;
          rt.series.forEach(function (x, k) { if (x.data[i] > 0) top = k; });
          return ctx.datasetIndex === top ? { topLeft: 4, topRight: 4 } : 0;
        }
      };
    });
    charts.rt.update();
    $('#rt-legend').innerHTML = n > 1 ? rt.series.map(function (s, si) { var c = charts.rt.data.datasets[si].backgroundColor; return '<li><i class="fo-sw" style="background:' + c + '"></i>' + esc(s.label) + '</li>'; }).join('') : '';
    // spikes: a minute well above the usual level
    var t = rt.total, sum = t.reduce(function (a, b) { return a + b; }, 0), mean = sum / t.length;
    var sd = Math.sqrt(t.reduce(function (a, b) { return a + (b - mean) * (b - mean); }, 0) / t.length);
    var peak = Math.max.apply(null, t), at = t.indexOf(peak);
    var note = I.nowActive.replace('%s', num(t[t.length - 1] || 0));
    if (peak >= 3 && peak > mean + 2 * sd) note += ' · ' + I.spike.replace('%1$s', labels[at]).replace('%2$s', num(peak));
    else if (!sum) note = I.noTraffic;
    $('#rt-note').textContent = note;
  }
  function renderCmp(c) {
    charts.cmp.data.labels = c.labels.map(function (k) { return dlabel(k, c.group); });
    charts.cmp.data.datasets[0].data = c.visitors;
    charts.cmp.data.datasets[1].data = c.runs;
    charts.cmp.update();
    $('#cmp-table').innerHTML = '<table class="widefat striped fo-table"><thead><tr><th>' + esc(I.period) + '</th><th class="num">' + esc(I.visitsCol) + '</th><th class="num">' + esc(I.uniqueVisitors) + '</th><th class="num">' + esc(I.pageViews) + '</th><th class="num">' + esc(I.toolRuns) + '</th><th class="num">' + esc(I.filesProcessed) + '</th><th class="num">' + esc(I.failed) + '</th></tr></thead><tbody>' +
      c.labels.map(function (k, i) { var none = c.source[i] === 'none'; return '<tr' + (none ? ' class="fo-muted"' : '') + '><td>' + esc(dlabel(k, c.group)) + (c.source[i] === 'partial' ? ' <small class="fo-muted">' + esc(I.partial) + '</small>' : '') + '</td><td class="num">' + (none ? '—' : num(c.visits[i])) + '</td><td class="num">' + (none ? '—' : num(c.visitors[i])) + '</td><td class="num">' + (none ? '—' : num(c.views[i])) + '</td><td class="num">' + (none ? '—' : num(c.runs[i])) + '</td><td class="num">' + (none ? '—' : num(c.files[i])) + '</td><td class="num">' + (none ? '—' : num(c.failed[i])) + '</td></tr>'; }).reverse().join('') + '</tbody></table>';
    var tv = c.visitors.reduce(function (a, b) { return a + b; }, 0), tr = c.runs.reduce(function (a, b) { return a + b; }, 0);
    $('#cmp-note').textContent = I.cmpTotals.replace('%1$s', dlabel(c.labels[0] || '', c.group)).replace('%2$s', dlabel(c.labels[c.labels.length - 1] || '', c.group)).replace('%3$s', num(tr)) + (c.source.indexOf('none') >= 0 ? ' ' + I.noDetail : '');
  }
  function renderPeriod(d) {
    var w = d.window, cov = d.coverage || {};
    var txt = I.showingPeriod.replace('%1$s', dt(w.start)).replace('%2$s', state.range === 'custom' ? day(w.end - 1) : I.now);
    if (cov.detail_from && w.start < cov.detail_from - 60) txt += ' ' + I.detailFrom.replace('%s', day(cov.detail_from));
    $('#fo-period').textContent = txt;
  }
  function renderTs(d) {
    state.tsData = d;
    $$('[data-interval]').forEach(function (b) { var ok = d.allowed.indexOf(b.dataset.interval) >= 0; b.disabled = !ok; b.setAttribute('aria-pressed', b.dataset.interval === d.interval ? 'true' : 'false'); });
    var rows = d.rows;
    charts.ts.data.labels = rows.map(function (r) { return tsLabel(r.t, d.interval); });
    charts.ts.data.datasets[0].data = rows.map(function (r) { return r.visitors; });
    charts.ts.data.datasets[1].data = rows.map(function (r) { return r.runs; });
    charts.ts.data.datasets[2].data = rows.map(function (r) { return r.files; });
    var pts = rows.length <= 60 ? 3 : 0;
    charts.ts.data.datasets.forEach(function (x) { x.pointRadius = pts; });
    charts.ts.update();
    $('#ts-sub').textContent = I['per_' + d.interval] + ' · ' + I.bucketsN.replace('%s', num(rows.length));
    // peak and the latest change
    var v = rows.map(function (r) { return r.visitors; }), sum = v.reduce(function (a, b) { return a + b; }, 0);
    var note = '';
    if (!sum) note = I.noData;
    else {
      var peak = Math.max.apply(null, v), at = v.indexOf(peak);
      note = I.peak.replace('%1$s', num(peak)).replace('%2$s', tsLabel(rows[at].t, d.interval, true));
      var half = Math.floor(v.length / 2);
      if (half >= 2) {
        var a = v.slice(0, half).reduce(function (x, y) { return x + y; }, 0), b = v.slice(v.length - half).reduce(function (x, y) { return x + y; }, 0);
        if (a && b !== a) note += ' · ' + (b > a ? I.trendUp : I.trendDown).replace('%s', Math.abs(Math.round((b - a) / a * 100)) + '%');
        else if (!a && b) note += ' · ' + I.trendNew;
      }
    }
    if (rows.some(function (r) { return r.source === 'none'; })) note += ' · ' + I.noDetail;
    $('#ts-note').textContent = note;
    renderTsTable();
  }
  function renderTsTable() {
    var d = state.tsData; if (!d) return;
    var rows = d.rows.slice().reverse(), per = 60, pages = Math.max(1, Math.ceil(rows.length / per));
    state.ts.page = Math.min(state.ts.page, pages);
    var start = (state.ts.page - 1) * per;
    var head = '<tr><th>' + esc(I.dateTime) + '</th><th class="num">' + esc(I.visitsCol) + '</th><th class="num">' + esc(I.uniqueVisitors) + '</th><th class="num">' + esc(I.change) + '</th><th class="num">' + esc(I.pageViews) + '</th><th class="num">' + esc(I.toolRuns) + '</th><th class="num">' + esc(I.filesProcessed) + '</th><th class="num">' + esc(I.failed) + '</th><th>' + esc(I.topLocations) + '</th></tr>';
    var body = rows.slice(start, start + per).map(function (r, i) {
      var prev = rows[start + i + 1], ch = prev ? r.visitors - prev.visitors : null;
      var chs = ch == null ? '' : ch > 0 ? '<span class="fo-up">▲ ' + num(ch) + '</span>' : ch < 0 ? '<span class="fo-down">▼ ' + num(-ch) + '</span>' : '<span class="fo-muted">0</span>';
      var loc = (r.locations || []).map(function (l) { return esc(l[0]) + ' <span class="fo-muted">(' + num(l[1]) + ')</span>'; }).join(', ');
      return '<tr><td>' + esc(tsLabel(r.t, d.interval, true)) + '</td><td class="num">' + num(r.visits) + '</td><td class="num">' + num(r.visitors) + '</td><td class="num">' + chs + '</td><td class="num">' + num(r.views) + '</td><td class="num">' + num(r.runs) + '</td><td class="num">' + num(r.files) + '</td><td class="num">' + num(r.failed) + '</td><td>' + (loc || '<span class="fo-muted">—</span>') + '</td></tr>';
    }).join('');
    $('#ts-table-in').innerHTML = '<table class="widefat striped fo-table"><thead>' + head + '</thead><tbody>' + body + '</tbody></table>';
    pager('ts', { page: state.ts.page, pages: pages, total: rows.length });
  }
  function renderTools(list) {
    var used = list.filter(function (t) { return t.runs || t.views; });
    if (!used.length) { $('#tools-table').innerHTML = '<p class="fo-empty">' + esc(I.noData) + '</p>'; return; }
    $('#tools-table').innerHTML = '<table class="widefat striped fo-table"><thead><tr><th>' + esc(I.tool) + '</th><th class="num">' + esc(I.toolViews) + '</th><th class="num">' + esc(I.browser) + '</th><th class="num">' + esc(I.server) + '</th><th class="num">' + esc(I.toolRuns) + '</th><th class="num">' + esc(I.failed) + '</th><th class="num">' + esc(I.success) + '</th><th class="num">' + esc(I.filesProcessed) + '</th><th class="num">' + esc(I.avgTime) + '</th></tr></thead><tbody>' +
      used.map(function (t) { return '<tr><td>' + esc(t.name) + '</td><td class="num">' + num(t.views) + '</td><td class="num">' + num(t.browser_runs) + '</td><td class="num">' + num(t.server_runs) + '</td><td class="num"><b>' + num(t.runs) + '</b></td><td class="num">' + num(t.failed) + '</td><td class="num">' + (t.ok_pct == null ? '—' : Number(t.ok_pct).toLocaleString(C.locale) + '%') + '</td><td class="num">' + num(t.files) + '</td><td class="num">' + (t.avg_ms == null ? '—' : (t.avg_ms / 1000).toFixed(1) + ' s') + '</td></tr>'; }).join('') + '</tbody></table>';
  }
  function bars(list, el) {
    var max = Math.max.apply(null, list.map(function (x) { return x.n || x.runs || 0; }).concat([1]));
    el.innerHTML = list.length ? '<ul class="fo-hbars">' + list.map(function (x) {
      var v = x.n != null ? x.n : x.runs;
      return '<li><span class="fo-hb-l">' + esc(x.label || x.name) + (x.failed ? ' <small class="fo-bad">' + esc(I.failedN.replace('%s', num(x.failed))) + '</small>' : '') + '</span><span class="fo-hb-bar"><i style="width:' + Math.max(2, Math.round(v / max * 100)) + '%"></i></span><span class="fo-hb-n">' + num(v) + '</span></li>';
    }).join('') + '</ul>' : '<p class="fo-empty">' + esc(I.noData) + '</p>';
  }
  function renderSide(d) {
    bars(d.top_tools, $('#top-tools'));
    renderTools(d.tools || []);
    bars(d.devices.device, $('#bd-device'));
    bars(d.devices.browser, $('#bd-browser'));
    bars(d.devices.os, $('#bd-os'));
  }

  /* ---------------- tables ---------------- */
  var ST = { done: [I.done, 'good'], failed: [I.failed, 'bad'], progress: [I.progress, 'warn'] };
  function status(s) { var x = ST[s] || [s, '']; return '<span class="fo-st fo-st-' + x[1] + '"><i aria-hidden="true"></i>' + esc(x[0]) + '</span>'; }
  function renderAct(d) {
    var ip = d.canSeeIp;
    var head = '<tr><th>' + esc(I.dateTime) + '</th><th>' + esc(I.tool) + '</th><th>' + esc(I.file) + '</th><th>' + esc(I.location) + '</th>' + (ip ? '<th>' + esc(I.ip) + '</th>' : '') + '<th>' + esc(I.status) + '</th></tr>';
    var rows = d.items.map(function (r) {
      var file = r.file ? esc(r.file) : '<span class="fo-muted">' + esc(r.files ? I.filesN.replace('%s', r.files) : '—') + '</span>';
      return '<tr><td><time title="' + esc(dt(r.at)) + '">' + esc(ago(r.at)) + '</time></td><td>' + esc(r.toolName) + '<br><small class="fo-muted">' + esc(r.exec === 'server' ? I.server : I.browser) + (r.ms != null ? ' · ' + (r.ms / 1000).toFixed(1) + ' s' : '') + '</small></td><td class="fo-file">' + file + '</td><td>' + (r.location ? esc(r.location) : '<span class="fo-muted">' + esc(I.unknown) + '</span>') + '</td>' + (ip ? '<td><code>' + esc(r.ip || '—') + '</code></td>' : '') + '<td>' + status(r.status) + (r.error ? '<br><small class="fo-muted" title="' + esc(r.error) + '">' + esc(r.error.slice(0, 60)) + '</small>' : '') + '</td></tr>';
    }).join('');
    $('#act-table').innerHTML = d.items.length ? '<table class="widefat striped fo-table"><thead>' + head + '</thead><tbody>' + rows + '</tbody></table>' : '<p class="fo-empty">' + esc(I.noActivity) + '</p>';
    pager('act', d);
  }
  var VCOLS = [['last_seen', 'lastActivity'], ['visitor', 'visitorId', true], ['country', 'location'], ['ip', 'ip', true], ['page', 'pageTool', true], ['device', 'device'], ['browser', 'browserCol'], ['pages', 'pagesN'], ['status', 'status', true]];
  function renderVis(d) {
    var ip = d.canSeeIp;
    var head = '<tr>' + VCOLS.filter(function (c) { return ip || c[0] !== 'ip'; }).map(function (c) {
      if (c[2]) return '<th>' + esc(I[c[1]]) + '</th>';
      var on = state.vis.orderby === c[0], dir = on && state.vis.order === 'asc' ? 'ascending' : on ? 'descending' : 'none';
      return '<th aria-sort="' + dir + '"><button type="button" class="fo-sort" data-sort="' + c[0] + '">' + esc(I[c[1]]) + (on ? (state.vis.order === 'asc' ? ' ▲' : ' ▼') : '') + '</button></th>';
    }).join('') + '</tr>';
    var rows = d.items.map(function (r) {
      return '<tr><td><time title="' + esc(I.firstSeen + ': ' + dt(r.first)) + '">' + esc(dt(r.last)) + '</time></td><td><code>' + esc(r.visitor) + '</code>' + (r['new'] ? ' <small class="fo-tag">' + esc(I.newTag) + '</small>' : '') + '</td><td>' + esc(r.location) + '</td>' + (ip ? '<td><code>' + esc(r.ip || '—') + '</code></td>' : '') +
        '<td class="fo-file">' + esc(r.tool || r.page || r.landing) + (r.referrer ? '<br><small class="fo-muted">' + esc(I.from + ' ' + r.referrer) + '</small>' : '') + '</td><td>' + esc(r.device) + '<br><small class="fo-muted">' + esc(r.os) + '</small></td><td>' + esc(r.browser) + '</td><td class="num">' + num(r.pages) + (r.runs ? '<br><small class="fo-muted">' + esc(I.runsN.replace('%s', r.runs)) + '</small>' : '') + '</td><td>' + (r.status === 'active' ? '<span class="fo-st fo-st-good"><i aria-hidden="true"></i>' + esc(I.active) + '</span>' : '<span class="fo-muted">' + esc(I.ended) + '</span>') + '</td></tr>';
    }).join('');
    $('#vis-table').innerHTML = d.items.length ? '<table class="widefat striped fo-table"><thead>' + head + '</thead><tbody>' + rows + '</tbody></table>' : '<p class="fo-empty">' + esc(I.noVisits) + '</p>';
    pager('vis', d);
  }
  function pager(k, d) {
    var el = $('#' + k + '-pager');
    if (d.pages <= 1) { el.innerHTML = d.total ? '<span>' + esc(I.results.replace('%s', num(d.total))) + '</span>' : ''; return; }
    el.innerHTML = '<span>' + esc(I.results.replace('%s', num(d.total))) + '</span><button type="button" class="button" data-page="' + (d.page - 1) + '"' + (d.page <= 1 ? ' disabled' : '') + '>‹ ' + esc(I.prev) + '</button><span>' + esc(I.pageOf.replace('%1$s', d.page).replace('%2$s', d.pages)) + '</span><button type="button" class="button" data-page="' + (d.page + 1) + '"' + (d.page >= d.pages ? ' disabled' : '') + '>' + esc(I.next) + ' ›</button>';
    $$('button[data-page]', el).forEach(function (b) { b.onclick = function () { state[k].page = +b.dataset.page; if (k === 'ts') renderTsTable(); else (k === 'act' ? loadAct : loadVis)(); }; });
  }
  function formParams(k) {
    var f = $('form[data-list="' + k + '"]'), p = { period: state.range, wfrom: state.range === 'custom' ? state.from : '', wto: state.range === 'custom' ? state.to : '' };
    $$('input, select', f).forEach(function (el) { if (el.type === 'checkbox') { if (el.checked) p[el.name] = el.value; } else if (el.value) p[el.name] = el.value; });
    return p;
  }

  /* ---------------- loading ---------------- */
  function loadSummary() {
    return api('admin/analytics', extend(period(), { level: state.level, days: state.days, group: state.group })).then(function (d) {
      renderPeriod(d); renderKpis(d.summary); renderLoc(d.locations); renderRt(d.realtime); renderCmp(d.compare); renderSide(d);
      return d;
    });
  }
  function loadSeries() {
    return api('admin/series', extend(period(), { interval: state.interval })).then(renderTs);
  }
  /* everything that depends on the period at the top */
  function loadPeriod() {
    state.act.page = 1; state.vis.page = 1; state.ts.page = 1;
    syncExport();
    return Promise.all([loadSummary(), loadSeries(), loadAct(), loadVis()]).catch(function (e) { $('#fo-updated').textContent = e && e.message ? e.message : I.loadErr; });
  }
  function loadAct() {
    var p = formParams('act'); p.page = state.act.page; p.per_page = 15;
    return api('admin/activity', p).then(renderAct);
  }
  function loadVis() {
    var p = formParams('vis'); p.page = state.vis.page; p.per_page = 20; p.orderby = state.vis.orderby; p.order = state.vis.order;
    return api('admin/visitors', p).then(renderVis);
  }
  function refresh(all) {
    if (state.busy) return;
    state.busy = true;
    $('#fo-live').className = 'fo-live is-loading';
    Promise.all([loadSummary(), loadSeries(), loadAct(), all === false ? null : loadVis()]).then(function () {
      state.last = Date.now();
      $('#fo-live').className = 'fo-live';
      $('#fo-updated').textContent = I.updated.replace('%s', hms(Date.now() / 1000));
    }).catch(function (e) {
      $('#fo-live').className = 'fo-live is-error';
      $('#fo-updated').textContent = (e && e.message ? e.message : I.loadErr) + (state.last ? ' · ' + I.showing.replace('%s', hms(state.last / 1000)) : '');
    }).then(function () { state.busy = false; });
  }

  /* ---------------- controls ---------------- */
  function press(sel, attr, val) { $$(sel).forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute(attr) === String(val) ? 'true' : 'false'); }); }
  press('.fo-range-btn', 'data-range', state.range);
  var custom = $('#fo-custom'), cbtn = $('.fo-range-btn[data-range="custom"]');
  function showCustom(on) { custom.hidden = !on; cbtn.setAttribute('aria-expanded', on ? 'true' : 'false'); }
  $('#fo-from').value = state.from; $('#fo-to').value = state.to;
  showCustom(state.range === 'custom');
  custom.onsubmit = function () {
    var f = $('#fo-from').value, t = $('#fo-to').value;
    if (!f || !t) { $('#fo-custom-err').textContent = I.pickDates; return false; }
    if (f > t) { var x = f; f = t; t = x; $('#fo-from').value = f; $('#fo-to').value = t; }
    $('#fo-custom-err').textContent = '';
    state.range = 'custom'; state.from = f; state.to = t; state.interval = '';
    press('.fo-range-btn', 'data-range', 'custom'); save(); loadPeriod();
    return false;
  };
  press('[data-level]', 'data-level', state.level);
  press('[data-group]', 'data-group', state.group);
  $('#cmp-days').value = String(state.days);
  $$('.fo-range-btn').forEach(function (b) { b.onclick = function () {
    if (b.dataset.range === 'custom') { showCustom(custom.hidden || state.range === 'custom'); if (!custom.hidden) $('#fo-from').focus(); return; }
    showCustom(false);
    state.range = b.dataset.range; state.interval = ''; press('.fo-range-btn', 'data-range', state.range); save(); loadPeriod();
  }; });
  $$('[data-interval]').forEach(function (b) { b.onclick = function () { state.interval = b.dataset.interval; state.ts.page = 1; save(); loadSeries().catch(function () {}); }; });
  /* export form: show the fields that apply, start from the period above */
  var xf = $('#fo-export');
  function xshow() {
    if (!xf) return;
    var set = xf.dataset ? xf.querySelector('[name="dataset"]').value : '', r = xf.querySelector('[name="range"]').value;
    $$('.fo-x-custom', xf).forEach(function (el) { el.hidden = r !== 'custom'; el.querySelector('input').required = r === 'custom'; });
    $$('.fo-x-series', xf).forEach(function (el) { el.hidden = set !== 'series'; });
    $$('.fo-x-events', xf).forEach(function (el) { el.hidden = set !== 'events'; });
    $$('.fo-x-ip', xf).forEach(function (el) { el.hidden = ['visits', 'events', 'processing'].indexOf(set) < 0; });
  }
  function syncExport() {
    if (!xf) return;
    var sel = xf.querySelector('[name="range"]');
    if (state.range === 'custom') { sel.value = 'custom'; xf.querySelector('[name="from"]').value = state.from; xf.querySelector('[name="to"]').value = state.to; }
    else if (sel.querySelector('option[value="' + state.range + '"]')) sel.value = state.range;
    xshow();
  }
  if (xf) { xf.addEventListener('change', xshow); syncExport(); }
  $$('[data-level]').forEach(function (b) { b.onclick = function () { state.level = b.dataset.level; press('[data-level]', 'data-level', state.level); save(); loadSummary().catch(function () {}); }; });
  $$('[data-group]').forEach(function (b) { b.onclick = function () { state.group = b.dataset.group; press('[data-group]', 'data-group', state.group); save(); loadSummary().catch(function () {}); }; });
  $('#cmp-days').onchange = function () { state.days = this.value; save(); loadSummary().catch(function () {}); };
  $$('[data-table-toggle]').forEach(function (b) { b.onclick = function () { var t = document.getElementById(b.dataset.tableToggle); t.hidden = !t.hidden; b.setAttribute('aria-expanded', String(!t.hidden)); b.textContent = t.hidden ? I.showTable : I.hideTable; }; });
  ['act', 'vis'].forEach(function (k) {
    var f = $('form[data-list="' + k + '"]'), timer;
    var go = function () { state[k].page = 1; (k === 'act' ? loadAct : loadVis)().catch(function () {}); };
    f.addEventListener('input', function (e) { clearTimeout(timer); timer = setTimeout(go, e.target.type === 'search' ? 350 : 0); });
    f.addEventListener('change', function (e) { if (e.target.type !== 'search') { clearTimeout(timer); go(); } });
    f.addEventListener('reset', function () { setTimeout(go, 0); });
  });
  $('#vis-table').addEventListener('click', function (e) {
    var b = e.target.closest('[data-sort]'); if (!b) return;
    var k = b.dataset.sort;
    state.vis.order = state.vis.orderby === k && state.vis.order === 'desc' ? 'asc' : 'desc';
    state.vis.orderby = k; state.vis.page = 1; loadVis().catch(function () {});
  });
  // filter menus
  var toolSel = $('form[data-list="act"] select[name="tool"]');
  C.tools.forEach(function (t) { var o = document.createElement('option'); o.value = t.id; o.textContent = t.name; toolSel.appendChild(o); });
  $$('select[name="country"]').forEach(function (sel) { Object.keys(C.countries).forEach(function (c) { var o = document.createElement('option'); o.value = c; o.textContent = C.countries[c]; sel.appendChild(o); }); });

  $('#fo-refresh').onclick = function () { refresh(); };
  var auto = $('#fo-auto');
  try { if (localStorage.getItem('fileora.an.auto') === '0') auto.checked = false; } catch (e) { /* ignore */ }
  auto.onchange = function () { try { localStorage.setItem('fileora.an.auto', auto.checked ? '1' : '0'); } catch (e) { /* ignore */ } };
  setInterval(function () {
    if (!auto.checked || document.visibilityState !== 'visible') return;
    if (Date.now() - state.last >= C.refresh - 1000) refresh();
  }, 5000);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible' && auto.checked && Date.now() - state.last > C.refresh) refresh(); });

  locChart(); rtChart(); cmpChart(); tsChart();
  refresh();
})();
