/* Fileora admin: small interface helpers. */
(function () {
  'use strict';
  var range = document.querySelector('[data-fo-range]');
  if (range) {
    var sync = function () {
      document.querySelectorAll('[data-fo-custom]').forEach(function (el) { el.hidden = range.value !== 'custom'; });
    };
    range.addEventListener('change', sync);
    sync();
  }
})();
