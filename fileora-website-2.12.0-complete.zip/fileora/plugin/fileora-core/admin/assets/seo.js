/* Fileora SEO box: Google preview, length meters and a live checklist; image pickers for the SEO screens. */
(function ($) {
  'use strict';

  /* ---- 60-day plan: confirm before undo ---- */
  $(document).on('submit', '.fo-plan-f', function (e) {
    var b = $(this).find('[data-confirm]');
    if (b.length && !window.confirm(b.attr('data-confirm'))) { e.preventDefault(); }
  });

  /* ---- image pickers (editor box and Fileora → SEO settings) ---- */
  $(document).on('click', '.fo-seo-pick', function (e) {
    e.preventDefault();
    var box = $(this).closest('.fo-seo-image');
    var frame = wp.media({ title: this.textContent, library: { type: 'image' }, multiple: false });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      box.find('input[type=hidden]').val(a.id).trigger('change');
      var u = (a.sizes && (a.sizes.medium || a.sizes.full) || a).url;
      box.find('.fo-seo-img-pv').html($('<img alt="">').attr('src', u));
      box.find('.fo-seo-clear').prop('hidden', false);
    });
    frame.open();
  });
  $(document).on('click', '.fo-seo-clear', function (e) {
    e.preventDefault();
    var box = $(this).closest('.fo-seo-image');
    box.find('input[type=hidden]').val('').trigger('change');
    box.find('.fo-seo-img-pv').empty();
    $(this).prop('hidden', true);
  });

  var root = document.querySelector('.fo-seo[data-config]');
  if (!root) return;
  var C = JSON.parse(root.getAttribute('data-config'));
  var $kw = $('#fo-seo-keyword'), $t = $('#fo-seo-title'), $d = $('#fo-seo-desc'), $kws = $('#fo-seo-keywords');
  $(root).on('click', '.fo-seo-use', function () { $t.val(this.getAttribute('data-title')).trigger('input'); $t.trigger('focus'); });

  function editor() { return window.wp && wp.data && wp.data.select('core/editor'); }
  function state() {
    var ed = editor(), s = { title: '', slug: '', link: '', html: '' };
    if (ed && ed.getEditedPostAttribute) {
      s.title = ed.getEditedPostAttribute('title') || '';
      s.slug = ed.getEditedPostAttribute('slug') || '';
      s.link = (ed.getPermalink && ed.getPermalink()) || '';
      s.html = ed.getEditedPostContent ? ed.getEditedPostContent() : '';
    } else {
      s.title = $('#title').val() || '';
      s.slug = $('#post_name').val() || $('#editable-post-name-full').text() || '';
      s.link = $('#sample-permalink a').attr('href') || '';
      var mce = window.tinymce && tinymce.get('content');
      s.html = mce && !mce.isHidden() ? mce.getContent() : ($('#content').val() || '');
    }
    var ex = (window.wp && wp.data && ed && ed.getEditedPostAttribute) ? ed.getEditedPostAttribute('excerpt') : $('#excerpt').val();
    if (ex && C.extra) s.html = '<p>' + ex + '</p>' + s.html;
    s.html += C.faq ? '\n' + C.faq : '';
    s.html += C.extra || '';
    return s;
  }
  function textOf(html) { var d = document.createElement('div'); d.innerHTML = html.replace(/<!--[\s\S]*?-->/g, ' '); return (d.textContent || '').replace(/\s+/g, ' ').trim(); }
  function lc(s) { return String(s || '').toLowerCase(); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function meter(id, len) {
    var m = root.querySelector('.fo-seo-meter[data-for="' + id + '"]'), c = root.querySelector('.fo-seo-count[data-for="' + id + '"]');
    var min = +m.dataset.min, max = +m.dataset.max;
    var cls = !len ? '' : len < min ? 'short' : len > max ? 'long' : 'good';
    m.className = 'fo-seo-meter ' + cls;
    m.firstChild.style.width = Math.min(100, Math.round(len / (max * 1.15) * 100)) + '%';
    c.textContent = len + ' / ' + min + '–' + max + ' characters' + (cls === 'short' ? ' · a bit short' : cls === 'long' ? ' · Google will cut it off' : cls === 'good' ? ' · good length' : '');
  }

  function run() {
    var s = state(), kw = lc($kw.val().trim());
    var seoTitle = $t.val().trim(), desc = $d.val().trim();
    var title = seoTitle || C.defTitle || s.title;
    var full = title + (lc(title).indexOf(lc(C.site)) >= 0 ? '' : C.sep + C.site);
    var descEff = desc || C.defDesc || textOf(s.html).slice(0, 155);
    var text = textOf(s.html), words = text ? text.split(' ').length : 0;
    var first = text.split(' ').slice(0, 120).join(' ');
    var heads = (s.html.match(/<h[23][^>]*>[\s\S]*?<\/h[23]>/gi) || []).map(textOf).join(' ');
    var imgs = s.html.match(/<img\b[^>]*>/gi) || [], noAlt = imgs.filter(function (t) { return !/\balt\s*=\s*"[^"]+"/i.test(t); }).length;
    var host = location.host, internal = /href\s*=\s*"\/(?!\/)/i.test(s.html) || new RegExp('href\\s*=\\s*"https?://' + host.replace(/\./g, '\\.'), 'i').test(s.html) || (C.isTool && !!C.faq);
    var link = s.link || (C.home + (s.slug ? s.slug + '/' : ''));
    var has = function (h) { return !!kw && lc(h).indexOf(kw) >= 0; };

    // preview
    root.querySelector('.fo-seo-pv-url').textContent = link.replace(/^https?:\/\//, '').replace(/\/$/, '').split('/').join(' › ');
    var pt = full.length > 62 ? full.slice(0, 60) + '…' : full;
    root.querySelector('.fo-seo-pv-title').textContent = pt;
    root.querySelector('.fo-seo-pv-desc').textContent = descEff.length > 160 ? descEff.slice(0, 157) + '…' : descEff;
    meter('fo-seo-title', title.length);
    meter('fo-seo-desc', descEff.length);

    var used = kw && C.others[kw];
    var checks = [
      [!!kw, 'Set a focus keyword', 'Add the phrase people search for.'],
      [has(title), 'Focus keyword in the SEO title', 'Put it near the start of the title.'],
      [has(descEff), 'Focus keyword in the meta description', 'Use it once, naturally.'],
      [has(s.slug.replace(/-/g, ' ')) || has(s.slug), 'Focus keyword in the page address', 'Edit the URL slug (only for new pages: changing an old address loses its ranking).'],
      [has(first), 'Focus keyword near the start of the text', 'Mention it in the first paragraph.'],
      [has(heads), 'Focus keyword in a subheading', 'Use it in one H2 or H3.'],
      [title.length >= 30 && title.length <= 60, 'SEO title 30–60 characters', title.length + ' now'],
      [descEff.length >= 120 && descEff.length <= 160, 'Meta description 120–160 characters', descEff.length + ' now'],
      [words >= 300, 'At least 300 words of text', words + ' now'],
      [noAlt === 0, 'All images have alt text', noAlt ? noAlt + ' image(s) without alt text' : ''],
      [internal, 'Links to another page on this site', 'Link to a related tool or guide.'],
      [!used, 'Focus keyword not used by another page', used ? 'Also used by “' + used + '”: the two pages compete in Google.' : '']
    ];
    var list = ($kws.val() || '').split(/\n/).map(function (k) { return k.trim(); }).filter(Boolean).slice(0, 10);
    var cov = root.querySelector('.fo-seo-kwcov');
    if (list.length) {
      var all = lc(title + ' ' + descEff + ' ' + text), found = list.filter(function (k) { return all.indexOf(lc(k)) >= 0; });
      var need = Math.min(8, list.length);
      checks.push([found.length >= need, 'Search keywords used in the text (at least ' + need + ')', (list.length - found.length) + ' not used yet']);
      if (cov) cov.innerHTML = '<strong>' + found.length + ' of ' + list.length + ' used</strong>' + list.map(function (k) { var ok = all.indexOf(lc(k)) >= 0; return '<span class="' + (ok ? 'ok' : 'no') + '">' + (ok ? '✓ ' : '✗ ') + esc(k) + '</span>'; }).join('');
    } else if (cov) cov.innerHTML = '';
    var ok = checks.filter(function (c) { return c[0]; }).length, score = Math.round(ok / checks.length * 100);
    var level = score >= 80 ? 'good' : score >= 50 ? 'ok' : 'bad';
    root.querySelector('.fo-seo-score').className = 'fo-seo-score ' + level;
    root.querySelector('.fo-seo-score-l').textContent = (level === 'good' ? 'Good' : level === 'ok' ? 'Could be better' : 'Needs work') + ' · ' + ok + ' of ' + checks.length + ' checks';
    root.querySelector('.fo-seo-list').innerHTML = checks.map(function (c) {
      return '<li class="' + (c[0] ? 'pass' : 'fail') + '"><span aria-hidden="true">' + (c[0] ? '✓' : '✗') + '</span><span><span class="screen-reader-text">' + (c[0] ? 'Done: ' : 'To do: ') + '</span>' + esc(c[1]) + (!c[0] && c[2] ? '<small>' + esc(c[2]) + '</small>' : '') + '</span></li>';
    }).join('');
  }

  var timer;
  function later() { clearTimeout(timer); timer = setTimeout(run, 250); }
  $kw.add($t).add($d).add($kws).on('input', later);
  $(document).on('input', '#title, #content, #post_name', later);
  if (window.wp && wp.data && wp.data.subscribe) wp.data.subscribe(later);
  if (window.tinymce) $(document).on('tinymce-editor-init', function (e, ed) { ed.on('keyup change', later); });
  run();
})(jQuery);
