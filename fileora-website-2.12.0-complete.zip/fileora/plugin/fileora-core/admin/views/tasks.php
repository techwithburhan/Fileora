<?php
/**
 * Fileora → Processing Tasks: every server task, filterable.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

$fo_res   = Fileora_Task_Manager::query( $filters );
$fo_pages = max( 1, (int) ceil( $fo_res['total'] / $filters['per_page'] ) );
$fo_tools = array_filter(
	Fileora_Tool_Registry::tools(),
	function ( $t ) {
		return 'browser' !== $t['exec'];
	}
);
$fo_status_names = array(
	'queued'  => __( 'Waiting', 'fileora' ),
	'running' => __( 'Running', 'fileora' ),
	'done'    => __( 'Completed', 'fileora' ),
	'failed'  => __( 'Failed', 'fileora' ),
);
$fo_codes = array(
	'processing'     => __( 'processing error', 'fileora' ),
	'rejected'       => __( 'file rejected', 'fileora' ),
	'unreachable'    => __( 'server unreachable', 'fileora' ),
	'auth'           => __( 'shared key rejected', 'fileora' ),
	'not_configured' => __( 'no server set up', 'fileora' ),
	'server_error'   => __( 'server error', 'fileora' ),
	'expired'        => __( 'expired', 'fileora' ),
	'abandoned'      => __( 'no result (visitor left)', 'fileora' ),
);
$fo_base = array_filter(
	array(
		'page'   => 'fileora-tasks',
		'range'  => $filters['range'],
		'tool'   => $filters['tool'],
		'status' => $filters['status'],
		'q'      => $filters['q'],
		'from'   => $filters['from'],
		'to'     => $filters['to'],
	)
);
?>
<?php
$fo_tmp       = Fileora_Temp_Cleanup::lookup();
$fo_temp_cell = function ( $r ) use ( $fo_tmp ) {
	if ( empty( $fo_tmp['ok'] ) ) {
		return '<span class="fo-sub">' . esc_html( fo_admin_na() ) . '</span>';
	}
	if ( isset( $fo_tmp['tasks'][ $r->id ] ) ) {
		list( $label, $state ) = Fileora_Temp_Cleanup::cleanup_label( $fo_tmp['tasks'][ $r->id ]['cleanup'], $fo_tmp['tasks'][ $r->id ] );
		return fo_admin_status( $state, $label ) . '<br><span class="fo-sub">' . esc_html( fo_admin_bytes( $fo_tmp['tasks'][ $r->id ]['size'] ) ) . '</span>';
	}
	if ( isset( $fo_tmp['removed'][ $r->id ] ) ) {
		$rm = $fo_tmp['removed'][ $r->id ];
		return esc_html( sprintf( /* translators: 1: time, 2: how */ __( 'Deleted %1$s ago (%2$s)', 'fileora' ), human_time_diff( (int) $rm['at'] ), Fileora_Temp_Cleanup::trigger_label( $rm['by'] ) ) );
	}
	if ( $r->downloaded_at ) {
		return esc_html__( 'Deleted after download', 'fileora' );
	}
	if ( in_array( $r->error_code, array( 'rejected', 'unreachable', 'auth', 'not_configured' ), true ) ) {
		return esc_html__( 'None (never stored)', 'fileora' );
	}
	return esc_html__( 'Not on the server any more', 'fileora' );
};
?>
<div class="wrap fo-wrap">
	<h1><?php esc_html_e( 'Processing Tasks', 'fileora' ); ?></h1>
	<nav class="fo-seg fo-tabs" aria-label="<?php esc_attr_e( 'Processing Tasks views', 'fileora' ); ?>">
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=fileora-tasks' ) ); ?>" aria-current="page"><?php esc_html_e( 'Task history', 'fileora' ); ?></a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=fileora-tasks&view=temp' ) ); ?>"><?php esc_html_e( 'Temporary files & cleanup', 'fileora' ); ?></a>
	</nav>
	<p class="fo-lead"><?php echo esc_html( sprintf( __( 'Every task sent to the processing server, including tasks it refused. Records are kept for %d days and never contain the files.', 'fileora' ), (int) Fileora_Core_Settings::value( 'task_retention' ) ) ); ?></p>

	<form class="fo-filters" method="get">
		<input type="hidden" name="page" value="fileora-tasks">
		<label><span><?php esc_html_e( 'Period', 'fileora' ); ?></span>
			<select name="range" data-fo-range>
				<option value="1" <?php selected( $filters['range'], '1' ); ?>><?php esc_html_e( 'Last 24 hours', 'fileora' ); ?></option>
				<option value="7" <?php selected( $filters['range'], '7' ); ?>><?php esc_html_e( 'Last 7 days', 'fileora' ); ?></option>
				<option value="30" <?php selected( $filters['range'], '30' ); ?>><?php esc_html_e( 'Last 30 days', 'fileora' ); ?></option>
				<option value="all" <?php selected( $filters['range'], 'all' ); ?>><?php esc_html_e( 'Everything kept', 'fileora' ); ?></option>
				<option value="custom" <?php selected( $filters['range'], 'custom' ); ?>><?php esc_html_e( 'Choose dates', 'fileora' ); ?></option>
			</select>
		</label>
		<label data-fo-custom <?php echo 'custom' === $filters['range'] ? '' : 'hidden'; ?>><span><?php esc_html_e( 'From', 'fileora' ); ?></span><input type="date" name="from" value="<?php echo esc_attr( $filters['from'] ); ?>"></label>
		<label data-fo-custom <?php echo 'custom' === $filters['range'] ? '' : 'hidden'; ?>><span><?php esc_html_e( 'To', 'fileora' ); ?></span><input type="date" name="to" value="<?php echo esc_attr( $filters['to'] ); ?>"></label>
		<label><span><?php esc_html_e( 'Tool', 'fileora' ); ?></span>
			<select name="tool">
				<option value=""><?php esc_html_e( 'All tools', 'fileora' ); ?></option>
				<?php foreach ( $fo_tools as $fo_t ) : ?>
					<option value="<?php echo esc_attr( $fo_t['id'] ); ?>" <?php selected( $filters['tool'], $fo_t['id'] ); ?>><?php echo esc_html( $fo_t['name'] ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<label><span><?php esc_html_e( 'Status', 'fileora' ); ?></span>
			<select name="status">
				<option value=""><?php esc_html_e( 'Any status', 'fileora' ); ?></option>
				<option value="done" <?php selected( $filters['status'], 'done' ); ?>><?php esc_html_e( 'Completed', 'fileora' ); ?></option>
				<option value="failed" <?php selected( $filters['status'], 'failed' ); ?>><?php esc_html_e( 'Failed', 'fileora' ); ?></option>
				<option value="open" <?php selected( $filters['status'], 'open' ); ?>><?php esc_html_e( 'Waiting or running', 'fileora' ); ?></option>
			</select>
		</label>
		<label><span><?php esc_html_e( 'Task id', 'fileora' ); ?></span><input type="search" name="q" value="<?php echo esc_attr( $filters['q'] ); ?>" placeholder="<?php esc_attr_e( 'Starts with…', 'fileora' ); ?>" size="12"></label>
		<button class="button"><?php esc_html_e( 'Filter', 'fileora' ); ?></button>
		<a class="button-link" href="<?php echo esc_url( admin_url( 'admin.php?page=fileora-tasks' ) ); ?>"><?php esc_html_e( 'Reset', 'fileora' ); ?></a>
	</form>

	<div class="fo-tablebar">
		<span><?php echo esc_html( sprintf( _n( '%s task', '%s tasks', $fo_res['total'], 'fileora' ), number_format_i18n( $fo_res['total'] ) ) ); ?></span>
		<form method="post" action="<?php echo esc_url( add_query_arg( $fo_base, admin_url( 'admin-post.php' ) ) ); ?>">
			<input type="hidden" name="action" value="fileora_export_tasks">
			<?php wp_nonce_field( 'fileora_export_tasks' ); ?>
			<button class="button"><?php esc_html_e( 'Download CSV', 'fileora' ); ?></button>
		</form>
	</div>

	<div class="fo-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Tasks', 'fileora' ); ?>">
	<table class="widefat striped fo-table fo-tasks">
		<thead><tr>
			<th><?php esc_html_e( 'Started', 'fileora' ); ?></th>
			<th><?php esc_html_e( 'Tool', 'fileora' ); ?></th>
			<th><?php esc_html_e( 'Status', 'fileora' ); ?></th>
			<th class="num"><?php esc_html_e( 'Time', 'fileora' ); ?></th>
			<th class="num"><?php esc_html_e( 'Files', 'fileora' ); ?></th>
			<th class="num"><?php esc_html_e( 'In', 'fileora' ); ?></th>
			<th class="num"><?php esc_html_e( 'Out', 'fileora' ); ?></th>
			<th><?php esc_html_e( 'Details', 'fileora' ); ?></th>
			<th><?php esc_html_e( 'Temporary files', 'fileora' ); ?></th>
		</tr></thead>
		<tbody>
		<?php if ( ! $fo_res['rows'] ) : ?>
			<tr><td colspan="9" class="fo-empty"><?php esc_html_e( 'No tasks match these filters.', 'fileora' ); ?></td></tr>
		<?php endif; ?>
		<?php foreach ( $fo_res['rows'] as $fo_r ) : ?>
			<?php
			$fo_state = 'done' === $fo_r->status ? 'good' : ( 'failed' === $fo_r->status ? 'critical' : 'unknown' );
			$fo_label = isset( $fo_status_names[ $fo_r->status ] ) ? $fo_status_names[ $fo_r->status ] : $fo_r->status;
			?>
			<tr>
				<td class="nowrap"><?php echo esc_html( fo_admin_time( $fo_r->created_at ) ); ?></td>
				<td><?php echo esc_html( fo_admin_tool_name( $fo_r->tool ) ); ?></td>
				<td><?php echo fo_admin_status( $fo_state, $fo_label ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
				<td class="num"><?php echo esc_html( fo_admin_ms( null === $fo_r->duration_ms ? null : (int) $fo_r->duration_ms ) ); ?></td>
				<td class="num"><?php echo esc_html( (int) $fo_r->files ); ?></td>
				<td class="num"><?php echo esc_html( $fo_r->bytes_in ? fo_admin_bytes( $fo_r->bytes_in ) : '–' ); ?></td>
				<td class="num"><?php echo esc_html( $fo_r->bytes_out ? fo_admin_bytes( $fo_r->bytes_out ) : '–' ); ?></td>
				<td>
					<?php if ( 'failed' === $fo_r->status ) : ?>
						<?php echo esc_html( (string) $fo_r->error ); ?>
						<?php if ( $fo_r->error_code ) : ?><span class="fo-code"><?php echo esc_html( isset( $fo_codes[ $fo_r->error_code ] ) ? $fo_codes[ $fo_r->error_code ] : $fo_r->error_code ); ?></span><?php endif; ?>
					<?php elseif ( 'done' === $fo_r->status ) : ?>
						<?php echo $fo_r->downloaded_at ? esc_html__( 'Downloaded', 'fileora' ) : esc_html__( 'Not downloaded', 'fileora' ); ?>
					<?php endif; ?>
					<br><code class="fo-id" title="<?php echo esc_attr( $fo_r->id ); ?>"><?php echo esc_html( substr( $fo_r->id, 0, 8 ) ); ?></code>
				</td>
				<td>
					<?php echo $fo_temp_cell( $fo_r ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside ?>
					<?php if ( ! empty( $fo_tmp['ok'] ) && isset( $fo_tmp['tasks'][ $fo_r->id ] ) ) : ?>
						<br><a href="<?php echo esc_url( admin_url( 'admin.php?page=fileora-tasks&view=temp&task=' . $fo_r->id ) ); ?>"><?php esc_html_e( 'Details', 'fileora' ); ?><span class="sr"> <?php echo esc_html( substr( $fo_r->id, 0, 8 ) ); ?></span></a>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	</div>

	<?php if ( empty( $fo_tmp['ok'] ) ) : ?>
		<p class="description"><?php echo esc_html( sprintf( __( 'Temporary files: Not Available (%s).', 'fileora' ), isset( $fo_tmp['error'] ) ? $fo_tmp['error'] : '' ) ); ?></p>
	<?php endif; ?>

	<?php if ( $fo_pages > 1 ) : ?>
		<div class="tablenav"><div class="tablenav-pages">
			<?php
			echo wp_kses_post(
				paginate_links(
					array(
						'base'    => add_query_arg( 'paged', '%#%', add_query_arg( $fo_base, admin_url( 'admin.php' ) ) ),
						'format'  => '',
						'current' => $filters['page'],
						'total'   => $fo_pages,
					)
				)
			);
			?>
		</div></div>
	<?php endif; ?>
</div>
