<?php
/**
 * Fileora → Tool Management.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

$fo_cats  = Fileora_Tool_Registry::categories();
$fo_tools = Fileora_Tool_Registry::tools();
$fo_use   = Fileora_Analytics::browser_runs_by_tool( 30 );
foreach ( Fileora_Task_Manager::by_tool( 30 ) as $fo_r ) {
	$fo_use[ $fo_r->tool ] = array( ( isset( $fo_use[ $fo_r->tool ] ) ? $fo_use[ $fo_r->tool ][0] : 0 ) + (int) $fo_r->total, 0 );
}
$fo_by_cat = array();
foreach ( $fo_tools as $fo_t ) {
	$fo_cid                 = $fo_t['category'] ? $fo_t['category']['id'] : 0;
	$fo_by_cat[ $fo_cid ][] = $fo_t;
}
$fo_missing = count( array_filter( $fo_tools, function ( $t ) { return ! $t['post_id']; } ) );
?>
<div class="wrap fo-wrap">
	<div class="fo-head">
		<h1><?php esc_html_e( 'Tool Management', 'fileora' ); ?></h1>
		<a class="button" href="<?php echo esc_url( admin_url( 'edit-tags.php?taxonomy=' . Fileora_Tool_Registry::TAXONOMY . '&post_type=' . Fileora_Tool_Registry::POST_TYPE ) ); ?>"><?php esc_html_e( 'Edit categories', 'fileora' ); ?></a>
	</div>
	<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Tools saved.', 'fileora' ); ?></p></div>
	<?php endif; ?>
	<?php if ( isset( $_GET['synced'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sprintf( _n( '%d tool page was restored.', '%d tool pages were restored.', absint( $_GET['synced'] ), 'fileora' ), absint( $_GET['synced'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>
	<p class="fo-lead"><?php esc_html_e( 'Switch tools on or off, change their order and category. Use “Edit page” to change a tool’s name, description, address, page text and FAQ. Pending tools stay off until they are built and tested.', 'fileora' ); ?></p>
	<?php if ( $fo_missing ) : ?>
		<div class="notice notice-warning inline"><p><?php echo esc_html( sprintf( _n( '%d tool has no page yet.', '%d tools have no page yet.', $fo_missing, 'fileora' ), $fo_missing ) ); ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="fileora_save_tools">
		<?php wp_nonce_field( 'fileora_save_tools' ); ?>
		<?php foreach ( $fo_cats + array( 0 => array( 'id' => 0, 'name' => __( 'No category', 'fileora' ), 'color' => 'organize', 'target' => 0 ) ) as $fo_cid => $fo_c ) : ?>
			<?php
			if ( empty( $fo_by_cat[ $fo_cid ] ) && 0 === $fo_cid ) {
				continue;
			}
			$fo_list  = isset( $fo_by_cat[ $fo_cid ] ) ? $fo_by_cat[ $fo_cid ] : array();
			$fo_ready = count( array_filter( $fo_list, function ( $t ) { return 'ready' === $t['status']; } ) );
			$fo_on    = count( array_filter( $fo_list, function ( $t ) { return $t['enabled']; } ) );
			?>
			<section class="fo-card fo-toolcat" data-cat="<?php echo esc_attr( $fo_c['color'] ); ?>">
				<header class="fo-toolcat-h">
					<h2><span class="fo-dot"></span><?php echo esc_html( $fo_c['name'] ); ?></h2>
					<span class="fo-counts">
						<?php if ( $fo_cid ) : ?>
							<label><?php esc_html_e( 'Target', 'fileora' ); ?> <input type="number" min="0" max="999" name="target[<?php echo esc_attr( $fo_cid ); ?>]" value="<?php echo esc_attr( (int) $fo_c['target'] ); ?>" class="small-text"></label>
						<?php endif; ?>
						<span><?php echo esc_html( sprintf( __( '%1$d in this category · %2$d implemented · %3$d on', 'fileora' ), count( $fo_list ), $fo_ready, $fo_on ) ); ?></span>
					</span>
				</header>
				<table class="widefat fo-table fo-tooltable">
					<thead><tr>
						<th class="check"><?php esc_html_e( 'On', 'fileora' ); ?></th>
						<th><?php esc_html_e( 'Tool', 'fileora' ); ?></th>
						<th><?php esc_html_e( 'Runs on', 'fileora' ); ?></th>
						<th><?php esc_html_e( 'Status', 'fileora' ); ?></th>
						<th><?php esc_html_e( 'Server', 'fileora' ); ?></th>
						<th class="num"><?php esc_html_e( 'Uses, 30 days', 'fileora' ); ?></th>
						<th><?php esc_html_e( 'Category', 'fileora' ); ?></th>
						<th class="num"><?php esc_html_e( 'Order', 'fileora' ); ?></th>
						<th></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $fo_list as $fo_t ) : ?>
						<?php
						$fo_avail = 'browser' === $fo_t['exec'] ? null : Fileora_Server_Monitor::tool_available( $fo_t['id'] );
						$fo_ready = 'ready' === $fo_t['status'];
						?>
						<tr class="<?php echo $fo_t['enabled'] ? '' : 'is-off'; ?>">
							<td class="check"><input type="checkbox" name="on[]" value="<?php echo esc_attr( $fo_t['id'] ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Switch %s on', 'fileora' ), $fo_t['name'] ) ); ?>" <?php checked( $fo_t['enabled'] ); ?> <?php disabled( ! $fo_ready || ! $fo_t['post_id'] ); ?>></td>
							<td><b><?php echo esc_html( $fo_t['name'] ); ?></b><?php echo $fo_t['paid'] ? ' <span class="fo-code">' . esc_html__( 'paid API', 'fileora' ) . '</span>' : ''; ?><br><span class="fo-sub">/<?php echo esc_html( $fo_t['slug'] ); ?>/</span></td>
							<td><?php echo esc_html( Fileora_Core_Admin::exec_label( $fo_t['exec'], Fileora_Tool_Registry::runs_on( $fo_t ) ) ); ?></td>
							<td><?php echo $fo_ready ? fo_admin_status( 'good', __( 'Implemented', 'fileora' ) ) : fo_admin_status( 'warning', __( 'Pending', 'fileora' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td>
								<?php
								if ( 'browser' === $fo_t['exec'] ) {
									echo '<span class="fo-sub">' . esc_html__( 'not needed', 'fileora' ) . '</span>';
								} else {
									echo true === $fo_avail ? fo_admin_status( 'good', __( 'Available', 'fileora' ) ) : ( false === $fo_avail ? fo_admin_status( 'critical', __( 'Not available', 'fileora' ) ) : fo_admin_status( 'unknown', __( 'Unknown', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								}
								?>
							</td>
							<td class="num"><?php echo esc_html( fo_admin_num( isset( $fo_use[ $fo_t['id'] ] ) ? $fo_use[ $fo_t['id'] ][0] : 0 ) ); ?></td>
							<td>
								<select name="cat[<?php echo esc_attr( $fo_t['id'] ); ?>]" aria-label="<?php esc_attr_e( 'Category', 'fileora' ); ?>">
									<?php foreach ( $fo_cats as $fo_cc ) : ?>
										<option value="<?php echo esc_attr( $fo_cc['id'] ); ?>" <?php selected( $fo_t['category'] ? $fo_t['category']['id'] : 0, $fo_cc['id'] ); ?>><?php echo esc_html( $fo_cc['name'] ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<td class="num"><input type="number" class="small-text" name="order[<?php echo esc_attr( $fo_t['id'] ); ?>]" value="<?php echo esc_attr( $fo_t['order'] ); ?>" aria-label="<?php esc_attr_e( 'Order', 'fileora' ); ?>"></td>
							<td class="nowrap">
								<?php if ( $fo_t['post_id'] ) : ?>
									<a href="<?php echo esc_url( get_edit_post_link( $fo_t['post_id'] ) ); ?>"><?php esc_html_e( 'Edit page', 'fileora' ); ?></a>
									<?php if ( $fo_t['enabled'] ) : ?> · <a href="<?php echo esc_url( $fo_t['url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View', 'fileora' ); ?></a><?php endif; ?>
								<?php else : ?>
									<span class="fo-sub"><?php esc_html_e( 'No page', 'fileora' ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</section>
		<?php endforeach; ?>
		<p class="fo-sticky-save"><button class="button button-primary button-large"><?php esc_html_e( 'Save tools', 'fileora' ); ?></button></p>
	</form>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="fo-card">
		<h2><?php esc_html_e( 'Restore missing tool pages', 'fileora' ); ?></h2>
		<p><?php esc_html_e( 'Creates a page for every tool in the code that doesn’t have one (for example after an update that adds tools). Existing pages and your edits are left alone.', 'fileora' ); ?></p>
		<input type="hidden" name="action" value="fileora_sync_tools">
		<?php wp_nonce_field( 'fileora_sync_tools' ); ?>
		<button class="button"><?php esc_html_e( 'Restore missing pages', 'fileora' ); ?></button>
	</form>
</div>
