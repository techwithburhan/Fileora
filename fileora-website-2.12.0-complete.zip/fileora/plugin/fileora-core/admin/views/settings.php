<?php
/**
 * Fileora → Settings.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

$fo_s    = Fileora_Core_Settings::get();
$fo_name = Fileora_Core_Settings::OPTION;
$fo_last = Fileora_Server_Monitor::last();
$fo_php  = array(
	'upload_max_filesize' => wp_convert_hr_to_bytes( ini_get( 'upload_max_filesize' ) ),
	'post_max_size'       => wp_convert_hr_to_bytes( ini_get( 'post_max_size' ) ),
);
$fo_toggle = function ( $key, $label, $help = '' ) use ( $fo_s, $fo_name ) {
	echo '<label class="fo-check"><input type="checkbox" name="' . esc_attr( $fo_name . '[' . $key . ']' ) . '" value="1" ' . checked( ! empty( $fo_s[ $key ] ), true, false ) . '> ' . esc_html( $label ) . '</label>';
	if ( $help ) {
		echo '<p class="description">' . esc_html( $help ) . '</p>';
	}
};
$fo_number = function ( $key, $suffix, $min, $max ) use ( $fo_s, $fo_name ) {
	echo '<input type="number" class="small-text" id="fo-' . esc_attr( $key ) . '" name="' . esc_attr( $fo_name . '[' . $key . ']' ) . '" value="' . esc_attr( $fo_s[ $key ] ) . '" min="' . esc_attr( $min ) . '" max="' . esc_attr( $max ) . '"> ' . esc_html( $suffix );
};
?>
<div class="wrap fo-wrap">
	<h1><?php esc_html_e( 'Fileora Settings', 'fileora' ); ?></h1>
	<?php settings_errors(); ?>
	<?php if ( isset( $_GET['checked'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-info is-dismissible"><p><?php echo $fo_last && $fo_last['ok'] && false !== $fo_last['auth'] ? esc_html__( 'Connection works: the server answered and accepted the shared key.', 'fileora' ) : esc_html( sprintf( __( 'Connection failed: %s', 'fileora' ), $fo_last ? $fo_last['error'] : '' ) ); ?></p></div>
	<?php endif; ?>

	<form method="post" action="options.php" class="fo-settings">
		<?php settings_fields( 'fileora_core' ); ?>

		<section class="fo-card">
			<h2><?php esc_html_e( 'Processing server', 'fileora' ); ?></h2>
			<p class="description"><?php esc_html_e( 'The server that runs the server tools (Word to PDF, OCR, Unlock, …). Visitors never talk to it directly: WordPress forwards their files using the shared key.', 'fileora' ); ?></p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="fo-url"><?php esc_html_e( 'Server address', 'fileora' ); ?></label></th>
					<td>
						<input type="url" class="regular-text code" id="fo-url" name="<?php echo esc_attr( $fo_name ); ?>[service_url]" value="<?php echo esc_attr( $fo_s['service_url'] ); ?>">
						<p class="description"><?php esc_html_e( 'Same server as WordPress: http://127.0.0.1:8000. WordPress on another host (e.g. Hostinger) and the service on a VPS/EC2: https://api.your-domain.com through Nginx with HTTPS (README, sections 7 and 8). Never open port 8000 to the internet.', 'fileora' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="fo-key"><?php esc_html_e( 'Shared key', 'fileora' ); ?></label></th>
					<td>
						<input type="text" class="large-text code" id="fo-key" name="<?php echo esc_attr( $fo_name ); ?>[service_key]" value="<?php echo esc_attr( $fo_s['service_key'] ); ?>" autocomplete="off" spellcheck="false">
						<p class="description"><?php esc_html_e( 'Must equal FILEORA_KEY in /etc/fileora/fileora.env on the server. Keep it secret: don’t share it in chats, screenshots or code repositories.', 'fileora' ); ?></p>
						<label class="fo-check"><input type="checkbox" name="<?php echo esc_attr( $fo_name ); ?>[new_key]" value="1"> <?php esc_html_e( 'Generate a new key on save (then copy it to the server and restart the service)', 'fileora' ); ?></label>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="fo-interval"><?php esc_html_e( 'Monitoring interval', 'fileora' ); ?></label></th>
					<td>
						<select id="fo-interval" name="<?php echo esc_attr( $fo_name ); ?>[monitor_interval]">
							<?php foreach ( array( 5, 10, 15, 30, 60 ) as $fo_m ) : ?>
								<option value="<?php echo esc_attr( $fo_m ); ?>" <?php selected( (int) $fo_s['monitor_interval'], $fo_m ); ?>><?php echo esc_html( sprintf( __( 'Every %d minutes', 'fileora' ), $fo_m ) ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'How often WordPress runs a health check for Server Monitoring.', 'fileora' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="fo-probe"><?php esc_html_e( 'Monitoring method', 'fileora' ); ?></label></th>
					<td>
						<select id="fo-probe" name="<?php echo esc_attr( $fo_name ); ?>[probe_method]">
							<option value="auto" <?php selected( $fo_s['probe_method'], 'auto' ); ?>><?php esc_html_e( 'Automatic: ICMP ping, TCP if ping isn’t possible', 'fileora' ); ?></option>
							<option value="icmp" <?php selected( $fo_s['probe_method'], 'icmp' ); ?>><?php esc_html_e( 'ICMP ping only', 'fileora' ); ?></option>
							<option value="tcp" <?php selected( $fo_s['probe_method'], 'tcp' ); ?>><?php esc_html_e( 'TCP connect to the HTTPS port', 'fileora' ); ?></option>
							<option value="http" <?php selected( $fo_s['probe_method'], 'http' ); ?>><?php esc_html_e( 'HTTP /health response time only', 'fileora' ); ?></option>
						</select>
						<label for="fo-probe-count" class="fo-inline-label"><?php esc_html_e( 'Packets per check', 'fileora' ); ?></label>
						<input type="number" id="fo-probe-count" class="small-text" min="1" max="10" name="<?php echo esc_attr( $fo_name ); ?>[probe_count]" value="<?php echo esc_attr( (int) $fo_s['probe_count'] ); ?>">
						<p class="description">
							<?php
							echo esc_html(
								Fileora_Net_Probe::icmp_available()
									? __( 'This web host can run ping. The EC2 security group must allow inbound ICMP (Echo Request) from the web host, otherwise the TCP check is used and labelled as such.', 'fileora' )
									: __( 'PHP on this web host can’t run ping (exec() is disabled or there is no ping program), so Automatic uses the TCP check, labelled as such on Server Monitoring.', 'fileora' )
							);
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="fo-probe-host"><?php esc_html_e( 'Address to probe', 'fileora' ); ?></label></th>
					<td>
						<input type="text" class="regular-text code" id="fo-probe-host" name="<?php echo esc_attr( $fo_name ); ?>[probe_host]" value="<?php echo esc_attr( $fo_s['probe_host'] ); ?>" placeholder="<?php echo esc_attr( wp_parse_url( (string) $fo_s['service_url'], PHP_URL_HOST ) ); ?>" spellcheck="false">
						<p class="description"><?php esc_html_e( 'Leave empty to use the host of the server address. A host name or IP address only.', 'fileora' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Connection', 'fileora' ); ?></th>
					<td>
						<?php
						if ( $fo_last ) {
							$fo_good = $fo_last['ok'] && false !== $fo_last['auth'];
							echo fo_admin_status( $fo_good ? 'good' : 'critical', $fo_good ? __( 'Working', 'fileora' ) : ( $fo_last['error'] ? $fo_last['error'] : __( 'Not reachable', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							echo ' <span class="fo-sub">' . esc_html( sprintf( __( 'checked %s ago', 'fileora' ), human_time_diff( $fo_last['time'] ) ) ) . '</span>';
						} else {
							echo fo_admin_status( 'unknown', __( 'Not checked yet', 'fileora' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						}
						?>
						<p class="description"><?php esc_html_e( 'Save first, then test the connection with the button below the form.', 'fileora' ); ?></p>
					</td>
				</tr>
			</table>
		</section>

		<section class="fo-card">
			<h2><?php esc_html_e( 'Limits', 'fileora' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="fo-max_mb"><?php esc_html_e( 'Max file size', 'fileora' ); ?></label></th>
					<td>
						<?php $fo_number( 'max_mb', __( 'MB per file', 'fileora' ), 1, 2048 ); ?>
						<?php if ( $fo_php['upload_max_filesize'] < (int) $fo_s['max_mb'] * MB_IN_BYTES || $fo_php['post_max_size'] < (int) $fo_s['max_mb'] * MB_IN_BYTES ) : ?>
							<p class="fo-warn"><?php echo esc_html( sprintf( __( 'This web server accepts only %1$s per file and %2$s per request (PHP upload_max_filesize and post_max_size). Raise them, or server tools will fail for bigger files. On Hostinger: hPanel → Websites → Manage → PHP Configuration → PHP Options.', 'fileora' ), size_format( $fo_php['upload_max_filesize'] ), size_format( $fo_php['post_max_size'] ) ) ); ?></p>
						<?php endif; ?>
						<p class="description"><?php esc_html_e( 'Browser tools are limited only by the visitor’s device; this limit applies to uploads to the server and is shown in the tools. Developers can raise it per user with the fileora_max_mb filter.', 'fileora' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="fo-max_files"><?php esc_html_e( 'Max files', 'fileora' ); ?></label></th>
					<td><?php $fo_number( 'max_files', __( 'per server task', 'fileora' ), 1, 100 ); ?></td>
				</tr>
				<tr>
					<th scope="row"><label for="fo-daily_limit"><?php esc_html_e( 'Server tasks', 'fileora' ); ?></label></th>
					<td>
						<?php $fo_number( 'daily_limit', __( 'per visitor in 24 hours', 'fileora' ), 0, 100000 ); ?>
						<p class="description"><?php esc_html_e( '0 means no limit. Browser tools are never limited, administrators are never limited, and tasks that failed because of the server don’t count. Developers can change it per user with the fileora_daily_limit filter.', 'fileora' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="fo-deletion"><?php esc_html_e( 'Deletion promise', 'fileora' ); ?></label></th>
					<td>
						<input type="text" class="regular-text" id="fo-deletion" name="<?php echo esc_attr( $fo_name ); ?>[deletion_text]" value="<?php echo esc_attr( $fo_s['deletion_text'] ); ?>">
						<p class="description"><?php esc_html_e( 'Shown to visitors, e.g. “Files are deleted within 1 hour”. Keep it true: the server deletes files after download and after FILEORA_TTL_MIN (60 minutes by default).', 'fileora' ); ?></p>
					</td>
				</tr>
			</table>
		</section>

		<section class="fo-card" id="analytics">
			<h2><?php esc_html_e( 'Visitor analytics', 'fileora' ); ?></h2>
			<p class="description"><?php esc_html_e( 'First-party statistics stored in your WordPress database: no cookies and no third-party analytics service. Describe what you record in your Privacy Policy; the [fileora_privacy_facts] shortcode lists it automatically from these settings.', 'fileora' ); ?></p>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'Recording', 'fileora' ); ?></th><td>
					<?php $fo_toggle( 'analytics', __( 'Record visits, page views and tool runs', 'fileora' ) ); ?>
					<?php $fo_toggle( 'respect_dnt', __( 'Skip visitors who send “Do Not Track” or “Global Privacy Control”', 'fileora' ) ); ?>
					<?php $fo_toggle( 'exclude_admins', __( 'Don’t count administrators', 'fileora' ) ); ?>
					<?php $fo_toggle( 'record_file_names', __( 'Record file names in tool runs (never file contents)', 'fileora' ), __( 'Shown in “Latest file processing”. File names can contain personal information (e.g. a person’s name); switch this off if you don’t need them.', 'fileora' ) ); ?>
				</td></tr>
				<tr><th scope="row"><label for="fo-ip_mode"><?php esc_html_e( 'IP addresses', 'fileora' ); ?></label></th><td>
					<select id="fo-ip_mode" name="<?php echo esc_attr( $fo_name ); ?>[ip_mode]">
						<option value="full" <?php selected( $fo_s['ip_mode'], 'full' ); ?>><?php esc_html_e( 'Store the full IP address', 'fileora' ); ?></option>
						<option value="anon" <?php selected( $fo_s['ip_mode'], 'anon' ); ?>><?php esc_html_e( 'Store a shortened IP address (last part removed)', 'fileora' ); ?></option>
						<option value="none" <?php selected( $fo_s['ip_mode'], 'none' ); ?>><?php esc_html_e( 'Don’t store IP addresses', 'fileora' ); ?></option>
					</select>
					<p><?php $fo_number( 'ip_retention', __( 'days, then stored IP addresses are erased (the rest of the record stays)', 'fileora' ), 1, 365 ); ?></p>
					<p class="description"><?php esc_html_e( 'Only administrators see IP addresses (and Support users, if allowed below). The location is looked up when the visit starts, so it works even when IP addresses are not stored.', 'fileora' ); ?></p>
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'After logging in', 'fileora' ); ?></th><td>
					<?php $fo_toggle( 'login_to_analytics', __( 'Open Visitor Analytics for users who can see reports', 'fileora' ) ); ?>
				</td></tr>
			</table>
		</section>

		<section class="fo-card" id="geo">
			<h2><?php esc_html_e( 'Visitor location', 'fileora' ); ?></h2>
			<?php $fo_geo = Fileora_Geo::db_info(); ?>
			<p class="description"><?php esc_html_e( 'Country, state and city are worked out on your own server from the visitor’s IP address, using a location database file. No outside service is asked.', 'fileora' ); ?></p>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="fo-geo_source"><?php esc_html_e( 'Source', 'fileora' ); ?></label></th><td>
					<select id="fo-geo_source" name="<?php echo esc_attr( $fo_name ); ?>[geo_source]">
						<option value="auto" <?php selected( $fo_s['geo_source'], 'auto' ); ?>><?php esc_html_e( 'Automatic: location database, otherwise Cloudflare’s country header', 'fileora' ); ?></option>
						<option value="database" <?php selected( $fo_s['geo_source'], 'database' ); ?>><?php esc_html_e( 'Location database only', 'fileora' ); ?></option>
						<option value="cloudflare" <?php selected( $fo_s['geo_source'], 'cloudflare' ); ?>><?php esc_html_e( 'Cloudflare headers only (site runs behind Cloudflare)', 'fileora' ); ?></option>
						<option value="off" <?php selected( $fo_s['geo_source'], 'off' ); ?>><?php esc_html_e( 'Off: don’t record locations', 'fileora' ); ?></option>
					</select>
				</td></tr>
				<tr><th scope="row"><label for="fo-ip_source"><?php esc_html_e( 'Visitor IP address comes from', 'fileora' ); ?></label></th><td>
					<select id="fo-ip_source" name="<?php echo esc_attr( $fo_name ); ?>[ip_source]">
						<option value="auto" <?php selected( $fo_s['ip_source'], 'auto' ); ?>><?php esc_html_e( 'Automatic (recommended)', 'fileora' ); ?></option>
						<option value="remote" <?php selected( $fo_s['ip_source'], 'remote' ); ?>><?php esc_html_e( 'The connection itself (REMOTE_ADDR)', 'fileora' ); ?></option>
						<option value="cloudflare" <?php selected( $fo_s['ip_source'], 'cloudflare' ); ?>><?php esc_html_e( 'Cloudflare (CF-Connecting-IP)', 'fileora' ); ?></option>
						<option value="forwarded" <?php selected( $fo_s['ip_source'], 'forwarded' ); ?>><?php esc_html_e( 'A proxy or CDN in front of the site (X-Forwarded-For)', 'fileora' ); ?></option>
						<option value="real" <?php selected( $fo_s['ip_source'], 'real' ); ?>><?php esc_html_e( 'X-Real-IP header', 'fileora' ); ?></option>
					</select>
					<p class="description"><?php esc_html_e( 'If every visitor shows the same location (your host’s or CDN’s), the site sits behind a proxy: see “Location check” below and pick the header that shows your real IP. Only choose a header option when a proxy or CDN really is in front of the site, because anyone can fake these headers otherwise.', 'fileora' ); ?></p>
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Database', 'fileora' ); ?></th><td>
					<?php if ( $fo_geo ) : ?>
						<p><strong><?php echo esc_html( $fo_geo['file'] ); ?></strong> · <?php echo esc_html( size_format( $fo_geo['size'] ) ); ?> · <?php echo esc_html( sprintf( /* translators: %s: date */ __( 'built %s', 'fileora' ), wp_date( get_option( 'date_format' ), (int) $fo_geo['date'] ) ) ); ?><?php echo $fo_geo['type'] ? ' · ' . esc_html( $fo_geo['type'] ) : ''; ?></p>
						<?php if ( $fo_geo['dbip'] ) : ?><p class="description"><?php echo wp_kses_post( __( 'Updated automatically every month. <a href="https://db-ip.com" target="_blank" rel="noopener">IP Geolocation by DB-IP</a>, licensed under CC BY 4.0.', 'fileora' ) ); ?></p><?php endif; ?>
					<?php else : ?>
						<p><?php esc_html_e( 'No database installed. Without it, only visits that come through Cloudflare get a country.', 'fileora' ); ?></p>
					<?php endif; ?>
					<p class="description"><?php echo esc_html( sprintf( /* translators: %s: folder */ __( 'Download the free DB-IP City Lite database below (about 60 MB download, 130 MB on disk), or upload a MaxMind GeoLite2-City or GeoIP2-City .mmdb file to %s.', 'fileora' ), str_replace( ABSPATH, '', Fileora_Geo::dir() ) ) ); ?></p>
				</td></tr>
			</table>
		</section>

		<section class="fo-card" id="retention">
			<h2><?php esc_html_e( 'Data retention', 'fileora' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="fo-event_retention"><?php esc_html_e( 'Visits and visitor events', 'fileora' ); ?></label></th><td><?php $fo_number( 'event_retention', __( 'days', 'fileora' ), 0, 3650 ); ?><p class="description"><?php esc_html_e( 'At least 90 days. 0 = keep forever (nothing is deleted automatically).', 'fileora' ); ?></p></td></tr>
				<tr><th scope="row"><label for="fo-task_retention"><?php esc_html_e( 'Processing task records', 'fileora' ); ?></label></th><td><?php $fo_number( 'task_retention', __( 'days', 'fileora' ), 0, 3650 ); ?><p class="description"><?php esc_html_e( 'At least 90 days. 0 = keep forever.', 'fileora' ); ?></p></td></tr>
				<tr><th scope="row"><label for="fo-message_retention"><?php esc_html_e( 'Contact form messages', 'fileora' ); ?></label></th><td><?php $fo_number( 'message_retention', __( 'days (30 to 730)', 'fileora' ), 30, 730 ); ?></td></tr>
				<tr><th scope="row"><label for="fo-contact_email"><?php esc_html_e( 'Send contact messages to', 'fileora' ); ?></label></th><td><input type="email" class="regular-text" id="fo-contact_email" name="<?php echo esc_attr( $fo_name . '[contact_email]' ); ?>" value="<?php echo esc_attr( $fo_s['contact_email'] ); ?>" placeholder="<?php echo esc_attr( Fileora_Contact::recipient() ); ?>"><p class="description"><?php esc_html_e( 'Empty = the privacy contact email, else the site’s admin email. Messages are also kept under Fileora → Messages, so none are lost if email fails.', 'fileora' ); ?></p></td></tr>
				<tr><th scope="row"><label for="fo-health_retention"><?php esc_html_e( 'Health checks', 'fileora' ); ?></label></th><td><?php $fo_number( 'health_retention', __( 'days (at least 30)', 'fileora' ), 30, 730 ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'When the plugin is deleted', 'fileora' ); ?></th><td><?php $fo_toggle( 'delete_data', __( 'Delete all Fileora data when the plugin is deleted', 'fileora' ), __( 'Off (recommended): analytics history, task records and settings stay in the database, so you can delete the plugin and upload a new version without losing anything.', 'fileora' ) ); ?></td></tr>
			</table>
			<p class="description"><?php esc_html_e( 'Older detailed records are deleted once a day. Before that, daily totals (counts per day and per tool, without visitor IDs, locations or IP addresses) are saved and kept, so long-term charts stay available. IP addresses are erased earlier, as set under Visitor analytics. Records never contain file contents or passwords. Your Privacy Policy and Security pages show these periods automatically.', 'fileora' ); ?></p>
		</section>

		<section class="fo-card" id="privacy">
			<h2><?php esc_html_e( 'Privacy and Security pages', 'fileora' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Used by the [fileora_privacy] shortcode on your Privacy Policy and Security pages. Leave empty to use general wording.', 'fileora' ); ?></p>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="fo-privacy_email"><?php esc_html_e( 'Privacy contact email', 'fileora' ); ?></label></th><td><input type="email" class="regular-text" id="fo-privacy_email" name="<?php echo esc_attr( $fo_name ); ?>[privacy_email]" value="<?php echo esc_attr( $fo_s['privacy_email'] ); ?>" placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>"></td></tr>
				<tr><th scope="row"><label for="fo-host_web"><?php esc_html_e( 'Website hosting', 'fileora' ); ?></label></th><td><input type="text" class="regular-text" id="fo-host_web" name="<?php echo esc_attr( $fo_name ); ?>[host_web]" value="<?php echo esc_attr( $fo_s['host_web'] ); ?>" placeholder="<?php esc_attr_e( 'e.g. Hostinger (India)', 'fileora' ); ?>"></td></tr>
				<tr><th scope="row"><label for="fo-host_server"><?php esc_html_e( 'Processing server', 'fileora' ); ?></label></th><td><input type="text" class="regular-text" id="fo-host_server" name="<?php echo esc_attr( $fo_name ); ?>[host_server]" value="<?php echo esc_attr( $fo_s['host_server'] ); ?>" placeholder="<?php esc_attr_e( 'e.g. Amazon Web Services, United States', 'fileora' ); ?>"><p class="description"><?php esc_html_e( 'Name the provider and country: visitors should know where their files are processed.', 'fileora' ); ?></p></td></tr>
			</table>
		</section>

		<section class="fo-card">
			<h2><?php esc_html_e( 'Blog Editor role', 'fileora' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Give this role (Users → Add New → Role: Blog Editor) to people who write blog posts. They can never change tools, settings, plugins, themes or users.', 'fileora' ); ?></p>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'Blog Editors can', 'fileora' ); ?></th><td>
					<?php $fo_toggle( 'editor_publish', __( 'Publish posts (otherwise they submit drafts for review)', 'fileora' ) ); ?>
					<?php $fo_toggle( 'editor_others', __( 'Edit posts written by others', 'fileora' ) ); ?>
					<?php $fo_toggle( 'editor_delete', __( 'Delete posts', 'fileora' ) ); ?>
					<?php $fo_toggle( 'editor_reports', __( 'See the Dashboard, Visitor Analytics, Server Monitoring and Processing Tasks', 'fileora' ) ); ?>
				</td></tr>
			</table>
		</section>

		<section class="fo-card" id="support-role">
			<h2><?php esc_html_e( 'Support role', 'fileora' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Support users can open Visitor Analytics, the Fileora Dashboard, Server Monitoring and Processing Tasks, and change their own password. They can’t change settings, tools, plugins, themes, posts or users.', 'fileora' ); ?></p>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'Support users can', 'fileora' ); ?></th><td>
					<?php $fo_toggle( 'support_ip', __( 'See visitors’ IP addresses', 'fileora' ) ); ?>
				</td></tr>
			</table>
		</section>

		<?php submit_button( __( 'Save settings', 'fileora' ) ); ?>
	</form>

	<section class="fo-card" id="geo-actions">
		<h2><?php esc_html_e( 'Location database and check', 'fileora' ); ?></h2>
		<?php
		$fo_gs   = Fileora_Geo::status();
		$fo_diag = Fileora_Geo::diagnose();
		if ( isset( $_GET['fo_geo'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$fo_msg = array(
				'deleted'  => __( 'The location database was removed.', 'fileora' ),
				'uploaded' => __( 'The database was installed and missing locations were filled in.', 'fileora' ),
				/* translators: %d: number of visits */
				'filled'   => sprintf( __( 'Locations filled in for %d visits.', 'fileora' ), isset( $_GET['fo_n'] ) ? absint( $_GET['fo_n'] ) : 0 ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			);
			$fo_k   = sanitize_key( wp_unslash( $_GET['fo_geo'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			?>
			<div class="notice notice-success inline"><p><?php echo esc_html( isset( $fo_msg[ $fo_k ] ) ? $fo_msg[ $fo_k ] : __( 'Done.', 'fileora' ) ); ?></p></div>
		<?php elseif ( isset( $_GET['fo_geo_error'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-error inline"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['fo_geo_error'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
		<?php endif; ?>
		<?php if ( ! empty( $fo_gs['state'] ) && ( 'running' === $fo_gs['state'] || ( 'error' === $fo_gs['state'] && time() - (int) $fo_gs['time'] < DAY_IN_SECONDS ) ) ) : ?>
			<div class="notice <?php echo 'error' === $fo_gs['state'] ? 'notice-error' : 'notice-info'; ?> inline"><p>
				<?php
				if ( 'running' === $fo_gs['state'] ) {
					echo esc_html( time() - (int) $fo_gs['time'] > 15 * MINUTE_IN_SECONDS ? __( 'The background download has not finished after 15 minutes. Background tasks may not run on this host: use “Download now (wait)” or upload the file below.', 'fileora' ) : __( 'Downloading in the background… reload this page in a minute or two.', 'fileora' ) );
				} else {
					/* translators: %s: error */
					echo esc_html( sprintf( __( 'The last download failed: %s. Try “Download now (wait)”, or download the file on your computer from db-ip.com/db/lite.php and upload it below.', 'fileora' ), $fo_gs['message'] ) );
				}
				?>
			</p></div>
		<?php endif; ?>

		<h3><?php esc_html_e( '1. Install a database', 'fileora' ); ?></h3>
		<p><?php echo $fo_diag['db'] ? esc_html( sprintf( /* translators: %s: file */ __( 'In use: %s.', 'fileora' ), $fo_diag['db']['file'] ) ) : '<strong>' . esc_html__( 'No database installed yet: this is why locations show “Unknown”.', 'fileora' ) . '</strong>'; ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="fo-inline-form">
			<input type="hidden" name="action" value="fileora_geo_download">
			<?php wp_nonce_field( 'fileora_geo_download' ); ?>
			<select name="edition" aria-label="<?php esc_attr_e( 'Database', 'fileora' ); ?>">
				<option value="city"><?php esc_html_e( 'City Lite: country, state and city (about 60 MB download)', 'fileora' ); ?></option>
				<option value="country"><?php esc_html_e( 'Country Lite: country only (about 4 MB)', 'fileora' ); ?></option>
			</select>
			<button class="button button-primary"><?php esc_html_e( 'Download in the background', 'fileora' ); ?></button>
			<button class="button" name="now" value="1"><?php esc_html_e( 'Download now (wait)', 'fileora' ); ?></button>
		</form>
		<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="fo-inline-form">
			<input type="hidden" name="action" value="fileora_geo_upload">
			<?php wp_nonce_field( 'fileora_geo_upload' ); ?>
			<label><?php esc_html_e( 'Or upload', 'fileora' ); ?> <input type="file" name="geo_file" accept=".mmdb,.gz"></label>
			<button class="button"><?php esc_html_e( 'Upload and use', 'fileora' ); ?></button>
		</form>
		<p class="description"><?php echo wp_kses_post( __( 'Upload a DB-IP Lite file (<a href="https://db-ip.com/db/lite.php" target="_blank" rel="noopener">db-ip.com/db/lite.php</a>, “IP to City Lite”, MMDB format) or MaxMind GeoLite2-City.mmdb, as .mmdb or .mmdb.gz. If the file is bigger than your PHP upload limit, upload it with the hPanel File Manager to wp-content/uploads/fileora-geo/ instead. DB-IP data is licensed CC BY 4.0 (IP Geolocation by DB-IP).', 'fileora' ) ); ?></p>
		<?php if ( $fo_diag['db'] ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="fo-inline-form">
				<input type="hidden" name="action" value="fileora_geo_delete">
				<?php wp_nonce_field( 'fileora_geo_delete' ); ?>
				<button class="button-link"><?php esc_html_e( 'Remove the database', 'fileora' ); ?></button>
			</form>
		<?php endif; ?>

		<h3><?php esc_html_e( '2. Location check (your own visit)', 'fileora' ); ?></h3>
		<table class="widefat striped fo-table" style="max-width:760px">
			<tbody>
				<?php foreach ( $fo_diag['candidates'] as $fo_h => $fo_v ) : ?>
					<tr><th scope="row" style="width:220px"><code><?php echo esc_html( $fo_h ); ?></code></th><td><?php echo '' === $fo_v ? '<span class="fo-muted">' . esc_html__( 'not sent', 'fileora' ) . '</span>' : '<code>' . esc_html( $fo_v ) . '</code>'; ?></td></tr>
				<?php endforeach; ?>
				<tr><th scope="row"><?php esc_html_e( 'IP address Fileora uses', 'fileora' ); ?></th><td><code><?php echo esc_html( $fo_diag['ip'] ); ?></code> <?php echo $fo_diag['public'] ? '' : '<strong class="fo-bad">' . esc_html__( 'private or local address: no location possible', 'fileora' ) . '</strong>'; ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Location found', 'fileora' ); ?></th><td><strong><?php echo esc_html( $fo_diag['result']['country'] ? Fileora_Geo::label( $fo_diag['result']['country'], $fo_diag['result']['region'], $fo_diag['result']['city'] ) : __( 'Unknown', 'fileora' ) ); ?></strong></td></tr>
			</tbody>
		</table>
		<p class="description">
			<?php
			if ( ! $fo_diag['db'] ) {
				esc_html_e( 'Install a database first (step 1).', 'fileora' );
			} elseif ( ! $fo_diag['public'] ) {
				esc_html_e( 'The site receives a private address, so it is behind a proxy. Choose the header that shows your real public IP in “Visitor IP address comes from” above, and save.', 'fileora' );
			} elseif ( ! $fo_diag['result']['country'] ) {
				esc_html_e( 'The database has no entry for this address. Try the City Lite database.', 'fileora' );
			} else {
				esc_html_e( 'Location works. If this is not your location, the site is behind a proxy or CDN: compare the headers above with your real IP (search “what is my IP”) and choose that header above.', 'fileora' );
			}
			?>
		</p>

		<h3><?php esc_html_e( '3. Fill in old visits', 'fileora' ); ?></h3>
		<p><?php echo esc_html( sprintf( /* translators: %d: number */ __( '%d visits have an IP address but no location (recorded before the database was installed). They are filled in automatically every hour, or now:', 'fileora' ), (int) $fo_diag['missing'] ) ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="fo-inline-form">
			<input type="hidden" name="action" value="fileora_geo_backfill">
			<?php wp_nonce_field( 'fileora_geo_backfill' ); ?>
			<button class="button" <?php disabled( ! $fo_diag['db'] || ! $fo_diag['missing'] ); ?>><?php esc_html_e( 'Fill in locations now', 'fileora' ); ?></button>
		</form>
		<p class="description"><?php esc_html_e( 'Visits recorded while IP addresses were not stored can’t be filled in later. Your own visits as an administrator are not counted at all (Settings → Don’t count administrators), so test with a phone on mobile data or a private window that is not logged in.', 'fileora' ); ?></p>
	</section>

	<?php $fo_st = Fileora_History::storage(); ?>
	<section class="fo-card" id="storage">
		<h2><?php esc_html_e( 'Analytics storage', 'fileora' ); ?></h2>
		<table class="widefat striped fo-storage">
			<thead><tr><th><?php esc_html_e( 'Records', 'fileora' ); ?></th><th><?php esc_html_e( 'Database table', 'fileora' ); ?></th><th class="num"><?php esc_html_e( 'Rows', 'fileora' ); ?></th><th class="num"><?php esc_html_e( 'Size', 'fileora' ); ?></th></tr></thead>
			<tbody>
			<?php
			$fo_lbl = array(
				'events'   => __( 'Events (page views, tool runs, “still here”)', 'fileora' ),
				'sessions' => __( 'Visits', 'fileora' ),
				'tasks'    => __( 'Server processing tasks', 'fileora' ),
				'daily'    => __( 'Daily totals', 'fileora' ),
				'tools'    => __( 'Daily totals per tool', 'fileora' ),
			);
			foreach ( $fo_st['tables'] as $fo_k => $fo_t ) :
				?>
				<tr><td><?php echo esc_html( $fo_lbl[ $fo_k ] ); ?></td><td><code><?php echo esc_html( $fo_t['table'] ); ?></code></td><td class="num"><?php echo esc_html( number_format_i18n( $fo_t['rows'] ) ); ?></td><td class="num"><?php echo esc_html( size_format( $fo_t['bytes'], 1 ) ); ?></td></tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p>
			<?php
			echo esc_html(
				$fo_st['oldest']
					? sprintf( /* translators: 1: date, 2: date */ __( 'Detailed records from %1$s. Daily totals from %2$s.', 'fileora' ), wp_date( get_option( 'date_format' ), $fo_st['oldest'] ), $fo_st['first_day'] ? mysql2date( get_option( 'date_format' ), $fo_st['first_day'] ) : '—' )
					: __( 'No visits recorded yet.', 'fileora' )
			);
			?>
		</p>
		<?php $fo_err = is_array( $fo_st['errors'] ) ? $fo_st['errors'] : array(); ?>
		<?php if ( ! empty( $fo_err['count'] ) ) : ?>
			<div class="notice notice-warning inline"><p><?php echo esc_html( sprintf( /* translators: 1: number, 2: date */ __( '%1$s database errors while saving analytics (latest %2$s). Details are in the PHP error log. If this keeps happening, check the database space in hPanel.', 'fileora' ), number_format_i18n( (int) $fo_err['count'] ), isset( $fo_err['last'] ) ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $fo_err['last'] ) : '' ) ); ?></p>
			<?php if ( ! empty( $fo_err['items'] ) ) : ?>
				<ul class="fo-muted"><?php foreach ( array_slice( $fo_err['items'], 0, 5 ) as $fo_i ) : ?><li><?php echo esc_html( wp_date( 'Y-m-d H:i', (int) $fo_i[0] ) . ' · ' . $fo_i[1] . ' · ' . $fo_i[2] ); ?></li><?php endforeach; ?></ul>
			<?php endif; ?>
			</div>
		<?php else : ?>
			<p class="fo-muted"><?php esc_html_e( 'No database errors while saving analytics.', 'fileora' ); ?></p>
		<?php endif; ?>
		<?php if ( ! empty( $fo_st['exports'] ) ) : ?>
			<h3><?php esc_html_e( 'Recent exports', 'fileora' ); ?></h3>
			<ul>
			<?php
			foreach ( array_slice( (array) $fo_st['exports'], 0, 10 ) as $fo_x ) :
				$fo_u = get_userdata( (int) $fo_x['user'] );
				?>
				<li><?php echo esc_html( sprintf( /* translators: 1: date, 2: user, 3: data set, 4: rows, 5: period start, 6: period end */ __( '%1$s · %2$s exported %3$s (%4$s rows, %5$s – %6$s)', 'fileora' ), wp_date( 'Y-m-d H:i', (int) $fo_x['at'] ), $fo_u ? $fo_u->user_login : '#' . (int) $fo_x['user'], $fo_x['dataset'], number_format_i18n( (int) $fo_x['rows'] ), wp_date( 'Y-m-d', (int) $fo_x['from'] ), wp_date( 'Y-m-d', (int) $fo_x['to'] - 1 ) ) . ( ! empty( $fo_x['ip'] ) ? ' · ' . __( 'with IP addresses', 'fileora' ) : '' ) ); ?></li>
			<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</section>

	<section class="fo-card" id="support">
		<h2><?php esc_html_e( 'Support account', 'fileora' ); ?></h2>
		<?php if ( isset( $_GET['fo_support_created'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success inline"><p><?php esc_html_e( 'The Support user was created. Give them the username and initial password through a private channel; they will be asked to choose a new password at first login.', 'fileora' ); ?></p></div>
		<?php elseif ( isset( $_GET['fo_support_error'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-error inline"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['fo_support_error'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
		<?php endif; ?>
		<?php $fo_sup = Fileora_Support::users(); ?>
		<?php if ( $fo_sup ) : ?>
			<p><?php esc_html_e( 'Users with the Support role:', 'fileora' ); ?>
				<?php
				echo implode( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					', ',
					array_map(
						function ( $u ) {
							$must = get_user_meta( $u->ID, Fileora_Support::MUST_CHANGE, true );
							return '<a href="' . esc_url( get_edit_user_link( $u->ID ) ) . '">' . esc_html( $u->display_name . ' (' . $u->user_login . ')' ) . '</a>' . ( $must ? ' <em>' . esc_html__( 'initial password not changed yet', 'fileora' ) . '</em>' : '' );
						},
						$fo_sup
					)
				);
				?>
			</p>
		<?php endif; ?>
		<?php if ( current_user_can( 'create_users' ) ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" autocomplete="off">
				<input type="hidden" name="action" value="fileora_create_support">
				<?php wp_nonce_field( 'fileora_create_support' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="fo-sup-login"><?php esc_html_e( 'Username', 'fileora' ); ?></label></th><td><input type="text" id="fo-sup-login" name="support_login" value="Support" class="regular-text" autocomplete="off"></td></tr>
					<tr><th scope="row"><label for="fo-sup-name"><?php esc_html_e( 'Display name', 'fileora' ); ?></label></th><td><input type="text" id="fo-sup-name" name="support_name" value="Support" class="regular-text"></td></tr>
					<tr><th scope="row"><label for="fo-sup-email"><?php esc_html_e( 'Email', 'fileora' ); ?></label></th><td><input type="email" id="fo-sup-email" name="support_email" class="regular-text" required><p class="description"><?php esc_html_e( 'Required: WordPress needs it to save the new password, and for “Lost your password?”.', 'fileora' ); ?></p></td></tr>
					<tr><th scope="row"><label for="fo-sup-pass"><?php esc_html_e( 'Initial password', 'fileora' ); ?></label></th><td><input type="password" id="fo-sup-pass" name="support_pass" class="regular-text" autocomplete="new-password" minlength="8" required><p class="description"><?php esc_html_e( 'Typed here once and handed to WordPress, which stores only a secure hash. It is not saved in settings or logs.', 'fileora' ); ?></p></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'First login', 'fileora' ); ?></th><td><label class="fo-check"><input type="checkbox" name="support_must_change" value="1" checked> <?php esc_html_e( 'Require a new password at first login', 'fileora' ); ?></label></td></tr>
				</table>
				<?php submit_button( __( 'Create Support user', 'fileora' ), 'secondary', 'submit', false ); ?>
			</form>
		<?php endif; ?>
	</section>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="fo-inline-form">
		<input type="hidden" name="action" value="fileora_check_now">
		<input type="hidden" name="back" value="settings">
		<?php wp_nonce_field( 'fileora_check_now' ); ?>
		<button class="button"><?php esc_html_e( 'Test the connection', 'fileora' ); ?></button>
	</form>
</div>
