<?php
/**
 * Fileora → Dashboard.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

$fo_days    = 30;
$fo_ev      = Fileora_Analytics::totals( $fo_days );
$fo_tasks   = Fileora_Task_Manager::totals( $fo_days );
$fo_up      = Fileora_Server_Monitor::uptime( $fo_days * DAY_IN_SECONDS );
$fo_last    = Fileora_Server_Monitor::last();
$fo_active  = Fileora_Analytics::active( 5 );
$fo_dates   = fo_admin_dates( $fo_days );
$fo_perday  = Fileora_Task_Manager::per_day( $fo_days );
$fo_byname  = array();
foreach ( Fileora_Task_Manager::by_tool( $fo_days ) as $fo_r ) {
	$fo_byname[ $fo_r->tool ] = array( 'server' => (int) $fo_r->total, 'browser' => 0, 'failed' => (int) $fo_r->failed );
}
foreach ( Fileora_Analytics::browser_runs_by_tool( $fo_days ) as $fo_id => $fo_v ) {
	if ( ! isset( $fo_byname[ $fo_id ] ) ) {
		$fo_byname[ $fo_id ] = array( 'server' => 0, 'browser' => 0, 'failed' => 0 );
	}
	$fo_byname[ $fo_id ]['browser'] = $fo_v[0];
	$fo_byname[ $fo_id ]['failed'] += $fo_v[1];
}
uasort(
	$fo_byname,
	function ( $a, $b ) {
		return ( $b['server'] + $b['browser'] ) <=> ( $a['server'] + $a['browser'] );
	}
);
$fo_byname = array_slice( $fo_byname, 0, 10, true );
$fo_fail   = Fileora_Task_Manager::recent_failures( 8 );

$fo_server_state = 'unknown';
$fo_server_label = __( 'No check yet', 'fileora' );
if ( ! Fileora_Core_Settings::backend_configured() ) {
	$fo_server_label = __( 'Not set up', 'fileora' );
} elseif ( $fo_last ) {
	if ( $fo_last['ok'] && false !== $fo_last['auth'] ) {
		$fo_server_state = 'good';
		$fo_server_label = __( 'Running', 'fileora' );
	} elseif ( $fo_last['ok'] ) {
		$fo_server_state = 'critical';
		$fo_server_label = __( 'Shared key rejected', 'fileora' );
	} else {
		$fo_server_state = 'critical';
		$fo_server_label = __( 'Not reachable', 'fileora' );
	}
}
?>
<div class="wrap fo-wrap">
	<h1><?php esc_html_e( 'Fileora Dashboard', 'fileora' ); ?></h1>
	<p class="fo-lead"><?php esc_html_e( 'The last 30 days. Visitor numbers come from anonymous page and tool events; server tasks come from the processing server’s task records. Browser tool runs never count as server tasks.', 'fileora' ); ?></p>

	<div class="fo-kpis">
		<?php
		fo_admin_kpi( __( 'Active now', 'fileora' ), fo_admin_num( $fo_active ), __( 'visitors in the last 5 minutes', 'fileora' ) );
		fo_admin_kpi( __( 'Tool runs', 'fileora' ), fo_admin_num( $fo_ev['browser_runs'] + $fo_tasks['total'] ), sprintf( __( '%1$s in browser · %2$s on server', 'fileora' ), fo_admin_num( $fo_ev['browser_runs'] ), fo_admin_num( $fo_tasks['total'] ) ) );
		fo_admin_kpi( __( 'Server tasks', 'fileora' ), fo_admin_num( $fo_tasks['done'] ) . ' / ' . fo_admin_num( $fo_tasks['failed'] ), __( 'completed / failed', 'fileora' ) );
		fo_admin_kpi( __( 'Task success rate', 'fileora' ), fo_admin_pct( null === $fo_tasks['rate'] ? null : $fo_tasks['rate'] * 100 ), __( 'of finished server tasks', 'fileora' ) );
		fo_admin_kpi( __( 'Average processing time', 'fileora' ), fo_admin_ms( $fo_tasks['avg_ms'] ), __( 'completed server tasks', 'fileora' ) );
		fo_admin_kpi( __( 'Server availability', 'fileora' ), fo_admin_pct( $fo_up['availability'], 2 ), sprintf( __( 'monitoring coverage %s', 'fileora' ), fo_admin_pct( $fo_up['coverage'] ) ), fo_admin_avail_state( $fo_up['availability'] ) );
		?>
	</div>

	<div class="fo-row">
		<section class="fo-card fo-grow">
			<h2><?php esc_html_e( 'Server tasks per day', 'fileora' ); ?></h2>
			<?php
			$fo_done = array();
			$fo_bad  = array();
			foreach ( $fo_perday as $fo_d => $fo_v ) {
				$fo_done[ $fo_d ] = $fo_v[0];
				$fo_bad[ $fo_d ]  = $fo_v[1];
			}
			if ( $fo_tasks['total'] ) {
				fo_admin_columns(
					$fo_dates,
					array(
						array( 'label' => __( 'Completed', 'fileora' ), 'class' => 's-good', 'values' => $fo_done ),
						array( 'label' => __( 'Failed', 'fileora' ), 'class' => 's-critical', 'values' => $fo_bad ),
					),
					__( 'Server tasks per day, last 30 days', 'fileora' )
				);
			} else {
				echo '<p class="fo-empty">' . esc_html__( 'No server tasks in the last 30 days yet.', 'fileora' ) . '</p>';
			}
			?>
		</section>
		<section class="fo-card fo-side">
			<h2><?php esc_html_e( 'Processing server', 'fileora' ); ?></h2>
			<p><?php echo fo_admin_status( $fo_server_state, $fo_server_label ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
			<?php if ( $fo_last ) : ?>
				<dl class="fo-dl">
					<dt><?php esc_html_e( 'Last check', 'fileora' ); ?></dt><dd><?php echo esc_html( sprintf( __( '%s ago', 'fileora' ), human_time_diff( $fo_last['time'] ) ) ); ?></dd>
					<dt><?php esc_html_e( 'Response time', 'fileora' ); ?></dt><dd><?php echo esc_html( fo_admin_ms( $fo_last['latency_ms'] ) ); ?></dd>
					<?php if ( ! empty( $fo_last['body']['tools'] ) ) : ?>
						<dt><?php esc_html_e( 'Tools available', 'fileora' ); ?></dt><dd><?php echo esc_html( count( array_filter( $fo_last['body']['tools'] ) ) . ' / ' . count( $fo_last['body']['tools'] ) ); ?></dd>
					<?php endif; ?>
					<?php if ( $fo_last['error'] ) : ?>
						<dt><?php esc_html_e( 'Problem', 'fileora' ); ?></dt><dd><?php echo esc_html( $fo_last['error'] ); ?></dd>
					<?php endif; ?>
				</dl>
			<?php endif; ?>
			<p><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=fileora-monitor' ) ); ?>"><?php esc_html_e( 'Server Monitoring', 'fileora' ); ?></a></p>
		</section>
	</div>

	<div class="fo-row">
		<section class="fo-card fo-grow">
			<h2><?php esc_html_e( 'Most-used tools', 'fileora' ); ?></h2>
			<?php if ( $fo_byname ) : ?>
				<table class="widefat striped fo-table">
					<thead><tr><th><?php esc_html_e( 'Tool', 'fileora' ); ?></th><th class="num"><?php esc_html_e( 'Browser runs', 'fileora' ); ?></th><th class="num"><?php esc_html_e( 'Server tasks', 'fileora' ); ?></th><th class="num"><?php esc_html_e( 'Failed', 'fileora' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $fo_byname as $fo_id => $fo_r ) : ?>
						<tr><td><?php echo esc_html( fo_admin_tool_name( $fo_id ) ); ?></td><td class="num"><?php echo esc_html( fo_admin_num( $fo_r['browser'] ) ); ?></td><td class="num"><?php echo esc_html( fo_admin_num( $fo_r['server'] ) ); ?></td><td class="num"><?php echo esc_html( fo_admin_num( $fo_r['failed'] ) ); ?></td></tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p class="fo-empty"><?php esc_html_e( 'No tool has been used yet.', 'fileora' ); ?></p>
			<?php endif; ?>
		</section>
		<section class="fo-card fo-grow">
			<h2><?php esc_html_e( 'Recent failures', 'fileora' ); ?></h2>
			<?php if ( $fo_fail ) : ?>
				<table class="widefat striped fo-table">
					<thead><tr><th><?php esc_html_e( 'When', 'fileora' ); ?></th><th><?php esc_html_e( 'Tool', 'fileora' ); ?></th><th><?php esc_html_e( 'Message shown to the visitor', 'fileora' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $fo_fail as $fo_f ) : ?>
						<tr><td class="nowrap"><?php echo esc_html( fo_admin_time( $fo_f->created_at ) ); ?></td><td><?php echo esc_html( fo_admin_tool_name( $fo_f->tool ) ); ?></td><td><?php echo esc_html( $fo_f->error ); ?><?php echo $fo_f->error_code ? ' <code>' . esc_html( $fo_f->error_code ) . '</code>' : ''; ?></td></tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=fileora-tasks&status=failed' ) ); ?>"><?php esc_html_e( 'All failed tasks', 'fileora' ); ?></a></p>
			<?php else : ?>
				<p class="fo-empty"><?php esc_html_e( 'No failures. Nice.', 'fileora' ); ?></p>
			<?php endif; ?>
		</section>
	</div>

	<?php
	$fo_ready  = count( array_filter( Fileora_Tool_Registry::tools(), function ( $t ) { return 'ready' === $t['status']; } ) );
	$fo_on     = count( Fileora_Tool_Registry::visible() );
	$fo_target = 0;
	foreach ( Fileora_Tool_Registry::categories() as $fo_c ) {
		$fo_target += $fo_c['target'];
	}
	?>
	<section class="fo-card">
		<h2><?php esc_html_e( 'Tools', 'fileora' ); ?></h2>
		<p><?php echo esc_html( sprintf( __( '%1$d planned · %2$d implemented · %3$d switched on for visitors.', 'fileora' ), $fo_target, $fo_ready, $fo_on ) ); ?>
			<?php if ( current_user_can( 'fileora_manage_tools' ) ) : ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=fileora-tools' ) ); ?>"><?php esc_html_e( 'Tool Management', 'fileora' ); ?></a>
			<?php endif; ?>
		</p>
	</section>
</div>
