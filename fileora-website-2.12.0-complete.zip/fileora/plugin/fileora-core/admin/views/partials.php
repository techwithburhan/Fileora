<?php
/**
 * Small view helpers for the admin screens: KPI tiles, SVG charts, labels.
 * Charts are drawn server-side as SVG with a native tooltip per mark (<title>)
 * and a table view underneath, so they need no chart library.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'fo_admin_kpi' ) ) {

	/** One KPI tile. $sub is a short secondary line. */
	function fo_admin_kpi( $label, $value, $sub = '', $status = '' ) {
		echo '<div class="fo-kpi' . ( $status ? ' is-' . esc_attr( $status ) : '' ) . '"><span class="fo-kpi-l">' . esc_html( $label ) . '</span><span class="fo-kpi-v">' . esc_html( $value ) . '</span>' . ( '' !== $sub ? '<span class="fo-kpi-s">' . esc_html( $sub ) . '</span>' : '' ) . '</div>';
	}

	function fo_admin_num( $n ) {
		return null === $n ? '–' : number_format_i18n( (float) $n );
	}

	function fo_admin_pct( $f, $decimals = 1 ) {
		return null === $f ? '–' : number_format_i18n( (float) $f, $decimals ) . '%';
	}

	function fo_admin_ms( $ms ) {
		if ( null === $ms ) {
			return '–';
		}
		$ms = (int) $ms;
		return $ms < 1000 ? $ms . ' ms' : ( $ms < 60000 ? number_format_i18n( $ms / 1000, 1 ) . ' s' : number_format_i18n( $ms / 60000, 1 ) . ' min' );
	}

	function fo_admin_bytes( $b ) {
		return null === $b ? '–' : size_format( (int) $b, (int) $b >= MB_IN_BYTES ? 1 : 0 );
	}

	function fo_admin_time( $utc ) {
		return $utc ? get_date_from_gmt( $utc, get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) : '–';
	}

	function fo_admin_tool_name( $id ) {
		$t = Fileora_Tool_Registry::get( $id );
		return $t ? $t['name'] : $id;
	}

	/** Last $days UTC dates, oldest first. */
	function fo_admin_dates( $days ) {
		$out = array();
		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$out[] = gmdate( 'Y-m-d', time() - $i * DAY_IN_SECONDS );
		}
		return $out;
	}

	function fo_admin_short_date( $ymd ) {
		return date_i18n( 'j M', strtotime( $ymd . ' 12:00:00' ) );
	}

	/** Rounded-up axis maximum and three gridline values. */
	function fo_admin_scale( $max ) {
		$max = max( 1, (float) $max );
		$pow = pow( 10, floor( log10( $max ) ) );
		foreach ( array( 1, 2, 2.5, 5, 10 ) as $m ) {
			if ( $m * $pow >= $max ) {
				$top = $m * $pow;
				break;
			}
		}
		$top = max( 1, $top );
		return array( $top, array( $top / 3, $top * 2 / 3, $top ) );
	}

	/**
	 * Column chart over days. $series: [ ['label' => 'Visitors', 'class' => 's1', 'values' => [date => n]] , ... ]
	 * Two series are stacked (e.g. done + failed); one series is plain.
	 */
	function fo_admin_columns( array $dates, array $series, $title, $unit = '' ) {
		$w   = 760;
		$h   = 210;
		$pl  = 40;
		$pr  = 8;
		$pt  = 10;
		$pb  = 26;
		$n   = max( 1, count( $dates ) );
		$cw  = ( $w - $pl - $pr ) / $n;
		$bw  = min( 24, max( 4, $cw * 0.62 ) );
		$tot = array();
		foreach ( $dates as $d ) {
			$tot[ $d ] = 0;
			foreach ( $series as $s ) {
				$tot[ $d ] += isset( $s['values'][ $d ] ) ? (float) $s['values'][ $d ] : 0;
			}
		}
		list( $top, $grid ) = fo_admin_scale( $tot ? max( $tot ) : 1 );
		$y = function ( $v ) use ( $h, $pt, $pb, $top ) {
			return $h - $pb - ( $v / $top ) * ( $h - $pt - $pb );
		};
		$svg = '<svg class="fo-chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="' . esc_attr( $title ) . '" preserveAspectRatio="none">';
		foreach ( $grid as $g ) {
			$gy   = $y( $g );
			$svg .= '<line class="fo-grid" x1="' . $pl . '" x2="' . ( $w - $pr ) . '" y1="' . $gy . '" y2="' . $gy . '"/>';
			$svg .= '<text class="fo-axis" x="' . ( $pl - 6 ) . '" y="' . ( $gy + 4 ) . '" text-anchor="end">' . esc_html( fo_admin_num( round( $g, $g < 3 ? 1 : 0 ) ) ) . '</text>';
		}
		$base = $y( 0 );
		$svg .= '<line class="fo-base" x1="' . $pl . '" x2="' . ( $w - $pr ) . '" y1="' . $base . '" y2="' . $base . '"/>';
		$every = max( 1, (int) ceil( $n / 8 ) );
		foreach ( $dates as $i => $d ) {
			$x   = $pl + $i * $cw + ( $cw - $bw ) / 2;
			$acc = 0;
			$tip = fo_admin_short_date( $d );
			$k   = 0;
			$last = count( $series ) - 1;
			// Find the top-most non-zero segment so only it gets the rounded end.
			$top_idx = -1;
			foreach ( $series as $si => $s ) {
				if ( ! empty( $s['values'][ $d ] ) ) {
					$top_idx = $si;
				}
			}
			foreach ( $series as $si => $s ) {
				$v = isset( $s['values'][ $d ] ) ? (float) $s['values'][ $d ] : 0;
				$tip .= ' · ' . $s['label'] . ': ' . fo_admin_num( $v ) . $unit;
				if ( $v <= 0 ) {
					continue;
				}
				$y0 = $y( $acc );
				$y1 = $y( $acc + $v );
				$gap = $acc > 0 ? 2 : 0; // surface gap between stacked segments
				$hgt = max( 1, $y0 - $y1 - $gap );
				$r   = $si === $top_idx ? min( 4, $hgt / 2, $bw / 2 ) : 0;
				$svg .= '<path class="fo-bar ' . esc_attr( $s['class'] ) . '" d="' . fo_admin_bar_path( $x, $y1, $bw, $hgt, $r ) . '"/>';
				$acc += $v;
				++$k;
			}
			$svg .= '<rect class="fo-hit" x="' . ( $pl + $i * $cw ) . '" y="' . $pt . '" width="' . $cw . '" height="' . ( $h - $pt - $pb ) . '"><title>' . esc_html( $tip ) . '</title></rect>';
			if ( ( 0 === $i % $every && $n - 1 - $i >= $every * 0.6 ) || $i === $n - 1 ) {
				$svg .= '<text class="fo-axis" x="' . ( $pl + $i * $cw + $cw / 2 ) . '" y="' . ( $h - 8 ) . '" text-anchor="middle">' . esc_html( fo_admin_short_date( $d ) ) . '</text>';
			}
		}
		$svg .= '</svg>';
		$legend = '';
		if ( count( $series ) > 1 ) {
			$legend = '<div class="fo-legend">';
			foreach ( $series as $s ) {
				$legend .= '<span><i class="' . esc_attr( $s['class'] ) . '"></i>' . esc_html( $s['label'] ) . '</span>';
			}
			$legend .= '</div>';
		}
		echo '<figure class="fo-fig"><figcaption>' . esc_html( $title ) . '</figcaption>' . $legend . $svg . '</figure>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts
	}

	/** Bar path with a rounded top and a square base. */
	function fo_admin_bar_path( $x, $y, $w, $h, $r ) {
		$r = max( 0, $r );
		return sprintf(
			'M%1$.2f %2$.2fV%3$.2fQ%1$.2f %4$.2f %5$.2f %4$.2fH%6$.2fQ%7$.2f %4$.2f %7$.2f %3$.2fV%2$.2fZ',
			$x,
			$y + $h,
			$y + $r,
			$y,
			$x + $r,
			$x + $w - $r,
			$x + $w
		);
	}

	/** Line chart of response times. $points: [ [unix, ms, ok], ... ] */
	function fo_admin_latency( array $points, $from, $to, $title ) {
		$w  = 760;
		$h  = 200;
		$pl = 48;
		$pr = 8;
		$pt = 10;
		$pb = 26;
		$max = 1;
		foreach ( $points as $p ) {
			if ( $p[2] ) {
				$max = max( $max, $p[1] );
			}
		}
		list( $top, $grid ) = fo_admin_scale( $max );
		$x = function ( $t ) use ( $from, $to, $w, $pl, $pr ) {
			return $pl + ( $t - $from ) / max( 1, $to - $from ) * ( $w - $pl - $pr );
		};
		$y = function ( $v ) use ( $h, $pt, $pb, $top ) {
			return $h - $pb - min( 1, $v / $top ) * ( $h - $pt - $pb );
		};
		$svg = '<svg class="fo-chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="' . esc_attr( $title ) . '" preserveAspectRatio="none">';
		foreach ( $grid as $g ) {
			$gy   = $y( $g );
			$svg .= '<line class="fo-grid" x1="' . $pl . '" x2="' . ( $w - $pr ) . '" y1="' . $gy . '" y2="' . $gy . '"/><text class="fo-axis" x="' . ( $pl - 6 ) . '" y="' . ( $gy + 4 ) . '" text-anchor="end">' . esc_html( fo_admin_ms( $g ) ) . '</text>';
		}
		$svg .= '<line class="fo-base" x1="' . $pl . '" x2="' . ( $w - $pr ) . '" y1="' . $y( 0 ) . '" y2="' . $y( 0 ) . '"/>';
		// Line segments break where a check failed or the gap is larger than two intervals.
		$cap  = 2 * Fileora_Server_Monitor::interval();
		$seg  = array();
		$prev = null;
		$path = '';
		foreach ( $points as $p ) {
			if ( ! $p[2] ) {
				$prev = null;
				$svg .= '<line class="fo-down" x1="' . $x( $p[0] ) . '" x2="' . $x( $p[0] ) . '" y1="' . $pt . '" y2="' . ( $h - $pb ) . '"><title>' . esc_html( wp_date( 'j M H:i', $p[0] ) . ' · ' . __( 'Down', 'fileora' ) ) . '</title></line>';
				continue;
			}
			$cmd   = ( null === $prev || $p[0] - $prev > $cap ) ? 'M' : 'L';
			$path .= sprintf( '%s%.2f %.2f', $cmd, $x( $p[0] ), $y( $p[1] ) );
			$prev  = $p[0];
		}
		if ( $path ) {
			$svg .= '<path class="fo-line" d="' . $path . '"/>';
		}
		foreach ( $points as $p ) {
			if ( $p[2] ) {
				$svg .= '<circle class="fo-hitdot" cx="' . $x( $p[0] ) . '" cy="' . $y( $p[1] ) . '" r="6"><title>' . esc_html( wp_date( 'j M H:i', $p[0] ) . ' · ' . fo_admin_ms( $p[1] ) ) . '</title></circle>';
			}
		}
		$ticks = 6;
		for ( $i = 0; $i <= $ticks; $i++ ) {
			$t    = $from + ( $to - $from ) * $i / $ticks;
			$svg .= '<text class="fo-axis" x="' . $x( $t ) . '" y="' . ( $h - 8 ) . '" text-anchor="' . ( 0 === $i ? 'start' : ( $ticks === $i ? 'end' : 'middle' ) ) . '">' . esc_html( wp_date( 'H:i', (int) $t ) ) . '</text>';
		}
		$svg .= '</svg>';
		echo '<figure class="fo-fig"><figcaption>' . esc_html( $title ) . '</figcaption>' . $svg . '</figure>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/** Status chip with an icon-like glyph and label (never colour alone). */
	function fo_admin_status( $state, $label ) {
		$glyph = array(
			'good'     => '●',
			'warning'  => '▲',
			'critical' => '■',
			'unknown'  => '○',
		);
		return '<span class="fo-st is-' . esc_attr( $state ) . '"><span aria-hidden="true">' . ( isset( $glyph[ $state ] ) ? $glyph[ $state ] : '○' ) . '</span>' . esc_html( $label ) . '</span>';
	}

	function fo_admin_avail_state( $a ) {
		if ( null === $a ) {
			return 'unknown';
		}
		return $a >= 99.5 ? 'good' : ( $a >= 95 ? 'warning' : 'critical' );
	}

	/** Window selector (7 / 30 / 90 days). */
	function fo_admin_days_nav( $page, $days, array $choices = array( 7, 30, 90 ) ) {
		echo '<nav class="fo-seg" aria-label="' . esc_attr__( 'Time range', 'fileora' ) . '">';
		foreach ( $choices as $d ) {
			/* translators: %d: number of days */
			$label = 1 === $d ? __( '24 hours', 'fileora' ) : sprintf( _n( '%d day', '%d days', $d, 'fileora' ), $d );
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=' . $page . '&days=' . $d ) ) . '"' . ( $d === $days ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
	}
	/** Shown wherever a value wasn't measured or the source isn't connected. */
	function fo_admin_na() {
		return __( 'Not Available', 'fileora' );
	}

	/** Round-trip time with decimals that fit (a ping can take well under 1 ms). */
	function fo_admin_rtt( $ms ) {
		if ( null === $ms || '' === $ms ) {
			return fo_admin_na();
		}
		$ms = (float) $ms;
		return ( $ms < 10 ? number_format_i18n( $ms, 2 ) : ( $ms < 100 ? number_format_i18n( $ms, 1 ) : number_format_i18n( $ms ) ) ) . ' ms';
	}

	/** Bytes per second. */
	function fo_admin_rate( $bps ) {
		return null === $bps || '' === $bps ? fo_admin_na() : size_format( max( 0, (int) $bps ), (int) $bps >= KB_IN_BYTES ? 1 : 0 ) . '/s';
	}

	/** 3 d 4 h, 2 h 5 min, 1 h, 12 min, 40 s. */
	function fo_admin_duration( $s ) {
		if ( null === $s || '' === $s ) {
			return fo_admin_na();
		}
		$s = max( 0, (int) $s );
		$d = intdiv( $s, DAY_IN_SECONDS );
		$h = intdiv( $s % DAY_IN_SECONDS, HOUR_IN_SECONDS );
		$m = intdiv( $s % HOUR_IN_SECONDS, MINUTE_IN_SECONDS );
		if ( $d ) {
			/* translators: 1: days, 2: hours */
			return $h ? sprintf( __( '%1$d d %2$d h', 'fileora' ), $d, $h ) : sprintf( __( '%d d', 'fileora' ), $d );
		}
		if ( $h ) {
			/* translators: 1: hours, 2: minutes */
			return $m ? sprintf( __( '%1$d h %2$d min', 'fileora' ), $h, $m ) : sprintf( __( '%d h', 'fileora' ), $h );
		}
		/* translators: %d: minutes or seconds */
		return $m ? sprintf( __( '%d min', 'fileora' ), $m ) : sprintf( __( '%d s', 'fileora' ), $s );
	}

	/** Date and time in short form (22 Oct, 5:53 am) for dense tables; $ts is a Unix time. */
	function fo_admin_short_time( $ts ) {
		return $ts ? wp_date( 'j M, ' . get_option( 'time_format' ), (int) $ts ) : fo_admin_na();
	}

	/** Time range links for Server Monitoring (1 h / 6 h / 24 h / 7 d). */
	function fo_admin_range_nav( $page, $current, array $ranges ) {
		echo '<nav class="fo-seg" aria-label="' . esc_attr__( 'Time range', 'fileora' ) . '">';
		foreach ( $ranges as $key => $r ) {
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=' . $page . '&range=' . $key ) ) . '"' . ( $key === $current ? ' aria-current="page"' : '' ) . '>' . esc_html( $r['label'] ) . '</a>';
		}
		echo '</nav>';
	}

	/**
	 * Averages [time, value] points into at most $n equal time buckets over [from, to].
	 * Empty buckets are left out (they become gaps). Each output point is [mid-time, average, count].
	 */
	function fo_admin_bucket( array $points, $from, $to, $n ) {
		if ( count( $points ) <= $n ) {
			return $points;
		}
		$size = max( 1, ( $to - $from ) / $n );
		$acc  = array();
		foreach ( $points as $p ) {
			if ( null === $p[1] ) {
				continue;
			}
			$b = (int) floor( ( $p[0] - $from ) / $size );
			if ( ! isset( $acc[ $b ] ) ) {
				$acc[ $b ] = array( 0.0, 0 );
			}
			$acc[ $b ][0] += (float) $p[1];
			++$acc[ $b ][1];
		}
		ksort( $acc );
		$out = array();
		foreach ( $acc as $b => $a ) {
			$out[] = array( (int) ( $from + ( $b + 0.5 ) * $size ), $a[0] / $a[1], $a[1] );
		}
		return $out;
	}

	/**
	 * Time-series chart as SVG: one axis, thin lines (or bars), recessive grid,
	 * a native tooltip per mark, gaps where nothing was measured.
	 *
	 * @param array $a {
	 *     @type string   $title  Accessible name (also the hidden caption).
	 *     @type int      $from   Window start (Unix time).
	 *     @type int      $to     Window end.
	 *     @type array    $series [ ['name' => 'Ping', 'class' => 's1', 'points' => [[t, value|null, tooltip?], ...]], ... ]
	 *     @type string   $type   'line' (default) or 'bars'.
	 *     @type callable $format Value formatter for the axis and tooltips.
	 *     @type float    $max    Fixed top of the scale (e.g. 100 for %); computed when absent.
	 *     @type array    $down   Times of failed checks, drawn as red marks.
	 *     @type int      $gap    Lines break when two points are further apart (seconds).
	 *     @type int      $height Height in viewBox units (default 200).
	 *     @type int      $width  Width in viewBox units: about the width it is shown at, so text isn't stretched (default 760).
	 * }
	 */
	function fo_admin_timechart( array $a ) {
		$w      = isset( $a['width'] ) ? (int) $a['width'] : 760;
		$h      = isset( $a['height'] ) ? (int) $a['height'] : 200;
		$pl     = isset( $a['pad_left'] ) ? (int) $a['pad_left'] : 58;
		$pr     = 10;
		$pt     = 10;
		$pb     = 26;
		$from   = (int) $a['from'];
		$to     = (int) $a['to'];
		$fmt    = isset( $a['format'] ) ? $a['format'] : 'fo_admin_num';
		$type   = isset( $a['type'] ) ? $a['type'] : 'line';
		$gap    = isset( $a['gap'] ) ? (int) $a['gap'] : 0;
		$series = $a['series'];
		$max    = 0;
		foreach ( $series as $s ) {
			foreach ( $s['points'] as $p ) {
				if ( null !== $p[1] ) {
					$max = max( $max, (float) $p[1] );
				}
			}
		}
		if ( isset( $a['max'] ) ) {
			$top  = (float) $a['max'];
			$grid = array( $top / 4, $top / 2, $top * 3 / 4, $top );
		} else {
			// A "nice" step (1, 2, 2.5 or 5 × 10^n), at most four grid lines; works below 1 too (ping in ms).
			$max  = $max > 0 ? $max * 1.05 : 1;
			$raw  = $max / 4;
			$pow  = pow( 10, floor( log10( $raw ) ) );
			$step = 10 * $pow;
			foreach ( array( 1, 2, 2.5, 5, 10 ) as $m ) {
				if ( $m * $pow >= $raw ) {
					$step = $m * $pow;
					break;
				}
			}
			$grid = array();
			for ( $i = 1; $i <= 4 && empty( $top ); $i++ ) {
				$grid[] = $step * $i;
				if ( $step * $i >= $max ) {
					$top = $step * $i;
				}
			}
			$top = empty( $top ) ? $step * 4 : $top;
		}
		$x = function ( $t ) use ( $from, $to, $w, $pl, $pr ) {
			return round( $pl + ( $t - $from ) / max( 1, $to - $from ) * ( $w - $pl - $pr ), 2 );
		};
		$y = function ( $v ) use ( $h, $pt, $pb, $top ) {
			return round( $h - $pb - min( 1, max( 0, $v ) / $top ) * ( $h - $pt - $pb ), 2 );
		};
		$stamp = function ( $t ) use ( $from, $to ) {
			return wp_date( ( $to - $from ) > DAY_IN_SECONDS ? 'j M H:i' : 'H:i', (int) $t );
		};
		$svg = '<svg class="fo-chart fo-tchart" viewBox="0 0 ' . $w . ' ' . $h . '" width="' . $w . '" height="' . $h . '" role="img" aria-label="' . esc_attr( $a['title'] ) . '">';
		foreach ( $grid as $g ) {
			$gy   = $y( $g );
			$svg .= '<line class="fo-grid" x1="' . $pl . '" x2="' . ( $w - $pr ) . '" y1="' . $gy . '" y2="' . $gy . '"/><text class="fo-axis" x="' . ( $pl - 6 ) . '" y="' . ( $gy + 4 ) . '" text-anchor="end">' . esc_html( call_user_func( $fmt, $g ) ) . '</text>';
		}
		$svg .= '<line class="fo-base" x1="' . $pl . '" x2="' . ( $w - $pr ) . '" y1="' . $y( 0 ) . '" y2="' . $y( 0 ) . '"/>';
		if ( ! empty( $a['down'] ) ) {
			foreach ( $a['down'] as $t ) {
				$svg .= '<line class="fo-down" x1="' . $x( $t ) . '" x2="' . $x( $t ) . '" y1="' . $pt . '" y2="' . ( $h - $pb ) . '"><title>' . esc_html( $stamp( $t ) . ' · ' . __( 'check failed', 'fileora' ) ) . '</title></line>';
			}
		}
		$n_max = 1;
		foreach ( $series as $s ) {
			$n_max = max( $n_max, count( $s['points'] ) );
		}
		$bw  = max( 1.5, min( 14, ( $w - $pl - $pr ) / $n_max * 0.7 ) );
		$hit = '';
		foreach ( $series as $s ) {
			$class = isset( $s['class'] ) ? $s['class'] : 's1';
			$name  = count( $series ) > 1 ? ' (' . $s['name'] . ')' : '';
			if ( 'bars' === $type ) {
				foreach ( $s['points'] as $p ) {
					if ( null === $p[1] ) {
						continue;
					}
					$tip = $stamp( $p[0] ) . ' · ' . ( isset( $p[2] ) && is_string( $p[2] ) ? $p[2] : call_user_func( $fmt, $p[1] ) ) . $name;
					$bx  = $x( $p[0] ) - $bw / 2;
					if ( $p[1] > 0 ) {
						$by   = $y( $p[1] );
						$svg .= '<rect class="fo-bar ' . esc_attr( $class ) . '" x="' . round( $bx, 2 ) . '" y="' . $by . '" width="' . round( $bw, 2 ) . '" height="' . round( max( 1, $y( 0 ) - $by ), 2 ) . '" rx="1"/>';
					}
					$hit .= '<rect class="fo-hit" x="' . round( $bx, 2 ) . '" y="' . $pt . '" width="' . round( max( $bw, 4 ), 2 ) . '" height="' . ( $h - $pt - $pb ) . '"><title>' . esc_html( $tip ) . '</title></rect>';
				}
				continue;
			}
			$path  = '';
			$prev  = null;
			$run   = array();
			$lone  = array();
			foreach ( $s['points'] as $p ) {
				if ( null === $p[1] ) {
					if ( 1 === count( $run ) ) {
						$lone[] = $run[0];
					}
					$prev = null;
					$run  = array();
					continue;
				}
				$break = null === $prev || ( $gap && $p[0] - $prev > $gap );
				if ( $break && 1 === count( $run ) ) {
					$lone[] = $run[0];
				}
				if ( $break ) {
					$run = array();
				}
				$run[] = $p;
				$path .= ( $break ? 'M' : 'L' ) . $x( $p[0] ) . ' ' . $y( $p[1] );
				$prev  = $p[0];
				$tip   = $stamp( $p[0] ) . ' · ' . ( isset( $p[2] ) && is_string( $p[2] ) ? $p[2] : call_user_func( $fmt, $p[1] ) ) . $name;
				$hit  .= '<circle class="fo-hitdot ' . esc_attr( $class ) . '" cx="' . $x( $p[0] ) . '" cy="' . $y( $p[1] ) . '" r="6"><title>' . esc_html( $tip ) . '</title></circle>';
			}
			if ( 1 === count( $run ) ) {
				$lone[] = $run[0];
			}
			if ( $path ) {
				$svg .= '<path class="fo-line ' . esc_attr( $class ) . '" d="' . $path . '"/>';
			}
			foreach ( $lone as $p ) {
				$svg .= '<circle class="fo-pt ' . esc_attr( $class ) . '" cx="' . $x( $p[0] ) . '" cy="' . $y( $p[1] ) . '" r="2.5"/>';
			}
		}
		$svg  .= $hit;
		$ticks = ( $to - $from ) > 2 * DAY_IN_SECONDS ? 7 : 6;
		for ( $i = 0; $i <= $ticks; $i++ ) {
			$t    = $from + ( $to - $from ) * $i / $ticks;
			$lbl  = wp_date( ( $to - $from ) > 2 * DAY_IN_SECONDS ? 'j M' : 'H:i', (int) $t );
			$svg .= '<text class="fo-axis" x="' . $x( $t ) . '" y="' . ( $h - 8 ) . '" text-anchor="' . ( 0 === $i ? 'start' : ( $ticks === $i ? 'end' : 'middle' ) ) . '">' . esc_html( $lbl ) . '</text>';
		}
		$svg .= '</svg>';
		$legend = '';
		if ( count( $series ) > 1 ) {
			$legend = '<div class="fo-legend">';
			foreach ( $series as $s ) {
				$legend .= '<span><i class="' . esc_attr( isset( $s['class'] ) ? $s['class'] : 's1' ) . '"></i>' . esc_html( $s['name'] ) . '</span>';
			}
			$legend .= '</div>';
		}
		echo '<figure class="fo-fig"><figcaption>' . esc_html( $a['title'] ) . '</figcaption>' . $svg . $legend . '</figure>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
