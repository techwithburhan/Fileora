<?php
/**
 * Fileora → Processing Tasks → Temporary files & cleanup.
 *
 * Live view of the temporary task folders on the processing server, the
 * cleanup schedule and its history, with admin controls. Filesystem paths
 * are never shown; tasks are identified by their task id.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only view parameters
$fo_filter  = isset( $_GET['cleanup'] ) && in_array( $_GET['cleanup'], Fileora_Temp_Cleanup::FILTERS, true ) ? sanitize_key( $_GET['cleanup'] ) : '';
$fo_task_id = isset( $_GET['task'] ) && preg_match( '/^[a-f0-9]{32}$/', (string) $_GET['task'] ) ? sanitize_key( $_GET['task'] ) : '';
$fo_confirm = isset( $_GET['confirm'] ) ? sanitize_key( $_GET['confirm'] ) : '';
// phpcs:enable
$fo_can    = current_user_can( Fileora_Temp_Cleanup::CAP_MANAGE );
$fo_notice = Fileora_Temp_Cleanup::take_notice();
$fo_o      = Fileora_Temp_Cleanup::overview();
$fo_url    = admin_url( 'admin.php?page=fileora-tasks&view=temp' );
$fo_post   = admin_url( 'admin-post.php' );
$fo_status_names = array(
	'queued'  => __( 'Waiting', 'fileora' ),
	'running' => __( 'Running', 'fileora' ),
	'done'    => __( 'Completed', 'fileora' ),
	'failed'  => __( 'Failed', 'fileora' ),
	'unknown' => __( 'Unknown', 'fileora' ),
);
$fo_when = function ( $ts ) {
	return $ts ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $ts ) : fo_admin_na();
};
$fo_ago = function ( $ts ) {
	if ( ! $ts ) {
		return fo_admin_na();
	}
	return (int) $ts > time() ? sprintf( __( 'in %s', 'fileora' ), human_time_diff( (int) $ts ) ) : sprintf( __( '%s ago', 'fileora' ), human_time_diff( (int) $ts ) );
};
?>
<div class="wrap fo-wrap">
	<h1><?php esc_html_e( 'Processing Tasks', 'fileora' ); ?></h1>
	<nav class="fo-seg fo-tabs" aria-label="<?php esc_attr_e( 'Processing Tasks views', 'fileora' ); ?>">
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=fileora-tasks' ) ); ?>"><?php esc_html_e( 'Task history', 'fileora' ); ?></a>
		<a href="<?php echo esc_url( $fo_url ); ?>" aria-current="page"><?php esc_html_e( 'Temporary files & cleanup', 'fileora' ); ?></a>
	</nav>
	<?php if ( $fo_notice ) : ?>
		<div class="notice notice-<?php echo esc_attr( 'error' === $fo_notice[0] ? 'error' : ( 'warning' === $fo_notice[0] ? 'warning' : 'success' ) ); ?> is-dismissible"><p><?php echo esc_html( $fo_notice[1] ); ?></p></div>
	<?php endif; ?>
	<p class="fo-lead"><?php esc_html_e( 'Files created while a server tool runs are kept in one temporary directory on the processing server, one folder per task. A result is deleted right after it is downloaded; the cleanup deletes whatever is left once it is older than the expiry. The cleanup only ever deletes expired task folders in that directory, never blog posts, pages, media, uploads, user data or the database.', 'fileora' ); ?></p>

	<?php if ( ! $fo_o['ok'] ) : ?>
		<div class="notice notice-error inline"><p><?php echo esc_html( sprintf( __( 'Not Available: %s', 'fileora' ), $fo_o['error'] ) ); ?></p></div>
	<?php else : ?>
		<?php
		$fo_st    = $fo_o['status'];
		$fo_set   = isset( $fo_st['settings'] ) ? $fo_st['settings'] : array();
		$fo_sum   = isset( $fo_o['temp']['summary'] ) ? $fo_o['temp']['summary'] : array();
		$fo_all   = isset( $fo_o['temp']['tasks'] ) ? (array) $fo_o['temp']['tasks'] : array();
		$fo_cnt   = isset( $fo_st['counts'] ) ? $fo_st['counts'] : array();
		$fo_last  = isset( $fo_st['last_run'] ) && is_array( $fo_st['last_run'] ) ? $fo_st['last_run'] : null;
		$fo_on    = ! empty( $fo_set['enabled'] );
		$fo_ver   = ! empty( $fo_st['verified'] );
		$fo_imp   = Fileora_Temp_Cleanup::impact();
		$fo_by    = array();
		foreach ( $fo_all as $fo_t ) {
			$fo_by[ $fo_t['cleanup'] ] = ( isset( $fo_by[ $fo_t['cleanup'] ] ) ? $fo_by[ $fo_t['cleanup'] ] : 0 ) + 1;
		}
		$fo_by['done'] = count(
			array_filter(
				$fo_all,
				function ( $t ) {
					return 'done' === $t['status'];
				}
			)
		);
		$fo_rows = $fo_filter ? array_values(
			array_filter(
				$fo_all,
				function ( $t ) use ( $fo_filter ) {
					return 'done' === $fo_filter ? 'done' === $t['status'] : $t['cleanup'] === $fo_filter;
				}
			)
		) : $fo_all;
		$fo_sched = isset( $fo_st['scheduler'] ) ? $fo_st['scheduler'] : '';
		$fo_sched_names = array(
			'running'     => __( 'Running now', 'fileora' ),
			'scheduled'   => __( 'Waiting for the next run', 'fileora' ),
			'stopped'     => __( 'Stopped', 'fileora' ),
			'not started' => __( 'Not started', 'fileora' ),
		);
		?>
		<?php if ( ! $fo_ver ) : ?>
			<div class="notice notice-error inline"><p><strong><?php esc_html_e( 'Cleanup is paused and deletes nothing:', 'fileora' ); ?></strong> <?php echo esc_html( isset( $fo_st['reason'] ) ? $fo_st['reason'] : '' ); ?> <?php esc_html_e( 'See README section 8.12, “Temporary files and cleanup”.', 'fileora' ); ?></p></div>
		<?php endif; ?>
		<?php if ( ! $fo_on ) : ?>
			<div class="notice notice-warning inline"><p>
				<strong><?php esc_html_e( 'Automatic cleanup is off.', 'fileora' ); ?></strong>
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: number of folders, 2: size */
						__( 'Expired files are kept, not deleted: %1$d expired task folders (%2$s) right now.', 'fileora' ),
						isset( $fo_sum['expired'] ) ? (int) $fo_sum['expired'] : 0,
						fo_admin_bytes( isset( $fo_sum['expired_bytes'] ) ? (int) $fo_sum['expired_bytes'] : 0 )
					)
				);
				if ( null !== $fo_imp['per_day'] ) {
					echo ' ' . esc_html(
						sprintf(
							/* translators: 1: size per day, 2: days, 3: results */
							__( 'From the task records of the last %2$d days, about %1$s of results that were never downloaded would be kept per day (%3$d results).', 'fileora' ),
							fo_admin_bytes( (int) $fo_imp['per_day'] ),
							$fo_imp['days'],
							$fo_imp['results']
						)
					);
				}
				if ( isset( $fo_sum['disk_free'] ) && null !== $fo_sum['disk_free'] ) {
					echo ' ' . esc_html( sprintf( __( 'Free disk space on the server: %s.', 'fileora' ), fo_admin_bytes( $fo_sum['disk_free'] ) ) );
				}
				?>
			</p></div>
		<?php endif; ?>

		<div class="fo-kpis">
			<?php
			fo_admin_kpi( __( 'Automatic cleanup', 'fileora' ), ! $fo_ver ? __( 'Paused', 'fileora' ) : ( $fo_on ? __( 'On', 'fileora' ) : __( 'Off', 'fileora' ) ), isset( $fo_sched_names[ $fo_sched ] ) ? $fo_sched_names[ $fo_sched ] : $fo_sched, ! $fo_ver ? 'critical' : ( $fo_on ? 'good' : 'warning' ) );
			fo_admin_kpi( __( 'Files expire after', 'fileora' ), isset( $fo_set['ttl_min'] ) ? fo_admin_duration( (int) $fo_set['ttl_min'] * 60 ) : fo_admin_na(), __( 'counted from task creation', 'fileora' ) );
			fo_admin_kpi( __( 'Runs every', 'fileora' ), isset( $fo_set['interval_min'] ) ? fo_admin_duration( (int) $fo_set['interval_min'] * 60 ) : fo_admin_na(), ! empty( $fo_st['next_run'] ) ? sprintf( __( 'next run %s', 'fileora' ), $fo_ago( $fo_st['next_run'] ) ) : __( 'no run scheduled', 'fileora' ) );
			fo_admin_kpi(
				__( 'Last run', 'fileora' ),
				$fo_last ? $fo_ago( $fo_last['finished'] ) : __( 'Never', 'fileora' ),
				$fo_last ? ( 'blocked' === $fo_last['mode'] ? __( 'blocked: nothing deleted', 'fileora' ) : sprintf( /* translators: 1: deleted, 2: failed */ __( '%1$d deleted, %2$d failed', 'fileora' ), (int) $fo_last['deleted'], (int) $fo_last['failed'] ) ) : '',
				$fo_last && ( 'blocked' === $fo_last['mode'] || $fo_last['failed'] ) ? 'warning' : ''
			);
			fo_admin_kpi( __( 'Successful / failed runs', 'fileora' ), fo_admin_num( isset( $fo_cnt['success_runs'] ) ? $fo_cnt['success_runs'] : 0 ) . ' / ' . fo_admin_num( isset( $fo_cnt['failed_runs'] ) ? $fo_cnt['failed_runs'] : 0 ), sprintf( __( '%1$s folders deleted, %2$s freed', 'fileora' ), fo_admin_num( isset( $fo_cnt['deleted_total'] ) ? $fo_cnt['deleted_total'] : 0 ), fo_admin_bytes( isset( $fo_cnt['freed_total'] ) ? $fo_cnt['freed_total'] : 0 ) ) );
			fo_admin_kpi( __( 'Temporary storage now', 'fileora' ), fo_admin_bytes( isset( $fo_sum['bytes'] ) ? $fo_sum['bytes'] : 0 ), sprintf( __( '%1$d task folders, %2$d in use', 'fileora' ), isset( $fo_sum['tasks'] ) ? (int) $fo_sum['tasks'] : 0, isset( $fo_sum['active'] ) ? (int) $fo_sum['active'] : 0 ) );
			fo_admin_kpi( __( 'Expired, not deleted yet', 'fileora' ), fo_admin_bytes( isset( $fo_sum['expired_bytes'] ) ? $fo_sum['expired_bytes'] : 0 ), sprintf( _n( '%d task folder', '%d task folders', isset( $fo_sum['expired'] ) ? (int) $fo_sum['expired'] : 0, 'fileora' ), isset( $fo_sum['expired'] ) ? (int) $fo_sum['expired'] : 0 ), ! empty( $fo_sum['expired'] ) && ! $fo_on ? 'warning' : '' );
			fo_admin_kpi( __( 'Free disk on the server', 'fileora' ), isset( $fo_sum['disk_free'] ) && null !== $fo_sum['disk_free'] ? fo_admin_bytes( $fo_sum['disk_free'] ) : fo_admin_na(), isset( $fo_sum['disk_total'] ) && $fo_sum['disk_total'] ? sprintf( __( 'of %s', 'fileora' ), fo_admin_bytes( $fo_sum['disk_total'] ) ) : '' );
			?>
		</div>

		<?php if ( 'run' === $fo_confirm && $fo_can ) : ?>
			<section class="fo-card fo-confirm" aria-labelledby="fo-confirm-run">
				<h2 id="fo-confirm-run"><?php esc_html_e( 'Run the cleanup now?', 'fileora' ); ?></h2>
				<p><?php echo esc_html( sprintf( __( 'This deletes the expired task folders that aren’t in use: %1$d right now (%2$s). Waiting and running tasks are left alone. It can’t be undone.', 'fileora' ), isset( $fo_sum['expired'] ) ? (int) $fo_sum['expired'] : 0, fo_admin_bytes( isset( $fo_sum['expired_bytes'] ) ? $fo_sum['expired_bytes'] : 0 ) ) ); ?></p>
				<form method="post" action="<?php echo esc_url( $fo_post ); ?>" class="fo-actions">
					<input type="hidden" name="action" value="fileora_cleanup_run">
					<?php wp_nonce_field( 'fileora_cleanup_run' ); ?>
					<button class="button button-primary"><?php esc_html_e( 'Yes, run the cleanup', 'fileora' ); ?></button>
					<a class="button" href="<?php echo esc_url( $fo_url ); ?>"><?php esc_html_e( 'Cancel', 'fileora' ); ?></a>
				</form>
			</section>
		<?php endif; ?>

		<?php
		if ( $fo_task_id ) :
			$fo_d   = Fileora_Temp_Cleanup::task( $fo_task_id );
			$fo_rec = Fileora_Task_Manager::find( $fo_task_id );
			?>
			<section class="fo-card fo-details" aria-labelledby="fo-details-h">
				<h2 id="fo-details-h"><?php echo esc_html( sprintf( __( 'Task %s', 'fileora' ), $fo_task_id ) ); ?></h2>
				<?php if ( $fo_d['ok'] ) : ?>
					<?php
					$fo_t = $fo_d['task'];
					list( $fo_cl, $fo_cs ) = Fileora_Temp_Cleanup::cleanup_label( $fo_t['cleanup'], $fo_t );
					?>
					<dl class="fo-dl fo-dl-wide">
						<dt><?php esc_html_e( 'Tool', 'fileora' ); ?></dt><dd><?php echo esc_html( $fo_t['tool'] ? fo_admin_tool_name( $fo_t['tool'] ) : fo_admin_na() ); ?></dd>
						<dt><?php esc_html_e( 'Processing status', 'fileora' ); ?></dt><dd><?php echo esc_html( isset( $fo_status_names[ $fo_t['status'] ] ) ? $fo_status_names[ $fo_t['status'] ] : $fo_t['status'] ); ?></dd>
						<dt><?php esc_html_e( 'Created', 'fileora' ); ?></dt><dd><?php echo esc_html( $fo_when( $fo_t['created'] ) ); ?></dd>
						<dt><?php esc_html_e( 'Started / finished', 'fileora' ); ?></dt><dd><?php echo esc_html( $fo_when( $fo_t['started'] ) . ' / ' . $fo_when( $fo_t['finished'] ) ); ?></dd>
						<dt><?php esc_html_e( 'Expires', 'fileora' ); ?></dt><dd><?php echo esc_html( $fo_when( $fo_t['expires'] ) . ' (' . $fo_ago( $fo_t['expires'] ) . ')' ); ?></dd>
						<dt><?php esc_html_e( 'Files on the server', 'fileora' ); ?></dt><dd><?php echo esc_html( sprintf( _n( '%1$d file, %2$s', '%1$d files, %2$s', (int) $fo_t['files'], 'fileora' ), (int) $fo_t['files'], fo_admin_bytes( $fo_t['size'] ) ) ); ?></dd>
						<dt><?php esc_html_e( 'Result', 'fileora' ); ?></dt><dd><?php echo esc_html( $fo_t['result'] ? strtoupper( $fo_t['result'] ) . ( 'text' === $fo_t['kind'] ? ' (' . __( 'text', 'fileora' ) . ')' : '' ) : fo_admin_na() ); ?></dd>
						<dt><?php esc_html_e( 'Cleanup', 'fileora' ); ?></dt><dd><?php echo fo_admin_status( $fo_cs, $fo_cl ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php echo $fo_t['cleanup_attempts'] ? ' <span class="fo-sub">' . esc_html( sprintf( __( '%d failed attempts', 'fileora' ), (int) $fo_t['cleanup_attempts'] ) ) . '</span>' : ''; ?></dd>
						<?php if ( $fo_t['error'] || $fo_t['cleanup_error'] ) : ?>
							<dt><?php esc_html_e( 'Error', 'fileora' ); ?></dt><dd><?php echo esc_html( trim( $fo_t['error'] . ' ' . $fo_t['cleanup_error'] ) ); ?></dd>
						<?php endif; ?>
						<?php if ( $fo_rec ) : ?>
							<dt><?php esc_html_e( 'Task record', 'fileora' ); ?></dt><dd><?php echo esc_html( sprintf( __( 'started %1$s · %2$s', 'fileora' ), fo_admin_time( $fo_rec->created_at ), $fo_rec->downloaded_at ? sprintf( __( 'downloaded %s', 'fileora' ), fo_admin_time( $fo_rec->downloaded_at ) ) : __( 'not downloaded', 'fileora' ) ) ); ?></dd>
						<?php endif; ?>
					</dl>
					<div class="fo-actions">
						<?php if ( $fo_can && 'active' !== $fo_t['cleanup'] ) : ?>
							<a class="button button-link-delete" href="<?php echo esc_url( add_query_arg( array( 'confirm' => 'delete', 'task' => $fo_task_id ), $fo_url ) ); ?>"><?php esc_html_e( 'Delete temporary files…', 'fileora' ); ?></a>
						<?php endif; ?>
						<a class="button" href="<?php echo esc_url( $fo_url ); ?>"><?php esc_html_e( 'Close', 'fileora' ); ?></a>
					</div>
				<?php else : ?>
					<p>
						<?php
						echo esc_html( $fo_d['error'] );
						if ( ! empty( $fo_d['removed']['at'] ) ) {
							echo ' ' . esc_html( sprintf( __( 'Deleted %1$s (%2$s).', 'fileora' ), $fo_when( $fo_d['removed']['at'] ), Fileora_Temp_Cleanup::trigger_label( $fo_d['removed']['by'] ) ) );
						}
						?>
					</p>
					<a class="button" href="<?php echo esc_url( $fo_url ); ?>"><?php esc_html_e( 'Close', 'fileora' ); ?></a>
				<?php endif; ?>
			</section>
			<?php if ( 'delete' === $fo_confirm && $fo_can && $fo_d['ok'] && 'active' !== $fo_d['task']['cleanup'] ) : ?>
				<section class="fo-card fo-confirm" aria-labelledby="fo-confirm-del">
					<h2 id="fo-confirm-del"><?php esc_html_e( 'Delete these temporary files?', 'fileora' ); ?></h2>
					<p><?php echo esc_html( sprintf( __( 'This deletes the folder of task %1$s on the processing server now: %2$d files, %3$s. A visitor who hasn’t downloaded the result yet won’t be able to. The task record stays in Task history. It can’t be undone.', 'fileora' ), substr( $fo_task_id, 0, 8 ), (int) $fo_d['task']['files'], fo_admin_bytes( $fo_d['task']['size'] ) ) ); ?></p>
					<form method="post" action="<?php echo esc_url( $fo_post ); ?>" class="fo-actions">
						<input type="hidden" name="action" value="fileora_cleanup_delete">
						<input type="hidden" name="task" value="<?php echo esc_attr( $fo_task_id ); ?>">
						<input type="hidden" name="confirm" value="1">
						<?php wp_nonce_field( 'fileora_cleanup_delete_' . $fo_task_id ); ?>
						<button class="button button-primary fo-danger"><?php esc_html_e( 'Yes, delete the files', 'fileora' ); ?></button>
						<a class="button" href="<?php echo esc_url( add_query_arg( 'task', $fo_task_id, $fo_url ) ); ?>"><?php esc_html_e( 'Cancel', 'fileora' ); ?></a>
					</form>
				</section>
			<?php endif; ?>
		<?php endif; ?>

		<section class="fo-card">
			<h2><?php esc_html_e( 'Cleanup schedule', 'fileora' ); ?></h2>
			<?php if ( $fo_can ) : ?>
				<form method="post" action="<?php echo esc_url( $fo_post ); ?>" class="fo-cleanup-form">
					<input type="hidden" name="action" value="fileora_cleanup_settings">
					<?php wp_nonce_field( 'fileora_cleanup_settings' ); ?>
					<label class="fo-check"><input type="checkbox" name="enabled" value="1" <?php checked( $fo_on ); ?>> <?php esc_html_e( 'Delete expired temporary files automatically', 'fileora' ); ?></label>
					<label><span><?php esc_html_e( 'Files expire after', 'fileora' ); ?></span>
						<select name="ttl_min">
							<?php foreach ( Fileora_Temp_Cleanup::TTL_CHOICES as $fo_v ) : ?>
								<option value="<?php echo esc_attr( $fo_v ); ?>" <?php selected( isset( $fo_set['ttl_min'] ) ? (int) $fo_set['ttl_min'] : 60, $fo_v ); ?>><?php echo esc_html( fo_admin_duration( $fo_v * 60 ) . ( 60 === $fo_v ? ' ' . __( '(default)', 'fileora' ) : '' ) ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label><span><?php esc_html_e( 'Run the cleanup every', 'fileora' ); ?></span>
						<select name="interval_min">
							<?php foreach ( Fileora_Temp_Cleanup::INTERVAL_CHOICES as $fo_v ) : ?>
								<option value="<?php echo esc_attr( $fo_v ); ?>" <?php selected( isset( $fo_set['interval_min'] ) ? (int) $fo_set['interval_min'] : 5, $fo_v ); ?>><?php echo esc_html( fo_admin_duration( $fo_v * 60 ) ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<button class="button button-primary"><?php esc_html_e( 'Save on the server', 'fileora' ); ?></button>
				</form>
				<div class="fo-actions">
					<form method="post" action="<?php echo esc_url( $fo_post ); ?>">
						<input type="hidden" name="action" value="fileora_cleanup_toggle">
						<input type="hidden" name="state" value="<?php echo esc_attr( $fo_on ? 'stop' : 'start' ); ?>">
						<?php wp_nonce_field( 'fileora_cleanup_toggle' ); ?>
						<button class="button"><?php echo $fo_on ? esc_html__( 'Stop schedule', 'fileora' ) : esc_html__( 'Start schedule', 'fileora' ); ?></button>
					</form>
					<a class="button" href="<?php echo esc_url( add_query_arg( 'confirm', 'run', $fo_url ) ); ?>"><?php esc_html_e( 'Run cleanup now…', 'fileora' ); ?></a>
				</div>
				<p class="description"><?php esc_html_e( 'Settings are saved on the processing server and survive restarts. Stopping the schedule only stops the automatic deletion: nothing is deleted, running tasks and the rest of the service carry on, and results are still deleted after download.', 'fileora' ); ?></p>
			<?php else : ?>
				<p class="description"><?php esc_html_e( 'Only administrators can change the cleanup.', 'fileora' ); ?></p>
			<?php endif; ?>
			<dl class="fo-dl fo-dl-wide">
				<dt><?php esc_html_e( 'Job status', 'fileora' ); ?></dt><dd><?php echo esc_html( isset( $fo_sched_names[ $fo_sched ] ) ? $fo_sched_names[ $fo_sched ] : $fo_sched ); ?></dd>
				<dt><?php esc_html_e( 'Last run', 'fileora' ); ?></dt><dd><?php echo esc_html( $fo_last ? $fo_when( $fo_last['finished'] ) . ' · ' . Fileora_Temp_Cleanup::trigger_label( $fo_last['trigger'] ) : __( 'Never', 'fileora' ) ); ?></dd>
				<dt><?php esc_html_e( 'Last successful run', 'fileora' ); ?></dt><dd><?php echo esc_html( $fo_when( isset( $fo_st['last_success'] ) ? $fo_st['last_success'] : 0 ) ); ?></dd>
				<dt><?php esc_html_e( 'Next run', 'fileora' ); ?></dt><dd><?php echo esc_html( ! empty( $fo_st['next_run'] ) ? $fo_when( $fo_st['next_run'] ) : __( 'None (stopped)', 'fileora' ) ); ?></dd>
				<dt><?php esc_html_e( 'Temporary directory', 'fileora' ); ?></dt><dd><?php echo $fo_ver ? fo_admin_status( 'good', __( 'Verified', 'fileora' ) ) : fo_admin_status( 'critical', __( 'Not verified: nothing is deleted', 'fileora' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></dd>
				<?php if ( ! empty( $fo_set['updated'] ) ) : ?>
					<dt><?php esc_html_e( 'Settings changed', 'fileora' ); ?></dt><dd><?php echo esc_html( $fo_when( $fo_set['updated'] ) ); ?></dd>
				<?php endif; ?>
			</dl>
		</section>

		<section class="fo-card">
			<div class="fo-w-head">
				<h2><?php esc_html_e( 'Temporary task folders', 'fileora' ); ?></h2>
				<nav class="fo-seg" aria-label="<?php esc_attr_e( 'Filter by status', 'fileora' ); ?>">
					<?php
					$fo_filters = array(
						''          => array( __( 'All', 'fileora' ), count( $fo_all ) ),
						'active'    => array( __( 'In use', 'fileora' ), isset( $fo_by['active'] ) ? $fo_by['active'] : 0 ),
						'scheduled' => array( __( 'Not expired', 'fileora' ), isset( $fo_by['scheduled'] ) ? $fo_by['scheduled'] : 0 ),
						'due'       => array( __( 'Expired', 'fileora' ), isset( $fo_by['due'] ) ? $fo_by['due'] : 0 ),
						'kept'      => array( __( 'Kept (cleanup off)', 'fileora' ), isset( $fo_by['kept'] ) ? $fo_by['kept'] : 0 ),
						'failed'    => array( __( 'Deletion failed', 'fileora' ), isset( $fo_by['failed'] ) ? $fo_by['failed'] : 0 ),
						'done'      => array( __( 'Completed tasks', 'fileora' ), $fo_by['done'] ),
					);
					foreach ( $fo_filters as $fo_k => $fo_f ) :
						?>
						<a href="<?php echo esc_url( $fo_k ? add_query_arg( 'cleanup', $fo_k, $fo_url ) : $fo_url ); ?>" <?php echo $fo_k === $fo_filter ? 'aria-current="page"' : ''; ?>><?php echo esc_html( $fo_f[0] . ' ' . $fo_f[1] ); ?></a>
					<?php endforeach; ?>
				</nav>
			</div>
			<div class="fo-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Temporary task folders', 'fileora' ); ?>">
			<table class="widefat striped fo-table fo-temp">
				<thead><tr>
					<th><?php esc_html_e( 'Task', 'fileora' ); ?></th>
					<th><?php esc_html_e( 'File', 'fileora' ); ?></th>
					<th class="num"><?php esc_html_e( 'Size', 'fileora' ); ?></th>
					<th><?php esc_html_e( 'Status', 'fileora' ); ?></th>
					<th><?php esc_html_e( 'Created', 'fileora' ); ?></th>
					<th><?php esc_html_e( 'Expires / time left', 'fileora' ); ?></th>
					<th><?php esc_html_e( 'Cleanup', 'fileora' ); ?></th>
					<th><?php esc_html_e( 'Error', 'fileora' ); ?></th>
					<th><span class="sr"><?php esc_html_e( 'Actions', 'fileora' ); ?></span></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $fo_rows ) : ?>
					<tr><td colspan="9" class="fo-empty"><?php echo $fo_all ? esc_html__( 'No task folders match this filter.', 'fileora' ) : esc_html__( 'The temporary directory is empty.', 'fileora' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $fo_rows as $fo_t ) : ?>
					<?php list( $fo_cl, $fo_cs ) = Fileora_Temp_Cleanup::cleanup_label( $fo_t['cleanup'], $fo_t ); ?>
					<tr<?php echo $fo_t['id'] === $fo_task_id ? ' class="is-selected"' : ''; ?>>
						<td><code class="fo-id" title="<?php echo esc_attr( $fo_t['id'] ); ?>"><?php echo esc_html( substr( $fo_t['id'], 0, 8 ) ); ?></code><br><span class="fo-sub"><?php echo esc_html( $fo_t['tool'] ? fo_admin_tool_name( $fo_t['tool'] ) : fo_admin_na() ); ?></span></td>
						<td class="nowrap"><?php echo esc_html( $fo_t['result'] ? substr( $fo_t['id'], 0, 8 ) . '.' . $fo_t['result'] : ( 'running' === $fo_t['status'] || 'queued' === $fo_t['status'] ? __( 'upload / work files', 'fileora' ) : __( 'no result', 'fileora' ) ) ); ?><br><span class="fo-sub"><?php echo esc_html( sprintf( _n( '%d file', '%d files', (int) $fo_t['files'], 'fileora' ), (int) $fo_t['files'] ) ); ?></span></td>
						<td class="num nowrap"><?php echo esc_html( fo_admin_bytes( $fo_t['size'] ) ); ?></td>
						<td><?php echo esc_html( isset( $fo_status_names[ $fo_t['status'] ] ) ? $fo_status_names[ $fo_t['status'] ] : $fo_t['status'] ); ?></td>
						<td class="nowrap"><?php echo esc_html( fo_admin_short_time( $fo_t['created'] ) ); ?></td>
						<td class="nowrap"><?php echo esc_html( fo_admin_short_time( $fo_t['expires'] ) ); ?><br><span class="fo-sub"><?php echo esc_html( 'active' === $fo_t['cleanup'] ? __( 'kept while in use', 'fileora' ) : ( $fo_t['remaining'] > 0 ? sprintf( __( '%s left', 'fileora' ), fo_admin_duration( $fo_t['remaining'] ) ) : sprintf( __( 'expired %s ago', 'fileora' ), human_time_diff( (int) $fo_t['expires'] ) ) ) ); ?></span></td>
						<td><?php echo fo_admin_status( $fo_cs, $fo_cl ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
						<td class="fo-err"><?php echo esc_html( trim( $fo_t['error'] . ' ' . $fo_t['cleanup_error'] ) ); ?></td>
						<td class="nowrap">
							<a href="<?php echo esc_url( add_query_arg( 'task', $fo_t['id'], $fo_url ) ); ?>"><?php esc_html_e( 'Details', 'fileora' ); ?><span class="sr"> <?php echo esc_html( substr( $fo_t['id'], 0, 8 ) ); ?></span></a>
							<?php if ( $fo_can && 'active' !== $fo_t['cleanup'] ) : ?>
								<br><a class="fo-del" href="<?php echo esc_url( add_query_arg( array( 'confirm' => 'delete', 'task' => $fo_t['id'] ), $fo_url ) ); ?>"><?php esc_html_e( 'Delete', 'fileora' ); ?><span class="sr"> <?php echo esc_html( substr( $fo_t['id'], 0, 8 ) ); ?></span></a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
			<?php if ( ! empty( $fo_sum['ignored'] ) ) : ?>
				<p class="description"><?php echo esc_html( sprintf( _n( '%d other item in the temporary directory isn’t a task folder; the cleanup leaves it alone.', '%d other items in the temporary directory aren’t task folders; the cleanup leaves them alone.', (int) $fo_sum['ignored'], 'fileora' ), (int) $fo_sum['ignored'] ) ); ?></p>
			<?php endif; ?>
		</section>

		<?php $fo_fail = isset( $fo_st['failures'] ) ? (array) $fo_st['failures'] : array(); ?>
		<?php if ( $fo_fail ) : ?>
			<section class="fo-card">
				<h2><?php esc_html_e( 'Failed deletions', 'fileora' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Each run tries these again. Retry now, or check the service log on the server (journalctl -u fileora).', 'fileora' ); ?></p>
				<table class="widefat striped fo-table">
					<thead><tr><th><?php esc_html_e( 'Task', 'fileora' ); ?></th><th class="num"><?php esc_html_e( 'Attempts', 'fileora' ); ?></th><th><?php esc_html_e( 'Last attempt', 'fileora' ); ?></th><th><?php esc_html_e( 'Error', 'fileora' ); ?></th><th><span class="sr"><?php esc_html_e( 'Actions', 'fileora' ); ?></span></th></tr></thead>
					<tbody>
					<?php foreach ( $fo_fail as $fo_f ) : ?>
						<tr>
							<td><code class="fo-id" title="<?php echo esc_attr( $fo_f['task'] ); ?>"><?php echo esc_html( substr( $fo_f['task'], 0, 8 ) ); ?></code></td>
							<td class="num"><?php echo esc_html( (int) $fo_f['attempts'] ); ?></td>
							<td class="nowrap"><?php echo esc_html( $fo_when( isset( $fo_f['last'] ) ? $fo_f['last'] : 0 ) ); ?></td>
							<td class="fo-err"><?php echo esc_html( isset( $fo_f['error'] ) ? $fo_f['error'] : '' ); ?></td>
							<td>
								<?php if ( $fo_can ) : ?>
									<form method="post" action="<?php echo esc_url( $fo_post ); ?>">
										<input type="hidden" name="action" value="fileora_cleanup_retry">
										<input type="hidden" name="task" value="<?php echo esc_attr( $fo_f['task'] ); ?>">
										<?php wp_nonce_field( 'fileora_cleanup_retry_' . $fo_f['task'] ); ?>
										<button class="button button-small"><?php esc_html_e( 'Retry', 'fileora' ); ?><span class="sr"> <?php echo esc_html( substr( $fo_f['task'], 0, 8 ) ); ?></span></button>
									</form>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</section>
		<?php endif; ?>

		<section class="fo-card">
			<h2><?php esc_html_e( 'Cleanup history', 'fileora' ); ?></h2>
			<?php if ( $fo_o['history'] ) : ?>
				<div class="fo-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Cleanup history', 'fileora' ); ?>">
				<table class="widefat striped fo-table">
					<thead><tr><th><?php esc_html_e( 'Time', 'fileora' ); ?></th><th><?php esc_html_e( 'What', 'fileora' ); ?></th><th><?php esc_html_e( 'By', 'fileora' ); ?></th><th><?php esc_html_e( 'Result', 'fileora' ); ?></th><th class="num"><?php esc_html_e( 'Freed', 'fileora' ); ?></th><th><?php esc_html_e( 'Details', 'fileora' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $fo_o['history'] as $fo_h ) : ?>
						<?php
						$fo_mode = isset( $fo_h['mode'] ) ? $fo_h['mode'] : '';
						$fo_det  = '';
						if ( 'settings' === $fo_mode && ! empty( $fo_h['changes'] ) ) {
							$fo_parts = array();
							foreach ( (array) $fo_h['changes'] as $fo_k => $fo_v ) {
								$fo_fmt     = function ( $x ) use ( $fo_k ) {
									return 'enabled' === $fo_k ? ( $x ? __( 'on', 'fileora' ) : __( 'off', 'fileora' ) ) : fo_admin_duration( (int) $x * 60 );
								};
								$fo_names   = array(
									'enabled'      => __( 'automatic cleanup', 'fileora' ),
									'ttl_min'      => __( 'expiry', 'fileora' ),
									'interval_min' => __( 'interval', 'fileora' ),
								);
								$fo_parts[] = ( isset( $fo_names[ $fo_k ] ) ? $fo_names[ $fo_k ] : $fo_k ) . ': ' . $fo_fmt( $fo_v[0] ) . ' → ' . $fo_fmt( $fo_v[1] );
							}
							$fo_det = implode( '; ', $fo_parts );
						} elseif ( 'blocked' === $fo_mode || 'error' === $fo_mode ) {
							$fo_det = isset( $fo_h['reason'] ) ? (string) $fo_h['reason'] : '';
						} elseif ( ! empty( $fo_h['errors'] ) ) {
							$fo_parts = array();
							foreach ( (array) $fo_h['errors'] as $fo_e ) {
								$fo_parts[] = substr( (string) $fo_e['task'], 0, 8 ) . ': ' . $fo_e['error'];
							}
							$fo_det = implode( '; ', $fo_parts );
						} elseif ( ! empty( $fo_h['skipped_active'] ) ) {
							$fo_det = sprintf( _n( '%d active task left alone', '%d active tasks left alone', (int) $fo_h['skipped_active'], 'fileora' ), (int) $fo_h['skipped_active'] );
						}
						$fo_by_h = isset( $fo_h['actor'] ) && '' !== $fo_h['actor'] ? preg_replace( '/^wp-user:\d+:([^ ]+).*$/', '$1', $fo_h['actor'] ) : ( 'schedule' === $fo_h['trigger'] ? __( 'Schedule', 'fileora' ) : fo_admin_na() );
						?>
						<tr>
							<td class="nowrap"><?php echo esc_html( $fo_when( isset( $fo_h['finished'] ) ? $fo_h['finished'] : $fo_h['started'] ) ); ?></td>
							<td><?php echo esc_html( Fileora_Temp_Cleanup::trigger_label( $fo_h['trigger'] ) ); ?></td>
							<td><?php echo esc_html( $fo_by_h ); ?></td>
							<td>
								<?php
								if ( 'blocked' === $fo_mode ) {
									echo fo_admin_status( 'critical', __( 'Blocked: nothing deleted', 'fileora' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								} elseif ( 'settings' === $fo_mode ) {
									echo fo_admin_status( 'good', __( 'Saved', 'fileora' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								} else {
									echo fo_admin_status( ! empty( $fo_h['failed'] ) ? 'warning' : 'good', sprintf( __( '%1$d deleted, %2$d failed', 'fileora' ), isset( $fo_h['deleted'] ) ? (int) $fo_h['deleted'] : 0, isset( $fo_h['failed'] ) ? (int) $fo_h['failed'] : 0 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								}
								?>
							</td>
							<td class="num"><?php echo esc_html( isset( $fo_h['freed'] ) ? fo_admin_bytes( $fo_h['freed'] ) : '–' ); ?></td>
							<td class="fo-err"><?php echo esc_html( $fo_det ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				</div>
				<p class="description"><?php esc_html_e( 'Scheduled runs that found nothing to delete are counted above but not listed.', 'fileora' ); ?></p>
			<?php else : ?>
				<p class="fo-empty"><?php esc_html_e( 'No cleanup has deleted anything yet.', 'fileora' ); ?></p>
			<?php endif; ?>
		</section>
	<?php endif; ?>

	<section class="fo-card">
		<h2><?php esc_html_e( 'Admin actions (audit log)', 'fileora' ); ?></h2>
		<?php $fo_audit = Fileora_Core_Log::audit_entries( 30 ); ?>
		<?php if ( $fo_audit ) : ?>
			<div class="fo-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Admin actions', 'fileora' ); ?>">
			<table class="widefat striped fo-table">
				<thead><tr><th><?php esc_html_e( 'Time', 'fileora' ); ?></th><th><?php esc_html_e( 'User', 'fileora' ); ?></th><th><?php esc_html_e( 'IP address', 'fileora' ); ?></th><th><?php esc_html_e( 'Action', 'fileora' ); ?></th><th><?php esc_html_e( 'Task', 'fileora' ); ?></th><th><?php esc_html_e( 'Result', 'fileora' ); ?></th><th><?php esc_html_e( 'Details', 'fileora' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $fo_audit as $fo_a ) : ?>
					<tr>
						<td class="nowrap"><?php echo esc_html( $fo_when( $fo_a['time'] ) ); ?></td>
						<td><?php echo esc_html( $fo_a['user'] ? $fo_a['user'] : '–' ); ?></td>
						<td><?php echo esc_html( $fo_a['ip'] ? $fo_a['ip'] : '–' ); ?></td>
						<td><code><?php echo esc_html( $fo_a['action'] ); ?></code></td>
						<td><?php echo $fo_a['target'] ? '<code class="fo-id">' . esc_html( substr( $fo_a['target'], 0, 8 ) ) . '</code>' : '–'; ?></td>
						<td><?php echo 'ok' === $fo_a['result'] ? fo_admin_status( 'good', __( 'Done', 'fileora' ) ) : ( 'refused' === $fo_a['result'] ? fo_admin_status( 'warning', __( 'Refused', 'fileora' ) ) : fo_admin_status( 'critical', __( 'Failed', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
						<td class="fo-err">
							<?php
							$fo_parts = array();
							foreach ( (array) $fo_a['details'] as $fo_k => $fo_v ) {
								$fo_parts[] = $fo_k . '=' . ( 'freed' === $fo_k ? size_format( (int) $fo_v ) : $fo_v );
							}
							echo esc_html( implode( ', ', $fo_parts ) );
							?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
		<?php else : ?>
			<p class="fo-empty"><?php esc_html_e( 'No admin actions yet.', 'fileora' ); ?></p>
		<?php endif; ?>
	</section>
</div>
