<?php
/**
 * Visitor Analytics: live dashboard. The page is a shell; admin/assets/analytics.js
 * fills it from the REST endpoints in class-reports.php and refreshes it every minute.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

$fo_ranges = array(
	'1m'  => __( 'Last 1 minute', 'fileora' ),
	'30m' => __( 'Last 30 minutes', 'fileora' ),
	'24h' => __( 'Last 24 hours', 'fileora' ),
	'7d'  => __( 'Last 7 days', 'fileora' ),
	'30d' => __( 'Last 30 days', 'fileora' ),
	'90d' => __( 'Last 90 days', 'fileora' ),
);
$fo_s      = Fileora_Core_Settings::get();
$fo_export = current_user_can( 'fileora_export_data' );
$fo_today  = Fileora_History::local_date( time() );
?>
<div class="wrap fo-wrap fo-an" id="fo-an">
	<div class="fo-an-head">
		<h1><?php esc_html_e( 'Visitor Analytics', 'fileora' ); ?></h1>
		<div class="fo-an-status" aria-live="polite">
			<span class="fo-live" id="fo-live" aria-hidden="true"></span>
			<span id="fo-updated"><?php esc_html_e( 'Loading…', 'fileora' ); ?></span>
			<button type="button" class="button" id="fo-refresh"><?php esc_html_e( 'Refresh now', 'fileora' ); ?></button>
			<label class="fo-auto"><input type="checkbox" id="fo-auto" checked> <?php esc_html_e( 'Update every minute', 'fileora' ); ?></label>
		</div>
	</div>
	<?php if ( empty( $fo_s['analytics'] ) ) : ?>
		<div class="notice notice-warning inline"><p><?php esc_html_e( 'Visitor analytics are switched off in Fileora → Settings, so no new visits are recorded.', 'fileora' ); ?></p></div>
	<?php endif; ?>

	<div class="fo-range" role="group" aria-label="<?php esc_attr_e( 'Time range', 'fileora' ); ?>">
		<?php foreach ( $fo_ranges as $fo_k => $fo_l ) : ?>
			<button type="button" class="fo-range-btn" data-range="<?php echo esc_attr( $fo_k ); ?>" aria-pressed="<?php echo '24h' === $fo_k ? 'true' : 'false'; ?>"><?php echo esc_html( $fo_l ); ?></button>
		<?php endforeach; ?>
		<button type="button" class="fo-range-btn" data-range="custom" aria-pressed="false" aria-controls="fo-custom" aria-expanded="false"><?php esc_html_e( 'Custom date range', 'fileora' ); ?></button>
	</div>
	<form class="fo-custom" id="fo-custom" hidden onsubmit="return false">
		<label><?php esc_html_e( 'From', 'fileora' ); ?> <input type="date" id="fo-from" max="<?php echo esc_attr( $fo_today ); ?>" required></label>
		<label><?php esc_html_e( 'To', 'fileora' ); ?> <input type="date" id="fo-to" max="<?php echo esc_attr( $fo_today ); ?>" required></label>
		<button type="submit" class="button button-primary" id="fo-apply"><?php esc_html_e( 'Show this period', 'fileora' ); ?></button>
		<span class="fo-muted" id="fo-custom-err" role="alert"></span>
	</form>
	<p class="fo-period" id="fo-period" aria-live="polite"></p>

	<div class="fo-kpis fo-an-kpis" id="fo-kpis" aria-busy="true">
		<?php
		$fo_tiles = array(
			'visits'     => array( __( 'Total visits', 'fileora' ), __( 'sessions in this period', 'fileora' ) ),
			'visitors'   => array( __( 'Unique visitors', 'fileora' ), __( 'different browsers', 'fileora' ) ),
			'active'     => array( __( 'Active now', 'fileora' ), __( 'visits active in the last 5 minutes', 'fileora' ) ),
			'page_views' => array( __( 'Page views', 'fileora' ), __( 'pages opened', 'fileora' ) ),
			'tool_runs'  => array( __( 'Tool runs', 'fileora' ), '' ),
			'files'      => array( __( 'Files processed', 'fileora' ), __( 'in successful runs', 'fileora' ) ),
		);
		foreach ( $fo_tiles as $fo_k => $fo_t ) :
			?>
			<div class="fo-kpi" data-kpi="<?php echo esc_attr( $fo_k ); ?>"><span class="fo-kpi-l"><?php echo esc_html( $fo_t[0] ); ?></span><b class="fo-kpi-v">–</b><span class="fo-kpi-s"><?php echo esc_html( $fo_t[1] ); ?></span></div>
		<?php endforeach; ?>
	</div>

	<div class="fo-an-grid">
		<section class="fo-card fo-w" id="w-loc" aria-labelledby="w-loc-h">
			<div class="fo-w-head">
				<h2 id="w-loc-h"><?php esc_html_e( 'Visitors by location', 'fileora' ); ?></h2>
				<div class="fo-seg" role="group" aria-label="<?php esc_attr_e( 'Location detail', 'fileora' ); ?>">
					<button type="button" data-level="country" aria-pressed="true"><?php esc_html_e( 'Country', 'fileora' ); ?></button>
					<button type="button" data-level="region" aria-pressed="false"><?php esc_html_e( 'State / region', 'fileora' ); ?></button>
					<button type="button" data-level="city" aria-pressed="false"><?php esc_html_e( 'City', 'fileora' ); ?></button>
				</div>
			</div>
			<div class="fo-loc">
				<div class="fo-loc-chart"><canvas id="c-loc" role="img" aria-label="<?php esc_attr_e( 'Doughnut chart of unique visitors by location', 'fileora' ); ?>"></canvas><div class="fo-loc-mid"><b id="loc-total">–</b><span><?php esc_html_e( 'visitors', 'fileora' ); ?></span></div></div>
				<ol class="fo-legend" id="loc-legend"></ol>
			</div>
			<p class="fo-empty" id="loc-empty" hidden><?php esc_html_e( 'No visitors in this period yet.', 'fileora' ); ?></p>
			<p class="fo-note" id="loc-note"></p>
		</section>

		<section class="fo-card fo-w" id="w-rt" aria-labelledby="w-rt-h">
			<div class="fo-w-head">
				<h2 id="w-rt-h"><?php esc_html_e( 'Real-time traffic', 'fileora' ); ?></h2>
				<span class="fo-sub"><?php esc_html_e( 'Visitors per minute, last 30 minutes', 'fileora' ); ?></span>
			</div>
			<div class="fo-chart-box"><canvas id="c-rt" role="img" aria-label="<?php esc_attr_e( 'Bar chart of visitors per minute in the last 30 minutes, split by country', 'fileora' ); ?>"></canvas></div>
			<ul class="fo-legend fo-legend-row" id="rt-legend"></ul>
			<p class="fo-note" id="rt-note"></p>
		</section>
	</div>

	<section class="fo-card fo-w" id="w-ts" aria-labelledby="w-ts-h">
		<div class="fo-w-head">
			<h2 id="w-ts-h"><?php esc_html_e( 'Traffic over time', 'fileora' ); ?></h2>
			<div class="fo-w-tools">
				<div class="fo-seg" role="group" aria-label="<?php esc_attr_e( 'Interval', 'fileora' ); ?>">
					<button type="button" data-interval="minute" aria-pressed="false"><?php esc_html_e( 'Per minute', 'fileora' ); ?></button>
					<button type="button" data-interval="hour" aria-pressed="false"><?php esc_html_e( 'Per hour', 'fileora' ); ?></button>
					<button type="button" data-interval="day" aria-pressed="false"><?php esc_html_e( 'Per day', 'fileora' ); ?></button>
				</div>
				<button type="button" class="button button-small" data-table-toggle="ts-table" aria-expanded="false"><?php esc_html_e( 'Show table', 'fileora' ); ?></button>
			</div>
		</div>
		<p class="fo-sub" id="ts-sub"></p>
		<ul class="fo-legend fo-legend-row"><li><i class="fo-sw fo-sw-line" style="background:var(--s1)"></i><?php esc_html_e( 'Unique visitors', 'fileora' ); ?></li><li><i class="fo-sw fo-sw-line" style="background:var(--s2)"></i><?php esc_html_e( 'Tool runs', 'fileora' ); ?></li><li><i class="fo-sw fo-sw-line" style="background:var(--s3)"></i><?php esc_html_e( 'Files processed', 'fileora' ); ?></li></ul>
		<div class="fo-chart-box fo-chart-tall"><canvas id="c-ts" role="img" aria-label="<?php esc_attr_e( 'Line chart of unique visitors, tool runs and files processed per interval in the selected period', 'fileora' ); ?>"></canvas></div>
		<p class="fo-note" id="ts-note"></p>
		<div id="ts-table" hidden><div class="fo-table-wrap" id="ts-table-in"></div><div class="fo-pager" id="ts-pager"></div></div>
	</section>

	<section class="fo-card fo-w" id="w-cmp" aria-labelledby="w-cmp-h">
		<div class="fo-w-head">
			<h2 id="w-cmp-h"><?php esc_html_e( 'Visitors vs. tool runs', 'fileora' ); ?></h2>
			<div class="fo-w-tools">
				<label><span class="screen-reader-text"><?php esc_html_e( 'Period', 'fileora' ); ?></span><select id="cmp-days"><option value="7"><?php esc_html_e( 'Last 7 days', 'fileora' ); ?></option><option value="30" selected><?php esc_html_e( 'Last 30 days', 'fileora' ); ?></option><option value="90"><?php esc_html_e( 'Last 90 days', 'fileora' ); ?></option><option value="180"><?php esc_html_e( 'Last 180 days', 'fileora' ); ?></option><option value="365"><?php esc_html_e( 'Last 365 days', 'fileora' ); ?></option><option value="range"><?php esc_html_e( 'Same as the period above', 'fileora' ); ?></option></select></label>
				<div class="fo-seg" role="group" aria-label="<?php esc_attr_e( 'Group by', 'fileora' ); ?>">
					<button type="button" data-group="day" aria-pressed="true"><?php esc_html_e( 'Daily', 'fileora' ); ?></button>
					<button type="button" data-group="week" aria-pressed="false"><?php esc_html_e( 'Weekly', 'fileora' ); ?></button>
					<button type="button" data-group="month" aria-pressed="false"><?php esc_html_e( 'Monthly', 'fileora' ); ?></button>
				</div>
				<button type="button" class="button button-small" data-table-toggle="cmp-table" aria-expanded="false"><?php esc_html_e( 'Show table', 'fileora' ); ?></button>
			</div>
		</div>
		<ul class="fo-legend fo-legend-row"><li><i class="fo-sw" style="background:var(--s1)"></i><?php esc_html_e( 'Unique visitors (bars)', 'fileora' ); ?></li><li><i class="fo-sw fo-sw-line" style="background:var(--s2)"></i><?php esc_html_e( 'Tool runs (line)', 'fileora' ); ?></li></ul>
		<div class="fo-chart-box fo-chart-tall"><canvas id="c-cmp" role="img" aria-label="<?php esc_attr_e( 'Chart comparing unique visitors and tool runs per period', 'fileora' ); ?>"></canvas></div>
		<p class="fo-note" id="cmp-note"></p>
		<div class="fo-table-wrap" id="cmp-table" hidden></div>
	</section>

	<section class="fo-card fo-w" id="w-tools" aria-labelledby="w-tools-h">
		<div class="fo-w-head">
			<h2 id="w-tools-h"><?php esc_html_e( 'Tool usage', 'fileora' ); ?></h2>
			<span class="fo-sub"><?php esc_html_e( 'Selected period. Tools with no visits or runs are not listed.', 'fileora' ); ?></span>
		</div>
		<div class="fo-table-wrap" id="tools-table" aria-live="polite"></div>
	</section>

	<section class="fo-card fo-w" id="w-act" aria-labelledby="w-act-h">
		<div class="fo-w-head">
			<h2 id="w-act-h"><?php esc_html_e( 'Latest file processing', 'fileora' ); ?></h2>
			<span class="fo-sub"><?php esc_html_e( 'Newest first, selected period (or the dates set here). File contents are never stored, only the details below.', 'fileora' ); ?></span>
		</div>
		<form class="fo-filters" data-list="act" onsubmit="return false">
			<input type="search" name="search" placeholder="<?php esc_attr_e( 'File name, city or IP', 'fileora' ); ?>" aria-label="<?php esc_attr_e( 'Search', 'fileora' ); ?>">
			<select name="tool" aria-label="<?php esc_attr_e( 'Tool', 'fileora' ); ?>"><option value=""><?php esc_html_e( 'All tools', 'fileora' ); ?></option></select>
			<select name="status" aria-label="<?php esc_attr_e( 'Status', 'fileora' ); ?>"><option value=""><?php esc_html_e( 'All statuses', 'fileora' ); ?></option><option value="done"><?php esc_html_e( 'Completed', 'fileora' ); ?></option><option value="failed"><?php esc_html_e( 'Failed', 'fileora' ); ?></option><option value="progress"><?php esc_html_e( 'In progress', 'fileora' ); ?></option></select>
			<select name="country" aria-label="<?php esc_attr_e( 'Country', 'fileora' ); ?>"><option value=""><?php esc_html_e( 'All locations', 'fileora' ); ?></option></select>
			<label><?php esc_html_e( 'From', 'fileora' ); ?> <input type="date" name="from"></label>
			<label><?php esc_html_e( 'To', 'fileora' ); ?> <input type="date" name="to"></label>
			<button type="reset" class="button-link"><?php esc_html_e( 'Clear', 'fileora' ); ?></button>
		</form>
		<div class="fo-table-wrap" id="act-table" aria-live="polite"></div>
		<div class="fo-pager" id="act-pager"></div>
	</section>

	<section class="fo-card fo-w" id="w-vis" aria-labelledby="w-vis-h">
		<div class="fo-w-head">
			<h2 id="w-vis-h"><?php esc_html_e( 'Visits', 'fileora' ); ?></h2>
			<span class="fo-sub"><?php esc_html_e( 'One row per visit with activity in the selected period (or the dates set here). A visit ends after 30 minutes without activity.', 'fileora' ); ?></span>
		</div>
		<form class="fo-filters" data-list="vis" onsubmit="return false">
			<input type="search" name="search" placeholder="<?php esc_attr_e( 'Visitor ID, city, page, referrer or IP', 'fileora' ); ?>" aria-label="<?php esc_attr_e( 'Search', 'fileora' ); ?>">
			<select name="country" aria-label="<?php esc_attr_e( 'Country', 'fileora' ); ?>"><option value=""><?php esc_html_e( 'All locations', 'fileora' ); ?></option></select>
			<label><?php esc_html_e( 'From', 'fileora' ); ?> <input type="date" name="from"></label>
			<label><?php esc_html_e( 'To', 'fileora' ); ?> <input type="date" name="to"></label>
			<label class="fo-check"><input type="checkbox" name="status" value="active"> <?php esc_html_e( 'Active now only', 'fileora' ); ?></label>
			<button type="reset" class="button-link"><?php esc_html_e( 'Clear', 'fileora' ); ?></button>
		</form>
		<div class="fo-table-wrap" id="vis-table" aria-live="polite"></div>
		<div class="fo-pager" id="vis-pager"></div>
	</section>

	<div class="fo-an-grid fo-an-grid3">
		<section class="fo-card fo-w" aria-labelledby="w-top-h"><h2 id="w-top-h"><?php esc_html_e( 'Most-used tools', 'fileora' ); ?></h2><div id="top-tools"></div></section>
		<section class="fo-card fo-w" aria-labelledby="w-dev-h"><h2 id="w-dev-h"><?php esc_html_e( 'Devices', 'fileora' ); ?></h2><div id="bd-device"></div></section>
		<section class="fo-card fo-w" aria-labelledby="w-br-h"><h2 id="w-br-h"><?php esc_html_e( 'Browsers and systems', 'fileora' ); ?></h2><div id="bd-browser"></div><div id="bd-os"></div></section>
	</div>
	<?php if ( $fo_export ) : ?>
	<section class="fo-card fo-w" id="w-export" aria-labelledby="w-export-h">
		<h2 id="w-export-h"><?php esc_html_e( 'Export data (CSV)', 'fileora' ); ?></h2>
		<form method="get" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="fo-filters fo-export" id="fo-export">
			<input type="hidden" name="action" value="fileora_export_analytics">
			<?php wp_nonce_field( 'fileora_export_analytics', '_wpnonce', false ); ?>
			<label><?php esc_html_e( 'Data', 'fileora' ); ?>
				<select name="dataset">
					<option value="visits"><?php esc_html_e( 'Visits (one row per visit)', 'fileora' ); ?></option>
					<option value="events"><?php esc_html_e( 'Events (page views, tool pages, tool runs)', 'fileora' ); ?></option>
					<option value="processing"><?php esc_html_e( 'File processing (server tasks and browser runs)', 'fileora' ); ?></option>
					<option value="series"><?php esc_html_e( 'Traffic per minute, hour or day', 'fileora' ); ?></option>
					<option value="daily"><?php esc_html_e( 'Daily totals', 'fileora' ); ?></option>
					<option value="tools"><?php esc_html_e( 'Tool usage', 'fileora' ); ?></option>
				</select>
			</label>
			<label><?php esc_html_e( 'Period', 'fileora' ); ?>
				<select name="range">
					<option value="30m"><?php esc_html_e( 'Last 30 minutes', 'fileora' ); ?></option>
					<option value="24h"><?php esc_html_e( 'Last 24 hours', 'fileora' ); ?></option>
					<option value="7d"><?php esc_html_e( 'Last 7 days', 'fileora' ); ?></option>
					<option value="30d" selected><?php esc_html_e( 'Last 30 days', 'fileora' ); ?></option>
					<option value="90d"><?php esc_html_e( 'Last 90 days', 'fileora' ); ?></option>
					<option value="custom"><?php esc_html_e( 'Custom date range', 'fileora' ); ?></option>
				</select>
			</label>
			<label class="fo-x-custom" hidden><?php esc_html_e( 'From', 'fileora' ); ?> <input type="date" name="from" max="<?php echo esc_attr( $fo_today ); ?>"></label>
			<label class="fo-x-custom" hidden><?php esc_html_e( 'To', 'fileora' ); ?> <input type="date" name="to" max="<?php echo esc_attr( $fo_today ); ?>"></label>
			<label class="fo-x-series" hidden><?php esc_html_e( 'Interval', 'fileora' ); ?>
				<select name="interval"><option value=""><?php esc_html_e( 'Automatic', 'fileora' ); ?></option><option value="minute"><?php esc_html_e( 'Per minute (up to 1 day)', 'fileora' ); ?></option><option value="hour"><?php esc_html_e( 'Per hour (up to 90 days)', 'fileora' ); ?></option><option value="day"><?php esc_html_e( 'Per day', 'fileora' ); ?></option></select>
			</label>
			<label class="fo-check fo-x-events" hidden><input type="checkbox" name="pings" value="1"> <?php esc_html_e( 'Include “still here” signals', 'fileora' ); ?></label>
			<?php if ( current_user_can( 'fileora_view_ip' ) && 'none' !== $fo_s['ip_mode'] ) : ?>
				<label class="fo-check fo-x-ip"><input type="checkbox" name="ip" value="1"> <?php esc_html_e( 'Include IP addresses', 'fileora' ); ?></label>
			<?php endif; ?>
			<button type="submit" class="button button-primary"><?php esc_html_e( 'Download CSV', 'fileora' ); ?></button>
		</form>
		<p class="description"><?php esc_html_e( 'Times are given in the site’s time zone and in UTC. The file can contain visitor details: store and share it with care. Every export is recorded under Fileora → Settings → Analytics storage.', 'fileora' ); ?></p>
	</section>
	<?php endif; ?>

	<p class="fo-foot-note"><?php esc_html_e( 'Visits from administrators, search engines and bots are not counted. Tool runs = browser tool runs reported by the visitor’s browser + tasks done on the processing server. Times are in the site’s time zone.', 'fileora' ); ?></p>
</div>
