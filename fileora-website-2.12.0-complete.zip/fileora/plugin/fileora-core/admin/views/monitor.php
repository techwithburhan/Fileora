<?php
/**
 * Fileora → Server Monitoring.
 *
 * Network probe (ICMP ping or a labelled TCP/HTTP fallback), /health checks,
 * availability, and the processing server's own CPU, memory, disk, network
 * and uptime figures. Everything comes from stored checks; a value that
 * wasn't measured is shown as "Not Available".
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

$fo_ranges = array(
	'1h'  => array( 'label' => __( '1 hour', 'fileora' ), 'secs' => HOUR_IN_SECONDS, 'name' => __( 'last hour', 'fileora' ) ),
	'6h'  => array( 'label' => __( '6 hours', 'fileora' ), 'secs' => 6 * HOUR_IN_SECONDS, 'name' => __( 'last 6 hours', 'fileora' ) ),
	'24h' => array( 'label' => __( '24 hours', 'fileora' ), 'secs' => DAY_IN_SECONDS, 'name' => __( 'last 24 hours', 'fileora' ) ),
	'7d'  => array( 'label' => __( '7 days', 'fileora' ), 'secs' => 7 * DAY_IN_SECONDS, 'name' => __( 'last 7 days', 'fileora' ) ),
);
$fo_range = isset( $_GET['range'] ) && isset( $fo_ranges[ $_GET['range'] ] ) ? sanitize_key( $_GET['range'] ) : '24h'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$fo_win   = $fo_ranges[ $fo_range ]['secs'];
$fo_rname = $fo_ranges[ $fo_range ]['name'];
$fo_to    = time();
$fo_from  = $fo_to - $fo_win;

$fo_last    = Fileora_Server_Monitor::last();
$fo_u1      = Fileora_Server_Monitor::uptime( DAY_IN_SECONDS );
$fo_u7      = Fileora_Server_Monitor::uptime( 7 * DAY_IN_SECONDS );
$fo_u30     = Fileora_Server_Monitor::uptime( 30 * DAY_IN_SECONDS );
$fo_daily   = Fileora_Server_Monitor::daily( 30 );
$fo_both    = Fileora_Server_Monitor::checks( 2 * $fo_win );
$fo_checks  = array();
$fo_prev    = array();
foreach ( $fo_both as $fo_c ) {
	$fo_c->t = strtotime( $fo_c->checked_at . ' UTC' );
	if ( $fo_c->t >= $fo_from ) {
		$fo_checks[] = $fo_c;
	} else {
		$fo_prev[] = $fo_c;
	}
}
$fo_recent  = array_slice( array_reverse( $fo_checks ), 0, 30 );
$fo_success = Fileora_Server_Monitor::last_success();
$fo_body    = $fo_last && is_array( $fo_last['body'] ) ? $fo_last['body'] : array();
$fo_probe   = $fo_last && isset( $fo_last['probe'] ) && is_array( $fo_last['probe'] ) ? $fo_last['probe'] : null;
$fo_metrics = $fo_last && isset( $fo_last['metrics'] ) && is_array( $fo_last['metrics'] ) ? $fo_last['metrics'] : null;
$fo_merr    = $fo_last && isset( $fo_last['metrics_error'] ) ? (string) $fo_last['metrics_error'] : '';
$fo_next    = wp_next_scheduled( Fileora_Server_Monitor::HOOK );
$fo_minute  = (int) ( Fileora_Server_Monitor::interval() / 60 );
$fo_target  = Fileora_Net_Probe::target();
$fo_can     = current_user_can( 'fileora_manage_settings' );

// Series for the charts: [time, value, tooltip]. NULL = not measured (a gap).
$fo_n     = '7d' === $fo_range ? 336 : 400; // 7 days: 30-minute averages
$fo_gap   = max( 2 * Fileora_Server_Monitor::interval(), '7d' === $fo_range ? HOUR_IN_SECONDS : 0 );
$fo_col   = function ( $prop ) use ( $fo_checks ) {
	$out = array();
	foreach ( $fo_checks as $c ) {
		$out[] = array( $c->t, null === $c->$prop ? null : (float) $c->$prop );
	}
	return $out;
};
$fo_bucket = function ( array $pts ) use ( $fo_from, $fo_to, $fo_n ) {
	return fo_admin_bucket( $pts, $fo_from, $fo_to, $fo_n );
};
$fo_ping = array(
	'icmp' => array(),
	'tcp'  => array(),
	'http' => array(),
);
$fo_loss = array();
$fo_mcount = array();
$fo_down = array();
$fo_http_down = array();
foreach ( $fo_checks as $fo_c ) {
	if ( null !== $fo_c->probe ) {
		$fo_mcount[ $fo_c->probe ] = ( isset( $fo_mcount[ $fo_c->probe ] ) ? $fo_mcount[ $fo_c->probe ] : 0 ) + 1;
	}
	$fo_label   = $fo_c->probe ? Fileora_Net_Probe::label( $fo_c->probe, (int) $fo_c->probe_port ) : '';
	$fo_replies = null === $fo_c->probe_sent ? '' : sprintf( /* translators: 1: replies, 2: sent */ __( '%1$d/%2$d replies', 'fileora' ), (int) $fo_c->probe_recv, (int) $fo_c->probe_sent );
	// One series per method: ICMP and TCP/HTTP times measure different things, so they're never joined into one line.
	foreach ( array( 'icmp', 'tcp', 'http' ) as $fo_k ) {
		$fo_ping[ $fo_k ][] = array( $fo_c->t, $fo_k === $fo_c->probe && null !== $fo_c->probe_ms ? (float) $fo_c->probe_ms : null, null === $fo_c->probe_ms ? '' : fo_admin_rtt( $fo_c->probe_ms ) . ' · ' . $fo_label . ( $fo_replies ? ' · ' . $fo_replies : '' ) );
	}
	$fo_loss[]  = array( $fo_c->t, null === $fo_c->probe_loss ? null : (float) $fo_c->probe_loss, null === $fo_c->probe_loss ? '' : fo_admin_pct( $fo_c->probe_loss, 0 ) . ' ' . __( 'packet loss', 'fileora' ) . ( $fo_replies ? ' · ' . $fo_replies : '' ) . ' · ' . $fo_label );
	if ( null !== $fo_c->reachable && ! (int) $fo_c->reachable ) {
		$fo_down[] = $fo_c->t;
	}
	if ( ! (int) $fo_c->ok ) {
		$fo_http_down[] = $fo_c->t;
	}
}
if ( '7d' === $fo_range ) {
	foreach ( $fo_ping as $fo_k => $fo_v ) {
		$fo_ping[ $fo_k ] = $fo_bucket( $fo_v );
	}
	$fo_loss      = $fo_bucket( $fo_loss );
	$fo_size      = $fo_win / $fo_n;
	$fo_squash    = function ( array $times ) use ( $fo_from, $fo_size ) {
		$out = array();
		foreach ( $times as $t ) {
			$out[ (int) floor( ( $t - $fo_from ) / $fo_size ) ] = (int) ( $fo_from + ( floor( ( $t - $fo_from ) / $fo_size ) + 0.5 ) * $fo_size );
		}
		return array_values( $out );
	};
	$fo_down      = $fo_squash( $fo_down );
	$fo_http_down = $fo_squash( $fo_http_down );
}

/** Average, min and max of non-null values of a column. */
$fo_stats = function ( array $rows, $prop ) {
	$v = array();
	foreach ( $rows as $r ) {
		if ( null !== $r->$prop ) {
			$v[] = (float) $r->$prop;
		}
	}
	return $v ? array( 'avg' => array_sum( $v ) / count( $v ), 'min' => min( $v ), 'max' => max( $v ), 'n' => count( $v ) ) : null;
};
$fo_ps   = $fo_stats( $fo_checks, 'probe_ms' );
$fo_pp   = $fo_stats( $fo_prev, 'probe_ms' );
$fo_ls   = $fo_stats( $fo_checks, 'probe_loss' );
$fo_hs   = $fo_stats( $fo_checks, 'latency_ms' );
$fo_has_metrics = false;
foreach ( $fo_checks as $fo_c ) {
	if ( null !== $fo_c->cpu_pct || null !== $fo_c->mem_pct || null !== $fo_c->disk_pct ) {
		$fo_has_metrics = true;
		break;
	}
}
$fo_m = function ( $path ) use ( $fo_metrics ) {
	$v = $fo_metrics;
	foreach ( explode( '.', $path ) as $k ) {
		if ( ! is_array( $v ) || ! array_key_exists( $k, $v ) ) {
			return null;
		}
		$v = $v[ $k ];
	}
	return $v;
};
$fo_icmp_note = array(
	'ok'          => '',
	'off'         => '',
	'no-reply'    => __( 'ICMP got no replies (the EC2 security group probably doesn’t allow ping), so this is a TCP connect check.', 'fileora' ),
	'unavailable' => __( 'PHP on this web host can’t run ping (exec() is disabled or there is no ping program), so this is a TCP connect check.', 'fileora' ),
	'error'       => __( 'ping couldn’t run on this host, so this is a TCP connect check.', 'fileora' ),
);
?>
<div class="wrap fo-wrap">
	<div class="fo-head">
		<h1><?php esc_html_e( 'Server Monitoring', 'fileora' ); ?></h1>
		<?php fo_admin_range_nav( 'fileora-monitor', $fo_range, $fo_ranges ); ?>
		<?php if ( $fo_can ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="fileora_check_now">
				<?php wp_nonce_field( 'fileora_check_now' ); ?>
				<button class="button button-primary"><?php esc_html_e( 'Check now', 'fileora' ); ?></button>
			</form>
		<?php endif; ?>
	</div>
	<?php if ( isset( $_GET['checked'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Health check done.', 'fileora' ); ?></p></div>
	<?php endif; ?>
	<?php if ( $fo_last && ! Fileora_Server_Monitor::schedule_ok() ) : ?>
		<div class="notice notice-warning"><p><?php echo esc_html( sprintf( __( 'No scheduled check for %s. WP-Cron isn’t running often enough: set up a real cron job (README section 7.9, “Real cron”).', 'fileora' ), human_time_diff( $fo_last['time'] ) ) ); ?></p></div>
	<?php endif; ?>
	<p class="fo-lead">
		<?php
		echo esc_html(
			sprintf(
				/* translators: 1: server host, 2: minutes */
				__( 'Every %2$d minutes WordPress measures the network path from this web host to %1$s, asks the processing server for /health and, with the shared key, for its CPU, memory, disk, network and uptime figures.', 'fileora' ),
				'' !== $fo_target['host'] ? $fo_target['host'] : __( '(no server address)', 'fileora' ),
				$fo_minute
			)
		);
		if ( $fo_next ) {
			echo ' ' . esc_html( sprintf( __( 'Next check in %s.', 'fileora' ), human_time_diff( $fo_next ) ) );
		}
		?>
	</p>

	<h2 class="fo-h2"><?php esc_html_e( 'Network and API', 'fileora' ); ?></h2>
	<div class="fo-kpis">
		<?php
		if ( $fo_probe && null !== $fo_probe['reachable'] ) {
			fo_admin_kpi( __( 'Reachability now', 'fileora' ), $fo_probe['reachable'] ? __( 'Reachable', 'fileora' ) : __( 'Unreachable', 'fileora' ), Fileora_Net_Probe::label( $fo_probe['method'], $fo_probe['port'] ) . ' · ' . sprintf( __( '%s ago', 'fileora' ), human_time_diff( $fo_last['time'] ) ), $fo_probe['reachable'] ? 'good' : 'critical' );
			fo_admin_kpi( __( 'Latency, last check', 'fileora' ), fo_admin_rtt( $fo_probe['avg_ms'] ), $fo_ps ? sprintf( /* translators: 1: average, 2: range */ __( 'average %1$s, %2$s', 'fileora' ), fo_admin_rtt( $fo_ps['avg'] ), $fo_rname ) : fo_admin_na() );
			fo_admin_kpi( __( 'Packet loss, last check', 'fileora' ), null === $fo_probe['loss'] ? fo_admin_na() : fo_admin_pct( $fo_probe['loss'], 0 ), $fo_ls ? sprintf( __( 'average %1$s, %2$s', 'fileora' ), fo_admin_pct( $fo_ls['avg'] ), $fo_rname ) : fo_admin_na(), null === $fo_probe['loss'] ? '' : ( $fo_probe['loss'] >= 50 ? 'critical' : ( $fo_probe['loss'] > 0 ? 'warning' : 'good' ) ) );
		} else {
			fo_admin_kpi( __( 'Reachability now', 'fileora' ), fo_admin_na(), $fo_last ? __( 'no network probe yet: press Check now', 'fileora' ) : __( 'no check yet', 'fileora' ), 'unknown' );
			fo_admin_kpi( __( 'Latency, last check', 'fileora' ), fo_admin_na(), '' );
			fo_admin_kpi( __( 'Packet loss, last check', 'fileora' ), fo_admin_na(), '' );
		}
		fo_admin_kpi( __( 'Last successful check', 'fileora' ), $fo_success ? sprintf( __( '%s ago', 'fileora' ), human_time_diff( $fo_success ) ) : fo_admin_na(), $fo_success ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $fo_success ) : '' );
		if ( $fo_last ) {
			$fo_state = $fo_last['ok'] && false !== $fo_last['auth'] ? 'good' : 'critical';
			fo_admin_kpi( __( 'API health (/health)', 'fileora' ), $fo_last['ok'] ? ( false === $fo_last['auth'] ? __( 'Key rejected', 'fileora' ) : __( 'Up', 'fileora' ) ) : __( 'Down', 'fileora' ), ( $fo_last['http'] ? 'HTTP ' . (int) $fo_last['http'] . ' · ' : '' ) . fo_admin_ms( $fo_last['latency_ms'] ), $fo_state );
		} else {
			fo_admin_kpi( __( 'API health (/health)', 'fileora' ), fo_admin_na(), __( 'no check yet', 'fileora' ), 'unknown' );
		}
		fo_admin_kpi( __( 'Monitoring', 'fileora' ), sprintf( __( 'Every %d min', 'fileora' ), $fo_minute ), $fo_last && ! Fileora_Server_Monitor::schedule_ok() ? __( 'not running on time', 'fileora' ) : ( $fo_next ? sprintf( __( 'next in %s', 'fileora' ), human_time_diff( $fo_next ) ) : __( 'not scheduled', 'fileora' ) ), $fo_last && ! Fileora_Server_Monitor::schedule_ok() ? 'warning' : '' );
		?>
	</div>
	<?php if ( $fo_probe ) : ?>
		<p class="fo-method">
			<?php
			echo fo_admin_status( 'icmp' === $fo_probe['method'] ? 'good' : 'warning', sprintf( __( 'Method: %s', 'fileora' ), Fileora_Net_Probe::label( $fo_probe['method'], $fo_probe['port'] ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$fo_why = isset( $fo_icmp_note[ $fo_probe['icmp'] ] ) ? $fo_icmp_note[ $fo_probe['icmp'] ] : '';
			if ( 'http' === $fo_probe['method'] ) {
				$fo_why = __( 'The /health response time is used as the latency (Settings → Monitoring method).', 'fileora' );
			}
			if ( 'tcp' === $fo_probe['method'] && 'off' === $fo_probe['icmp'] ) {
				$fo_why = __( 'TCP connect time was chosen in Settings → Monitoring method.', 'fileora' );
			}
			echo ' <span class="fo-sub">' . esc_html( trim( $fo_why . ' ' . ( $fo_probe['note'] && ! $fo_why ? $fo_probe['note'] : '' ) ) ) . '</span>';
			if ( count( $fo_mcount ) > 1 ) {
				$fo_parts = array();
				foreach ( $fo_mcount as $fo_k => $fo_v ) {
					/* translators: 1: method, 2: number of checks */
					$fo_parts[] = sprintf( _n( '%1$s: %2$d check', '%1$s: %2$d checks', $fo_v, 'fileora' ), Fileora_Net_Probe::label( $fo_k, $fo_target['port'] ), $fo_v );
				}
				echo ' <span class="fo-sub">' . esc_html( sprintf( __( 'Methods used in this period: %s.', 'fileora' ), implode( '; ', $fo_parts ) ) ) . '</span>';
			}
			?>
		</p>
	<?php endif; ?>

	<div class="fo-row">
		<section class="fo-card fo-grow">
			<h2>
				<?php
				echo esc_html( count( $fo_mcount ) > 1 ? sprintf( __( 'Network latency, %s', 'fileora' ), $fo_rname ) : sprintf( /* translators: 1: method, 2: range */ __( 'Latency (%1$s), %2$s', 'fileora' ), $fo_probe ? Fileora_Net_Probe::label( $fo_probe['method'], $fo_probe['port'] ) : __( 'network probe', 'fileora' ), $fo_rname ) );
				?>
			</h2>
			<?php
			$fo_ping_series = array();
			$fo_classes     = array( 'icmp' => 's1', 'tcp' => 's2', 'http' => 's3' );
			foreach ( $fo_ping as $fo_k => $fo_v ) {
				if ( ! empty( $fo_mcount[ $fo_k ] ) ) {
					$fo_ping_series[] = array( 'name' => Fileora_Net_Probe::label( $fo_k, $fo_target['port'] ), 'class' => $fo_classes[ $fo_k ], 'points' => $fo_v );
				}
			}
			?>
			<?php if ( $fo_ps && $fo_ping_series ) : ?>
				<p class="fo-sub fo-chart-note">
					<?php
					echo esc_html( sprintf( /* translators: 1: avg, 2: min, 3: max, 4: count */ __( 'Average %1$s · min %2$s · max %3$s · %4$d measurements', 'fileora' ), fo_admin_rtt( $fo_ps['avg'] ), fo_admin_rtt( $fo_ps['min'] ), fo_admin_rtt( $fo_ps['max'] ), $fo_ps['n'] ) );
					if ( $fo_pp ) {
						$fo_delta = $fo_ps['avg'] - $fo_pp['avg'];
						echo ' · ' . esc_html( sprintf( __( '%1$s%2$s against the period before', 'fileora' ), $fo_delta >= 0 ? '+' : '−', fo_admin_rtt( abs( $fo_delta ) ) ) );
					}
					?>
				</p>
				<?php
				fo_admin_timechart(
					array(
						'title'  => __( 'Network latency of each check in milliseconds; red lines are checks where the server was unreachable', 'fileora' ),
						'from'   => $fo_from,
						'to'     => $fo_to,
						'series' => $fo_ping_series,
						'format' => 'fo_admin_rtt',
						'down'   => $fo_down,
						'gap'    => $fo_gap,
						'width'  => 1200,
					)
				);
				?>
			<?php else : ?>
				<p class="fo-empty"><?php echo esc_html( fo_admin_na() . ': ' . __( 'no network measurements in this period. They start with the next check (or press Check now).', 'fileora' ) ); ?></p>
			<?php endif; ?>
		</section>
	</div>

	<div class="fo-row">
		<section class="fo-card fo-grow">
			<h2><?php echo esc_html( sprintf( __( 'Packet loss, %s', 'fileora' ), $fo_rname ) ); ?></h2>
			<?php if ( $fo_ls ) : ?>
				<p class="fo-sub fo-chart-note"><?php echo esc_html( $fo_ls['max'] > 0 ? sprintf( /* translators: 1: average, 2: worst */ __( 'Average %1$s · worst check %2$s', 'fileora' ), fo_admin_pct( $fo_ls['avg'] ), fo_admin_pct( $fo_ls['max'], 0 ) ) : sprintf( _n( 'No packet loss in %d measurement.', 'No packet loss in any of the %d measurements.', $fo_ls['n'], 'fileora' ), $fo_ls['n'] ) ); ?></p>
			<?php endif; ?>
			<?php
			if ( $fo_ls ) {
				fo_admin_timechart(
					array(
						'title'  => __( 'Share of ping packets or TCP connections without an answer, per check', 'fileora' ),
						'from'   => $fo_from,
						'to'     => $fo_to,
						'type'   => 'bars',
						'max'    => 100,
						'height' => 170,
						'width'  => 580,
						'series' => array( array( 'name' => __( 'Packet loss', 'fileora' ), 'class' => 's1', 'points' => $fo_loss ) ),
						'format' => function ( $v ) {
							return fo_admin_pct( $v, 0 );
						},
					)
				);
			} else {
				echo '<p class="fo-empty">' . esc_html( fo_admin_na() ) . '</p>';
			}
			?>
		</section>
		<section class="fo-card fo-grow">
			<h2><?php echo esc_html( sprintf( __( 'API response time (/health), %s', 'fileora' ), $fo_rname ) ); ?></h2>
			<?php
			if ( $fo_hs ) {
				$fo_hpts = array();
				foreach ( $fo_checks as $fo_c ) {
					$fo_hpts[] = array( $fo_c->t, (int) $fo_c->ok ? (float) $fo_c->latency_ms : null );
				}
				fo_admin_timechart(
					array(
						'title'  => __( 'Response time of the /health request; red lines are failed checks', 'fileora' ),
						'from'   => $fo_from,
						'to'     => $fo_to,
						'height' => 170,
						'width'  => 580,
						'series' => array( array( 'name' => __( 'Response time', 'fileora' ), 'class' => 's1', 'points' => '7d' === $fo_range ? $fo_bucket( $fo_hpts ) : $fo_hpts ) ),
						'format' => 'fo_admin_ms',
						'down'   => $fo_http_down,
						'gap'    => $fo_gap,
					)
				);
			} else {
				echo '<p class="fo-empty">' . esc_html( fo_admin_na() ) . '</p>';
			}
			?>
		</section>
	</div>

	<h2 class="fo-h2"><?php esc_html_e( 'Availability', 'fileora' ); ?></h2>
	<div class="fo-kpis">
		<?php
		fo_admin_kpi( __( 'Availability, 24 hours', 'fileora' ), fo_admin_pct( $fo_u1['availability'], 2 ), sprintf( __( 'coverage %s', 'fileora' ), fo_admin_pct( $fo_u1['coverage'] ) ), fo_admin_avail_state( $fo_u1['availability'] ) );
		fo_admin_kpi( __( 'Availability, 7 days', 'fileora' ), fo_admin_pct( $fo_u7['availability'], 2 ), sprintf( __( 'coverage %s', 'fileora' ), fo_admin_pct( $fo_u7['coverage'] ) ), fo_admin_avail_state( $fo_u7['availability'] ) );
		fo_admin_kpi( __( 'Availability, 30 days', 'fileora' ), fo_admin_pct( $fo_u30['availability'], 2 ), sprintf( __( 'coverage %s', 'fileora' ), fo_admin_pct( $fo_u30['coverage'] ) ), fo_admin_avail_state( $fo_u30['availability'] ) );
		fo_admin_kpi( __( 'Successful checks, 30 days', 'fileora' ), fo_admin_num( $fo_u30['ok_checks'] ) . ' / ' . fo_admin_num( $fo_u30['checks'] ), __( 'check-success rate ', 'fileora' ) . fo_admin_pct( $fo_u30['check_rate'] ) );
		?>
	</div>
	<p class="description fo-formula"><?php esc_html_e( 'Availability = time covered by successful /health checks ÷ monitored time × 100. Each check covers the time until the next one, at most two intervals; longer gaps are unmonitored and shown as lower coverage instead of being counted as up or down.', 'fileora' ); ?></p>

	<section class="fo-card">
		<h2><?php esc_html_e( 'Availability per day, last 30 days', 'fileora' ); ?></h2>
		<div class="fo-strip" role="list">
			<?php foreach ( $fo_daily as $fo_d => $fo_u ) : ?>
				<?php
				$fo_st  = fo_admin_avail_state( $fo_u['availability'] );
				$fo_tip = fo_admin_short_date( $fo_d ) . ': ' . ( null === $fo_u['availability'] ? __( 'no data', 'fileora' ) : fo_admin_pct( $fo_u['availability'], 2 ) . ' ' . sprintf( __( '(coverage %s)', 'fileora' ), fo_admin_pct( $fo_u['coverage'], 0 ) ) );
				?>
				<span role="listitem" class="fo-day is-<?php echo esc_attr( $fo_st ); ?>" title="<?php echo esc_attr( $fo_tip ); ?>"><span class="sr"><?php echo esc_html( $fo_tip ); ?></span></span>
			<?php endforeach; ?>
		</div>
		<div class="fo-legend">
			<span><i class="s-good"></i><?php esc_html_e( '99.5% or more', 'fileora' ); ?></span>
			<span><i class="s-warning"></i><?php esc_html_e( '95–99.5%', 'fileora' ); ?></span>
			<span><i class="s-critical"></i><?php esc_html_e( 'below 95%', 'fileora' ); ?></span>
			<span><i class="s-unknown"></i><?php esc_html_e( 'no data', 'fileora' ); ?></span>
		</div>
	</section>

	<h2 class="fo-h2"><?php esc_html_e( 'Server resources', 'fileora' ); ?></h2>
	<?php if ( ! $fo_metrics ) : ?>
		<div class="notice notice-info inline"><p>
			<?php
			if ( 'not-supported' === $fo_merr ) {
				esc_html_e( 'Not Available: this processing server doesn’t provide /metrics yet. Update it to version 2.4 (README section 8.13).', 'fileora' );
			} elseif ( $fo_last && ( ! $fo_last['ok'] || true !== $fo_last['auth'] ) ) {
				esc_html_e( 'Not Available: the figures are read with the shared key once the server is up and the key is accepted.', 'fileora' );
			} elseif ( $fo_merr ) {
				echo esc_html( sprintf( __( 'Not Available: %s', 'fileora' ), $fo_merr ) );
			} else {
				esc_html_e( 'Not Available until the next check.', 'fileora' );
			}
			?>
		</p></div>
	<?php endif; ?>
	<div class="fo-kpis">
		<?php
		$fo_cpu = $fo_m( 'cpu.pct_5m' );
		$fo_cpu = null === $fo_cpu ? $fo_m( 'cpu.pct' ) : $fo_cpu;
		$fo_load = $fo_m( 'cpu.load' );
		fo_admin_kpi( __( 'CPU, 5-minute average', 'fileora' ), null === $fo_cpu ? fo_admin_na() : fo_admin_pct( $fo_cpu ), null === $fo_m( 'cpu.cores' ) ? '' : sprintf( /* translators: 1: cores, 2: load */ __( '%1$d cores · load %2$s', 'fileora' ), (int) $fo_m( 'cpu.cores' ), is_array( $fo_load ) ? number_format_i18n( (float) $fo_load[0], 2 ) : fo_admin_na() ), null === $fo_cpu ? '' : ( $fo_cpu >= 90 ? 'critical' : ( $fo_cpu >= 75 ? 'warning' : '' ) ) );
		$fo_mp = $fo_m( 'memory.pct' );
		fo_admin_kpi( __( 'Memory used', 'fileora' ), null === $fo_mp ? fo_admin_na() : fo_admin_pct( $fo_mp ), null === $fo_m( 'memory.total' ) ? '' : sprintf( __( '%1$s of %2$s', 'fileora' ), fo_admin_bytes( $fo_m( 'memory.used' ) ), fo_admin_bytes( $fo_m( 'memory.total' ) ) ), null === $fo_mp ? '' : ( $fo_mp >= 90 ? 'critical' : ( $fo_mp >= 80 ? 'warning' : '' ) ) );
		$fo_dp = $fo_m( 'disk.pct' );
		fo_admin_kpi( __( 'Disk used', 'fileora' ), null === $fo_dp ? fo_admin_na() : fo_admin_pct( $fo_dp ), null === $fo_m( 'disk.free' ) ? '' : sprintf( __( '%1$s free of %2$s', 'fileora' ), fo_admin_bytes( $fo_m( 'disk.free' ) ), fo_admin_bytes( $fo_m( 'disk.total' ) ) ), null === $fo_dp ? '' : ( $fo_dp >= 90 ? 'critical' : ( $fo_dp >= 80 ? 'warning' : '' ) ) );
		fo_admin_kpi( __( 'Network in / out', 'fileora' ), null === $fo_m( 'network.rx_bps' ) ? fo_admin_na() : fo_admin_rate( $fo_m( 'network.rx_bps' ) ) . ' / ' . fo_admin_rate( $fo_m( 'network.tx_bps' ) ), __( '5-minute average', 'fileora' ) );
		fo_admin_kpi( __( 'Server uptime', 'fileora' ), fo_admin_duration( $fo_m( 'uptime' ) ), null === $fo_m( 'service_uptime' ) ? '' : sprintf( __( 'service running for %s', 'fileora' ), fo_admin_duration( $fo_m( 'service_uptime' ) ) ) );
		fo_admin_kpi( __( 'Temporary files', 'fileora' ), null === $fo_m( 'temp.tasks' ) ? fo_admin_na() : fo_admin_bytes( $fo_m( 'temp.bytes' ) ), null === $fo_m( 'temp.tasks' ) ? '' : sprintf( _n( '%s task folder', '%s task folders', (int) $fo_m( 'temp.tasks' ), 'fileora' ), number_format_i18n( (int) $fo_m( 'temp.tasks' ) ) ) );
		?>
	</div>
	<?php if ( $fo_metrics ) : ?>
		<p class="fo-sub fo-chart-note"><?php echo esc_html( sprintf( __( 'Reported by the processing server (version %1$s) at %2$s.', 'fileora' ), (string) $fo_m( 'version' ), wp_date( get_option( 'time_format' ), (int) $fo_m( 'time' ) ) ) ); ?> <a href="<?php echo esc_url( admin_url( 'admin.php?page=fileora-tasks&view=temp' ) ); ?>"><?php esc_html_e( 'Temporary files and cleanup', 'fileora' ); ?></a></p>
	<?php endif; ?>
	<?php if ( $fo_has_metrics ) : ?>
		<div class="fo-grid3">
			<?php
			$fo_pct = function ( $v ) {
				return fo_admin_pct( $v, 0 );
			};
			foreach ( array(
				'cpu_pct'  => __( 'CPU', 'fileora' ),
				'mem_pct'  => __( 'Memory', 'fileora' ),
				'disk_pct' => __( 'Disk', 'fileora' ),
			) as $fo_k => $fo_lbl ) :
				$fo_pts = $fo_col( $fo_k );
				?>
				<section class="fo-card">
					<h2><?php echo esc_html( sprintf( __( '%1$s used, %2$s', 'fileora' ), $fo_lbl, $fo_rname ) ); ?></h2>
					<?php
					fo_admin_timechart(
						array(
							'title'    => sprintf( __( '%s use in percent', 'fileora' ), $fo_lbl ),
							'from'     => $fo_from,
							'to'       => $fo_to,
							'max'      => 100,
							'height'   => 170,
							'width'    => 380,
							'pad_left' => 44,
							'series'   => array( array( 'name' => $fo_lbl, 'class' => 's1', 'points' => '7d' === $fo_range ? $fo_bucket( $fo_pts ) : $fo_pts ) ),
							'format'   => $fo_pct,
							'gap'      => $fo_gap,
						)
					);
					?>
				</section>
			<?php endforeach; ?>
		</div>
		<section class="fo-card">
			<h2><?php echo esc_html( sprintf( __( 'Network traffic, %s', 'fileora' ), $fo_rname ) ); ?></h2>
			<?php
			$fo_rx = $fo_col( 'net_rx_bps' );
			$fo_tx = $fo_col( 'net_tx_bps' );
			fo_admin_timechart(
				array(
					'title'    => __( 'Bytes per second received and sent by the processing server (5-minute averages)', 'fileora' ),
					'from'     => $fo_from,
					'to'       => $fo_to,
					'height'   => 190,
					'width'    => 1200,
					'pad_left' => 76,
					'series'   => array(
						array( 'name' => __( 'In (received)', 'fileora' ), 'class' => 's1', 'points' => '7d' === $fo_range ? $fo_bucket( $fo_rx ) : $fo_rx ),
						array( 'name' => __( 'Out (sent)', 'fileora' ), 'class' => 's2', 'points' => '7d' === $fo_range ? $fo_bucket( $fo_tx ) : $fo_tx ),
					),
					'format'   => 'fo_admin_rate',
					'gap'      => $fo_gap,
				)
			);
			?>
		</section>
	<?php elseif ( $fo_metrics ) : ?>
		<p class="fo-empty"><?php esc_html_e( 'Graphs of these figures appear after a few checks.', 'fileora' ); ?></p>
	<?php endif; ?>

	<div class="fo-row">
		<section class="fo-card fo-grow">
			<h2><?php esc_html_e( 'What the server reports', 'fileora' ); ?></h2>
			<?php if ( $fo_body ) : ?>
				<dl class="fo-dl fo-dl-wide">
					<dt><?php esc_html_e( 'Shared key set on the server', 'fileora' ); ?></dt><dd><?php echo ! empty( $fo_body['key_set'] ) ? fo_admin_status( 'good', __( 'Yes', 'fileora' ) ) : fo_admin_status( 'critical', __( 'No', 'fileora' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></dd>
					<dt><?php esc_html_e( 'Shared key accepted', 'fileora' ); ?></dt><dd><?php echo null === $fo_last['auth'] ? fo_admin_status( 'unknown', __( 'Unknown', 'fileora' ) ) : ( $fo_last['auth'] ? fo_admin_status( 'good', __( 'Yes', 'fileora' ) ) : fo_admin_status( 'critical', __( 'No, it doesn’t match FILEORA_KEY', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></dd>
					<dt><?php esc_html_e( 'Parallel workers', 'fileora' ); ?></dt><dd><?php echo isset( $fo_body['workers'] ) ? esc_html( (int) $fo_body['workers'] ) : esc_html( fo_admin_na() ); ?></dd>
					<dt><?php esc_html_e( 'Queue', 'fileora' ); ?></dt><dd>
						<?php
						if ( isset( $fo_body['queue'] ) && is_array( $fo_body['queue'] ) ) {
							echo esc_html( sprintf( __( '%1$d waiting, %2$d running', 'fileora' ), (int) ( isset( $fo_body['queue']['queued'] ) ? $fo_body['queue']['queued'] : 0 ), (int) ( isset( $fo_body['queue']['running'] ) ? $fo_body['queue']['running'] : 0 ) ) );
						} else {
							echo esc_html( fo_admin_na() );
						}
						?>
					</dd>
					<?php if ( ! empty( $fo_body['ocr_languages'] ) ) : ?>
						<dt><?php esc_html_e( 'OCR languages', 'fileora' ); ?></dt><dd><?php echo esc_html( implode( ', ', (array) $fo_body['ocr_languages'] ) ); ?></dd>
					<?php endif; ?>
				</dl>
			<?php else : ?>
				<p class="fo-empty"><?php esc_html_e( 'The server hasn’t answered a health check yet.', 'fileora' ); ?></p>
			<?php endif; ?>
		</section>
		<section class="fo-card fo-grow">
			<h2><?php esc_html_e( 'Server tools', 'fileora' ); ?></h2>
			<table class="widefat striped fo-table">
				<thead><tr><th><?php esc_html_e( 'Tool', 'fileora' ); ?></th><th><?php esc_html_e( 'Needs', 'fileora' ); ?></th><th><?php esc_html_e( 'Server status', 'fileora' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( Fileora_Tool_Registry::tools() as $fo_t ) : ?>
					<?php
					if ( 'browser' === $fo_t['exec'] ) {
						continue;
					}
					$fo_a = Fileora_Server_Monitor::tool_available( $fo_t['id'] );
					?>
					<tr><td><?php echo esc_html( $fo_t['name'] ); ?></td><td><?php echo esc_html( $fo_t['needs'] ); ?></td><td><?php echo true === $fo_a ? fo_admin_status( 'good', __( 'Available', 'fileora' ) ) : ( false === $fo_a ? fo_admin_status( 'critical', __( 'Not available', 'fileora' ) ) : fo_admin_status( 'unknown', __( 'Unknown', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</section>
	</div>

	<section class="fo-card">
		<h2><?php echo esc_html( sprintf( __( 'Checks, %s (newest 30)', 'fileora' ), $fo_rname ) ); ?></h2>
		<?php if ( $fo_recent ) : ?>
			<div class="fo-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Checks', 'fileora' ); ?>">
			<table class="widefat striped fo-table">
				<thead><tr>
					<th><?php esc_html_e( 'Time', 'fileora' ); ?></th>
					<th><?php esc_html_e( 'Network', 'fileora' ); ?></th>
					<th class="num"><?php esc_html_e( 'Latency', 'fileora' ); ?></th>
					<th class="num"><?php esc_html_e( 'Loss', 'fileora' ); ?></th>
					<th><?php esc_html_e( 'API (/health)', 'fileora' ); ?></th>
					<th><?php esc_html_e( 'Key', 'fileora' ); ?></th>
					<th class="num"><?php esc_html_e( 'CPU · memory · disk', 'fileora' ); ?></th>
					<th><?php esc_html_e( 'Problem', 'fileora' ); ?></th>
					<th><?php esc_html_e( 'Run by', 'fileora' ); ?></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $fo_recent as $fo_c ) : ?>
					<?php
					$fo_res = array();
					foreach ( array( 'cpu_pct', 'mem_pct', 'disk_pct' ) as $fo_k ) {
						$fo_res[] = null === $fo_c->$fo_k ? '–' : fo_admin_pct( $fo_c->$fo_k, 0 );
					}
					?>
					<tr>
						<td class="nowrap"><?php echo esc_html( fo_admin_short_time( $fo_c->t ) ); ?></td>
						<td class="nowrap"><?php echo null === $fo_c->reachable ? esc_html( fo_admin_na() ) : ( $fo_c->reachable ? fo_admin_status( 'good', __( 'Reachable', 'fileora' ) ) : fo_admin_status( 'critical', __( 'Unreachable', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><br><span class="fo-sub"><?php echo esc_html( $fo_c->probe ? Fileora_Net_Probe::label( $fo_c->probe, (int) $fo_c->probe_port ) : fo_admin_na() ); ?></span></td>
						<td class="num nowrap"><?php echo esc_html( fo_admin_rtt( $fo_c->probe_ms ) ); ?></td>
						<td class="num nowrap"><?php echo esc_html( null === $fo_c->probe_loss ? fo_admin_na() : fo_admin_pct( $fo_c->probe_loss, 0 ) . ' (' . (int) $fo_c->probe_recv . '/' . (int) $fo_c->probe_sent . ')' ); ?></td>
						<td class="nowrap"><?php echo $fo_c->ok ? fo_admin_status( 'good', __( 'Up', 'fileora' ) ) : fo_admin_status( 'critical', __( 'Down', 'fileora' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><br><span class="fo-sub"><?php echo esc_html( ( $fo_c->http_code ? 'HTTP ' . $fo_c->http_code . ' · ' : '' ) . fo_admin_ms( $fo_c->latency_ms ) ); ?></span></td>
						<td><?php echo null === $fo_c->auth_ok ? '–' : ( $fo_c->auth_ok ? esc_html__( 'accepted', 'fileora' ) : esc_html__( 'rejected', 'fileora' ) ); ?></td>
						<td class="num nowrap"><?php echo esc_html( implode( ' · ', $fo_res ) ); ?></td>
						<td class="fo-err"><?php echo esc_html( (string) $fo_c->error ); ?></td>
						<td><?php echo 'manual' === $fo_c->source ? esc_html__( 'Check now', 'fileora' ) : esc_html__( 'Schedule', 'fileora' ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
		<?php else : ?>
			<p class="fo-empty"><?php esc_html_e( 'No checks in this period. Press “Check now”, and make sure WP-Cron runs (README, “Real cron”).', 'fileora' ); ?></p>
		<?php endif; ?>
		<p class="description"><?php echo esc_html( sprintf( __( 'Checks are kept for %d days (Settings → Data retention → Health checks).', 'fileora' ), (int) Fileora_Core_Settings::value( 'health_retention' ) ) ); ?></p>
	</section>
</div>
