#!/bin/bash
# Builds public/js/fileora-engine.js from public/js/src/*.js (in name order), wrapped in one function scope.
set -e
D="$(cd "$(dirname "$0")/.." && pwd)/plugin/fileora-core/public/js"
{
  echo "/*! Fileora tool engine $(date -u +%Y-%m-%d). Built from public/js/src by tools/build-engine.sh; edit the sources, not this file. */"
  echo "(function () {"
  echo "'use strict';"
  for f in "$D"/src/*.js; do echo; echo "/* ---- $(basename "$f") ---- */"; cat "$f"; done
  echo "})();"
} > "$D/fileora-engine.js"
node --check "$D/fileora-engine.js"
echo "built $(wc -c < "$D/fileora-engine.js") bytes"
