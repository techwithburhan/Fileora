"""
Fileora processing service
==========================
Runs the server-side tools of the Fileora website as background jobs.

* Listens on 127.0.0.1 only. The WordPress plugin forwards visitors' files
  here and adds the shared secret in the X-Fileora-Key header.
* Each job gets its own folder. Uploads are removed as soon as the job ends,
  results when they are downloaded, and anything left after FILEORA_TTL_MIN.

Endpoints (all need X-Fileora-Key, except /health)
-------------------------------------------------
POST   /jobs/{tool}      multipart/form-data: files (any field name starting
                         with "files"), options (JSON string), url (HTML to PDF)
                         -> 202 {"job": "<32 hex>", "status": "queued"}
GET    /jobs/{id}        -> {"status": "queued|running|done|failed", "ahead": n,
                             "kind": "file|text", "name", "size", "text", "error"}
GET    /jobs/{id}/file   -> the result file (several results come as one ZIP)
DELETE /jobs/{id}        -> removes the job folder now
GET    /health           -> which tools are ready on this server

Environment (see /etc/fileora/fileora.env)
------------------------------------------
FILEORA_KEY        shared secret, must match the WordPress plugin setting
FILEORA_WORKDIR    job folders            (default /var/lib/fileora/jobs)
FILEORA_MAX_MB     max size per file      (default 200)
FILEORA_WORKERS    jobs that run at once  (default 2, about 1 per 2 GB RAM)
FILEORA_TTL_MIN    delete jobs after      (default 60 minutes)
FILEORA_AI_MODEL   Claude model for AI tools (default claude-haiku-5-5)
ANTHROPIC_API_KEY  needed only for AI Summarizer and Translate PDF

Licences: this file uses PyMuPDF and pdf2docx (which needs PyMuPDF). PyMuPDF is
AGPL-3.0 or commercial (Artifex). Read the licensing section of the README.
"""
import hmac
import ipaddress
import json
import mimetypes
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlparse

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse

KEY = os.environ.get("FILEORA_KEY", "")
WORK = Path(os.environ.get("FILEORA_WORKDIR", "/var/lib/fileora/jobs"))
MAX_BYTES = int(os.environ.get("FILEORA_MAX_MB", "200")) * 1024 * 1024
AI_MODEL = os.environ.get("FILEORA_AI_MODEL", "claude-haiku-5-5")
SOFFICE = shutil.which("soffice") or shutil.which("libreoffice") or "soffice"
QPDF = shutil.which("qpdf") or "qpdf"
# Only for local testing. Never set this on a public server.
ALLOW_PRIVATE_URLS = os.environ.get("FILEORA_ALLOW_PRIVATE_URLS") == "1"
WORKERS = int(os.environ.get("FILEORA_WORKERS", "2"))
TTL = int(os.environ.get("FILEORA_TTL_MIN", "60")) * 60
POOL = ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix="fileora-job")
WORK.mkdir(parents=True, exist_ok=True)

@asynccontextmanager
async def lifespan(_app):
    recover_and_start()
    yield


app = FastAPI(title="Fileora processing service", docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)


class ToolError(Exception):
    """A problem the visitor should read. The message is shown on the website."""

    def __init__(self, message, status=422):
        super().__init__(message)
        self.status = status


@app.exception_handler(ToolError)
async def _tool_error(_request, exc: ToolError):
    return JSONResponse({"error": str(exc)}, status_code=exc.status)


# ---------------------------------------------------------------- helpers
ACCEPT = {
    "pdf": {".pdf"},
    "word": {".doc", ".docx", ".odt", ".rtf", ".txt"},
    "ppt": {".ppt", ".pptx", ".pps", ".ppsx", ".odp"},
    "excel": {".xls", ".xlsx", ".ods", ".csv"},
    "html": {".html", ".htm"},
}
OCR_LANG = {"en": "eng", "hi": "hin", "bn": "ben", "ta": "tam", "te": "tel", "mr": "mar", "ur": "urd",
            "gu": "guj", "kn": "kan", "ml": "mal", "pa": "pan",
            "ar": "ara", "zh": "chi_sim", "ja": "jpn", "ko": "kor", "fr": "fra", "de": "deu", "es": "spa",
            "pt": "por", "it": "ita", "ru": "rus", "tr": "tur", "id": "ind"}
LANG_NAME = {"en": "English", "hi": "Hindi", "bn": "Bengali", "ta": "Tamil", "te": "Telugu", "mr": "Marathi",
             "gu": "Gujarati", "kn": "Kannada", "ml": "Malayalam", "pa": "Punjabi",
             "ur": "Urdu", "ar": "Arabic", "zh": "Simplified Chinese", "ja": "Japanese", "ko": "Korean",
             "fr": "French", "de": "German", "es": "Spanish", "pt": "Portuguese", "it": "Italian",
             "ru": "Russian", "tr": "Turkish", "id": "Indonesian"}


def safe_name(name: str) -> str:
    name = os.path.basename(name or "file").strip() or "file"
    name = re.sub(r"[^\w.\- ()]+", "_", name)
    return name[-120:]


def run(cmd, timeout=240, ok=(0,), env=None, fail="The file couldn't be processed."):
    """Run a command-line tool and turn failures into a readable error."""
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env)
    except subprocess.TimeoutExpired:
        raise ToolError("This file took too long to process. Try a smaller file.", 504)
    if proc.returncode not in ok:
        print("command failed:", cmd[0], proc.returncode, proc.stderr[-2000:], file=sys.stderr)
        raise ToolError(fail)
    return proc


def argfile(job: Path, args):
    """Write arguments to a file so passwords never appear in the process list."""
    path = job / f"args-{uuid.uuid4().hex}.txt"
    path.write_text("\n".join(args), encoding="utf-8")
    path.chmod(0o600)
    return f"@{path}"


def out_dir(job: Path) -> Path:
    d = job / "out"
    d.mkdir(exist_ok=True)
    return d


def pdf_text(path: Path, limit=400_000) -> str:
    import pymupdf
    with pymupdf.open(path) as doc:
        return "\n\n".join(page.get_text() for page in doc)[:limit]


# ---------------------------------------------------------------- tools
def office_to_pdf(files, opts, job, url):
    outs = []
    profile = (job / "lo-profile").as_uri()
    env = {**os.environ, "HOME": str(job)}
    for i, f in enumerate(files):
        target = out_dir(job) / str(i)
        target.mkdir()
        ext = f.suffix.lower()
        filt = "pdf"
        if ext in ACCEPT["excel"] and opts.get("fit", True):
            filt = 'pdf:calc_pdf_Export:{"SinglePageSheets":{"type":"boolean","value":"true"}}'
        if ext in ACCEPT["ppt"] and opts.get("notes"):
            filt = 'pdf:impress_pdf_Export:{"ExportNotesPages":{"type":"boolean","value":"true"}}'
        run([SOFFICE, f"-env:UserInstallation={profile}", "--headless", "--norestore", "--nolockcheck",
             "--convert-to", filt, "--outdir", str(target), str(f)],
            timeout=300, env=env, fail=f"{f.name} couldn't be converted. Open it in Office, save it again and retry.")
        result = target / (f.stem + ".pdf")
        if not result.exists():
            raise ToolError(f"{f.name} couldn't be converted. It may be damaged or password-protected.")
        outs.append(result)
    return outs


def ocr(files, opts, job, url):
    lang = OCR_LANG.get(opts.get("lang", "en"), "eng")
    outs = []
    for f in files:
        out = out_dir(job) / f"{f.stem}-ocr.pdf"
        cmd = [sys.executable, "-m", "ocrmypdf", "-l", lang, "--skip-text", "--rotate-pages", "--deskew",
               "--output-type", "pdf"]
        sidecar = None
        if opts.get("out") == "txt":
            sidecar = out_dir(job) / f"{f.stem}.txt"
            cmd += ["--sidecar", str(sidecar)]
        proc = subprocess.run(cmd + [str(f), str(out)], capture_output=True, text=True, timeout=900)
        if proc.returncode != 0:
            err = proc.stderr
            print("ocrmypdf failed:", proc.returncode, err[-2000:], file=sys.stderr)
            if "language" in err.lower() and lang in err:
                raise ToolError(f"OCR for {LANG_NAME.get(opts.get('lang'), lang)} isn't installed on the server yet.", 503)
            if proc.returncode == 8:
                raise ToolError(f"{f.name} is password-protected. Unlock it first.")
            raise ToolError(f"OCR couldn't read {f.name}. Check that it's a valid PDF.")
        outs.append(sidecar if sidecar else out)
    return outs


def pdfa(files, opts, job, url):
    level = str(opts.get("level", "2b"))[0]
    if level not in "123":
        level = "2"
    outs = []
    for f in files:
        out = out_dir(job) / f"{f.stem}-pdfa.pdf"
        run([sys.executable, "-m", "ocrmypdf", "--skip-text", "--tesseract-timeout", "0",
             "--output-type", f"pdfa-{level}", str(f), str(out)],
            timeout=600, fail=f"{f.name} couldn't be converted to PDF/A.")
        outs.append(out)
    return outs


def check_host(host: str):
    if ALLOW_PRIVATE_URLS:
        return
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        raise ToolError("That web address couldn't be found. Check it and try again.")
    for info in infos:
        if not ipaddress.ip_address(info[4][0]).is_global:
            raise ToolError("That address points to a private network, so it can't be captured.", 400)


HIDE_ADS = """iframe[src*="ads"],[id*="google_ads"],[class*="advert"],[class*="ad-banner"],[class*="cookie"],
[id*="cookie"],[class*="consent"],[id*="consent"],[class*="newsletter-popup"],[class*="modal-backdrop"]
{display:none!important}"""


def public_only_guard():
    """A Playwright route handler: lets data:/blob: and public internet addresses through,
    blocks private networks, localhost, cloud metadata and every other scheme (file:, ftp: ...)."""
    checked = {}

    def guard(route):
        target = route.request.url
        if target.startswith(("data:", "blob:")):
            return route.continue_()
        parts = urlparse(target)
        host = parts.hostname or ""
        if parts.scheme not in ("http", "https") or not host:
            return route.abort()
        if host not in checked:
            try:
                check_host(host)
                checked[host] = True
            except ToolError:
                checked[host] = False
        return route.continue_() if checked[host] else route.abort()
    return guard


PAGE_MARGINS = {"none": "0mm", "small": "6mm", "normal": "12mm"}
MAX_HTML_BYTES = 5 * 1024 * 1024


def code2pdf(files, opts, job, url):
    """HTML code to PDF: renders the visitor's own HTML in headless Chromium and prints it.
    Scripts are off unless the visitor turns them on; network access is public-internet only."""
    from playwright.sync_api import sync_playwright
    f = files[0]
    if f.stat().st_size > MAX_HTML_BYTES:
        raise ToolError("The HTML is larger than 5 MB. Link big images instead of embedding them.", 413)
    html = f.read_bytes().decode("utf-8", errors="replace")
    if not html.strip():
        raise ToolError("There's no HTML to convert. Paste your code first.")
    name = safe_name(str(opts.get("name") or "").strip() or "document")
    name = re.sub(r"\.pdf$", "", name, flags=re.I) or "document"
    out = out_dir(job) / f"{name}.pdf"
    margin = PAGE_MARGINS.get(opts.get("margin"), "12mm")
    with sync_playwright() as pw:
        browser = pw.chromium.launch(args=["--disable-dev-shm-usage"])
        try:
            ctx = browser.new_context(viewport={"width": 1240, "height": 900}, java_script_enabled=bool(opts.get("js")))
            ctx.route("**/*", public_only_guard())
            page = ctx.new_page()
            page.set_default_timeout(30000)
            try:
                page.set_content(html, wait_until="load", timeout=30000)
            except Exception:
                page.wait_for_timeout(500)  # a slow image shouldn't block the PDF: print what has loaded
            page.wait_for_timeout(800 if opts.get("js") else 200)
            page.emulate_media(media="print" if opts.get("media", "print") != "screen" else "screen")
            bg = opts.get("bg", True) is not False
            if opts.get("page") == "fit":
                width = max(320, min(page.evaluate("Math.max(document.documentElement.scrollWidth, document.body ? document.body.scrollWidth : 0)"), 4000))
                height = min(page.evaluate("Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0)") + 2, 19000)
                page.pdf(path=str(out), width=f"{width}px", height=f"{height}px", print_background=bg,
                         margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})
            else:
                page.pdf(path=str(out), format="Letter" if opts.get("page") == "letter" else "A4",
                         landscape=opts.get("orient") == "landscape", print_background=bg,
                         prefer_css_page_size=True,
                         margin={"top": margin, "bottom": margin, "left": margin, "right": margin})
        finally:
            browser.close()
    return [out]


def html2pdf(files, opts, job, url):
    from playwright.sync_api import sync_playwright
    url = (url or opts.get("url") or "").strip()
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    parts = urlparse(url)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise ToolError("Enter a full web address, like https://example.com.")
    check_host(parts.hostname)
    guard = public_only_guard()

    out = out_dir(job) / f"{safe_name(parts.hostname)}.pdf"
    with sync_playwright() as pw:
        browser = pw.chromium.launch(args=["--disable-dev-shm-usage"])
        try:
            page = browser.new_context(viewport={"width": 1280, "height": 900}).new_page()
            page.route("**/*", guard)
            try:
                page.goto(url, wait_until="load", timeout=45000)
            except Exception:
                raise ToolError("That page didn't load. Check the address, or try again later.")
            page.wait_for_timeout(1500)
            if opts.get("clean", True):
                page.add_style_tag(content=HIDE_ADS)
            if opts.get("page") == "one":
                height = min(page.evaluate("document.documentElement.scrollHeight") + 40, 19000)
                page.pdf(path=str(out), width="1280px", height=f"{height}px", print_background=True)
            else:
                page.pdf(path=str(out), format="Letter" if opts.get("page") == "letter" else "A4",
                         landscape=opts.get("orient") == "landscape", print_background=True,
                         margin={"top": "12mm", "bottom": "12mm", "left": "10mm", "right": "10mm"})
        finally:
            browser.close()
    return [out]


def pdf2word(files, opts, job, url):
    from pdf2docx import Converter
    outs = []
    for f in files:
        src = f
        if opts.get("ocr", True) and len(pdf_text(f, 2000).strip()) < 20:
            src = ocr([f], {"lang": "en"}, job, url)[0]
        out = out_dir(job) / f"{f.stem}.docx"
        try:
            cv = Converter(str(src))
            cv.convert(str(out))
            cv.close()
        except Exception as exc:
            print("pdf2docx failed:", exc, file=sys.stderr)
            raise ToolError(f"{f.name} couldn't be converted to Word.")
        outs.append(out)
    return outs


def pdf2ppt(files, opts, job, url):
    import pymupdf
    from pptx import Presentation
    from pptx.util import Emu
    outs = []
    for f in files:
        with pymupdf.open(f) as doc:
            first = doc[0].rect
            prs = Presentation()
            prs.slide_width, prs.slide_height = Emu(int(first.width * 12700)), Emu(int(first.height * 12700))
            for page in doc:
                img = job / f"slide-{page.number}.png"
                page.get_pixmap(dpi=150).save(img)
                slide = prs.slides.add_slide(prs.slide_layouts[6])
                slide.shapes.add_picture(str(img), 0, 0, prs.slide_width, prs.slide_height)
        out = out_dir(job) / f"{f.stem}.pptx"
        prs.save(out)
        outs.append(out)
    return outs


def _cell(value):
    if value is None:
        return None
    value = str(value).replace("\n", " ").strip()
    if re.fullmatch(r"-?\d{1,3}(,\d{3})+(\.\d+)?|-?\d+(\.\d+)?", value):
        try:
            number = float(value.replace(",", ""))
            return int(number) if number.is_integer() and "." not in value else number
        except ValueError:
            pass
    return value


def pdf2excel(files, opts, job, url):
    import openpyxl
    import pdfplumber
    outs = []
    for f in files:
        wb = openpyxl.Workbook()
        wb.remove(wb.active)
        one = opts.get("sheets") == "one"
        found = 0
        for settings in (None, {"vertical_strategy": "text", "horizontal_strategy": "text"}):
            with pdfplumber.open(f) as pdf:
                sheet = wb.create_sheet("Tables") if one else None
                for number, page in enumerate(pdf.pages, 1):
                    tables = page.extract_tables(settings) if settings else page.extract_tables()
                    tables = [t for t in tables if t and len(t) > 1]
                    if not tables:
                        continue
                    if one:
                        sheet.append([f"Page {number}"])
                    else:
                        sheet = wb.create_sheet(f"Page {number}")
                    for table in tables:
                        for row in table:
                            sheet.append([_cell(c) for c in row])
                        sheet.append([])
                        found += 1
            if found:
                break
            for name in wb.sheetnames:
                wb.remove(wb[name])
        if not found:
            raise ToolError(f"We couldn't find any tables in {f.name}. If it's a scan, run OCR PDF first.")
        out = out_dir(job) / f"{f.stem}.xlsx"
        wb.save(out)
        outs.append(out)
    return outs


def protect(files, opts, job, url):
    password = str(opts.get("pw") or "")
    if len(password) < 6:
        raise ToolError("Use a password with at least 6 characters.")
    outs = []
    for f in files:
        out = out_dir(job) / f"{f.stem}-protected.pdf"
        args = ["--encrypt", password, uuid.uuid4().hex, "256"]
        if opts.get("noprint"):
            args += ["--print=none", "--extract=n", "--modify=none"]
        args += ["--", str(f), str(out)]
        run([QPDF, argfile(job, args)], ok=(0, 3), fail=f"{f.name} couldn't be protected. It may already have a password.")
        outs.append(out)
    return outs


def unlock(files, opts, job, url):
    password = str(opts.get("pw") or "")
    outs = []
    for f in files:
        # qpdf --requires-password: 0 = needs a password, 2 = not encrypted, 3 = only restrictions (no open password).
        # qpdf also exits with 2 on any error (unreadable or damaged file), so 2 only means
        # "not encrypted" when qpdf printed nothing.
        check = subprocess.run([QPDF, "--requires-password", str(f)], capture_output=True, text=True, timeout=60)
        state, problem = check.returncode, (check.stderr or "").strip()
        if state == 2 and problem:
            print("unlock check failed:", f.name, f.stat().st_size, "bytes:", problem[-2000:], file=sys.stderr)
            raise ToolError(f"{f.name} couldn't be read. It may be damaged or didn't upload completely. Try uploading it again, or use Repair PDF.")
        if state == 2:
            raise ToolError(f"{f.name} isn't password-protected, so there's nothing to unlock.")
        if state == 0 and not password:
            raise ToolError(f"{f.name} needs its password to open. Enter it and try again.")
        out = out_dir(job) / f"{f.stem}-unlocked.pdf"
        args = ([f"--password={password}"] if password else []) + ["--decrypt", str(f), str(out)]
        run([QPDF, argfile(job, args)], ok=(0, 3), fail=f"That password doesn't open {f.name}.")
        outs.append(out)
    return outs


EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
PHONE_RE = re.compile(r"\+?\d[\d\s().-]{8,}\d")


def redact(files, opts, job, url):
    import pymupdf
    f = files[0]
    terms = {t.strip() for t in str(opts.get("terms") or "").splitlines() if t.strip()}
    count = 0
    with pymupdf.open(f) as doc:
        if doc.needs_pass:
            raise ToolError(f"{f.name} is password-protected. Unlock it first.")
        for page in doc:
            text = page.get_text()
            found = set(terms)
            if opts.get("emails", True):
                found.update(m.group(0) for m in EMAIL_RE.finditer(text))
            if opts.get("phones", True):
                found.update(m.group(0).strip() for m in PHONE_RE.finditer(text)
                             if 10 <= sum(ch.isdigit() for ch in m.group(0)) <= 15)
            for item in found:
                for rect in page.search_for(item):
                    page.add_redact_annot(rect, fill=(0, 0, 0))
                    count += 1
            page.apply_redactions()
        if not count:
            raise ToolError("Nothing to black out: none of those words, emails or phone numbers were found.")
        out = out_dir(job) / f"{f.stem}-redacted.pdf"
        doc.save(out, garbage=4, deflate=True, clean=True)
    return [out]


def forms(files, opts, job, url):
    import pymupdf
    f = files[0]
    mode = opts.get("detect", "all")
    added = 0
    with pymupdf.open(f) as doc:
        for page in doc:
            taken = []

            def free(rect):
                return all(not rect.intersects(r) for r in taken)

            def add(kind, rect):
                nonlocal added
                widget = pymupdf.Widget()
                widget.field_type = kind
                widget.rect = rect
                widget.field_name = f"field_{page.number + 1}_{len(taken) + 1}"
                if kind == pymupdf.PDF_WIDGET_TYPE_TEXT:
                    widget.text_fontsize = 0
                page.add_widget(widget)
                taken.append(rect)
                added += 1

            words = page.get_text("words")
            if mode in ("all", "text"):
                for w in words:
                    if re.fullmatch(r"_{4,}", w[4]):
                        rect = pymupdf.Rect(w[0], w[3] - 16, w[2], w[3])
                        if free(rect):
                            add(pymupdf.PDF_WIDGET_TYPE_TEXT, rect)
                for drawing in page.get_drawings():
                    for item in drawing["items"]:
                        if item[0] != "l":
                            continue
                        p1, p2 = item[1], item[2]
                        if abs(p1.y - p2.y) < 1 and abs(p2.x - p1.x) >= 60:
                            y = max(p1.y, p2.y)
                            rect = pymupdf.Rect(min(p1.x, p2.x), y - 16, max(p1.x, p2.x), y - 0.5)
                            if free(rect) and not page.get_textbox(rect).strip():
                                add(pymupdf.PDF_WIDGET_TYPE_TEXT, rect)
            if mode in ("all", "check"):
                for w in words:
                    if w[4] in ("☐", "□", "❑", "◻"):
                        rect = pymupdf.Rect(w[:4])
                        if free(rect):
                            add(pymupdf.PDF_WIDGET_TYPE_CHECKBOX, rect)
        if not added:
            raise ToolError("We couldn't find blank lines or boxes to turn into fields in this PDF.")
        out = out_dir(job) / f"{f.stem}-fillable.pdf"
        doc.save(out, garbage=3, deflate=True)
    return [out]


def ask_claude(instruction: str, text: str, max_tokens: int) -> str:
    if not os.environ.get("ANTHROPIC_API_KEY"):
        raise ToolError("AI tools aren't switched on yet. The site owner needs to add an API key.", 503)
    import anthropic
    client = anthropic.Anthropic()
    try:
        message = client.messages.create(
            model=AI_MODEL, max_tokens=max_tokens,
            messages=[{"role": "user", "content": f"{instruction}\n\n<document>\n{text}\n</document>"}])
    except anthropic.APIError as exc:
        print("Claude API error:", exc, file=sys.stderr)
        raise ToolError("The AI service is busy right now. Try again in a minute.", 503)
    return "".join(block.text for block in message.content if block.type == "text").strip()


def summarize(files, opts, job, url):
    text = pdf_text(files[0])
    if len(text.strip()) < 40:
        raise ToolError("This PDF has no selectable text. Run OCR PDF on it first.")
    length = {"short": "about 5 bullet points or 80 words",
              "medium": "about 10 bullet points or 200 words",
              "long": "a detailed summary of about 500 words, organized under short headings"}.get(opts.get("len"), "about 200 words")
    style = "bullet points" if opts.get("style", "bullets") == "bullets" else "flowing paragraphs"
    lang = LANG_NAME.get(opts.get("lang", "en"), "English")
    summary = ask_claude(f"Summarize the document below in {lang}, as {style}, in {length}. "
                         "Cover the main purpose, key facts, numbers, dates and any decisions or actions. "
                         "Reply with the summary only.", text, 4000)
    return {"text": summary}


def translate(files, opts, job, url):
    text = pdf_text(files[0], limit=150_000)
    if len(text.strip()) < 20:
        raise ToolError("This PDF has no selectable text. Run OCR PDF on it first.")
    lang = LANG_NAME.get(opts.get("to", "hi"), "Hindi")
    chunks, current = [], ""
    for para in text.split("\n\n"):
        if len(current) + len(para) > 12000 and current:
            chunks.append(current)
            current = ""
        current += para + "\n\n"
    if current.strip():
        chunks.append(current)
    parts = [ask_claude(f"Translate the document below into {lang}. Keep the paragraph breaks, headings, "
                        "lists and numbers. Reply with the translation only.", chunk, 16000) for chunk in chunks]
    return {"text": "\n\n".join(parts)}


def compress(files, opts, job, url):
    """Ghostscript keeps text selectable, unlike the in-browser fallback."""
    preset = {"light": "/printer", "balanced": "/ebook", "strong": "/screen"}.get(opts.get("level"), "/ebook")
    outs = []
    for f in files:
        out = out_dir(job) / f"{f.stem}-compressed.pdf"
        run(["gs", "-q", "-dNOPAUSE", "-dBATCH", "-dSAFER", "-sDEVICE=pdfwrite", "-dCompatibilityLevel=1.6",
             f"-dPDFSETTINGS={preset}", "-dDetectDuplicateImages=true", "-dCompressFonts=true",
             f"-sOutputFile={out}", str(f)],
            timeout=600, fail=f"{f.name} couldn't be compressed. If it has a password, unlock it first.")
        if not out.exists() or out.stat().st_size >= f.stat().st_size:
            shutil.copyfile(f, out)  # already optimized: keep the original bytes
        outs.append(out)
    return outs


def _pdf_ok(path: Path) -> bool:
    try:
        import pikepdf
        with pikepdf.open(path) as pdf:
            return len(pdf.pages) > 0
    except Exception:
        return False


def repair(files, opts, job, url):
    """1) qpdf rebuilds the cross-reference table and object streams.
    2) If that fails, Ghostscript re-reads every page it can and writes a new PDF."""
    f = files[0]
    first = out_dir(job) / f"{f.stem}-repaired.pdf"
    proc = subprocess.run([QPDF, "--warning-exit-0", str(f), str(first)], capture_output=True, text=True, timeout=300)
    if proc.returncode == 0 and _pdf_ok(first):
        return [first]
    second = out_dir(job) / f"{f.stem}-rebuilt.pdf"
    proc = subprocess.run(["gs", "-q", "-dNOPAUSE", "-dBATCH", "-dSAFER", "-sDEVICE=pdfwrite",
                           f"-sOutputFile={second}", str(f)], capture_output=True, text=True, timeout=600)
    if second.exists() and _pdf_ok(second):
        return [second]
    raise ToolError(f"We couldn't recover {f.name}. Too much of the file is missing or it isn't a PDF.")


def edit(files, opts, job, url):
    raise ToolError("Edit PDF works in the editor screen, which hasn't been added to this site yet.", 501)


TOOLS = {
    # tool id: (handler, accepted input, needs files)
    "ocr": (ocr, "pdf", True), "pdfa": (pdfa, "pdf", True),
    "word2pdf": (office_to_pdf, "word", True), "ppt2pdf": (office_to_pdf, "ppt", True),
    "excel2pdf": (office_to_pdf, "excel", True), "html2pdf": (html2pdf, None, False),
    "code2pdf": (code2pdf, "html", True),
    "pdf2word": (pdf2word, "pdf", True), "pdf2ppt": (pdf2ppt, "pdf", True),
    "pdf2excel": (pdf2excel, "pdf", True), "protect": (protect, "pdf", True),
    "unlock": (unlock, "pdf", True), "redact": (redact, "pdf", True), "forms": (forms, "pdf", True),
    "edit": (edit, "pdf", True), "summarize": (summarize, "pdf", True), "translate": (translate, "pdf", True),
    "compress": (compress, "pdf", True), "repair": (repair, "pdf", True),
}


# ---------------------------------------------------------------- jobs
JOB_ID = re.compile(r"^[0-9a-f]{32}$")


def write_status(job: Path, **data):
    tmp = job / "status.json.tmp"
    tmp.write_text(json.dumps(data), encoding="utf-8")
    tmp.replace(job / "status.json")


def read_status(job: Path) -> dict:
    try:
        return json.loads((job / "status.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def execute(job: Path, tool: str, paths, opts, url):
    """Runs in a worker thread. Writes the outcome to status.json."""
    handler = TOOLS[tool][0]
    base = read_status(job)
    write_status(job, **{**base, "status": "running", "started": time.time()})
    try:
        result = handler(paths, opts, job, url)
        final = job / "result"
        final.mkdir(exist_ok=True)
        if isinstance(result, dict):
            name = f"{paths[0].stem if paths else 'result'}-{tool}.txt"
            (final / name).write_text(result["text"], encoding="utf-8")
            done = {"kind": "text", "name": name, "text": result["text"]}
        else:
            if len(result) == 1:
                target = final / result[0].name
                shutil.move(str(result[0]), target)
            else:
                target, used = final / "fileora-results.zip", set()
                with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
                    for p in result:
                        name, n = p.name, 1
                        while name in used:
                            name, n = f"{p.stem}-{n}{p.suffix}", n + 1
                        used.add(name)
                        z.write(p, name)
            done = {"kind": "file", "name": target.name}
        done["size"] = (final / done["name"]).stat().st_size
        write_status(job, **{**base, **done, "status": "done", "finished": time.time()})
    except ToolError as exc:
        write_status(job, **{**base, "status": "failed", "error": str(exc), "code": exc.status, "finished": time.time()})
    except Exception as exc:
        print("unexpected error in", tool, repr(exc), file=sys.stderr)
        write_status(job, **{**base, "status": "failed", "error": "Something went wrong on the server. Try again, or try a different file.",
                             "code": 500, "finished": time.time()})
    finally:
        shutil.rmtree(job / "in", ignore_errors=True)   # uploads are never kept after the job
        shutil.rmtree(job / "out", ignore_errors=True)
        shutil.rmtree(job / "lo-profile", ignore_errors=True)


def janitor():
    """Deletes job folders older than FILEORA_TTL_MIN, every 5 minutes."""
    while True:
        cutoff = time.time() - TTL
        for job in WORK.iterdir():
            try:
                if job.is_dir() and job.stat().st_mtime < cutoff:
                    shutil.rmtree(job, ignore_errors=True)
            except OSError:
                pass
        time.sleep(300)


def recover_and_start():
    # Jobs that were waiting or running when the service stopped can't resume.
    for job in WORK.iterdir():
        st = read_status(job) if job.is_dir() else {}
        if st.get("status") in ("queued", "running"):
            write_status(job, **{**st, "status": "failed", "error": "The server restarted. Please try again."})
            shutil.rmtree(job / "in", ignore_errors=True)
    threading.Thread(target=janitor, daemon=True, name="fileora-janitor").start()


def authorized(request: Request) -> bool:
    return bool(KEY) and hmac.compare_digest(request.headers.get("x-fileora-key", ""), KEY)


def job_dir(job_id: str) -> Path:
    if not JOB_ID.match(job_id or ""):
        raise ToolError("Unknown job.", 404)
    job = WORK / job_id
    if not (job / "status.json").exists():
        raise ToolError("This task has expired. Please run it again.", 404)
    return job


@app.post("/jobs/{tool}", status_code=202)
async def submit(tool: str, request: Request):
    if not authorized(request):
        return JSONResponse({"error": "Not allowed."}, status_code=401)
    if tool not in TOOLS:
        raise ToolError("Unknown tool.", 404)
    _, accept, needs_files = TOOLS[tool]
    job_id = uuid.uuid4().hex
    job = WORK / job_id
    job.mkdir(parents=True)
    try:
        form = await request.form(max_files=50)
        try:
            opts = json.loads(form.get("options") or "{}")
        except ValueError:
            opts = {}
        url = form.get("url")
        paths = []
        for key, value in form.multi_items():
            if not key.startswith("files") or not hasattr(value, "filename"):
                continue
            name = safe_name(value.filename)
            if accept and Path(name).suffix.lower() not in ACCEPT[accept]:
                raise ToolError(f"{name} isn't a supported file for this tool.")
            folder = job / "in" / str(len(paths))
            folder.mkdir(parents=True)
            target, size = folder / name, 0
            with open(target, "wb") as fh:
                while chunk := await value.read(1024 * 1024):
                    size += len(chunk)
                    if size > MAX_BYTES:
                        raise ToolError(f"{name} is larger than {MAX_BYTES // 1048576} MB.", 413)
                    fh.write(chunk)
            paths.append(target)
        if needs_files and not paths:
            raise ToolError("Add a file first.")
    except Exception:
        shutil.rmtree(job, ignore_errors=True)
        raise
    write_status(job, status="queued", tool=tool, created=time.time(), files=len(paths))
    POOL.submit(execute, job, tool, paths, opts, url)
    return {"job": job_id, "status": "queued"}


@app.get("/jobs/{job_id}")
def status(job_id: str, request: Request):
    if not authorized(request):
        return JSONResponse({"error": "Not allowed."}, status_code=401)
    job = job_dir(job_id)
    st = read_status(job)
    out = {k: st.get(k) for k in ("status", "tool", "kind", "name", "size", "error", "text") if st.get(k) is not None}
    if st.get("status") == "queued":
        out["ahead"] = sum(1 for other in WORK.iterdir()
                           if other != job and read_status(other).get("status") in ("queued", "running")
                           and read_status(other).get("created", 0) < st.get("created", 0))
    return out


@app.get("/jobs/{job_id}/file")
def download(job_id: str, request: Request):
    if not authorized(request):
        return JSONResponse({"error": "Not allowed."}, status_code=401)
    job = job_dir(job_id)
    st = read_status(job)
    if st.get("status") != "done":
        raise ToolError("This task isn't finished yet.", 409)
    path = job / "result" / st["name"]
    media = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return FileResponse(path, media_type=media, filename=path.name)


@app.delete("/jobs/{job_id}")
def delete(job_id: str, request: Request):
    if not authorized(request):
        return JSONResponse({"error": "Not allowed."}, status_code=401)
    if JOB_ID.match(job_id or ""):
        shutil.rmtree(WORK / job_id, ignore_errors=True)
    return {"deleted": True}


@app.get("/health")
def health():
    def has_module(name):
        try:
            __import__(name)
            return True
        except ImportError:
            return False

    def tesseract_langs():
        try:
            out = subprocess.run(["tesseract", "--list-langs"], capture_output=True, text=True, timeout=10).stdout
            return [l.strip() for l in out.splitlines()[1:] if l.strip()]
        except Exception:
            return []

    office = bool(shutil.which("soffice") or shutil.which("libreoffice"))
    ocr_ok = bool(shutil.which("tesseract")) and has_module("ocrmypdf")
    pdfa_ok = ocr_ok and bool(shutil.which("gs"))
    qpdf_ok = bool(shutil.which("qpdf"))
    mupdf = has_module("pymupdf")
    ai = bool(os.environ.get("ANTHROPIC_API_KEY")) and has_module("anthropic")
    return {
        "ok": bool(KEY),
        "key_set": bool(KEY),
        "ocr_languages": tesseract_langs(),
        "tools": {
            "ocr": ocr_ok, "pdfa": pdfa_ok, "word2pdf": office, "ppt2pdf": office, "excel2pdf": office,
            "html2pdf": has_module("playwright"), "code2pdf": has_module("playwright"), "pdf2word": has_module("pdf2docx"),
            "pdf2ppt": mupdf and has_module("pptx"), "pdf2excel": has_module("pdfplumber") and has_module("openpyxl"),
            "protect": qpdf_ok, "unlock": qpdf_ok, "redact": mupdf, "forms": mupdf,
            "edit": False, "summarize": ai, "translate": ai,
            "compress": bool(shutil.which("gs")), "repair": qpdf_ok,
        },
        "workers": WORKERS,
        "queue": queue_counts(),
    }


def queue_counts() -> dict:
    """Jobs waiting and running right now (shown on the WordPress Server Monitoring page)."""
    counts = {"queued": 0, "running": 0}
    try:
        for job in WORK.iterdir():
            status = read_status(job).get("status")
            if status in counts:
                counts[status] += 1
    except OSError:
        pass
    return counts
