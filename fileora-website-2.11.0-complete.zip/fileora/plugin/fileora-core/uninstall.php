<?php
/**
 * Runs when Fileora Core is deleted from Plugins → Installed Plugins.
 *
 * Always removes scheduled events, capabilities, the Blog Editor and Support
 * roles and the IP location database.
 *
 * Analytics history, task records and settings are KEPT unless Settings →
 * Data retention → "Delete all Fileora data when the plugin is deleted" is
 * ticked, so deleting the plugin to upload a new version loses nothing.
 * Announcements (fileora_notice posts) are kept as content. Tool pages (fileora_tool posts) and their categories
 * are kept, so a reinstall restores the site as it was; delete them under
 * Fileora → Tool Management first if you want them gone. Users who had the
 * Blog Editor role fall back to having no role on this site.
 *
 * @package Fileora
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;
$fileora_settings = get_option( 'fileora_core_settings', array() );
if ( is_array( $fileora_settings ) && ! empty( $fileora_settings['delete_data'] ) ) {
	foreach ( array( 'fileora_tasks', 'fileora_events', 'fileora_sessions', 'fileora_health', 'fileora_daily', 'fileora_daily_tools' ) as $fileora_t ) {
		$fileora_table = $wpdb->prefix . $fileora_t;
		$wpdb->query( "DROP TABLE IF EXISTS {$fileora_table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}
	foreach ( (array) get_posts( array( 'post_type' => 'fileora_message', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ) ) as $fileora_m ) {
		wp_delete_post( $fileora_m, true );
	}
	delete_option( 'fileora_seo' );
	delete_option( 'fileora_seo_plan' );
	delete_option( 'fileora_blog_plan' );
	delete_option( 'fileora_resume' );
	delete_post_meta_by_key( '_fileora_plan_backup' );
	foreach ( array( 'fileora_core_settings', 'fileora_core_version', 'fileora_core_activated', 'fileora_tasks_db_version', 'fileora_events_db_version', 'fileora_health_db_version', 'fileora_history_db_version', 'fileora_rollup_through', 'fileora_db_errors', 'fileora_export_log', 'fileora_tasks_imported', 'fileora_last_health', 'fileora_rewrite_sig', 'fileora_core_imported_disabled', 'fileora_policy_review' ) as $fileora_o ) {
		delete_option( $fileora_o );
	}
} else {
	// Keep the data; make the next activation re-run table and role setup.
	delete_option( 'fileora_core_version' );
	delete_option( 'fileora_rewrite_sig' );
}
foreach ( array( 'fileora_core_hourly', 'fileora_core_daily', 'fileora_core_health_check', 'fileora_geo_update' ) as $fileora_h ) {
	wp_clear_scheduled_hook( $fileora_h );
}
remove_role( 'fileora_blog_editor' );
remove_role( 'fileora_support' ); // Support users keep their account but no longer have a role here
// The downloaded IP location database.
$fileora_up = wp_upload_dir( null, false );
foreach ( (array) glob( trailingslashit( $fileora_up['basedir'] ) . 'fileora-geo/*' ) as $fileora_f ) {
	wp_delete_file( $fileora_f );
}
@rmdir( trailingslashit( $fileora_up['basedir'] ) . 'fileora-geo' ); // phpcs:ignore
foreach ( wp_roles()->role_objects as $fileora_role ) {
	foreach ( array( 'fileora_manage_tools', 'fileora_manage_settings', 'fileora_view_reports', 'fileora_view_ip', 'fileora_manage_announcements', 'fileora_export_data' ) as $fileora_cap ) {
		$fileora_role->remove_cap( $fileora_cap );
	}
}
