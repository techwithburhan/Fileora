<?php
/**
 * Bootstrap: wires every part to WordPress, plus activation and upgrades.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Core {

	/** The earlier single-plugin version of Fileora, replaced by this plugin and the theme. */
	const OLD_PLUGIN = 'fileora/fileora.php';

	public static function boot() {
		Fileora_Permissions::init();
		Fileora_Tool_Registry::init();
		Fileora_Core_REST::init();
		Fileora_Server_Monitor::init();
		Fileora_Core_Frontend::init();
		Fileora_SEO::init();
		Fileora_Core_Cleanup::init();
		Fileora_Geo::init();
		Fileora_Reports::init();
		Fileora_History::init();
		Fileora_Announcements::init();
		Fileora_Support::init();
		Fileora_Content::init();
		Fileora_Contact::init();
		Fileora_Resume::init();
		Fileora_SEO_Fields::init();
		Fileora_SEO_Plan::init();
		if ( is_admin() ) {
			Fileora_Core_Admin::init();
		}
		add_action( 'init', array( __CLASS__, 'maybe_upgrade' ), 5 ); // after translations are available (WordPress 6.7+)
		add_action( 'admin_init', array( __CLASS__, 'retire_old_plugin' ) );
	}

	public static function activate() {
		Fileora_Task_Manager::install();
		Fileora_Analytics::install();
		Fileora_Server_Monitor::install();
		Fileora_Core_Settings::ensure_defaults();
		Fileora_Permissions::install();
		Fileora_Tool_Registry::register();
		Fileora_Tool_Registry::sync();
		Fileora_Core_Cleanup::schedule();
		Fileora_Server_Monitor::schedule();
		update_option( 'fileora_core_version', FILEORA_CORE_VERSION, false );
		add_option( 'fileora_core_activated', time(), '', false );
		delete_option( 'fileora_rewrite_sig' ); // rebuild tool page addresses on the next request
		self::retire_old_plugin();
	}

	public static function deactivate() {
		Fileora_Core_Cleanup::unschedule();
		Fileora_Server_Monitor::unschedule();
		Fileora_Geo::unschedule();
		flush_rewrite_rules( false );
	}

	/** Runs table and role upgrades after the plugin files were updated. */
	public static function maybe_upgrade() {
		Fileora_Task_Manager::maybe_upgrade();
		Fileora_Analytics::maybe_upgrade();
		Fileora_Server_Monitor::maybe_upgrade();
		if ( get_option( 'fileora_core_version' ) !== FILEORA_CORE_VERSION ) {
			Fileora_Permissions::install();
			add_action(
				'init',
				function () {
					Fileora_Tool_Registry::sync();
				},
				30
			);
			Fileora_Core_Cleanup::schedule();
			Fileora_Server_Monitor::schedule();
			update_option( 'fileora_core_version', FILEORA_CORE_VERSION, false );
		}
	}

	/**
	 * The old "Fileora" plugin served a fixed copy of the site and would take
	 * over the homepage. Its settings were imported on activation, so switch it off.
	 */
	public static function retire_old_plugin() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		if ( is_plugin_active( self::OLD_PLUGIN ) && ( current_user_can( 'activate_plugins' ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) ) {
			deactivate_plugins( self::OLD_PLUGIN, true );
			set_transient( 'fileora_old_plugin_retired', 1, HOUR_IN_SECONDS );
		}
	}
}
