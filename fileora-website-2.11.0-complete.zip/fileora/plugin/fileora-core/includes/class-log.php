<?php
/**
 * Minimal logger. Writes to the PHP error log (wp-content/debug.log when
 * WP_DEBUG_LOG is on). File contents and passwords are never logged.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Core_Log {

	public static function error( $message, array $context = array() ) {
		self::write( 'ERROR', $message, $context );
	}

	public static function info( $message, array $context = array() ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			self::write( 'INFO', $message, $context );
		}
	}

	private static function write( $level, $message, array $context ) {
		unset( $context['password'], $context['options'], $context['key'] );
		$line = sprintf( '[Fileora] %s %s', $level, $message );
		if ( $context ) {
			$line .= ' ' . wp_json_encode( $context );
		}
		error_log( $line ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	}
}
