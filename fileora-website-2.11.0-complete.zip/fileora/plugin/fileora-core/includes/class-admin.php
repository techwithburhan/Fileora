<?php
/**
 * Administration: the Fileora menu and its screens, the tool page editor
 * boxes, category fields and admin actions.
 *
 *   Visitor Analytics      fileora_view_reports (own top-level menu, opens after login)
 *   Fileora
 *     Dashboard            fileora_view_reports
 *     Server Monitoring    fileora_view_reports (Check now: fileora_manage_settings)
 *     Processing Tasks     fileora_view_reports
 *     Tool Management      fileora_manage_tools
 *     Tool Categories      fileora_manage_tools
 *     Blog Management      edit_posts (opens Posts)
 *     Announcements        fileora_manage_announcements
 *     Settings             fileora_manage_settings
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Core_Admin {

	const SLUG = 'fileora';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
		add_action( 'admin_post_fileora_save_tools', array( __CLASS__, 'save_tools' ) );
		add_action( 'admin_post_fileora_sync_tools', array( __CLASS__, 'sync_tools' ) );
		add_action( 'admin_post_fileora_check_now', array( __CLASS__, 'check_now' ) );
		add_action( 'admin_post_fileora_export_tasks', array( __CLASS__, 'export_tasks' ) );
		add_action( 'admin_post_fileora_geo_download', array( __CLASS__, 'geo_download' ) );
		add_action( 'admin_post_fileora_geo_delete', array( __CLASS__, 'geo_delete' ) );
		add_action( 'admin_post_fileora_geo_upload', array( __CLASS__, 'geo_upload' ) );
		add_action( 'admin_post_fileora_geo_backfill', array( __CLASS__, 'geo_backfill' ) );
		add_action( 'add_meta_boxes_' . Fileora_Tool_Registry::POST_TYPE, array( __CLASS__, 'meta_boxes' ) );
		add_action( 'save_post_' . Fileora_Tool_Registry::POST_TYPE, array( __CLASS__, 'save_tool_meta' ), 10, 2 );
		add_action( Fileora_Tool_Registry::TAXONOMY . '_add_form_fields', array( __CLASS__, 'term_fields_add' ) );
		add_action( Fileora_Tool_Registry::TAXONOMY . '_edit_form_fields', array( __CLASS__, 'term_fields_edit' ) );
		add_action( 'created_' . Fileora_Tool_Registry::TAXONOMY, array( __CLASS__, 'save_term' ) );
		add_action( 'edited_' . Fileora_Tool_Registry::TAXONOMY, array( __CLASS__, 'save_term' ) );
		add_filter( 'manage_' . Fileora_Tool_Registry::POST_TYPE . '_posts_columns', array( __CLASS__, 'tool_columns' ) );
		add_action( 'manage_' . Fileora_Tool_Registry::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'tool_column' ), 10, 2 );
		add_filter( 'parent_file', array( __CLASS__, 'parent_file' ) );
		add_filter( 'submenu_file', array( __CLASS__, 'submenu_file' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( FILEORA_CORE_FILE ), array( __CLASS__, 'plugin_links' ) );
	}

	public static function menu() {
		add_menu_page( __( 'Visitor Analytics', 'fileora' ), __( 'Visitor Analytics', 'fileora' ), 'fileora_view_reports', 'fileora-analytics', array( __CLASS__, 'page_analytics' ), 'dashicons-chart-pie', 3 );
		add_menu_page( __( 'Fileora', 'fileora' ), __( 'Fileora', 'fileora' ), 'fileora_view_reports', self::SLUG, array( __CLASS__, 'page_dashboard' ), 'dashicons-media-document', 58 );
		add_submenu_page( self::SLUG, __( 'Fileora Dashboard', 'fileora' ), __( 'Dashboard', 'fileora' ), 'fileora_view_reports', self::SLUG, array( __CLASS__, 'page_dashboard' ) );
		add_submenu_page( self::SLUG, __( 'Server Monitoring', 'fileora' ), __( 'Server Monitoring', 'fileora' ), 'fileora_view_reports', 'fileora-monitor', array( __CLASS__, 'page_monitor' ) );
		add_submenu_page( self::SLUG, __( 'Processing Tasks', 'fileora' ), __( 'Processing Tasks', 'fileora' ), 'fileora_view_reports', 'fileora-tasks', array( __CLASS__, 'page_tasks' ) );
		add_submenu_page( self::SLUG, __( 'Tool Management', 'fileora' ), __( 'Tool Management', 'fileora' ), 'fileora_manage_tools', 'fileora-tools', array( __CLASS__, 'page_tools' ) );
		add_submenu_page( self::SLUG, __( 'Tool Categories', 'fileora' ), __( 'Tool Categories', 'fileora' ), 'fileora_manage_tools', 'edit-tags.php?taxonomy=' . Fileora_Tool_Registry::TAXONOMY . '&post_type=' . Fileora_Tool_Registry::POST_TYPE );
		add_submenu_page( self::SLUG, __( 'Blog Management', 'fileora' ), __( 'Blog Management', 'fileora' ), 'edit_posts', 'edit.php' );
		add_submenu_page( self::SLUG, __( 'Announcements', 'fileora' ), __( 'Announcements', 'fileora' ), 'fileora_manage_announcements', 'edit.php?post_type=' . Fileora_Announcements::POST_TYPE );
		add_submenu_page( self::SLUG, __( 'Messages', 'fileora' ), __( 'Messages', 'fileora' ), 'fileora_manage_settings', 'edit.php?post_type=' . Fileora_Contact::POST_TYPE );
		add_submenu_page( self::SLUG, __( 'SEO', 'fileora' ), __( 'SEO', 'fileora' ), 'fileora_manage_settings', 'fileora-seo', array( 'Fileora_SEO_Fields', 'page' ) );
		add_submenu_page( self::SLUG, __( 'Fileora Settings', 'fileora' ), __( 'Settings', 'fileora' ), 'fileora_manage_settings', 'fileora-settings', array( __CLASS__, 'page_settings' ) );
	}

	/** Keeps the Fileora menu open on the tool editor and category screens. */
	public static function parent_file( $parent ) {
		$screen = get_current_screen();
		if ( $screen && ( Fileora_Tool_Registry::POST_TYPE === $screen->post_type || Fileora_Tool_Registry::TAXONOMY === $screen->taxonomy || Fileora_Announcements::POST_TYPE === $screen->post_type || Fileora_Contact::POST_TYPE === $screen->post_type ) ) {
			return self::SLUG;
		}
		return $parent;
	}

	public static function submenu_file( $sub ) {
		$screen = get_current_screen();
		if ( $screen && Fileora_Tool_Registry::TAXONOMY === $screen->taxonomy ) {
			return 'edit-tags.php?taxonomy=' . Fileora_Tool_Registry::TAXONOMY . '&post_type=' . Fileora_Tool_Registry::POST_TYPE;
		}
		if ( $screen && Fileora_Tool_Registry::POST_TYPE === $screen->post_type ) {
			return 'fileora-tools';
		}
		if ( $screen && Fileora_Announcements::POST_TYPE === $screen->post_type ) {
			return 'edit.php?post_type=' . Fileora_Announcements::POST_TYPE;
		}
		if ( $screen && Fileora_Contact::POST_TYPE === $screen->post_type ) {
			return 'edit.php?post_type=' . Fileora_Contact::POST_TYPE;
		}
		return $sub;
	}

	public static function plugin_links( $links ) {
		if ( current_user_can( 'fileora_manage_settings' ) ) {
			array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=fileora-settings' ) ) . '">' . esc_html__( 'Settings', 'fileora' ) . '</a>' );
		}
		return $links;
	}

	public static function is_fileora_screen() {
		$screen = get_current_screen();
		return $screen && ( false !== strpos( (string) $screen->id, 'fileora' ) );
	}

	public static function assets() {
		$screen = get_current_screen();
		if ( self::is_fileora_screen() || ( $screen && Fileora_Announcements::POST_TYPE === $screen->post_type ) ) {
			wp_enqueue_style( 'fileora-admin', FILEORA_CORE_URL . 'admin/assets/admin.css', array(), FILEORA_CORE_VERSION );
			wp_enqueue_script( 'fileora-admin', FILEORA_CORE_URL . 'admin/assets/admin.js', array(), FILEORA_CORE_VERSION, true );
		}
		if ( $screen && 'toplevel_page_fileora-analytics' === $screen->id ) {
			wp_enqueue_script( 'fileora-chartjs', FILEORA_CORE_URL . 'admin/assets/vendor/chart.umd.min.js', array(), '4.5.1', true );
			wp_enqueue_script( 'fileora-analytics', FILEORA_CORE_URL . 'admin/assets/analytics.js', array( 'fileora-chartjs' ), FILEORA_CORE_VERSION, true );
			wp_localize_script( 'fileora-analytics', 'FileoraAn', self::analytics_config() );
		}
	}

	/** Settings, labels and filter menus for the Visitor Analytics dashboard. */
	private static function analytics_config() {
		$tools = array();
		foreach ( Fileora_Tool_Registry::tools() as $t ) {
			$tools[] = array( 'id' => $t['id'], 'name' => $t['name'] );
		}
		usort(
			$tools,
			function ( $a, $b ) {
				return strcasecmp( $a['name'], $b['name'] );
			}
		);
		global $wp_locale;
		return array(
			'root'      => esc_url_raw( rest_url( Fileora_Core_REST::NS . '/' ) ),
			'nonce'     => wp_create_nonce( 'wp_rest' ),
			'refresh'   => 60000,
			'offset'    => (int) round( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ),
			'locale'    => str_replace( '_', '-', get_user_locale() ),
			'tools'     => $tools,
			'countries' => Fileora_Reports::countries(),
			'i18n'      => array(
				'months'         => array_values( array_map( array( $wp_locale, 'get_month_abbrev' ), $wp_locale->month ) ),
				'visitors'       => __( 'visitors', 'fileora' ),
				'uniqueVisitors' => __( 'Unique visitors', 'fileora' ),
				'uniqueSub'      => __( 'different browsers', 'fileora' ),
				'newN'           => __( '%s first-time visitors', 'fileora' ),
				'toolRuns'       => __( 'Tool runs', 'fileora' ),
				'pageViews'      => __( 'Page views', 'fileora' ),
				'runsSplit'      => __( '%1$s in browser, %2$s on server', 'fileora' ),
				'failedN'        => __( '%s failed', 'fileora' ),
				'total'          => __( 'Total', 'fileora' ),
				'period'         => __( 'Period', 'fileora' ),
				'weekOf'         => __( 'Week of', 'fileora' ),
				'unknownLoc'     => __( '%s visitors have no known location.', 'fileora' ),
				'nowActive'      => __( 'This minute: %s visitors', 'fileora' ),
				'spike'          => __( 'Spike at %1$s: %2$s visitors', 'fileora' ),
				'noTraffic'      => __( 'No visitors in the last 30 minutes.', 'fileora' ),
				'noData'         => __( 'No data for this period yet.', 'fileora' ),
				'noActivity'     => __( 'No file processing matches these filters yet.', 'fileora' ),
				'noVisits'       => __( 'No visits match these filters yet.', 'fileora' ),
				'updated'        => __( 'Updated %s', 'fileora' ),
				'showing'        => __( 'showing data from %s', 'fileora' ),
				'loadErr'        => __( 'Couldn’t refresh', 'fileora' ),
				'authErr'        => __( 'Your login has expired. Reload the page.', 'fileora' ),
				'justNow'        => __( 'just now', 'fileora' ),
				'minAgo'         => __( '%d min ago', 'fileora' ),
				'hAgo'           => __( '%d h ago', 'fileora' ),
				'dateTime'       => __( 'Date and time', 'fileora' ),
				'tool'           => __( 'Tool', 'fileora' ),
				'file'           => __( 'File name', 'fileora' ),
				'filesN'         => __( '%s files', 'fileora' ),
				'location'       => __( 'Location', 'fileora' ),
				'ip'             => __( 'IP address', 'fileora' ),
				'status'         => __( 'Status', 'fileora' ),
				'done'           => __( 'Completed', 'fileora' ),
				'failed'         => __( 'Failed', 'fileora' ),
				'progress'       => __( 'In progress', 'fileora' ),
				'server'         => __( 'Server', 'fileora' ),
				'browser'        => __( 'In browser', 'fileora' ),
				'unknown'        => __( 'Unknown', 'fileora' ),
				'lastActivity'   => __( 'Last activity', 'fileora' ),
				'firstSeen'      => __( 'Visit started', 'fileora' ),
				'visitorId'      => __( 'Visitor ID', 'fileora' ),
				'pageTool'       => __( 'Page or tool', 'fileora' ),
				'device'         => __( 'Device', 'fileora' ),
				'pagesN'         => __( 'Pages', 'fileora' ),
				'browserCol'     => __( 'Browser', 'fileora' ),
				'runsN'          => __( '%s tool runs', 'fileora' ),
				'from'           => __( 'from', 'fileora' ),
				'newTag'         => __( 'new', 'fileora' ),
				'active'         => __( 'Active', 'fileora' ),
				'ended'          => __( 'Ended', 'fileora' ),
				'results'        => __( '%s results', 'fileora' ),
				'prev'           => __( 'Previous', 'fileora' ),
				'next'           => __( 'Next', 'fileora' ),
				'pageOf'         => __( 'Page %1$s of %2$s', 'fileora' ),
				'showTable'      => __( 'Show table', 'fileora' ),
				'hideTable'      => __( 'Hide table', 'fileora' ),
				'filesProcessed' => __( 'Files processed', 'fileora' ),
				'visitsCol'      => __( 'Visits', 'fileora' ),
				'visitsN'        => __( '%s visits', 'fileora' ),
				'viewsN'         => __( '%s page views', 'fileora' ),
				/* translators: 1: start date and time, 2: end date or "now" */
				'showingPeriod'  => __( 'Showing %1$s – %2$s (site time).', 'fileora' ),
				'now'            => __( 'now', 'fileora' ),
				/* translators: %s: date */
				'detailFrom'     => __( 'Detailed records start on %s; earlier days show saved daily totals where they exist.', 'fileora' ),
				'per_minute'     => __( 'Per minute', 'fileora' ),
				'per_hour'       => __( 'Per hour', 'fileora' ),
				'per_day'        => __( 'Per day', 'fileora' ),
				'bucketsN'       => __( '%s intervals', 'fileora' ),
				/* translators: 1: number of visitors, 2: time */
				'peak'           => __( 'Busiest: %1$s visitors at %2$s', 'fileora' ),
				'trendUp'        => __( 'second half of the period %s higher than the first', 'fileora' ),
				'trendDown'      => __( 'second half of the period %s lower than the first', 'fileora' ),
				'trendNew'       => __( 'traffic only in the second half of the period', 'fileora' ),
				'noDetail'       => __( 'Some days have no records (before the site recorded visits, or removed by the retention setting).', 'fileora' ),
				'change'         => __( 'Change', 'fileora' ),
				'topLocations'   => __( 'Top locations', 'fileora' ),
				'toolViews'      => __( 'Page views', 'fileora' ),
				'success'        => __( 'Success', 'fileora' ),
				'avgTime'        => __( 'Average time', 'fileora' ),
				'partial'        => __( '(partly)', 'fileora' ),
				/* translators: 1: first period, 2: last period, 3: number of tool runs */
				'cmpTotals'      => __( '%1$s – %2$s: %3$s tool runs in total.', 'fileora' ),
				'pickDates'      => __( 'Choose a start and an end date.', 'fileora' ),
			),
		);
	}

	public static function geo_download() {
		if ( ! current_user_can( 'fileora_manage_settings' ) ) {
			wp_die( '', 403 );
		}
		check_admin_referer( 'fileora_geo_download' );
		$edition = isset( $_POST['edition'] ) && 'country' === $_POST['edition'] ? 'country' : 'city';
		if ( ! empty( $_POST['now'] ) ) {
			// Download right away in this request (when background tasks don't run on the host).
			Fileora_Geo::run_download_job( $edition );
		} else {
			Fileora_Geo::queue_download( $edition );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=fileora-settings#geo-actions' ) );
		exit;
	}

	public static function geo_upload() {
		if ( ! current_user_can( 'fileora_manage_settings' ) ) {
			wp_die( '', 403 );
		}
		check_admin_referer( 'fileora_geo_upload' );
		$r = isset( $_FILES['geo_file'] ) ? Fileora_Geo::install_upload( $_FILES['geo_file'] ) : new WP_Error( 'none', __( 'Choose a file first.', 'fileora' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$q = is_wp_error( $r ) ? array( 'fo_geo_error' => rawurlencode( $r->get_error_message() ) ) : array( 'fo_geo' => 'uploaded' );
		if ( ! is_wp_error( $r ) ) {
			Fileora_Geo::backfill();
		}
		wp_safe_redirect( add_query_arg( array_merge( array( 'page' => 'fileora-settings' ), $q ), admin_url( 'admin.php' ) ) . '#geo-actions' );
		exit;
	}

	public static function geo_backfill() {
		if ( ! current_user_can( 'fileora_manage_settings' ) ) {
			wp_die( '', 403 );
		}
		check_admin_referer( 'fileora_geo_backfill' );
		$n = Fileora_Geo::backfill();
		wp_safe_redirect( admin_url( 'admin.php?page=fileora-settings&fo_geo=filled&fo_n=' . (int) $n . '#geo-actions' ) );
		exit;
	}

	public static function geo_delete() {
		if ( ! current_user_can( 'fileora_manage_settings' ) ) {
			wp_die( '', 403 );
		}
		check_admin_referer( 'fileora_geo_delete' );
		Fileora_Geo::delete_db();
		Fileora_Geo::unschedule();
		wp_safe_redirect( admin_url( 'admin.php?page=fileora-settings&fo_geo=deleted#geo' ) );
		exit;
	}

	public static function register_settings() {
		register_setting(
			'fileora_core',
			Fileora_Core_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'Fileora_Core_Settings', 'sanitize' ),
			)
		);
	}

	private static function view( $name, array $vars = array() ) {
		extract( $vars ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
		require FILEORA_CORE_DIR . 'admin/views/partials.php';
		require FILEORA_CORE_DIR . 'admin/views/' . $name . '.php';
	}

	/** Reads ?days= for report screens (7, 30 or 90). */
	public static function days() {
		$d = isset( $_GET['days'] ) ? absint( $_GET['days'] ) : 30; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return in_array( $d, array( 1, 7, 30, 90 ), true ) ? $d : 30;
	}

	public static function page_dashboard() {
		self::view( 'dashboard' );
	}

	public static function page_analytics() {
		self::view( 'analytics' );
	}

	public static function page_monitor() {
		self::view( 'monitor' );
	}

	public static function page_tasks() {
		self::view( 'tasks', array( 'filters' => self::task_filters() ) );
	}

	public static function page_tools() {
		self::view( 'tools' );
	}

	public static function page_settings() {
		self::view( 'settings' );
	}

	/** Filters for the Processing Tasks screen and CSV export, from the query string. */
	public static function task_filters() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$range = isset( $_GET['range'] ) ? sanitize_key( $_GET['range'] ) : '30';
		$from  = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$to    = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
		$f     = array(
			'range'    => in_array( $range, array( '1', '7', '30', 'all', 'custom' ), true ) ? $range : '30',
			'tool'     => isset( $_GET['tool'] ) ? sanitize_key( $_GET['tool'] ) : '',
			'status'   => isset( $_GET['status'] ) && in_array( $_GET['status'], array( 'done', 'failed', 'open' ), true ) ? sanitize_key( $_GET['status'] ) : '',
			'q'        => isset( $_GET['q'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( sanitize_text_field( wp_unslash( $_GET['q'] ) ) ) ) : '',
			'page'     => isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1,
			'per_page' => 50,
			'from'     => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ? $from : '',
			'to'       => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ? $to : '',
		);
		// phpcs:enable
		if ( 'custom' === $f['range'] ) {
			if ( $f['from'] ) {
				$f['from_utc'] = get_gmt_from_date( $f['from'] . ' 00:00:00' );
			}
			if ( $f['to'] ) {
				$f['to_utc'] = get_gmt_from_date( gmdate( 'Y-m-d', strtotime( $f['to'] . ' +1 day' ) ) . ' 00:00:00' );
			}
		} elseif ( 'all' !== $f['range'] ) {
			$f['from_utc'] = gmdate( 'Y-m-d H:i:s', time() - (int) $f['range'] * DAY_IN_SECONDS );
		}
		return $f;
	}

	/* ---------------- actions ---------------- */

	private static function back( $page, array $args = array() ) {
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php?page=' . $page ) ) );
		exit;
	}

	/** Tool Management: on/off, order, category and target counts. */
	public static function save_tools() {
		if ( ! current_user_can( 'fileora_manage_tools' ) ) {
			wp_die( esc_html__( 'You are not allowed to manage tools.', 'fileora' ), 403 );
		}
		check_admin_referer( 'fileora_save_tools' );
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$on      = isset( $_POST['on'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['on'] ) ) : array();
		$orders  = isset( $_POST['order'] ) ? (array) wp_unslash( $_POST['order'] ) : array();
		$cats    = isset( $_POST['cat'] ) ? (array) wp_unslash( $_POST['cat'] ) : array();
		$targets = isset( $_POST['target'] ) ? (array) wp_unslash( $_POST['target'] ) : array();
		// phpcs:enable
		$changed = 0;
		foreach ( Fileora_Tool_Registry::tools() as $id => $t ) {
			if ( ! $t['post_id'] ) {
				continue;
			}
			$want   = in_array( $id, $on, true ) && 'ready' === $t['status'] ? 'publish' : 'draft';
			$update = array( 'ID' => $t['post_id'] );
			if ( get_post_status( $t['post_id'] ) !== $want ) {
				$update['post_status'] = $want;
			}
			if ( isset( $orders[ $id ] ) && (int) $orders[ $id ] !== $t['order'] ) {
				$update['menu_order'] = (int) $orders[ $id ];
			}
			if ( count( $update ) > 1 ) {
				wp_update_post( $update );
				++$changed;
			}
			if ( isset( $cats[ $id ] ) && absint( $cats[ $id ] ) && ( ! $t['category'] || (int) $t['category']['id'] !== absint( $cats[ $id ] ) ) ) {
				wp_set_object_terms( $t['post_id'], absint( $cats[ $id ] ), Fileora_Tool_Registry::TAXONOMY );
				++$changed;
			}
		}
		foreach ( $targets as $term_id => $n ) {
			update_term_meta( absint( $term_id ), 'fo_target', absint( $n ) );
		}
		Fileora_Tool_Registry::flush_cache();
		self::back( 'fileora-tools', array( 'saved' => 1 ) );
	}

	public static function sync_tools() {
		if ( ! current_user_can( 'fileora_manage_tools' ) ) {
			wp_die( esc_html__( 'You are not allowed to manage tools.', 'fileora' ), 403 );
		}
		check_admin_referer( 'fileora_sync_tools' );
		$n = Fileora_Tool_Registry::sync();
		self::back( 'fileora-tools', array( 'synced' => $n ) );
	}

	public static function check_now() {
		if ( ! current_user_can( 'fileora_manage_settings' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'fileora' ), 403 );
		}
		check_admin_referer( 'fileora_check_now' );
		Fileora_Server_Monitor::check( 'manual' );
		$back = isset( $_POST['back'] ) && 'settings' === $_POST['back'] ? 'fileora-settings' : 'fileora-monitor'; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		self::back( $back, array( 'checked' => 1 ) );
	}

	/** CSV download of the filtered Processing Tasks list. */
	public static function export_tasks() {
		if ( ! current_user_can( 'fileora_view_reports' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'fileora' ), 403 );
		}
		check_admin_referer( 'fileora_export_tasks' );
		$f        = self::task_filters();
		$f['all'] = true;
		$res      = Fileora_Task_Manager::query( $f );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="fileora-tasks-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		fputcsv( $out, array( 'started_utc', 'finished_utc', 'tool', 'status', 'failure_code', 'error', 'duration_ms', 'files', 'bytes_in', 'bytes_out', 'downloaded_utc', 'job_id' ) );
		foreach ( $res['rows'] as $r ) {
			fputcsv( $out, array( $r->created_at, $r->finished_at, $r->tool, $r->status, $r->error_code, $r->error, $r->duration_ms, $r->files, $r->bytes_in, $r->bytes_out, $r->downloaded_at, $r->id ) );
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}

	/* ---------------- tool page editor ---------------- */

	public static function meta_boxes() {
		add_meta_box( 'fileora-tool-info', __( 'Tool', 'fileora' ), array( __CLASS__, 'box_info' ), null, 'side', 'high' );
		add_meta_box( 'fileora-tool-faq', __( 'Questions and answers (FAQ)', 'fileora' ), array( __CLASS__, 'box_faq' ), null, 'normal', 'default' );
	}

	public static function box_info( $post ) {
		$t = Fileora_Tool_Registry::by_post( $post );
		if ( ! $t ) {
			echo '<p>' . esc_html__( 'This page isn’t linked to a tool in the code.', 'fileora' ) . '</p>';
			return;
		}
		$runs = Fileora_Tool_Registry::runs_on( $t );
		echo '<dl class="fo-dl">';
		echo '<dt>' . esc_html__( 'Tool id', 'fileora' ) . '</dt><dd><code>' . esc_html( $t['id'] ) . '</code></dd>';
		echo '<dt>' . esc_html__( 'Runs on', 'fileora' ) . '</dt><dd>' . esc_html( self::exec_label( $t['exec'], $runs ) ) . '</dd>';
		echo '<dt>' . esc_html__( 'Accepts', 'fileora' ) . '</dt><dd>' . esc_html( Fileora_Tool_Registry::accept_noun( $t['accept'], true ) ) . '</dd>';
		echo '<dt>' . esc_html__( 'Status', 'fileora' ) . '</dt><dd>' . ( 'ready' === $t['status'] ? esc_html__( 'Implemented and tested', 'fileora' ) : esc_html__( 'Pending (shown as “coming soon”)', 'fileora' ) ) . '</dd>';
		if ( $t['needs'] && 'browser' !== $t['exec'] ) {
			echo '<dt>' . esc_html__( 'Server needs', 'fileora' ) . '</dt><dd>' . esc_html( $t['needs'] ) . '</dd>';
		}
		echo '</dl>';
		echo '<p class="description">' . esc_html__( 'Title = tool name. Excerpt = the short description on cards and in search results. Publish = on, Draft = off.', 'fileora' ) . '</p>';
		echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=fileora-tools' ) ) . '">' . esc_html__( 'Tool Management', 'fileora' ) . '</a></p>';
	}

	public static function box_faq( $post ) {
		wp_nonce_field( 'fileora_faq', 'fileora_faq_nonce' );
		$faq = get_post_meta( $post->ID, Fileora_Tool_Registry::META_FAQ, true );
		echo '<p class="description">' . esc_html__( 'One question per block: the question on the first line, the answer on the next. Leave an empty line between blocks. Shown under the tool and added to search results as FAQ data.', 'fileora' ) . '</p>';
		echo '<textarea name="fileora_faq" rows="12" class="large-text code">' . esc_textarea( $faq ) . '</textarea>';
	}

	public static function save_tool_meta( $post_id, $post ) {
		if ( ! isset( $_POST['fileora_faq_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['fileora_faq_nonce'] ), 'fileora_faq' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$faq = isset( $_POST['fileora_faq'] ) ? sanitize_textarea_field( wp_unslash( $_POST['fileora_faq'] ) ) : '';
		update_post_meta( $post_id, Fileora_Tool_Registry::META_FAQ, $faq );
		// A pending tool can't be switched on from the editor.
		$t = Fileora_Tool_Registry::by_post( $post );
		if ( $t && 'ready' !== $t['status'] && 'publish' === $post->post_status ) {
			remove_action( 'save_post_' . Fileora_Tool_Registry::POST_TYPE, array( __CLASS__, 'save_tool_meta' ), 10 );
			wp_update_post(
				array(
					'ID'          => $post_id,
					'post_status' => 'draft',
				)
			);
		}
	}

	public static function tool_columns( $cols ) {
		$new = array();
		foreach ( $cols as $k => $v ) {
			$new[ $k ] = $v;
			if ( 'title' === $k ) {
				$new['fo_runs']   = __( 'Runs on', 'fileora' );
				$new['fo_status'] = __( 'Status', 'fileora' );
			}
		}
		unset( $new['date'] );
		return $new;
	}

	public static function tool_column( $col, $post_id ) {
		$t = Fileora_Tool_Registry::by_post( $post_id );
		if ( ! $t ) {
			return;
		}
		if ( 'fo_runs' === $col ) {
			echo esc_html( self::exec_label( $t['exec'], Fileora_Tool_Registry::runs_on( $t ) ) );
		} elseif ( 'fo_status' === $col ) {
			echo 'ready' === $t['status'] ? esc_html__( 'Implemented', 'fileora' ) : esc_html__( 'Pending', 'fileora' );
		}
	}

	public static function exec_label( $exec, $runs ) {
		if ( 'hybrid' === $exec ) {
			/* translators: %s: where it runs now */
			return sprintf( __( 'Server, browser fallback (now: %s)', 'fileora' ), 'server' === $runs ? __( 'server', 'fileora' ) : __( 'browser', 'fileora' ) );
		}
		return 'server' === $exec ? __( 'Server', 'fileora' ) : __( 'Browser', 'fileora' );
	}

	/* ---------------- category fields ---------------- */

	private static function colors() {
		return array(
			'organize' => __( 'Blue', 'fileora' ),
			'optimize' => __( 'Green', 'fileora' ),
			'to'       => __( 'Orange', 'fileora' ),
			'from'     => __( 'Red', 'fileora' ),
			'edit'     => __( 'Purple', 'fileora' ),
			'security' => __( 'Navy', 'fileora' ),
			'ai'       => __( 'Teal', 'fileora' ),
			'image'    => __( 'Pink', 'fileora' ),
		);
	}

	public static function term_fields_add() {
		wp_nonce_field( 'fileora_term', 'fileora_term_nonce' );
		echo '<div class="form-field"><label for="fo_color">' . esc_html__( 'Colour', 'fileora' ) . '</label><select name="fo_color" id="fo_color">';
		foreach ( self::colors() as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $label ) . '</option>';
		}
		echo '</select></div>';
		echo '<div class="form-field"><label for="fo_order">' . esc_html__( 'Order', 'fileora' ) . '</label><input type="number" name="fo_order" id="fo_order" value="80"></div>';
	}

	public static function term_fields_edit( $term ) {
		wp_nonce_field( 'fileora_term', 'fileora_term_nonce' );
		$color = get_term_meta( $term->term_id, 'fo_color', true );
		echo '<tr class="form-field"><th scope="row"><label for="fo_color">' . esc_html__( 'Colour', 'fileora' ) . '</label></th><td><select name="fo_color" id="fo_color">';
		foreach ( self::colors() as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $color, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></td></tr>';
		echo '<tr class="form-field"><th scope="row"><label for="fo_order">' . esc_html__( 'Order', 'fileora' ) . '</label></th><td><input type="number" name="fo_order" id="fo_order" value="' . esc_attr( (int) get_term_meta( $term->term_id, 'fo_order', true ) ) . '"><p class="description">' . esc_html__( 'Lower numbers come first on the website.', 'fileora' ) . '</p></td></tr>';
	}

	public static function save_term( $term_id ) {
		if ( ! isset( $_POST['fileora_term_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['fileora_term_nonce'] ), 'fileora_term' ) || ! current_user_can( 'fileora_manage_tools' ) ) {
			return;
		}
		if ( isset( $_POST['fo_color'] ) && array_key_exists( sanitize_key( $_POST['fo_color'] ), self::colors() ) ) {
			update_term_meta( $term_id, 'fo_color', sanitize_key( $_POST['fo_color'] ) );
		}
		if ( isset( $_POST['fo_order'] ) ) {
			update_term_meta( $term_id, 'fo_order', (int) $_POST['fo_order'] );
		}
		Fileora_Tool_Registry::flush_cache();
	}

	/* ---------------- notices ---------------- */

	public static function notices() {
		if ( get_transient( 'fileora_old_plugin_retired' ) && current_user_can( 'activate_plugins' ) ) {
			delete_transient( 'fileora_old_plugin_retired' );
			echo '<div class="notice notice-info is-dismissible"><p>' . esc_html__( 'Fileora Core switched off the old “Fileora” plugin and imported its settings and task history. You can delete the old plugin. Activate the Fileora theme under Appearance → Themes for the full website.', 'fileora' ) . '</p></div>';
		}
		if ( ! self::is_fileora_screen() || ! current_user_can( 'fileora_view_reports' ) ) {
			return;
		}
		$last = Fileora_Server_Monitor::last();
		if ( ! Fileora_Core_Settings::backend_configured() ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'No processing server is set up yet. Browser tools work; server tools are unavailable until you add the server address and shared key in Fileora → Settings.', 'fileora' ) . '</p></div>';
		} elseif ( $last && ( ! $last['ok'] || false === $last['auth'] ) && ( time() - $last['time'] ) < 2 * HOUR_IN_SECONDS ) {
			echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'Processing server problem:', 'fileora' ) . '</strong> ' . esc_html( $last['error'] ? $last['error'] : __( 'not reachable', 'fileora' ) ) . ' ' . '<a href="' . esc_url( admin_url( 'admin.php?page=fileora-monitor' ) ) . '">' . esc_html__( 'Server Monitoring', 'fileora' ) . '</a></p></div>';
		}
		if ( Fileora_Core_Settings::backend_configured() && (int) get_option( 'fileora_core_activated', 0 ) < time() - HOUR_IN_SECONDS && ( ! $last || ( time() - $last['time'] ) > max( 3 * Fileora_Server_Monitor::interval(), HOUR_IN_SECONDS ) ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'Health checks are not running on schedule, so uptime can’t be measured. WP-Cron only runs when someone visits the site: set up a real cron job (README, “Real cron”).', 'fileora' ) . '</p></div>';
		}
	}
}
