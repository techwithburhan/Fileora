<?php
/**
 * Plugin Name:       Fileora Core
 * Plugin URI:        https://fileora.com
 * Description:       Fileora's tool registry, tool pages, processing-server integration, visitor analytics with live charts, popup announcements, server monitoring, roles and administration. Works with the Fileora theme or any other theme.
 * Version:           2.11.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Fileora
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       fileora
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

define( 'FILEORA_CORE_VERSION', '2.11.0' );
define( 'FILEORA_CORE_FILE', __FILE__ );
define( 'FILEORA_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'FILEORA_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once FILEORA_CORE_DIR . 'includes/class-log.php';
require_once FILEORA_CORE_DIR . 'includes/class-settings.php';
require_once FILEORA_CORE_DIR . 'includes/class-permissions.php';
require_once FILEORA_CORE_DIR . 'includes/class-tool-registry.php';
require_once FILEORA_CORE_DIR . 'includes/class-security.php';
require_once FILEORA_CORE_DIR . 'includes/class-backend-api.php';
require_once FILEORA_CORE_DIR . 'includes/class-task-manager.php';
require_once FILEORA_CORE_DIR . 'includes/class-geo.php';
require_once FILEORA_CORE_DIR . 'includes/class-analytics.php';
require_once FILEORA_CORE_DIR . 'includes/class-history.php';
require_once FILEORA_CORE_DIR . 'includes/class-reports.php';
require_once FILEORA_CORE_DIR . 'includes/class-announcements.php';
require_once FILEORA_CORE_DIR . 'includes/class-support.php';
require_once FILEORA_CORE_DIR . 'includes/class-content.php';
require_once FILEORA_CORE_DIR . 'includes/class-contact.php';
require_once FILEORA_CORE_DIR . 'includes/class-resume.php';
require_once FILEORA_CORE_DIR . 'includes/class-seo-fields.php';
require_once FILEORA_CORE_DIR . 'includes/class-markdown.php';
require_once FILEORA_CORE_DIR . 'includes/class-seo-plan.php';
require_once FILEORA_CORE_DIR . 'includes/class-server-monitor.php';
require_once FILEORA_CORE_DIR . 'includes/class-rest.php';
require_once FILEORA_CORE_DIR . 'includes/class-icons.php';
require_once FILEORA_CORE_DIR . 'includes/class-frontend.php';
require_once FILEORA_CORE_DIR . 'includes/class-seo.php';
require_once FILEORA_CORE_DIR . 'includes/class-cleanup.php';
require_once FILEORA_CORE_DIR . 'includes/class-admin.php';
require_once FILEORA_CORE_DIR . 'includes/class-core.php';
require_once FILEORA_CORE_DIR . 'includes/functions.php';

register_activation_hook( __FILE__, array( 'Fileora_Core', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Fileora_Core', 'deactivate' ) );

Fileora_Core::boot();
