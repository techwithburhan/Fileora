<?php
/**
 * Small view helpers for the admin screens: KPI tiles, SVG charts, labels.
 * Charts are drawn server-side as SVG with a native tooltip per mark (<title>)
 * and a table view underneath, so they need no chart library.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'fo_admin_kpi' ) ) {

	/** One KPI tile. $sub is a short secondary line. */
	function fo_admin_kpi( $label, $value, $sub = '', $status = '' ) {
		echo '<div class="fo-kpi' . ( $status ? ' is-' . esc_attr( $status ) : '' ) . '"><span class="fo-kpi-l">' . esc_html( $label ) . '</span><span class="fo-kpi-v">' . esc_html( $value ) . '</span>' . ( '' !== $sub ? '<span class="fo-kpi-s">' . esc_html( $sub ) . '</span>' : '' ) . '</div>';
	}

	function fo_admin_num( $n ) {
		return null === $n ? '–' : number_format_i18n( (float) $n );
	}

	function fo_admin_pct( $f, $decimals = 1 ) {
		return null === $f ? '–' : number_format_i18n( (float) $f, $decimals ) . '%';
	}

	function fo_admin_ms( $ms ) {
		if ( null === $ms ) {
			return '–';
		}
		$ms = (int) $ms;
		return $ms < 1000 ? $ms . ' ms' : ( $ms < 60000 ? number_format_i18n( $ms / 1000, 1 ) . ' s' : number_format_i18n( $ms / 60000, 1 ) . ' min' );
	}

	function fo_admin_bytes( $b ) {
		return null === $b ? '–' : size_format( (int) $b, (int) $b >= MB_IN_BYTES ? 1 : 0 );
	}

	function fo_admin_time( $utc ) {
		return $utc ? get_date_from_gmt( $utc, get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) : '–';
	}

	function fo_admin_tool_name( $id ) {
		$t = Fileora_Tool_Registry::get( $id );
		return $t ? $t['name'] : $id;
	}

	/** Last $days UTC dates, oldest first. */
	function fo_admin_dates( $days ) {
		$out = array();
		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$out[] = gmdate( 'Y-m-d', time() - $i * DAY_IN_SECONDS );
		}
		return $out;
	}

	function fo_admin_short_date( $ymd ) {
		return date_i18n( 'j M', strtotime( $ymd . ' 12:00:00' ) );
	}

	/** Rounded-up axis maximum and three gridline values. */
	function fo_admin_scale( $max ) {
		$max = max( 1, (float) $max );
		$pow = pow( 10, floor( log10( $max ) ) );
		foreach ( array( 1, 2, 2.5, 5, 10 ) as $m ) {
			if ( $m * $pow >= $max ) {
				$top = $m * $pow;
				break;
			}
		}
		$top = max( 1, $top );
		return array( $top, array( $top / 3, $top * 2 / 3, $top ) );
	}

	/**
	 * Column chart over days. $series: [ ['label' => 'Visitors', 'class' => 's1', 'values' => [date => n]] , ... ]
	 * Two series are stacked (e.g. done + failed); one series is plain.
	 */
	function fo_admin_columns( array $dates, array $series, $title, $unit = '' ) {
		$w   = 760;
		$h   = 210;
		$pl  = 40;
		$pr  = 8;
		$pt  = 10;
		$pb  = 26;
		$n   = max( 1, count( $dates ) );
		$cw  = ( $w - $pl - $pr ) / $n;
		$bw  = min( 24, max( 4, $cw * 0.62 ) );
		$tot = array();
		foreach ( $dates as $d ) {
			$tot[ $d ] = 0;
			foreach ( $series as $s ) {
				$tot[ $d ] += isset( $s['values'][ $d ] ) ? (float) $s['values'][ $d ] : 0;
			}
		}
		list( $top, $grid ) = fo_admin_scale( $tot ? max( $tot ) : 1 );
		$y = function ( $v ) use ( $h, $pt, $pb, $top ) {
			return $h - $pb - ( $v / $top ) * ( $h - $pt - $pb );
		};
		$svg = '<svg class="fo-chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="' . esc_attr( $title ) . '" preserveAspectRatio="none">';
		foreach ( $grid as $g ) {
			$gy   = $y( $g );
			$svg .= '<line class="fo-grid" x1="' . $pl . '" x2="' . ( $w - $pr ) . '" y1="' . $gy . '" y2="' . $gy . '"/>';
			$svg .= '<text class="fo-axis" x="' . ( $pl - 6 ) . '" y="' . ( $gy + 4 ) . '" text-anchor="end">' . esc_html( fo_admin_num( round( $g, $g < 3 ? 1 : 0 ) ) ) . '</text>';
		}
		$base = $y( 0 );
		$svg .= '<line class="fo-base" x1="' . $pl . '" x2="' . ( $w - $pr ) . '" y1="' . $base . '" y2="' . $base . '"/>';
		$every = max( 1, (int) ceil( $n / 8 ) );
		foreach ( $dates as $i => $d ) {
			$x   = $pl + $i * $cw + ( $cw - $bw ) / 2;
			$acc = 0;
			$tip = fo_admin_short_date( $d );
			$k   = 0;
			$last = count( $series ) - 1;
			// Find the top-most non-zero segment so only it gets the rounded end.
			$top_idx = -1;
			foreach ( $series as $si => $s ) {
				if ( ! empty( $s['values'][ $d ] ) ) {
					$top_idx = $si;
				}
			}
			foreach ( $series as $si => $s ) {
				$v = isset( $s['values'][ $d ] ) ? (float) $s['values'][ $d ] : 0;
				$tip .= ' · ' . $s['label'] . ': ' . fo_admin_num( $v ) . $unit;
				if ( $v <= 0 ) {
					continue;
				}
				$y0 = $y( $acc );
				$y1 = $y( $acc + $v );
				$gap = $acc > 0 ? 2 : 0; // surface gap between stacked segments
				$hgt = max( 1, $y0 - $y1 - $gap );
				$r   = $si === $top_idx ? min( 4, $hgt / 2, $bw / 2 ) : 0;
				$svg .= '<path class="fo-bar ' . esc_attr( $s['class'] ) . '" d="' . fo_admin_bar_path( $x, $y1, $bw, $hgt, $r ) . '"/>';
				$acc += $v;
				++$k;
			}
			$svg .= '<rect class="fo-hit" x="' . ( $pl + $i * $cw ) . '" y="' . $pt . '" width="' . $cw . '" height="' . ( $h - $pt - $pb ) . '"><title>' . esc_html( $tip ) . '</title></rect>';
			if ( ( 0 === $i % $every && $n - 1 - $i >= $every * 0.6 ) || $i === $n - 1 ) {
				$svg .= '<text class="fo-axis" x="' . ( $pl + $i * $cw + $cw / 2 ) . '" y="' . ( $h - 8 ) . '" text-anchor="middle">' . esc_html( fo_admin_short_date( $d ) ) . '</text>';
			}
		}
		$svg .= '</svg>';
		$legend = '';
		if ( count( $series ) > 1 ) {
			$legend = '<div class="fo-legend">';
			foreach ( $series as $s ) {
				$legend .= '<span><i class="' . esc_attr( $s['class'] ) . '"></i>' . esc_html( $s['label'] ) . '</span>';
			}
			$legend .= '</div>';
		}
		echo '<figure class="fo-fig"><figcaption>' . esc_html( $title ) . '</figcaption>' . $legend . $svg . '</figure>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts
	}

	/** Bar path with a rounded top and a square base. */
	function fo_admin_bar_path( $x, $y, $w, $h, $r ) {
		$r = max( 0, $r );
		return sprintf(
			'M%1$.2f %2$.2fV%3$.2fQ%1$.2f %4$.2f %5$.2f %4$.2fH%6$.2fQ%7$.2f %4$.2f %7$.2f %3$.2fV%2$.2fZ',
			$x,
			$y + $h,
			$y + $r,
			$y,
			$x + $r,
			$x + $w - $r,
			$x + $w
		);
	}

	/** Line chart of response times. $points: [ [unix, ms, ok], ... ] */
	function fo_admin_latency( array $points, $from, $to, $title ) {
		$w  = 760;
		$h  = 200;
		$pl = 48;
		$pr = 8;
		$pt = 10;
		$pb = 26;
		$max = 1;
		foreach ( $points as $p ) {
			if ( $p[2] ) {
				$max = max( $max, $p[1] );
			}
		}
		list( $top, $grid ) = fo_admin_scale( $max );
		$x = function ( $t ) use ( $from, $to, $w, $pl, $pr ) {
			return $pl + ( $t - $from ) / max( 1, $to - $from ) * ( $w - $pl - $pr );
		};
		$y = function ( $v ) use ( $h, $pt, $pb, $top ) {
			return $h - $pb - min( 1, $v / $top ) * ( $h - $pt - $pb );
		};
		$svg = '<svg class="fo-chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="' . esc_attr( $title ) . '" preserveAspectRatio="none">';
		foreach ( $grid as $g ) {
			$gy   = $y( $g );
			$svg .= '<line class="fo-grid" x1="' . $pl . '" x2="' . ( $w - $pr ) . '" y1="' . $gy . '" y2="' . $gy . '"/><text class="fo-axis" x="' . ( $pl - 6 ) . '" y="' . ( $gy + 4 ) . '" text-anchor="end">' . esc_html( fo_admin_ms( $g ) ) . '</text>';
		}
		$svg .= '<line class="fo-base" x1="' . $pl . '" x2="' . ( $w - $pr ) . '" y1="' . $y( 0 ) . '" y2="' . $y( 0 ) . '"/>';
		// Line segments break where a check failed or the gap is larger than two intervals.
		$cap  = 2 * Fileora_Server_Monitor::interval();
		$seg  = array();
		$prev = null;
		$path = '';
		foreach ( $points as $p ) {
			if ( ! $p[2] ) {
				$prev = null;
				$svg .= '<line class="fo-down" x1="' . $x( $p[0] ) . '" x2="' . $x( $p[0] ) . '" y1="' . $pt . '" y2="' . ( $h - $pb ) . '"><title>' . esc_html( wp_date( 'j M H:i', $p[0] ) . ' · ' . __( 'Down', 'fileora' ) ) . '</title></line>';
				continue;
			}
			$cmd   = ( null === $prev || $p[0] - $prev > $cap ) ? 'M' : 'L';
			$path .= sprintf( '%s%.2f %.2f', $cmd, $x( $p[0] ), $y( $p[1] ) );
			$prev  = $p[0];
		}
		if ( $path ) {
			$svg .= '<path class="fo-line" d="' . $path . '"/>';
		}
		foreach ( $points as $p ) {
			if ( $p[2] ) {
				$svg .= '<circle class="fo-hitdot" cx="' . $x( $p[0] ) . '" cy="' . $y( $p[1] ) . '" r="6"><title>' . esc_html( wp_date( 'j M H:i', $p[0] ) . ' · ' . fo_admin_ms( $p[1] ) ) . '</title></circle>';
			}
		}
		$ticks = 6;
		for ( $i = 0; $i <= $ticks; $i++ ) {
			$t    = $from + ( $to - $from ) * $i / $ticks;
			$svg .= '<text class="fo-axis" x="' . $x( $t ) . '" y="' . ( $h - 8 ) . '" text-anchor="' . ( 0 === $i ? 'start' : ( $ticks === $i ? 'end' : 'middle' ) ) . '">' . esc_html( wp_date( 'H:i', (int) $t ) ) . '</text>';
		}
		$svg .= '</svg>';
		echo '<figure class="fo-fig"><figcaption>' . esc_html( $title ) . '</figcaption>' . $svg . '</figure>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/** Status chip with an icon-like glyph and label (never colour alone). */
	function fo_admin_status( $state, $label ) {
		$glyph = array(
			'good'     => '●',
			'warning'  => '▲',
			'critical' => '■',
			'unknown'  => '○',
		);
		return '<span class="fo-st is-' . esc_attr( $state ) . '"><span aria-hidden="true">' . ( isset( $glyph[ $state ] ) ? $glyph[ $state ] : '○' ) . '</span>' . esc_html( $label ) . '</span>';
	}

	function fo_admin_avail_state( $a ) {
		if ( null === $a ) {
			return 'unknown';
		}
		return $a >= 99.5 ? 'good' : ( $a >= 95 ? 'warning' : 'critical' );
	}

	/** Window selector (7 / 30 / 90 days). */
	function fo_admin_days_nav( $page, $days, array $choices = array( 7, 30, 90 ) ) {
		echo '<nav class="fo-seg" aria-label="' . esc_attr__( 'Time range', 'fileora' ) . '">';
		foreach ( $choices as $d ) {
			/* translators: %d: number of days */
			$label = 1 === $d ? __( '24 hours', 'fileora' ) : sprintf( _n( '%d day', '%d days', $d, 'fileora' ), $d );
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=' . $page . '&days=' . $d ) ) . '"' . ( $d === $days ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
	}
}
