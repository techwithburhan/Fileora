<?php
/**
 * Fileora → Server Monitoring.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

$fo_last   = Fileora_Server_Monitor::last();
$fo_u1     = Fileora_Server_Monitor::uptime( DAY_IN_SECONDS );
$fo_u7     = Fileora_Server_Monitor::uptime( 7 * DAY_IN_SECONDS );
$fo_u30    = Fileora_Server_Monitor::uptime( 30 * DAY_IN_SECONDS );
$fo_daily  = Fileora_Server_Monitor::daily( 30 );
$fo_checks = Fileora_Server_Monitor::checks( DAY_IN_SECONDS );
$fo_recent = array_slice( array_reverse( $fo_checks ), 0, 20 );
$fo_points = array();
foreach ( $fo_checks as $fo_c ) {
	$fo_points[] = array( strtotime( $fo_c->checked_at . ' UTC' ), (int) $fo_c->latency_ms, (int) $fo_c->ok );
}
$fo_body   = $fo_last && is_array( $fo_last['body'] ) ? $fo_last['body'] : array();
$fo_tools  = isset( $fo_body['tools'] ) && is_array( $fo_body['tools'] ) ? $fo_body['tools'] : array();
$fo_next   = wp_next_scheduled( Fileora_Server_Monitor::HOOK );
$fo_minute = (int) ( Fileora_Server_Monitor::interval() / 60 );
?>
<div class="wrap fo-wrap">
	<div class="fo-head">
		<h1><?php esc_html_e( 'Server Monitoring', 'fileora' ); ?></h1>
		<?php if ( current_user_can( 'fileora_manage_settings' ) ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="fileora_check_now">
				<?php wp_nonce_field( 'fileora_check_now' ); ?>
				<button class="button button-primary"><?php esc_html_e( 'Check now', 'fileora' ); ?></button>
			</form>
		<?php endif; ?>
	</div>
	<?php if ( isset( $_GET['checked'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Health check done.', 'fileora' ); ?></p></div>
	<?php endif; ?>
	<p class="fo-lead">
		<?php
		echo esc_html(
			sprintf(
				/* translators: 1: server address, 2: minutes */
				__( 'WordPress checks %1$s every %2$d minutes: is it up, how fast does it answer, is the shared key accepted, and which tools can it run.', 'fileora' ),
				Fileora_Core_Settings::value( 'service_url' ),
				$fo_minute
			)
		);
		if ( $fo_next ) {
			echo ' ' . esc_html( sprintf( __( 'Next check in %s.', 'fileora' ), human_time_diff( $fo_next ) ) );
		}
		?>
	</p>

	<div class="fo-kpis">
		<?php
		if ( $fo_last ) {
			$fo_state = $fo_last['ok'] && false !== $fo_last['auth'] ? 'good' : 'critical';
			fo_admin_kpi( __( 'Status now', 'fileora' ), $fo_last['ok'] ? ( false === $fo_last['auth'] ? __( 'Key rejected', 'fileora' ) : __( 'Up', 'fileora' ) ) : __( 'Down', 'fileora' ), sprintf( __( 'checked %s ago', 'fileora' ), human_time_diff( $fo_last['time'] ) ), $fo_state );
			fo_admin_kpi( __( 'Response time', 'fileora' ), fo_admin_ms( $fo_last['latency_ms'] ), __( 'last check', 'fileora' ) );
		} else {
			fo_admin_kpi( __( 'Status now', 'fileora' ), __( 'Unknown', 'fileora' ), __( 'no check yet', 'fileora' ), 'unknown' );
		}
		fo_admin_kpi( __( 'Availability, 24 hours', 'fileora' ), fo_admin_pct( $fo_u1['availability'], 2 ), sprintf( __( 'coverage %s', 'fileora' ), fo_admin_pct( $fo_u1['coverage'] ) ), fo_admin_avail_state( $fo_u1['availability'] ) );
		fo_admin_kpi( __( 'Availability, 7 days', 'fileora' ), fo_admin_pct( $fo_u7['availability'], 2 ), sprintf( __( 'coverage %s', 'fileora' ), fo_admin_pct( $fo_u7['coverage'] ) ), fo_admin_avail_state( $fo_u7['availability'] ) );
		fo_admin_kpi( __( 'Availability, 30 days', 'fileora' ), fo_admin_pct( $fo_u30['availability'], 2 ), sprintf( __( 'coverage %s', 'fileora' ), fo_admin_pct( $fo_u30['coverage'] ) ), fo_admin_avail_state( $fo_u30['availability'] ) );
		fo_admin_kpi( __( 'Successful checks, 30 days', 'fileora' ), fo_admin_num( $fo_u30['ok_checks'] ) . ' / ' . fo_admin_num( $fo_u30['checks'] ), __( 'check-success rate ', 'fileora' ) . fo_admin_pct( $fo_u30['check_rate'] ) );
		?>
	</div>
	<p class="description fo-formula"><?php esc_html_e( 'Availability = time covered by successful checks ÷ monitored time × 100. Each check covers the time until the next one, at most two intervals; longer gaps are unmonitored and shown as lower coverage instead of being counted as up or down.', 'fileora' ); ?></p>

	<div class="fo-row">
		<section class="fo-card fo-grow">
			<h2><?php esc_html_e( 'Response time, last 24 hours', 'fileora' ); ?></h2>
			<?php
			if ( $fo_points ) {
				fo_admin_latency( $fo_points, time() - DAY_IN_SECONDS, time(), __( 'Response time of each health check; red lines are failed checks', 'fileora' ) );
			} else {
				echo '<p class="fo-empty">' . esc_html__( 'No checks in the last 24 hours.', 'fileora' ) . '</p>';
			}
			?>
		</section>
	</div>

	<section class="fo-card">
		<h2><?php esc_html_e( 'Availability per day, last 30 days', 'fileora' ); ?></h2>
		<div class="fo-strip" role="list">
			<?php foreach ( $fo_daily as $fo_d => $fo_u ) : ?>
				<?php
				$fo_st  = fo_admin_avail_state( $fo_u['availability'] );
				$fo_tip = fo_admin_short_date( $fo_d ) . ': ' . ( null === $fo_u['availability'] ? __( 'no data', 'fileora' ) : fo_admin_pct( $fo_u['availability'], 2 ) . ' ' . sprintf( __( '(coverage %s)', 'fileora' ), fo_admin_pct( $fo_u['coverage'], 0 ) ) );
				?>
				<span role="listitem" class="fo-day is-<?php echo esc_attr( $fo_st ); ?>" title="<?php echo esc_attr( $fo_tip ); ?>"><span class="sr"><?php echo esc_html( $fo_tip ); ?></span></span>
			<?php endforeach; ?>
		</div>
		<div class="fo-legend">
			<span><i class="s-good"></i><?php esc_html_e( '99.5% or more', 'fileora' ); ?></span>
			<span><i class="s-warning"></i><?php esc_html_e( '95–99.5%', 'fileora' ); ?></span>
			<span><i class="s-critical"></i><?php esc_html_e( 'below 95%', 'fileora' ); ?></span>
			<span><i class="s-unknown"></i><?php esc_html_e( 'no data', 'fileora' ); ?></span>
		</div>
	</section>

	<div class="fo-row">
		<section class="fo-card fo-grow">
			<h2><?php esc_html_e( 'What the server reports', 'fileora' ); ?></h2>
			<?php if ( $fo_body ) : ?>
				<dl class="fo-dl fo-dl-wide">
					<dt><?php esc_html_e( 'Shared key set on the server', 'fileora' ); ?></dt><dd><?php echo ! empty( $fo_body['key_set'] ) ? fo_admin_status( 'good', __( 'Yes', 'fileora' ) ) : fo_admin_status( 'critical', __( 'No', 'fileora' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></dd>
					<dt><?php esc_html_e( 'Shared key accepted', 'fileora' ); ?></dt><dd><?php echo null === $fo_last['auth'] ? fo_admin_status( 'unknown', __( 'Unknown', 'fileora' ) ) : ( $fo_last['auth'] ? fo_admin_status( 'good', __( 'Yes', 'fileora' ) ) : fo_admin_status( 'critical', __( 'No, it doesn’t match FILEORA_KEY', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></dd>
					<dt><?php esc_html_e( 'Parallel workers', 'fileora' ); ?></dt><dd><?php echo isset( $fo_body['workers'] ) ? esc_html( (int) $fo_body['workers'] ) : esc_html__( 'Not reported', 'fileora' ); ?></dd>
					<dt><?php esc_html_e( 'Queue', 'fileora' ); ?></dt><dd>
						<?php
						if ( isset( $fo_body['queue'] ) && is_array( $fo_body['queue'] ) ) {
							echo esc_html( sprintf( __( '%1$d waiting, %2$d running', 'fileora' ), (int) ( isset( $fo_body['queue']['queued'] ) ? $fo_body['queue']['queued'] : 0 ), (int) ( isset( $fo_body['queue']['running'] ) ? $fo_body['queue']['running'] : 0 ) ) );
						} else {
							esc_html_e( 'Not reported by this server version (update app.py to see it).', 'fileora' );
						}
						?>
					</dd>
					<?php if ( ! empty( $fo_body['ocr_languages'] ) ) : ?>
						<dt><?php esc_html_e( 'OCR languages', 'fileora' ); ?></dt><dd><?php echo esc_html( implode( ', ', (array) $fo_body['ocr_languages'] ) ); ?></dd>
					<?php endif; ?>
				</dl>
			<?php else : ?>
				<p class="fo-empty"><?php esc_html_e( 'The server hasn’t answered a health check yet.', 'fileora' ); ?></p>
			<?php endif; ?>
		</section>
		<section class="fo-card fo-grow">
			<h2><?php esc_html_e( 'Server tools', 'fileora' ); ?></h2>
			<table class="widefat striped fo-table">
				<thead><tr><th><?php esc_html_e( 'Tool', 'fileora' ); ?></th><th><?php esc_html_e( 'Needs', 'fileora' ); ?></th><th><?php esc_html_e( 'Server status', 'fileora' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( Fileora_Tool_Registry::tools() as $fo_t ) : ?>
					<?php
					if ( 'browser' === $fo_t['exec'] ) {
						continue;
					}
					$fo_a = Fileora_Server_Monitor::tool_available( $fo_t['id'] );
					?>
					<tr><td><?php echo esc_html( $fo_t['name'] ); ?></td><td><?php echo esc_html( $fo_t['needs'] ); ?></td><td><?php echo true === $fo_a ? fo_admin_status( 'good', __( 'Available', 'fileora' ) ) : ( false === $fo_a ? fo_admin_status( 'critical', __( 'Not available', 'fileora' ) ) : fo_admin_status( 'unknown', __( 'Unknown', 'fileora' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</section>
	</div>

	<section class="fo-card">
		<h2><?php esc_html_e( 'Recent health checks', 'fileora' ); ?></h2>
		<?php if ( $fo_recent ) : ?>
			<table class="widefat striped fo-table">
				<thead><tr><th><?php esc_html_e( 'Time', 'fileora' ); ?></th><th><?php esc_html_e( 'Result', 'fileora' ); ?></th><th class="num"><?php esc_html_e( 'HTTP', 'fileora' ); ?></th><th class="num"><?php esc_html_e( 'Response time', 'fileora' ); ?></th><th><?php esc_html_e( 'Key', 'fileora' ); ?></th><th class="num"><?php esc_html_e( 'Tools', 'fileora' ); ?></th><th><?php esc_html_e( 'Problem', 'fileora' ); ?></th><th><?php esc_html_e( 'Run by', 'fileora' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $fo_recent as $fo_c ) : ?>
					<tr>
						<td class="nowrap"><?php echo esc_html( fo_admin_time( $fo_c->checked_at ) ); ?></td>
						<td><?php echo $fo_c->ok ? fo_admin_status( 'good', __( 'Up', 'fileora' ) ) : fo_admin_status( 'critical', __( 'Down', 'fileora' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
						<td class="num"><?php echo esc_html( $fo_c->http_code ? $fo_c->http_code : '–' ); ?></td>
						<td class="num"><?php echo esc_html( fo_admin_ms( $fo_c->latency_ms ) ); ?></td>
						<td><?php echo null === $fo_c->auth_ok ? '–' : ( $fo_c->auth_ok ? esc_html__( 'accepted', 'fileora' ) : esc_html__( 'rejected', 'fileora' ) ); ?></td>
						<td class="num"><?php echo null === $fo_c->tools_total ? '–' : esc_html( $fo_c->tools_ok . ' / ' . $fo_c->tools_total ); ?></td>
						<td><?php echo esc_html( (string) $fo_c->error ); ?></td>
						<td><?php echo 'manual' === $fo_c->source ? esc_html__( 'Check now', 'fileora' ) : esc_html__( 'Schedule', 'fileora' ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p class="fo-empty"><?php esc_html_e( 'No checks in the last 24 hours. Press “Check now”, and make sure WP-Cron runs (README, “Real cron”).', 'fileora' ); ?></p>
		<?php endif; ?>
	</section>
</div>
