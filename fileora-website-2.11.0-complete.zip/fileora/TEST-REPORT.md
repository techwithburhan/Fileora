# Fileora 2.0 test report

Environment: WordPress 7.1.3, PHP 8, MariaDB, Fileora Core 2.0.0, Fileora theme 2.0.0, processing service (`server/app.py`) on the same machine, Chromium (Playwright). Date: 16 October 2026.

## Tools, end to end through the WordPress tool pages

Each tool page was opened, real files were added, the tool was run, and the result was checked (page count, size, image dimensions; server PDFs re-opened with PyMuPDF).

| Result | Tools |
|---|---|
| **Pass (50 browser tools)** | Merge, Split, Organize, Rotate, Crop, Page numbers, Watermark, Sign (typed signature), PDF to JPG, JPG to PDF, Scan to PDF, PDF to Markdown, Compare, Aadhaar Card Print (password-protected test PDF), ID Card Print, Interleave, Split Pages in Half, Remove Blank Pages, N-up, Booklet, Bates, Header & Footer, Metadata, Flatten, Extract Images, Resize Pages, Reverse Pages, PDF to Text, Dark Mode PDF, Stamp, Compress Image, Resize, Convert, Crop Image, JPG to PNG, PNG to JPG, Compress to 20 KB, Exam Photo, Passport Photo, HEIC to JPG*, Remove EXIF, Watermark Image, Rotate Image, Blur, Combine Images, Favicon, SVG to PNG, Colour Palette, Base64, Border |
| **Pass (15 server tools, via WordPress → service)** | Word to PDF, Excel to PDF, PowerPoint to PDF, PDF to Word, PDF to Excel, PDF to PowerPoint, HTML to PDF, Compress PDF, Repair PDF, OCR PDF, PDF to PDF/A, Protect PDF, Unlock PDF, Redact PDF, PDF Forms |
| Not run | Edit PDF (pending, no backend), AI Summarizer and Translate PDF (switched off; need `ANTHROPIC_API_KEY`) |

\* No real HEIC file could be created in the test environment; the tool was run with a JPEG.

Checked behaviour on purpose:
* Remove Blank Pages on a file without blank pages shows "No blank pages found" instead of an empty result.
* Unlock PDF keeps the button disabled until the visitor confirms permission.
* Aadhaar Card Print asks for the e-Aadhaar password before showing the card.
* HTML to PDF refuses addresses on a private network (the server blocks them unless `FILEORA_ALLOW_PRIVATE_URLS=1`, used only for this test).

## Website (theme)

Pages: homepage, All tools, tool page, blog post, search, 404 — light and dark, 1440 px and 390 px. 20/20 interaction checks passed: search palette (`/` key, ranking: "pdf to word", "jpg to pdf", misspelt "aadhar"), Enter opens result, mega menu open/close, category tabs, filter, empty state, "In browser only", dark mode remembered, drop files on homepage → suggestions (Merge first for two PDFs) → files arrive in the tool, recently used tools, mobile drawer, no horizontal scrolling on phones. No JavaScript errors.

Theme without Fileora Core: homepage, post, search and pages work as a blog; the search box searches the site.
Fileora Core with Twenty Twenty-Five: tool page shows workspace and FAQ, Merge works.

## Admin, roles and data

* All Fileora admin pages load without PHP warnings: Dashboard, Visitor Analytics, Server Monitoring, Processing Tasks, Tool Management, Tool Categories, Settings.
* Server tasks are recorded (23 completed, 2 failed in the test run); browser runs are recorded as `tool_run` events and are not counted as server tasks.
* Visits from a normal browser are counted; headless/bot user agents are ignored.
* Health checks run on schedule and from "Check now"; `/health` reports the queue (0 waiting, 0 running).
* Blog Editor: can write posts and upload media; gets "not allowed" (403) on Fileora Settings, Tool Management, Fileora Dashboard (reports off), Plugins, Users, Themes and the Tools post list.

## Version 2.2 (17 October 2026)

Same environment, Fileora Core 2.2.0 and theme 2.2.0. Location tests used MaxMind's public GeoIP2 test database, and a test-only filter to simulate visitors from 9 IP addresses (UK, US, Sweden, China, Bhutan, Philippines). That filter is not part of the plugin.

| Area | Checked | Result |
|---|---|---|
| All tools again | Every tool switched on, through its page, after the tool libraries moved to the plugin | Pass, same results as above |
| Visitor tracking | Visits, unique visitors, first-time flag, landing page, referrer without query string, device, browser, OS, country / region / city, IP (full, shortened, none), file name and count per tool run, server tasks with the visit's location, pings | Pass |
| Visitor Analytics | Login opens the page; 6 time filters; country / region / city; real-time chart with spike note; daily / weekly / monthly comparison and table; activity filters (status, tool, location, dates, search) and pages; visit search and sorting; refresh every minute without reload; phone and tablet widths without horizontal page scroll | Pass |
| Permissions | Anonymous REST: 401; logged in without nonce: 403; Support sees analytics, tasks, monitoring; gets 403 on Settings, Tools, Users, Plugins, new post, Announcements; IP column hidden | Pass |
| Support account | Created from Settings with the initial password; first login forced to the profile page until the password was changed; afterwards lands on Visitor Analytics; the password is in no file, option or log | Pass |
| Announcements | Popup and bottom bar shown; Esc and focus handling; once per visit and once per day honoured; expired one not shown; preview visible to admins only; phone layout | Pass |
| Information pages | Six pages imported (Privacy Policy reuses WordPress's draft and is set as the privacy page); one H1 each, own title and description, canonical; FAQ structured data with 20 questions; shortcodes render; no broken internal links; footer "Information" column | Pass |
| Data flow | Merge PDF, Compress Image, PDF to JPG, HEIC to JPG: no request to any other website, only a ~200-byte analytics event while processing; Word to PDF: upload to WordPress only | Pass |
| Review reminder | Changing the IP setting shows the notice; changing it back clears it | Pass |
| Retention | IP addresses older than the setting are erased; the rest of the record stays | Pass |

Not verified here: the DB-IP download itself (the test environment can't reach download.db-ip.com) and real visitor locations in India; Cloudflare location headers.


## Version 2.3 (17 October 2026)

Fileora Core 2.3.0, theme 2.3.0, same environment. Accuracy was tested with marked test records at known times (local test database only, removed afterwards), comparing the reports with the expected numbers.

| Area | Checked | Result |
|---|---|---|
| Last 30 minutes | 10 visits one per minute, 3 browser runs (1 failed, 4 files) and 1 server task: visits 10, page views 10, tool runs 4, files 5, failed 1; 31 one-minute rows; the minute of the runs shows 3 runs, 4 files, 1 failed and its location | Pass |
| 7 / 90 days, custom range | 15 visits in 7 days, 26 in 90 days; a custom single day 40 days back shows exactly its 7 visits and location; the comparison chart follows the custom range; the 90-day series per day shows that day | Pass |
| Tables follow the period | Visits table and file processing table return the period's rows; their own dates still override | Pass |
| Intervals | Per minute refused for 7 days (falls back to per hour); 90 days per hour = 2,161 rows; per day from saved totals | Pass |
| History | Daily totals saved; after detailed records of an old day were deleted, the day still shows its totals; a later rollup does not overwrite it with zeros | Pass |
| Duplicates | The same event id sent 3 times (also after the short-term cache was cleared) is stored once; the live tracker sends a 16-character id with every event | Pass |
| Export | Visits, events, file processing, per-minute/hour/day, daily totals and tool usage download as CSV with the right row counts for a custom range; IP column only when allowed and asked; formula cells neutralised; exports listed in Settings | Pass |
| Permissions | Export needs `fileora_export_data` (administrators); Support has no export | Pass |
| Settings | Retention minimum 90 days, 0 = forever; existing values under 90 raised to 90 on update; storage card shows rows, size, oldest record, errors and exports | Pass |
| Layout | Desktop and 390 px phone width: no horizontal page scroll | Pass |


## Version 2.4 (19 October 2026)

New tool **PNG & JPG to SVG**, Fileora Core 2.4.0, theme 2.4.0 (version number only).

| Case | Result |
|---|---|
| Colour logo, transparent PNG 600 × 600 | SVG 600 × 600, 3 colours, 7 shapes, 2.2 KB; valid XML, renders; transparent areas stay transparent | 
| Signature photo, JPG 1200 × 500 on off-white paper, Black & white, automatic darkness | 1 black shape, background removed, 4.4 KB; dark-blue ink option gives the blue fill |
| Tiny icon, 64 × 64 PNG | enlarged before tracing; SVG keeps 64 × 64 with a 256 × 256 viewBox |
| Two files at once | two SVGs, ZIP offered |
| Photo, High detail | 1.6 MB SVG with 5,592 shapes; the result warns that it is heavy |
| Web Worker blocked | falls back to tracing on the page; same result |
| Data flow | no request to another website; the only request while processing is the analytics event (no file data); `tool_run` recorded with the file name |
| Page | title "PNG to SVG Converter Online Free – JPG to SVG Vector – Fileora", own meta description, WebApplication + FAQPage + BreadcrumbList structured data, one H1, 5 content H2s, 7 FAQs; 390 px phone width without horizontal scroll |


## Version 2.5 (19 October 2026)

Fileora Core 2.5.0 and theme 2.5.0.

| Area | Checked | Result |
|---|---|---|
| Accessibility | axe-core 4.10 (WCAG 2.0/2.1/2.2 A + AA and best practices) on home, All tools, three tool pages, Privacy Policy, Contact, Accessibility, FAQ, Blog, Sitemap, search and 404, in light and dark mode | 0 violations (heading order and a nested landmark were fixed) |
| Responsive | All 67 enabled tools at 320, 390, 768 and 1024 px, empty and (at 320/390) with a file added; nothing wider than the screen | Pass (the 2 AI tools are switched off by default and were skipped) |
| Information pages | Privacy Policy 1120 px wide on desktop; tables become one card per row on phones; no sideways scroll at 390 px | Pass |
| Contact form | Empty send shows three errors in words and focuses the first field; a valid message is saved under Fileora → Messages, the email attempt is recorded, the status is announced; honeypot, 3-second minimum and 5-per-hour limit | Pass (local test site can't send email, so "not sent" was shown as designed) |
| SEO | Custom title and description on a tool page; noindex gives `noindex, follow` and removes the page from the sitemap; canonical URL; verification code pasted as a whole tag is cleaned; Organization + WebSite + SearchAction on the homepage; invalid social URLs dropped; editor box: Google preview, length bars, 12-point checklist updating while typing; overview of 81 pages | Pass |
| Footer | "Website created by @techdeployers" linking to https://www.techdeployers.com, opens in a new tab with a screen-reader note | Pass |
| Regression | Merge PDF, Compress Image, PDF to JPG, HEIC to JPG, Word to PDF; PNG & JPG to SVG; analytics history checks | Pass |

## Version 2.6 (21 October 2026)

Tested on the local WordPress with Chromium, as before.

| Check | Result |
|---|---|
| All 60 days enabled in order (with “work ahead”) | 0 errors; 41 tool pages updated, 39 drafts created (24 guides, 15 pages), nothing skipped |
| Publishing | 29 drafts published at once; the 10 pages that need a size check waited until “I checked the sizes” was ticked, then published |
| SEO checklist on every plan page | All 80 plan items score 80% or more in Fileora → SEO (average across the site 87%) |
| Content checks before import | Every file: SEO title 25–60 characters, description 120–160, focus keyword in title, description, first paragraph and a subheading |
| Undo | Day 2: tool text, FAQ and SEO fields restored, header menu back to the previous one; day 5: unpublished guide moved to the trash. Re-applying both days restored the plan content |
| Day locking | Fresh site: day 1 open, days 2–60 “Later”; enabling day 1 starts the calendar |
| Exam preset (IBPS, 390 px) | Choices Photo · Signature · Thumb · Declaration · Custom; Thumb gave 240 × 240 px, 20 KB (allowed 20–50 KB) |
| KB preset (10 KB, 390 px) | Phone photo compressed to 9.8 KB |
| Hindi guide | `<html lang="hi">`, Devanagari title, no sideways scroll |
| “Guides for” on tool pages | Merge PDF and the exam resizer list 6 published guides each |
| Accessibility (axe) | Plan screen: 0 WCAG violations after fixes (tick buttons now have names, darker green for contrast); exam page, KB page, size list and Merge PDF: 0 at 1440 and 390 px; blog posts no longer nest landmark asides |
| Sitemap setting | Day 1 turns on “Sitemap and archives”; users and tags providers removed, tag/author/date/search pages noindex |

**Not verified here:** exam sizes against the official notifications (that is the manual check built into days 31–35), and rankings, which only Google can show over the coming weeks.

## Version 2.7 (21 October 2026)

Tested on the local WordPress with Chromium, after the 60-day plan had been applied and published.

| Check | Result |
|---|---|
| Content checks before import (all 53 posts) | SEO title 25–60 characters, description 120–160, focus keyword in title, description, first paragraph and a subheading; exactly 10 keywords, each found in the title, description or text; 10 title ideas of 65 characters or less, no more than 3 starting with “How to”; at least 4 FAQs, a tool button and 550+ words; no stock clichés: 0 issues |
| Internal links | Every link goes to a tool page, a category page, a starter post or a post scheduled on an earlier day: 0 problems |
| All 53 days enabled (work ahead) | 0 errors; 47 drafts created, 6 existing posts refreshed in place (same ID and address) |
| SEO checklist | All 53 posts score 90% or more, average 99%; each has 10 search keywords and 10 title ideas stored |
| Categories | PDF Tools 30, Image Tools 21, File Optimizer 2; refreshed posts keep their old category too |
| Undo (all 53 days, newest first) | The 3 refreshed posts sampled returned exactly to their old title, text, excerpt, categories and SEO fields; all 47 drafts moved to the trash; the 60-day plan untouched |
| Re-apply and publish | 47 drafts published from the cards; undo of a published day leaves the post online |
| SEO box | “10 of 10 used” coverage list, 10 title ideas with *Use as SEO title*, 13 of 13 checks on a sample post |
| Guides | 10 search keywords added to all 24 guides, each found in the guide's text; the 60-day plan still applies with 0 errors and every guide at 80%+ |
| Accessibility (axe) and layout | Blog plan screen and a blog post: 0 WCAG violations; post at 390 px: no sideways scroll |

**Not verified here:** search volume of the keywords (check in Keyword Planner and Search Console) and rankings.

## Version 2.8 (21 October 2026)

| Check | Result |
|---|---|
| All 53 days enabled | 53 cover images added to the Media Library, one per post; each is attached to its post, is the featured image, has alt text and has all WordPress sizes (thumbnail, medium, large, card) |
| Undo all, enable again | The refreshed Merge PDF post returned to its earlier featured image; re-enabling reused the same 53 images (no duplicates) |
| Site that enabled days before 2.8 | Featured images removed to simulate it: the automatic fill-in added all 53 covers over 7 admin page loads |
| Front end | Merge PDF post shows its 1200 px cover with alt text; `og:image` is the cover; all cards on the blog page show their image; no failed image requests |
| Upgrade notice | The plugin's upgrade routine now runs on `init`, so WordPress 6.7+ no longer reports translations loading too early after an update |
| Regression | 60-day plan: 0 errors, every plan page 80%+; blog plan: 0 errors, every post 90%+ |

## Version 2.9 (21 October 2026)

| Check | Result |
|---|---|
| Content checks (69 posts) | All pass: titles and descriptions in range, 10 keywords each found in the text, 10 title ideas, 4+ FAQs, 550+ words, no stock clichés |
| Facts | Each new post checked against the processing server code: formats, file limits, options, OCR and AI languages, what each output is (e.g. PDF to PowerPoint = picture slides, Translate = text) |
| Links | Only tools, categories and earlier posts; no post links to Edit PDF or to an AI tool except the AI posts themselves: 0 problems |
| Days 54–69 on a site that already ran days 1–53 | 0 errors; 16 drafts with covers; Publish published 14 and held 2 (AI tools switched off); after switching AI Summarizer on, its post published |
| SEO checklist | 14 posts 100%, PDF/A 92% (slug can't contain "/"), the rest 100% after slug fixes |
| Tool page corrections | PDF to PowerPoint and Excel to PDF pages rewritten when unchanged since the 60-day plan; a page with the owner's own edit was left as it was |
| Browser | Excel to PDF shows one setting with an explanation; new post with cover; blog plan screen and post: axe 0 |

## Version 2.10 (21 October 2026)

| Check | Result |
|---|---|
| HTML Code to PDF on the processing server | A4, US Letter landscape with no margins, fit content: correct page sizes; text selectable; `@media print` styles used by default, screen styles on request; JavaScript ignored unless turned on; empty code and wrong file types refused with clear messages |
| Network safety | A page with an image, iframe, stylesheet and `fetch()` pointing at 127.0.0.1 and localhost made **no** request to a local listener; `file:///etc/passwd` and the cloud metadata address were not loaded |
| Browser tool | Example inserted → preview → PDF named as typed (`invoice-1024.pdf`), 1 A4 page with the invoice text; preview frame sandboxed and cross-origin; with JavaScript off neither inline scripts nor `onerror` handlers ran; settings change the preview's paper; code kept after *Start over* and after a reload; 390 px: no sideways scroll; axe: 0 violations |
| Blog plan day 70 | Post created with cover and code block, SEO 100%; tool page text, FAQ (6) and SEO fields written, SEO 100%; undo restored the tool page's default text and left the published post online |
| HTML to PDF page correction | The unedited page now links to HTML Code to PDF for local files |
| Theme 2.7.0 | Code blocks in posts get a *Copy code* button (copies the code, announced to screen readers) and keyboard scrolling; axe 0 on the post |
| Content | 70 posts pass the content checks; 700 keywords all unique; links checked |

## Version 2.11 (22 October 2026)

| Check | Result |
|---|---|
| Install | Once on an admin page load: page `/ats-resume-builder/` published with role *resume*, SEO 100%; "ATS Resume" added to the header menu before "Contact us"; running again added nothing |
| Templates (example resume) | Classic, Modern, Compact: 1 page; Minimal: 2 pages. pdftotext reads the name first and the sections in order; 9 bullets; email, LinkedIn and GitHub are clickable links; PDF title "Name – Job title – Resume" |
| ATS check | 11 checks, 10–11 passing for the example (2 pages flagged for Minimal); readable-text box shows the extracted text; job ad comparison found 9 of 15 key words incl. "data analyst" and "power bi", listed "snowflake", "dbt", "a/b" as missing |
| Editing | Section moved up → order changed in the PDF; section hidden → not in the PDF; entries added (focus on the new job title) and removed; "I work here now" hides End and prints "Present" |
| Characters | "₹5 lakh" printed as "Rs.5 lakh"; Devanagari left out and named in the Characters check |
| Data | Kept after reload; a new tab without "Remember" starts empty; "Remember" keeps it across tabs; saved .json opened in another tab; "Clear all" needs two clicks |
| Accessibility and layout | axe: 0 violations on the builder (preview and ATS tabs) at 1440 px, at 390 px and in dark mode; no sideways scroll at 390 px; header fits at 1180–1920 px (search becomes an icon below 1680 px when there are 9+ links) |
| Not changed | A small sideways scroll on the homepage at 1040–1100 px comes from the hero illustration and existed before; it is not part of this change |
